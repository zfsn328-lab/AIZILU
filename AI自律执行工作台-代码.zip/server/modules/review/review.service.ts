import {
  BadRequestException,
  Inject,
  Injectable,
  Logger,
  OnModuleInit,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, gte, lt, desc, isNull, or, lte } from 'drizzle-orm';
import {
  reviewTable,
  dailyMetricTable,
  taskTable,
  eventTable,
  habitTable,
  habitLogTable,
  quickNoteTable,
} from '@server/database/schema';
import { isHabitDueOnDay } from '../plan/plan-helpers';
import type {
  ReviewMetrics,
  ReviewItem,
  DailyMetricItem,
  ReviewType,
} from '@shared/api.interface';

@Injectable()
export class ReviewService implements OnModuleInit {
  private readonly logger = new Logger(ReviewService.name);
  private timer: ReturnType<typeof setInterval> | null = null;

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  onModuleInit() {
    // 每天 21:30 后后台自动补生成当天日报（每 5 分钟检查一次）
    this.timer = setInterval(() => {
      void this.autoGenerateTodayIfDue();
    }, 5 * 60 * 1000);
    void this.autoGenerateTodayIfDue();
  }

  onModuleDestroy() {
    if (this.timer) clearInterval(this.timer);
  }

  private todayStr(): string {
    return new Date(Date.now() + 8 * 3600 * 1000)
      .toISOString()
      .slice(0, 10);
  }

  private nowHm(): string {
    const d = new Date(Date.now() + 8 * 3600 * 1000);
    return `${String(d.getHours()).padStart(2, '0')}:${String(
      d.getMinutes(),
    ).padStart(2, '0')}`;
  }

  private async autoGenerateTodayIfDue(): Promise<void> {
    try {
      if (this.nowHm() < '21:30') return;
      const today = this.todayStr();
      const existing = await this.db
        .select({ recordId: reviewTable.recordId })
        .from(reviewTable)
        .where(
          and(
            eq(reviewTable.reviewType, 'daily'),
            eq(reviewTable.periodStart, today),
          ),
        )
        .limit(1);
      if (existing.length === 0) {
        this.logger.log(`自动生成日报 ${today}`);
        await this.generateDaily(today);
      }
    } catch (e: unknown) {
      this.logger.error('自动生成日报失败', e);
    }
  }

  /**
   * 生成某天的日报：基于 task/event/habit/habit_log/quick_note 实时统计并落库（不存在新增、存在更新）。
   */
  async generateDaily(date: string): Promise<ReviewItem> {
    const startOfDay = new Date(`${date}T00:00:00+08:00`);
    const nextDate = this.shiftDate(date, 1);
    const startOfNextDay = new Date(`${nextDate}T00:00:00+08:00`);

    // 当天任务：总计划 / 已完成 / 未完成
    const tasks = await this.db
      .select()
      .from(taskTable)
      .where(
        and(eq(taskTable.dueDate, date), eq(taskTable.isDeleted, false)),
      );
    const plannedCount = tasks.length;
    const completedCount = tasks.filter(
      (t) => t.status === 'done' || t.status === 'completed',
    ).length;
    const delayedNames = tasks
      .filter((t) => t.status !== 'done' && t.status !== 'completed')
      .slice(0, 3)
      .map((t) => t.title || '未命名');
    const delayedCount = tasks.length - completedCount;

    // 当天应打卡习惯
    const activeHabits = await this.db
      .select()
      .from(habitTable)
      .where(
        and(
          eq(habitTable.status, 'active'),
          lte(habitTable.startDate, date),
          or(isNull(habitTable.endDate), gte(habitTable.endDate, date)),
          eq(habitTable.isDeleted, false),
        ),
      );
    // 当天日程时长
    const events = await this.db
      .select()
      .from(eventTable)
      .where(
        and(
          gte(eventTable.startDatetime, startOfDay),
          lt(eventTable.startDatetime, startOfNextDay),
          eq(eventTable.isDeleted, false),
        ),
      );
    // 预估专注 = 当天日程 + 当天未完成任务 + 当天应打卡习惯 的预估时长合计
    const eventMinutes = events.reduce(
      (sum: number, e) => sum + (e.durationMinutes ?? 0),
      0,
    );
    const taskMinutes = tasks
      .filter((t) => t.status !== 'done' && t.status !== 'completed')
      .reduce((sum: number, t) => sum + (t.estimateMinutes ?? 0), 0);
    const habitMinutes = activeHabits.reduce(
      (sum: number, h) => sum + (h.durationMinutes ?? 0),
      0,
    );
    const totalFocusMinutes = eventMinutes + taskMinutes + habitMinutes;
    const eventHours = Math.round((totalFocusMinutes / 60) * 10) / 10;

    const dueHabits = activeHabits.filter((h) =>
      isHabitDueOnDay(h, this.isoWeekday(date)),
    );
    const habitTotal = dueHabits.length;
    const habitLogs = await this.db
      .select({ habitId: habitLogTable.habitId })
      .from(habitLogTable)
      .where(
        and(
          eq(habitLogTable.logDate, date),
          eq(habitLogTable.status, 'done'),
        ),
      );
    const habitDoneIds = new Set(habitLogs.map((l) => l.habitId));
    const habitDone = dueHabits.filter((h) =>
      habitDoneIds.has(h.recordId),
    ).length;
    const habitRate =
      habitTotal === 0
        ? 0
        : Math.round((habitDone / habitTotal) * 100) / 100;
    const habitRatePct = Math.round(habitRate * 100);

    // 当天新增（任务+随手记+日程）
    const [newTasks, newNotes, newEvents] = await Promise.all([
      this.db
        .select({ recordId: taskTable.recordId })
        .from(taskTable)
        .where(
          and(
            gte(taskTable.createdAt, startOfDay),
            lt(taskTable.createdAt, startOfNextDay),
            eq(taskTable.isDeleted, false),
          ),
        ),
      this.db
        .select({ recordId: quickNoteTable.recordId })
        .from(quickNoteTable)
        .where(
          and(
            gte(quickNoteTable.createdAt, startOfDay),
            lt(quickNoteTable.createdAt, startOfNextDay),
            eq(quickNoteTable.isDeleted, false),
          ),
        ),
      this.db
        .select({ recordId: eventTable.recordId })
        .from(eventTable)
        .where(
          and(
            gte(eventTable.createdAt, startOfDay),
            lt(eventTable.createdAt, startOfNextDay),
            eq(eventTable.isDeleted, false),
          ),
        ),
    ]);
    const newAddedCount =
      newTasks.length + newNotes.length + newEvents.length;

    const completionRate =
      plannedCount === 0
        ? 0
        : Math.round((completedCount / plannedCount) * 100) / 100;
    const completionRatePct = Math.round(completionRate * 100);

    // 文本
    const completionDesc =
      plannedCount === 0
        ? '今天没有待办安排'
        : `今天共安排 ${plannedCount} 项，完成 ${completedCount} 项（${completionRatePct}%）${
            delayedCount > 0 ? `，还有 ${delayedCount} 项未完成` : '，全部完成'
          }`;
    const habitDesc =
      habitTotal === 0
        ? '今天没有需要打卡的习惯'
        : `习惯打卡 ${habitDone}/${habitTotal}（${habitRatePct}%）`;
    const eventDesc =
      eventHours > 0
        ? `当天安排约 ${eventHours} 小时`
        : '';
    const summaryText = [completionDesc, habitDesc, eventDesc]
      .filter(Boolean)
      .join('；');

    const highlights = JSON.stringify([
      completedCount > 0 ? `完成 ${completedCount} 项待办` : '开始记录今天的生活',
      habitDone > 0 ? `习惯打卡 ${habitDone} 次` : '今天还没有打卡',
      newAddedCount > 0 ? `新增 ${newAddedCount} 条记录` : '暂无新增记录',
    ]);
    const issues = JSON.stringify(
      delayedCount > 0
        ? [`有 ${delayedCount} 项待办尚未完成`]
        : [],
    );
    const adviceItems = JSON.stringify(
      delayedCount > 0
        ? [`把未完成的 ${delayedCount} 项安排到明天，保持节奏`]
        : ['今天很稳，继续保持'],
    );
    const topDelayedTasks =
      delayedNames.length > 0 ? JSON.stringify(delayedNames) : null;

    const recordId = `R_D_${date}`;
    const existing = await this.db
      .select({ recordId: reviewTable.recordId })
      .from(reviewTable)
      .where(eq(reviewTable.recordId, recordId))
      .limit(1);

    if (existing.length > 0) {
      await this.db
        .update(reviewTable)
        .set({
          plannedCount,
          completedCount,
          newAddedCount,
          completionRate: String(completionRate),
          delayedCount,
          estDeepWorkMinutes: totalFocusMinutes,
          eventHours: String(eventHours),
          habitTotal,
          habitDone,
          habitRate: String(habitRate),
          topDelayedTasks,
          highlights,
          issues,
          adviceItems,
          summaryText,
          generatedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(reviewTable.recordId, recordId));
    } else {
      await this.db.insert(reviewTable).values({
        recordId,
        reviewType: 'daily',
        periodStart: date,
        periodEnd: date,
        plannedCount,
        completedCount,
        newAddedCount,
        completionRate: String(completionRate),
        completionRateInclNew: String(completionRate),
        delayedCount,
        newDelayedCount: 0,
        cancelledCount: 0,
        estDeepWorkMinutes: totalFocusMinutes,
        actualTrackedMinutes: 0,
        eventHours: String(eventHours),
        habitTotal,
        habitDone,
        habitRate: String(habitRate),
        topDelayedTasks,
        goalProgress: null,
        highlights,
        issues,
        adviceItems,
        weekdayHeatmap: null,
        summaryText,
        generatedAt: new Date(),
        laterUpdateCount: 0,
        deliveryStatus: 'generated',
        userRead: false,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }

    const rows = await this.db
      .select()
      .from(reviewTable)
      .where(eq(reviewTable.recordId, recordId))
      .limit(1);
    this.logger.log(`生成日报 ${date} 完成`);
    return this.mapReviewItem(rows[0]);
  }

  async getMetrics(period: 'today' | 'week' | 'month'): Promise<ReviewMetrics> {
    const today = new Date().toISOString().slice(0, 10);
    let days = 1;
    if (period === 'week') days = 7;
    if (period === 'month') days = 30;

    const startDate = this.shiftDate(today, -(days - 1));

    const metrics = await this.db
      .select()
      .from(dailyMetricTable)
      .where(
        and(
          gte(dailyMetricTable.metricDate, startDate),
          lt(dailyMetricTable.metricDate, this.shiftDate(today, 1)),
        ),
      )
      .orderBy(dailyMetricTable.metricDate);

    if (metrics.length === 0) {
      return {
        period,
        completionRate: 0,
        completedCount: 0,
        delayedCount: 0,
        estDeepWorkMinutes: 0,
      };
    }

    const totalCompleted = metrics.reduce(
      (sum: number, m) => sum + m.completedCount,
      0,
    );
    const totalPlanned = metrics.reduce(
      (sum: number, m) => sum + m.plannedCount,
      0,
    );
    const totalDelayed = metrics.reduce(
      (sum: number, m) => sum + m.delayedCount,
      0,
    );
    const totalDeepWork = metrics.reduce(
      (sum: number, m) => sum + m.estDeepWorkMinutes,
      0,
    );
    const completionRate = totalPlanned === 0 ? 0 : totalCompleted / totalPlanned;

    return {
      period,
      completionRate: Math.round(completionRate * 100) / 100,
      completedCount: totalCompleted,
      delayedCount: totalDelayed,
      estDeepWorkMinutes: totalDeepWork,
    };
  }

  async getDaily(date: string): Promise<ReviewItem | null> {
    // 惰性生成：今天且已过 21:30 仍未生成日报时，现场生成
    if (date === this.todayStr() && this.nowHm() >= '21:30') {
      const exists = await this.db
        .select({ recordId: reviewTable.recordId })
        .from(reviewTable)
        .where(
          and(
            eq(reviewTable.reviewType, 'daily'),
            eq(reviewTable.periodStart, date),
          ),
        )
        .limit(1);
      if (exists.length === 0) {
        return this.generateDaily(date);
      }
    }
    const items = await this.db
      .select()
      .from(reviewTable)
      .where(
        and(
          eq(reviewTable.reviewType, 'daily'),
          eq(reviewTable.periodStart, date),
          eq(reviewTable.periodEnd, date),
        ),
      )
      .limit(1);

    if (items.length === 0) return null;
    return this.mapReviewItem(items[0]);
  }

  async getWeekly(weekStart: string): Promise<ReviewItem | null> {
    const items = await this.db
      .select()
      .from(reviewTable)
      .where(
        and(
          eq(reviewTable.reviewType, 'weekly'),
          eq(reviewTable.periodStart, weekStart),
        ),
      )
      .limit(1);

    if (items.length === 0) return null;
    return this.mapReviewItem(items[0]);
  }

  async getDailyMetrics(start: string, end: string): Promise<DailyMetricItem[]> {
    if (!start || !end) {
      throw new BadRequestException('start and end are required');
    }

    const metrics = await this.db
      .select()
      .from(dailyMetricTable)
      .where(
        and(
          gte(dailyMetricTable.metricDate, start),
          lt(dailyMetricTable.metricDate, this.shiftDate(end, 1)),
        ),
      )
      .orderBy(dailyMetricTable.metricDate);

    return metrics.map((m) => this.mapDailyMetricItem(m));
  }

  private shiftDate(dateStr: string, days: number): string {
    const d = new Date(`${dateStr}T00:00:00+08:00`);
    d.setDate(d.getDate() + days);
    return d.toISOString().slice(0, 10);
  }

  private isoWeekday(dateStr: string): number {
    const d = new Date(`${dateStr}T00:00:00Z`);
    const jsDay = d.getUTCDay();
    return jsDay === 0 ? 7 : jsDay;
  }

  private mapReviewItem(row: typeof reviewTable.$inferSelect): ReviewItem {
    return {
      recordId: row.recordId,
      reviewType: row.reviewType as ReviewType,
      periodStart: String(row.periodStart),
      periodEnd: String(row.periodEnd),
      plannedCount: row.plannedCount,
      completedCount: row.completedCount,
      newAddedCount: row.newAddedCount,
      completionRate: Number(row.completionRate),
      completionRateInclNew: Number(row.completionRateInclNew),
      delayedCount: row.delayedCount,
      newDelayedCount: row.newDelayedCount,
      cancelledCount: row.cancelledCount,
      estDeepWorkMinutes: row.estDeepWorkMinutes,
      actualTrackedMinutes: row.actualTrackedMinutes,
      eventHours: Number(row.eventHours),
      habitTotal: row.habitTotal,
      habitDone: row.habitDone,
      habitRate: Number(row.habitRate),
      topDelayedTasks: row.topDelayedTasks,
      goalProgress: row.goalProgress,
      highlights: row.highlights,
      issues: row.issues,
      adviceItems: row.adviceItems,
      weekdayHeatmap: row.weekdayHeatmap,
      summaryText: row.summaryText,
      generatedAt: row.generatedAt.toISOString(),
      laterUpdateCount: row.laterUpdateCount,
      deliveryStatus: row.deliveryStatus,
      userRead: row.userRead,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    };
  }

  private mapDailyMetricItem(
    row: typeof dailyMetricTable.$inferSelect,
  ): DailyMetricItem {
    return {
      recordId: row.recordId,
      metricDate: String(row.metricDate),
      plannedCount: row.plannedCount,
      completedCount: row.completedCount,
      newAddedCount: row.newAddedCount,
      delayedCount: row.delayedCount,
      completionRate: Number(row.completionRate),
      estDeepWorkMinutes: row.estDeepWorkMinutes,
      eventCount: row.eventCount,
      habitTotal: row.habitTotal,
      habitDone: row.habitDone,
      inboxPending: row.inboxPending,
      snapshotAt: row.snapshotAt ? row.snapshotAt.toISOString() : null,
      isFinal: row.isFinal,
    };
  }
}
