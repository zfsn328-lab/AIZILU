import { Controller, Get, Post, Query, BadRequestException } from '@nestjs/common';
import { ReviewService } from './review.service';
import type {
  ReviewMetrics,
  ReviewItem,
  DailyMetricItem,
} from '@shared/api.interface';

@Controller('api/review')
export class ReviewController {
  constructor(private readonly reviewService: ReviewService) {}

  @Get('metrics')
  async getMetrics(
    @Query('period') period: 'today' | 'week' | 'month',
  ): Promise<ReviewMetrics> {
    if (!['today', 'week', 'month'].includes(period)) {
      throw new BadRequestException('period must be today, week or month');
    }
    return this.reviewService.getMetrics(period);
  }

  @Post('daily/generate')
  async generateDaily(
    @Query('date') date: string,
  ): Promise<ReviewItem> {
    if (!date) throw new BadRequestException('date is required');
    return this.reviewService.generateDaily(date);
  }

  @Get('daily')
  async getDaily(@Query('date') date: string): Promise<ReviewItem | null> {
    return this.reviewService.getDaily(date);
  }

  @Get('weekly')
  async getWeekly(@Query('weekStart') weekStart: string): Promise<ReviewItem | null> {
    return this.reviewService.getWeekly(weekStart);
  }

  @Get('daily-metrics')
  async getDailyMetrics(
    @Query('start') start: string,
    @Query('end') end: string,
  ): Promise<DailyMetricItem[]> {
    return this.reviewService.getDailyMetrics(start, end);
  }
}
