import { Inject, Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, or, lte, isNotNull, desc, ne, lt } from 'drizzle-orm';

import {
  quickNoteTable,
  taskTable,
  eventTable,
  reminderNotificationTable,
} from '@server/database/schema';

export interface ReminderItem {
  id: string;
  itemType: string;
  itemId: string;
  content: string;
  remindAt: string;
  notifiedAt: string;
  isRead: boolean;
}

const SCAN_INTERVAL_MS = 60_000;

/**
 * 服务端到点自动提醒：
 * 每分钟扫描已到期的提醒条目（随手记/待办/日程），写入通知表，
 * 前端轮询后弹出提醒横幅 —— 无需依赖外部定时服务，应用常驻即可靠。
 */
@Injectable()
export class ReminderService implements OnModuleInit {
  private readonly logger = new Logger(ReminderService.name);
  private timer: NodeJS.Timeout | null = null;

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  onModuleInit() {
    this.scan().catch((e) => this.logger.error('启动扫描失败', e));
    this.timer = setInterval(() => {
      this.scan().catch((e) => this.logger.error('定时扫描失败', e));
    }, SCAN_INTERVAL_MS);
    if (typeof this.timer.unref === 'function') this.timer.unref();
    this.logger.log(`提醒扫描已启动，每 ${SCAN_INTERVAL_MS / 1000}s 一次`);
  }

  /** 扫描所有已到期待提醒条目，写入通知表（幂等去重） */
  async scan(): Promise<number> {
    const now = new Date();
    const candidates: { type: string; id: string; content: string; remindAt: Date }[] = [];

    // 1) 随手记（note 类型带 remindAt）
    const notes = await this.db
      .select({
        recordId: quickNoteTable.recordId,
        content: quickNoteTable.content,
        remindAt: quickNoteTable.remindAt,
      })
      .from(quickNoteTable)
      .where(
        and(
          lte(quickNoteTable.remindAt, now),
          isNotNull(quickNoteTable.remindAt),
          eq(quickNoteTable.isDone, false),
          eq(quickNoteTable.isDeleted, false),
        ),
      )
      .limit(100);
    for (const n of notes) {
      if (!n.remindAt) continue;
      candidates.push({ type: 'note', id: n.recordId, content: n.content, remindAt: new Date(n.remindAt) });
    }

    // 2) 待办（task 表，dueDate + dueTime 组合为提醒时刻，服务端时区 +08）
    const tasks = await this.db
      .select({
        recordId: taskTable.recordId,
        title: taskTable.title,
        dueDate: taskTable.dueDate,
        dueTime: taskTable.dueTime,
        status: taskTable.status,
      })
      .from(taskTable)
      .where(
        and(
          isNotNull(taskTable.dueDate),
          ne(taskTable.status, 'done'),
          eq(taskTable.isDeleted, false),
        ),
      )
      .limit(200);
    for (const t of tasks) {
      if (!t.dueDate) continue;
      const timePart = t.dueTime || '09:00';
      // VM 时区为 +08，本地拼接即墙钟时间
      const remindAt = new Date(`${t.dueDate}T${timePart}:00`);
      if (remindAt <= now) {
        candidates.push({ type: 'task', id: t.recordId, content: t.title, remindAt });
      }
    }

    // 3) 日程（event 表，startDatetime 即提醒时刻）
    const events = await this.db
      .select({
        recordId: eventTable.recordId,
        title: eventTable.title,
        startDatetime: eventTable.startDatetime,
        status: eventTable.status,
      })
      .from(eventTable)
      .where(
        and(
          lte(eventTable.startDatetime, now),
          ne(eventTable.status, 'done'),
          ne(eventTable.status, 'completed'),
          eq(eventTable.isDeleted, false),
        ),
      )
      .limit(100);
    for (const e of events) {
      if (!e.startDatetime) continue;
      candidates.push({ type: 'event', id: e.recordId, content: e.title, remindAt: new Date(e.startDatetime) });
    }

    if (candidates.length === 0) return 0;

    let inserted = 0;
    for (const c of candidates) {
      const id = `RMD_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      try {
        const result = await this.db
          .insert(reminderNotificationTable)
          .values({
            id,
            itemType: c.type,
            itemId: c.id,
            content: c.content,
            remindAt: c.remindAt,
          })
          .onConflictDoNothing()
          .returning({ id: reminderNotificationTable.id });
        inserted += result.length;
      } catch (e) {
        this.logger.warn(`写入提醒失败: ${c.id}`, e);
      }
    }
    if (inserted > 0) {
      this.logger.log(`到点提醒已生成 ${inserted} 条`);
    }
    return inserted;
  }

  /** 未读提醒（前端轮询用） */
  async getPending(limit = 50): Promise<ReminderItem[]> {
    await this.scan();
    const rows = await this.db
      .select()
      .from(reminderNotificationTable)
      .where(eq(reminderNotificationTable.isRead, false))
      .orderBy(desc(reminderNotificationTable.remindAt))
      .limit(limit);
    return rows.map((r) => ({
      id: r.id,
      itemType: r.itemType,
      itemId: r.itemId,
      content: r.content,
      remindAt: r.remindAt.toISOString(),
      notifiedAt: r.notifiedAt.toISOString(),
      isRead: r.isRead,
    }));
  }

  /** 已读 */
  async markRead(id: string): Promise<boolean> {
    const result = await this.db
      .update(reminderNotificationTable)
      .set({ isRead: true })
      .where(eq(reminderNotificationTable.id, id))
      .returning({ id: reminderNotificationTable.id });
    return result.length > 0;
  }

  /** 历史提醒 */
  async getHistory(limit = 50): Promise<ReminderItem[]> {
    const rows = await this.db
      .select()
      .from(reminderNotificationTable)
      .orderBy(desc(reminderNotificationTable.notifiedAt))
      .limit(limit);
    return rows.map((r) => ({
      id: r.id,
      itemType: r.itemType,
      itemId: r.itemId,
      content: r.content,
      remindAt: r.remindAt.toISOString(),
      notifiedAt: r.notifiedAt.toISOString(),
      isRead: r.isRead,
    }));
  }
}
