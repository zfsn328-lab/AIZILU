import { Inject, Injectable, Logger } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, gte, lt, isNull, or, lte, count, desc } from 'drizzle-orm';
import {
  taskTable,
  eventTable,
  habitTable,
  habitLogTable,
  inboxTable,
  goalTable,
  quickNoteTable,
} from '@server/database/schema';
import type {
  TodayOverview,
  TodayTimelineItem,
  TodayAiSuggestion,
  TaskPriority,
  EventType,
} from '@shared/api.interface';

@Injectable()
export class TodayService {
  private readonly logger = new Logger(TodayService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  /**
   * 切换任务完成状态（todo/doing → done，done → todo）
   */
  async toggleTask(taskId: string): Promise<{ status: string }> {
    const rows = await this.db
      .select({ status: taskTable.status })
      .from(taskTable)
      .where(and(eq(taskTable.recordId, taskId), eq(taskTable.isDeleted, false)));
    if (rows.length === 0) {
      throw new Error(`任务不存在: ${taskId}`);
    }
    const next = rows[0].status === 'done' ? 'todo' : 'done';
    const now = new Date();
    await this.db
      .update(taskTable)
      .set({
        status: next,
        completedAt: next === 'done' ? now : null,
        updatedAt: now,
      })
      .where(eq(taskTable.recordId, taskId));
    this.logger.log(`任务 ${taskId} → ${next}`);
    return { status: next };
  }

  async getOverview(date: string): Promise<TodayOverview> {
    const nextDate = this.getNextDate(date);
    const startOfDay = new Date(`${date}T00:00:00+08:00`);
    const startOfNextDay = new Date(`${nextDate}T00:00:00+08:00`);
    const weekday = this.getIsoWeekday(date);

    // Tasks due today
    const tasks = await this.db
      .select()
      .from(taskTable)
      .where(and(eq(taskTable.dueDate, date), eq(taskTable.isDeleted, false)));

    const totalTaskCount = tasks.length;
    const completedCount = tasks.filter(
      (t) => t.status === 'done',
    ).length;
    const pendingTaskCount = tasks.filter(
      (t) => t.status === 'todo' || t.status === 'doing',
    ).length;
    const completionRate = totalTaskCount === 0 ? 0 : completedCount / totalTaskCount;

    // Events today
    const events = await this.db
      .select()
      .from(eventTable)
      .where(
        and(
          gte(eventTable.startDatetime, startOfDay),
          lt(eventTable.startDatetime, startOfNextDay),
          eq(eventTable.isDeleted, false),
        ),
      );
    const eventCount = events.length;

    // Habits due today
    const activeHabits = await this.db
      .select()
      .from(habitTable)
      .where(
        and(
          eq(habitTable.status, 'active'),
          lte(habitTable.startDate, date),
          or(isNull(habitTable.endDate), gte(habitTable.endDate, date)),
          eq(habitTable.isDeleted, false),
        ),
      );

    const dueHabits = activeHabits.filter((h) =>
      this.isHabitDueOnDay(h, weekday, date),
    );
    const habitCount = dueHabits.length;

    // Habit done count today
    const dueHabitIds = dueHabits.map((h) => h.recordId);
    let habitDoneCount = 0;
    if (dueHabitIds.length > 0) {
      const doneLogs = await this.db
        .select({ count: count() })
        .from(habitLogTable)
        .where(
          and(
            eq(habitLogTable.logDate, date),
            eq(habitLogTable.status, 'done'),
          ),
        );
      habitDoneCount = Number(doneLogs[0]?.count ?? 0);
    }

    // Inbox pending count
    const pendingResult = await this.db
      .select({ count: count() })
      .from(inboxTable)
      .where(and(eq(inboxTable.status, 'pending'), eq(inboxTable.isDeleted, false)));
    const pendingInboxCount = Number(pendingResult[0]?.count ?? 0);

    // Active goals count
    const goalResult = await this.db
      .select({ count: count() })
      .from(goalTable)
      .where(and(eq(goalTable.status, 'active'), eq(goalTable.isDeleted, false)));
    const activeGoalsCount = Number(goalResult[0]?.count ?? 0);

    // Build full items list (tasks / events / habits / notes), each with title/type/time/status
    const habitLogs = await this.db
      .select()
      .from(habitLogTable)
      .where(eq(habitLogTable.logDate, date));
    const habitDoneMap = new Map<string, string>();
    for (const log of habitLogs) {
      habitDoneMap.set(log.habitId, log.status);
    }

    const notes = await this.db
      .select()
      .from(quickNoteTable)
      .where(
        and(
          eq(quickNoteTable.isDeleted, false),
          gte(quickNoteTable.remindAt, startOfDay),
          lt(quickNoteTable.remindAt, startOfNextDay),
        ),
      );

    const items: TodayTimelineItem[] = [];

    for (const task of tasks) {
      const sortTime = task.dueTime ?? '23:59:59';
      items.push({
        id: task.recordId,
        type: 'task',
        timeLabel: task.dueTime ?? '全天',
        sortTime,
        title: task.title,
        status: task.status,
        priority: task.priority as TaskPriority,
      });
    }

    for (const evt of events) {
      const timeStr = this.formatTime(evt.startDatetime);
      items.push({
        id: evt.recordId,
        type: 'event',
        timeLabel: timeStr,
        sortTime: timeStr,
        title: evt.title,
        status: evt.status,
        eventType: evt.eventType as EventType,
        subtitle: evt.location ?? undefined,
      });
    }

    for (const habit of dueHabits) {
      const sortTime = habit.suggestedTime ?? '09:00:00';
      const status = habitDoneMap.get(habit.recordId) ?? 'pending';
      items.push({
        id: habit.recordId,
        type: 'habit',
        timeLabel: habit.suggestedTime ?? '上午',
        sortTime,
        title: habit.name,
        status,
      });
    }

    for (const note of notes) {
      if (!note.remindAt) continue;
      const timeStr = this.formatTime(note.remindAt);
      items.push({
        id: note.recordId,
        type: 'note',
        timeLabel: timeStr,
        sortTime: timeStr,
        title: note.content,
        status: note.isDone ? 'done' : 'pending',
      });
    }

    items.sort((a, b) => a.sortTime.localeCompare(b.sortTime));

    return {
      date,
      greeting: this.getGreeting(),
      completionRate: Math.round(completionRate * 100) / 100,
      completedCount,
      totalCount: totalTaskCount,
      pendingTaskCount,
      eventCount,
      habitCount,
      habitDoneCount,
      pendingInboxCount,
      activeGoalsCount,
      items,
    };
  }

  async getTimeline(date: string): Promise<TodayTimelineItem[]> {
    const nextDate = this.getNextDate(date);
    const startOfDay = new Date(`${date}T00:00:00+08:00`);
    const startOfNextDay = new Date(`${nextDate}T00:00:00+08:00`);
    const weekday = this.getIsoWeekday(date);

    // Tasks due today
    const tasks = await this.db
      .select()
      .from(taskTable)
      .where(and(eq(taskTable.dueDate, date), eq(taskTable.isDeleted, false)));

    // Events today
    const events = await this.db
      .select()
      .from(eventTable)
      .where(
        and(
          gte(eventTable.startDatetime, startOfDay),
          lt(eventTable.startDatetime, startOfNextDay),
          eq(eventTable.isDeleted, false),
        ),
      );

    // Habits due today
    const activeHabits = await this.db
      .select()
      .from(habitTable)
      .where(
        and(
          eq(habitTable.status, 'active'),
          lte(habitTable.startDate, date),
          or(isNull(habitTable.endDate), gte(habitTable.endDate, date)),
          eq(habitTable.isDeleted, false),
        ),
      );
    const dueHabits = activeHabits.filter((h) =>
      this.isHabitDueOnDay(h, weekday, date),
    );

    // Check habit done status
    const habitLogs = await this.db
      .select()
      .from(habitLogTable)
      .where(eq(habitLogTable.logDate, date));
    const habitDoneMap = new Map<string, string>();
    for (const log of habitLogs) {
      habitDoneMap.set(log.habitId, log.status);
    }

    // Notes with remindAt falling inside today (Beijing time range)
    const notes = await this.db
      .select()
      .from(quickNoteTable)
      .where(
        and(
          eq(quickNoteTable.isDeleted, false),
          gte(quickNoteTable.remindAt, startOfDay),
          lt(quickNoteTable.remindAt, startOfNextDay),
        ),
      );

    const items: TodayTimelineItem[] = [];

    for (const task of tasks) {
      const sortTime = task.dueTime ?? '23:59:59';
      items.push({
        id: task.recordId,
        type: 'task',
        timeLabel: task.dueTime ?? '全天',
        sortTime,
        title: task.title,
        status: task.status,
        priority: task.priority as TaskPriority,
      });
    }

    for (const evt of events) {
      const timeStr = this.formatTime(evt.startDatetime);
      items.push({
        id: evt.recordId,
        type: 'event',
        timeLabel: timeStr,
        sortTime: timeStr,
        title: evt.title,
        status: evt.status,
        eventType: evt.eventType as EventType,
        subtitle: evt.location ?? undefined,
      });
    }

    for (const habit of dueHabits) {
      const sortTime = habit.suggestedTime ?? '09:00:00';
      const status = habitDoneMap.get(habit.recordId) ?? 'pending';
      items.push({
        id: habit.recordId,
        type: 'habit',
        timeLabel: habit.suggestedTime ?? '上午',
        sortTime,
        title: habit.name,
        status,
      });
    }

    for (const note of notes) {
      if (!note.remindAt) continue;
      const timeStr = this.formatTime(note.remindAt);
      items.push({
        id: note.recordId,
        type: 'note',
        timeLabel: timeStr,
        sortTime: timeStr,
        title: note.content,
        status: note.isDone ? 'done' : 'pending',
      });
    }

    items.sort((a, b) => a.sortTime.localeCompare(b.sortTime));
    return items;
  }

  async getAiSuggestion(date: string): Promise<TodayAiSuggestion | null> {
    const pendingItems = await this.db
      .select()
      .from(inboxTable)
      .where(
        and(
          eq(inboxTable.status, 'pending'),
          isNull(inboxTable.batchId),
          eq(inboxTable.isDeleted, false),
        ),
      )
      .orderBy(desc(inboxTable.createdAt))
      .limit(5);

    const highConfidence = pendingItems.find(
      (item) => item.confidence !== null && Number(item.confidence) > 0.8,
    );

    if (!highConfidence) return null;

    let action = '确认创建';
    if (highConfidence.suggestedType === 'task') action = '添加为任务';
    else if (highConfidence.suggestedType === 'event') action = '添加为日程';
    else if (highConfidence.suggestedType === 'habit') action = '添加为习惯';
    else if (highConfidence.suggestedType === 'goal') action = '添加为目标';

    return {
      id: highConfidence.recordId,
      content: highConfidence.rawInput,
      dataSource: `inbox:${highConfidence.recordId}`,
      action,
    };
  }

  private getGreeting(): string {
    const hour = new Date().getHours();
    if (hour < 12) return '早上好';
    if (hour < 18) return '下午好';
    return '晚上好';
  }

  private getNextDate(dateStr: string): string {
    // Pure UTC date arithmetic: parse as UTC midnight, no TZ shift
    const d = new Date(`${dateStr}T00:00:00Z`);
    d.setUTCDate(d.getUTCDate() + 1);
    return d.toISOString().slice(0, 10);
  }

  private getIsoWeekday(dateStr: string): number {
    // Parse as UTC midnight of the calendar date, independent of server TZ
    const d = new Date(`${dateStr}T00:00:00Z`);
    // JS: 0=Sunday, 6=Saturday; ISO: 1=Monday, 7=Sunday
    const jsDay = d.getUTCDay();
    return jsDay === 0 ? 7 : jsDay;
  }

  private isHabitDueOnDay(
    habit: { frequencyType: string; targetWeekdays: string },
    weekday: number,
    _date: string,
  ): boolean {
    const freq = habit.frequencyType;
    if (freq === 'daily') return true;
    if (freq === 'weekly') {
      try {
        const weekdays: string[] = JSON.parse(habit.targetWeekdays || '[]');
        return weekdays.includes(String(weekday));
      } catch {
        return false;
      }
    }
    return true;
  }

  private formatTime(date: Date): string {
    const h = String(date.getHours()).padStart(2, '0');
    const m = String(date.getMinutes()).padStart(2, '0');
    return `${h}:${m}`;
  }
}
