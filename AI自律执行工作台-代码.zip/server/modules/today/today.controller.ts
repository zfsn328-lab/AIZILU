import { Controller, Get, Param, Post, Query } from '@nestjs/common';
import { TodayService } from './today.service';
import type {
  TodayOverview,
  TodayTimelineItem,
  TodayAiSuggestion,
} from '@shared/api.interface';

function formatDate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

@Controller('api/today')
export class TodayController {
  constructor(private readonly todayService: TodayService) {}

  @Get('overview')
  async getOverview(@Query('date') date: string): Promise<TodayOverview> {
    const d = date || formatDate(new Date());
    return this.todayService.getOverview(d);
  }

  @Get('timeline')
  async getTimeline(
    @Query('date') date: string,
  ): Promise<TodayTimelineItem[]> {
    const d = date || formatDate(new Date());
    return this.todayService.getTimeline(d);
  }

  @Post('tasks/:id/toggle')
  async toggleTask(@Param('id') id: string): Promise<{ status: string }> {
    return this.todayService.toggleTask(id);
  }

  @Get('ai-suggestion')
  async getAiSuggestion(
    @Query('date') date: string,
  ): Promise<TodayAiSuggestion | null> {
    const d = date || formatDate(new Date());
    return this.todayService.getAiSuggestion(d);
  }
}
