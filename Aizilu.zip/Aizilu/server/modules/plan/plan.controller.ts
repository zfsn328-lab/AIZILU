import { Body, Controller, Delete, Get, Param, Post, Query } from '@nestjs/common';
import { PlanService } from './plan.service';
import type {
  WeekViewData,
  UnscheduledTask,
  HabitItem,
  GoalItem,
  MonthViewData,
  DayTimelineItem,
  HabitProgressItem,
} from '@shared/api.interface';

@Controller('api/plan')
export class PlanController {
  constructor(private readonly planService: PlanService) {}

  @Delete('tasks/:id')
  async deleteTask(@Param('id') id: string): Promise<{ success: boolean }> {
    await this.planService.softDeleteTask(id);
    return { success: true };
  }

  @Delete('events/:id')
  async deleteEvent(@Param('id') id: string): Promise<{ success: boolean }> {
    await this.planService.softDeleteEvent(id);
    return { success: true };
  }

  @Delete('habits/:id')
  async deleteHabit(@Param('id') id: string): Promise<{ success: boolean }> {
    await this.planService.softDeleteHabit(id);
    return { success: true };
  }

  @Delete('goals/:id')
  async deleteGoal(@Param('id') id: string): Promise<{ success: boolean }> {
    await this.planService.softDeleteGoal(id);
    return { success: true };
  }

  @Get('day')
  async getDay(@Query('date') date: string): Promise<{ items: DayTimelineItem[] }> {
    const items = await this.planService.getDay(date);
    return { items };
  }

  @Get('habit-progress')
  async getHabitProgress(@Query('month') month: string): Promise<HabitProgressItem[]> {
    return this.planService.getHabitProgress(month);
  }

  @Post('habits/:id/toggle')
  async toggleHabit(
    @Param('id') id: string,
    @Body() body: { date: string },
  ): Promise<{ status: string }> {
    const date = body.date ?? new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 10);
    return this.planService.toggleHabit(id, date);
  }

  @Post('events/:id/toggle')
  async toggleEvent(@Param('id') id: string): Promise<{ status: string }> {
    return this.planService.toggleEvent(id);
  }

  @Get('month')
  async getMonth(@Query('month') month: string): Promise<MonthViewData> {
    return this.planService.getMonth(month);
  }

  @Get('week')
  async getWeek(@Query('date') date: string): Promise<WeekViewData> {
    return this.planService.getWeek(date);
  }

  @Get('unscheduled')
  async getUnscheduled(): Promise<UnscheduledTask[]> {
    return this.planService.getUnscheduled();
  }

  @Get('habits')
  async getHabits(): Promise<HabitItem[]> {
    return this.planService.getHabits();
  }

  @Get('goals')
  async getGoals(): Promise<GoalItem[]> {
    return this.planService.getGoals();
  }

  @Post('goals/:id/checkin')
  async checkinGoal(
    @Param('id') id: string,
    @Query('date') date: string,
  ): Promise<GoalItem> {
    return this.planService.checkinGoal(id, date);
  }
}
