import { Inject, Injectable, Logger, BadRequestException } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, gte, lt, lte, isNull, or, asc, inArray } from 'drizzle-orm';
import {
  taskTable,
  eventTable,
  habitTable,
  habitLogTable,
  goalTable,
  goalLogTable,
  quickNoteTable,
} from '@server/database/schema';
import type {
  WeekViewData,
  WeekDayData,
  WeekSlotItem,
  UnscheduledTask,
  HabitItem,
  GoalItem,
  MonthViewData,
  MonthDayData,
  DayTimelineItem,
  HabitProgressItem,
  TaskPriority,
  EventType,
} from '@shared/api.interface';
import {
  isHabitDueOnDay,
  getTimeSlot,
  defaultTimeForSlot,
  formatTime,
  mapHabitItem,
  mapGoalItem,
  isOneShotGoal,
  dateStr,
} from './plan-helpers';

@Injectable()
export class PlanService {
  private readonly logger = new Logger(PlanService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  private getIsoWeekday(dateStr: string): number {
    const d = new Date(`${dateStr}T00:00:00Z`);
    const jsDay = d.getUTCDay();
    return jsDay === 0 ? 7 : jsDay;
  }

  async getWeek(date: string): Promise<WeekViewData> {
    const { weekStart, weekEnd } = this.getWeekRange(date);
    const today = new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 10);
    const weekEndNext = this.shiftDate(weekEnd, 1);

    // Tasks with due_date in the week
    const tasks = await this.db
      .select()
      .from(taskTable)
      .where(
        and(
          gte(taskTable.dueDate, weekStart),
          lt(taskTable.dueDate, weekEndNext),
          eq(taskTable.isDeleted, false),
        ),
      );

    // Events in the week
    const weekStartDate = new Date(`${weekStart}T00:00:00+08:00`);
    const weekEndDate = new Date(`${weekEndNext}T00:00:00+08:00`);
    const events = await this.db
      .select()
      .from(eventTable)
      .where(
        and(
          gte(eventTable.startDatetime, weekStartDate),
          lt(eventTable.startDatetime, weekEndDate),
          eq(eventTable.isDeleted, false),
        ),
      );

    // Active habits overlapping the week
    const activeHabits = await this.db
      .select()
      .from(habitTable)
      .where(
        and(
          eq(habitTable.status, 'active'),
          lt(habitTable.startDate, weekEndNext),
          or(isNull(habitTable.endDate), gte(habitTable.endDate, weekStart)),
          eq(habitTable.isDeleted, false),
        ),
      );

    // Quick notes with remind_at in the week
    const noteWeekStart = new Date(`${weekStart}T00:00:00+08:00`);
    const noteWeekEnd = new Date(`${weekEnd}T00:00:00+08:00`);
    noteWeekEnd.setDate(noteWeekEnd.getDate() + 1);
    const weekNotes = await this.db
      .select()
      .from(quickNoteTable)
      .where(
        and(
          eq(quickNoteTable.isDeleted, false),
          gte(quickNoteTable.remindAt, noteWeekStart),
          lt(quickNoteTable.remindAt, noteWeekEnd),
        ),
      );

    // Build days
    const days: WeekDayData[] = [];
    for (let i = 0; i < 7; i += 1) {
      const d = this.shiftDate(weekStart, i);
      const weekday = i + 1; // ISO: 1=Mon
      const isToday = d === today;

      const dayTasks = tasks.filter((t) => t.dueDate === d && t.dueTime);
      const dayEvents = events.filter(
        (e) =>
          new Date(e.startDatetime.getTime() + 8 * 3600 * 1000)
            .toISOString()
            .slice(0, 10) === d,
      );
      const dayHabits = activeHabits.filter((h) =>
        isHabitDueOnDay(h, weekday),
      );
      const dayNotes = weekNotes.filter(
        (n) =>
          n.remindAt &&
          new Date(n.remindAt.getTime() + 8 * 3600 * 1000)
            .toISOString()
            .slice(0, 10) === d,
      );

      const morning: WeekSlotItem[] = [];
      const afternoon: WeekSlotItem[] = [];
      const evening: WeekSlotItem[] = [];

      for (const task of dayTasks) {
        const slot = getTimeSlot(task.dueTime ?? '');
        const item: WeekSlotItem = {
          id: task.recordId,
          type: 'task',
          title: task.title,
          status: task.status,
          timeLabel: task.dueTime ?? undefined,
        };
        if (slot === 'morning') morning.push(item);
        else if (slot === 'afternoon') afternoon.push(item);
        else evening.push(item);
      }

      for (const evt of dayEvents) {
        const timeStr = formatTime(evt.startDatetime);
        const slot = getTimeSlot(timeStr);
        const item: WeekSlotItem = {
          id: evt.recordId,
          type: 'event',
          title: evt.title,
          status: evt.status,
          eventType: evt.eventType as EventType,
          timeLabel: timeStr,
        };
        if (slot === 'morning') morning.push(item);
        else if (slot === 'afternoon') afternoon.push(item);
        else evening.push(item);
      }

      for (const habit of dayHabits) {
        if (!habit.suggestedTime && habit.timeSlot === 'any') continue;
        const timeStr = habit.suggestedTime ?? defaultTimeForSlot(habit.timeSlot);
        const slot = getTimeSlot(timeStr);
        const item: WeekSlotItem = {
          id: habit.recordId,
          type: 'habit',
          title: habit.name,
          status: 'active',
          timeLabel: habit.suggestedTime ?? undefined,
        };
        if (slot === 'morning') morning.push(item);
        else if (slot === 'afternoon') afternoon.push(item);
        else evening.push(item);
      }

      for (const note of dayNotes) {
        // remindAt is a UTC Date; formatTime uses server-local getHours() (+08:00)
        const timeStr = formatTime(note.remindAt as Date);
        const slot = getTimeSlot(timeStr);
        const item: WeekSlotItem = {
          id: note.recordId,
          type: 'note',
          title: note.content,
          status: 'active',
          timeLabel: timeStr,
        };
        if (slot === 'morning') morning.push(item);
        else if (slot === 'afternoon') afternoon.push(item);
        else evening.push(item);
      }

      const sortByTime = (a: WeekSlotItem, b: WeekSlotItem) =>
        (a.timeLabel ?? '').localeCompare(b.timeLabel ?? '');
      morning.sort(sortByTime);
      afternoon.sort(sortByTime);
      evening.sort(sortByTime);

      days.push({
        date: d,
        weekday,
        isToday,
        morning,
        afternoon,
        evening,
      });
    }

    return { weekStart, weekEnd, days };
  }

  /**
   * 月历视图：统计某月每天的 task/event/note 数量（不含习惯，习惯只在当日详情显示）。
   * 支持补位相邻月的日期（inMonth=false），方便前端渲染 7 列网格。
   */
  async getMonth(month: string): Promise<MonthViewData> {
    const [yearStr, monthStr] = month.split('-');
    const year = parseInt(yearStr, 10);
    const monthIndex = parseInt(monthStr, 10);
    const today = new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 10);

    const firstOfMonth = new Date(Date.UTC(year, monthIndex - 1, 1));
    const daysInMonth = new Date(Date.UTC(year, monthIndex, 0)).getUTCDate();

    // 北京时区下当月首日的 ISO 星期几（1=Mon..7=Sun）
    const jsFirstDay = firstOfMonth.getUTCDay();
    const isoFirstDay = jsFirstDay === 0 ? 7 : jsFirstDay;

    // 前置补位：当月1号之前的上月日期
    const leadDays = isoFirstDay - 1;
    const cells: { date: string; inMonth: boolean }[] = [];
    for (let i = leadDays; i > 0; i -= 1) {
      const d = new Date(firstOfMonth);
      d.setUTCDate(d.getUTCDate() - i);
      cells.push({ date: d.toISOString().slice(0, 10), inMonth: false });
    }
    for (let day = 1; day <= daysInMonth; day += 1) {
      const d = new Date(firstOfMonth);
      d.setUTCDate(d.getUTCDate() + (day - 1));
      cells.push({ date: d.toISOString().slice(0, 10), inMonth: true });
    }

    const monthEnd = new Date(Date.UTC(year, monthIndex - 1, daysInMonth)).toISOString().slice(0, 10);
    const rangeStart = cells[0].date;
    const rangeEnd = this.shiftDate(monthEnd, 1);

    // Tasks（按 dueDate 字符串匹配）
    const tasks = await this.db
      .select({ dueDate: taskTable.dueDate })
      .from(taskTable)
      .where(
        and(
          gte(taskTable.dueDate, rangeStart),
          lt(taskTable.dueDate, rangeEnd),
          eq(taskTable.isDeleted, false),
        ),
      );

    // Events（startDatetime 落在 [当月1号0点, 月末+1天0点) 北京时间）
    const rangeStartDate = new Date(`${rangeStart}T00:00:00+08:00`);
    const rangeEndDate = new Date(`${rangeEnd}T00:00:00+08:00`);
    const events = await this.db
      .select({ startDatetime: eventTable.startDatetime })
      .from(eventTable)
      .where(
        and(
          gte(eventTable.startDatetime, rangeStartDate),
          lt(eventTable.startDatetime, rangeEndDate),
          eq(eventTable.isDeleted, false),
        ),
      );

    // Notes（remindAt 落在同一北京区间）
    const notes = await this.db
      .select({ remindAt: quickNoteTable.remindAt })
      .from(quickNoteTable)
      .where(
        and(
          eq(quickNoteTable.isDeleted, false),
          gte(quickNoteTable.remindAt, rangeStartDate),
          lt(quickNoteTable.remindAt, rangeEndDate),
        ),
      );

    // 按日期归并（统一用北京日期 YYYY-MM-DD）
    const taskByDate = new Map<string, number>();
    for (const t of tasks) {
      if (!t.dueDate) continue;
      taskByDate.set(t.dueDate, (taskByDate.get(t.dueDate) ?? 0) + 1);
    }
    const eventByDate = new Map<string, number>();
    for (const e of events) {
      const d = new Date(e.startDatetime.getTime() + 8 * 3600 * 1000)
        .toISOString()
        .slice(0, 10);
      eventByDate.set(d, (eventByDate.get(d) ?? 0) + 1);
    }
    const noteByDate = new Map<string, number>();
    for (const n of notes) {
      if (!n.remindAt) continue;
      const d = new Date(n.remindAt.getTime() + 8 * 3600 * 1000)
        .toISOString()
        .slice(0, 10);
      noteByDate.set(d, (noteByDate.get(d) ?? 0) + 1);
    }

    const days: MonthDayData[] = cells.map((cell, idx) => {
      const isoDay = ((cell.date ? new Date(cell.date + 'T00:00:00Z').getUTCDay() : 0) || 7);
      const weekday = isoDay;
      return {
        date: cell.date,
        weekday,
        isToday: cell.date === today,
        inMonth: cell.inMonth,
        taskCount: taskByDate.get(cell.date) ?? 0,
        eventCount: eventByDate.get(cell.date) ?? 0,
        noteCount: noteByDate.get(cell.date) ?? 0,
        total:
          (taskByDate.get(cell.date) ?? 0) +
          (eventByDate.get(cell.date) ?? 0) +
          (noteByDate.get(cell.date) ?? 0),
      };
    });

    return {
      month: `${year}-${String(monthIndex).padStart(2, '0')}`,
      year,
      monthIndex,
      days,
    };
  }

  async getUnscheduled(): Promise<UnscheduledTask[]> {
    const today = new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 10);
    const priorityOrder: Record<string, number> = {
      P0: 0, P1: 1, P2: 2, P3: 3,
    };

    const tasks = await this.db
      .select()
      .from(taskTable)
      .where(
        and(
          eq(taskTable.status, 'todo'),
          or(isNull(taskTable.scheduledSlot), eq(taskTable.scheduledSlot, '')),
          gte(taskTable.dueDate, today),
          eq(taskTable.isDeleted, false),
        ),
      )
      .orderBy(asc(taskTable.dueDate));

    const result: UnscheduledTask[] = tasks.map((t) => ({
      recordId: t.recordId,
      title: t.title,
      estimateMinutes: t.estimateMinutes,
      priority: t.priority as TaskPriority,
    }));

    result.sort((a, b) => {
      const pa = priorityOrder[a.priority] ?? 99;
      const pb = priorityOrder[b.priority] ?? 99;
      return pa - pb;
    });

    return result;
  }

  async getHabits(): Promise<HabitItem[]> {
    const habits = await this.db
      .select()
      .from(habitTable)
      .where(and(eq(habitTable.status, 'active'), eq(habitTable.isDeleted, false)))
      .orderBy(asc(habitTable.createdAt));

    if (habits.length === 0) return [];

    // 统计每个习惯周期内的实际打卡天数（habit_log status=done，按日期去重）
    const habitIds = habits.map((h) => h.recordId);
    const logs = await this.db
      .select({
        habitId: habitLogTable.habitId,
        logDate: habitLogTable.logDate,
      })
      .from(habitLogTable)
      .where(
        and(
          inArray(habitLogTable.habitId, habitIds),
          eq(habitLogTable.status, 'done'),
        ),
      );
    const doneDaysByHabit = new Map<string, Set<string>>();
    for (const l of logs) {
      const ds = String(l.logDate).slice(0, 10);
      if (!doneDaysByHabit.has(l.habitId)) {
        doneDaysByHabit.set(l.habitId, new Set());
      }
      doneDaysByHabit.get(l.habitId)!.add(ds);
    }

    // 服务端 +8 墙钟的今天
    const today = new Date(Date.now() + 8 * 3600 * 1000)
      .toISOString()
      .slice(0, 10);

    return habits.map((h) => {
      const item = mapHabitItem(h);
      const doneSet = doneDaysByHabit.get(h.recordId);
      let doneCount = 0;
      if (doneSet) {
        const rangeEnd = h.endDate ? dateStr(h.endDate) : today;
        for (const ds of doneSet) {
          if (ds >= dateStr(h.startDate) && ds <= rangeEnd) doneCount += 1;
        }
      }
      item.periodDoneDays = doneCount;

      // 周期总天数：优先 periodDays；有 endDate 时按区间天数；都没有则不显示百分比
      let totalDays: number | null = h.periodDays ?? null;
      if (totalDays === null && h.endDate) {
        const start = new Date(`${dateStr(h.startDate)}T00:00:00+08:00`).getTime();
        const end = new Date(`${dateStr(h.endDate)}T00:00:00+08:00`).getTime();
        totalDays = Math.round((end - start) / 86400000) + 1;
      }
      item.periodTotalDays = totalDays;
      if (totalDays && totalDays > 0) {
        item.periodProgressPercent = Math.min(
          100,
          Math.round((doneCount / totalDays) * 100),
        );
      }
      return item;
    });
  }

  async getGoals(): Promise<GoalItem[]> {
    const goals = await this.db
      .select()
      .from(goalTable)
      .where(and(eq(goalTable.status, 'active'), eq(goalTable.isDeleted, false)))
      .orderBy(asc(goalTable.createdAt));
    const items = goals.map((g) => mapGoalItem(g));
    if (items.length === 0) return items;

    const goalIds = items.map((g) => g.recordId);
    const logs = await this.db
      .select({ goalId: goalLogTable.goalId, logDate: goalLogTable.logDate })
      .from(goalLogTable)
      .where(
        and(
          inArray(goalLogTable.goalId, goalIds),
          eq(goalLogTable.status, 'done'),
        ),
      );
    const doneByGoal = new Map<string, Set<string>>();
    for (const l of logs) {
      if (!doneByGoal.has(l.goalId)) doneByGoal.set(l.goalId, new Set());
      doneByGoal.get(l.goalId)!.add(String(l.logDate));
    }
    return items.map((g) => {
      const done = doneByGoal.get(g.recordId)?.size ?? 0;
      if (g.periodDays) {
        g.periodDoneDays = done;
        g.periodRemain = Math.max(0, g.periodDays - done);
        g.progressPercent = Math.min(100, Math.round((done / g.periodDays) * 100));
      } else if (g.targetValue && g.targetValue > 0) {
        g.progressPercent = Math.min(
          100,
          Math.round((g.currentValue / g.targetValue) * 100),
        );
      }
      return g;
    });
  }

  /**
   * 目标打卡：每次点击 +1 进度，可一天多次累加；写 goal_log 并更新 currentValue。
   */
  async checkinGoal(recordId: string, date: string): Promise<GoalItem> {
    const goals = await this.db
      .select()
      .from(goalTable)
      .where(
        and(eq(goalTable.recordId, recordId), eq(goalTable.isDeleted, false)),
      )
      .limit(1);
    if (goals.length === 0) {
      throw new BadRequestException('目标不存在');
    }
    const goal = goals[0];

    const today =
      date ||
      new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 10);

    const isOneShot = isOneShotGoal(goal.title, goal.unit ?? '');

    await this.db.insert(goalLogTable).values({
      recordId: `GL_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      goalId: recordId,
      logDate: today,
      status: 'done',
      completedAt: new Date(),
    });

    if (isOneShot) {
      const targetValue = goal.targetValue != null ? Number(goal.targetValue) : 1;
      const currentValue = targetValue > 0 ? targetValue : 1;
      await this.db
        .update(goalTable)
        .set({
          currentValue: String(currentValue),
          progressPercent: '100',
          status: 'achieved',
          achievedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(goalTable.recordId, recordId));
    } else {
      const newCurrent = Number(goal.currentValue) + 1;
      const targetValue = goal.targetValue != null ? Number(goal.targetValue) : 0;
      const progressPercent =
        targetValue > 0
          ? String(Math.min(100, Math.round((newCurrent / targetValue) * 100)))
          : '0';
      await this.db
        .update(goalTable)
        .set({
          currentValue: String(newCurrent),
          progressPercent,
          updatedAt: new Date(),
        })
        .where(eq(goalTable.recordId, recordId));
    }

    const refreshed = await this.db
      .select()
      .from(goalTable)
      .where(eq(goalTable.recordId, recordId))
      .limit(1);
    const item = mapGoalItem(refreshed[0]);
    const logs = await this.db
      .select({ logDate: goalLogTable.logDate })
      .from(goalLogTable)
      .where(
        and(eq(goalLogTable.goalId, recordId), eq(goalLogTable.status, 'done')),
      );
    if (item.periodDays) {
      const doneDays = new Set(logs.map((l) => String(l.logDate))).size;
      item.periodDoneDays = doneDays;
      item.periodRemain = Math.max(0, item.periodDays - doneDays);
      item.progressPercent = Math.min(
        100,
        Math.round((doneDays / item.periodDays) * 100),
      );
    }
    return item;
  }

  /**
   * 当日时间轴：某天的 task/event/habit/note 混合，按时间排序，含打卡/完成状态。
   */
  async getDay(date: string): Promise<DayTimelineItem[]> {
    const nextDate = this.shiftDate(date, 1);
    const startOfDay = new Date(`${date}T00:00:00+08:00`);
    const startOfNextDay = new Date(`${nextDate}T00:00:00+08:00`);
    const weekday = this.getIsoWeekday(date);

    const tasks = await this.db
      .select()
      .from(taskTable)
      .where(and(eq(taskTable.dueDate, date), eq(taskTable.isDeleted, false)));

    const events = await this.db
      .select()
      .from(eventTable)
      .where(
        and(
          gte(eventTable.startDatetime, startOfDay),
          lt(eventTable.startDatetime, startOfNextDay),
          eq(eventTable.isDeleted, false),
        ),
      );

    const activeHabits = await this.db
      .select()
      .from(habitTable)
      .where(
        and(
          eq(habitTable.status, 'active'),
          lte(habitTable.startDate, date),
          or(isNull(habitTable.endDate), gte(habitTable.endDate, date)),
          eq(habitTable.isDeleted, false),
        ),
      );
    const dueHabits = activeHabits.filter((h) =>
      isHabitDueOnDay(h, weekday),
    );

    const habitLogs = await this.db
      .select()
      .from(habitLogTable)
      .where(eq(habitLogTable.logDate, date));
    const habitDoneMap = new Map<string, string>();
    for (const log of habitLogs) {
      habitDoneMap.set(log.habitId, log.status);
    }

    const noteStart = new Date(`${date}T00:00:00+08:00`);
    const noteEnd = new Date(`${nextDate}T00:00:00+08:00`);
    const notes = await this.db
      .select()
      .from(quickNoteTable)
      .where(
        and(
          eq(quickNoteTable.isDeleted, false),
          gte(quickNoteTable.remindAt, noteStart),
          lt(quickNoteTable.remindAt, noteEnd),
        ),
      );

    const items: DayTimelineItem[] = [];

    for (const task of tasks) {
      items.push({
        id: task.recordId,
        type: 'task',
        title: task.title,
        status: task.status,
        timeLabel: task.dueTime ?? undefined,
      });
    }

    for (const evt of events) {
      items.push({
        id: evt.recordId,
        type: 'event',
        title: evt.title,
        status: evt.status,
        timeLabel: formatTime(evt.startDatetime),
        eventType: evt.eventType as EventType,
      });
    }

    for (const habit of dueHabits) {
      items.push({
        id: habit.recordId,
        type: 'habit',
        title: habit.name,
        status: habitDoneMap.get(habit.recordId) ?? 'pending',
        timeLabel: habit.suggestedTime ?? undefined,
      });
    }

    for (const note of notes) {
      if (!note.remindAt) continue;
      items.push({
        id: note.recordId,
        type: 'note',
        title: note.content,
        status: note.isDone ? 'done' : 'pending',
        timeLabel: formatTime(note.remindAt),
      });
    }

    const sortTime = (it: DayTimelineItem) => it.timeLabel ?? '23:59:59';
    items.sort((a, b) => sortTime(a).localeCompare(sortTime(b)));
    return items;
  }

  /**
   * 习惯月度打卡进度：当月应打卡天数 vs 已打卡天数（habit_log done）
   */
  async getHabitProgress(month: string): Promise<HabitProgressItem[]> {
    const [yearStr, monthStr] = month.split('-');
    const year = parseInt(yearStr, 10);
    const monthIndex = parseInt(monthStr, 10);
    const daysInMonth = new Date(Date.UTC(year, monthIndex, 0)).getUTCDate();

    const monthStart = `${year}-${String(monthIndex).padStart(2, '0')}-01`;
    const monthEnd = `${year}-${String(monthIndex).padStart(2, '0')}-${String(daysInMonth).padStart(2, '0')}`;
    const afterMonth = this.shiftDate(monthEnd, 1);

    const habits = await this.db
      .select()
      .from(habitTable)
      .where(and(eq(habitTable.status, 'active'), eq(habitTable.isDeleted, false)));

    // 计算每个习惯当月应打卡天数（daily=每天，weekly=目标星期几出现次数）
    const dueMap = new Map<string, number>();
    for (let day = 1; day <= daysInMonth; day += 1) {
      const d = `${year}-${String(monthIndex).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const weekday = this.getIsoWeekday(d);
      for (const h of habits) {
        if (h.startDate && d < String(h.startDate)) continue;
        if (h.endDate && d > String(h.endDate)) continue;
        if (isHabitDueOnDay(h, weekday)) {
          dueMap.set(h.recordId, (dueMap.get(h.recordId) ?? 0) + 1);
        }
      }
    }

    // 当月 done 打卡记录
    const logs = await this.db
      .select({ habitId: habitLogTable.habitId, status: habitLogTable.status })
      .from(habitLogTable)
      .where(
        and(
          gte(habitLogTable.logDate, monthStart),
          lt(habitLogTable.logDate, afterMonth),
          eq(habitLogTable.status, 'done'),
        ),
      );
    const doneMap = new Map<string, number>();
    for (const log of logs) {
      doneMap.set(log.habitId, (doneMap.get(log.habitId) ?? 0) + 1);
    }

    const result: HabitProgressItem[] = habits.map((h) => {
      const dueDays = dueMap.get(h.recordId) ?? 0;
      const doneDays = doneMap.get(h.recordId) ?? 0;
      return {
        recordId: h.recordId,
        name: h.name,
        dueDays,
        doneDays,
        rate: dueDays === 0 ? 0 : Math.min(1, doneDays / dueDays),
      };
    });

    return result.sort((a, b) => b.rate - a.rate);
  }

  /**
   * 软删除任务（与全局软删除一致，保留记录仅标记删除）
   */
  async softDeleteTask(taskId: string): Promise<void> {
    const result = await this.db
      .update(taskTable)
      .set({ isDeleted: true, updatedAt: new Date() })
      .where(
        and(eq(taskTable.recordId, taskId), eq(taskTable.isDeleted, false)),
      )
      .returning({ id: taskTable.recordId });
    if (result.length === 0) {
      throw new Error(`任务不存在或已删除: ${taskId}`);
    }
    this.logger.log(`软删除任务 ${taskId}`);
  }

  async softDeleteEvent(eventId: string): Promise<void> {
    const result = await this.db
      .update(eventTable)
      .set({ isDeleted: true, updatedAt: new Date() })
      .where(
        and(eq(eventTable.recordId, eventId), eq(eventTable.isDeleted, false)),
      )
      .returning({ id: eventTable.recordId });
    if (result.length === 0) {
      throw new Error(`日程不存在或已删除: ${eventId}`);
    }
    this.logger.log(`软删除日程 ${eventId}`);
  }

  async softDeleteHabit(habitId: string): Promise<void> {
    const result = await this.db
      .update(habitTable)
      .set({ isDeleted: true, updatedAt: new Date() })
      .where(
        and(eq(habitTable.recordId, habitId), eq(habitTable.isDeleted, false)),
      )
      .returning({ id: habitTable.recordId });
    if (result.length === 0) {
      throw new Error(`习惯不存在或已删除: ${habitId}`);
    }
    this.logger.log(`软删除习惯 ${habitId}`);
  }

  async softDeleteGoal(goalId: string): Promise<void> {
    const result = await this.db
      .update(goalTable)
      .set({ isDeleted: true, updatedAt: new Date() })
      .where(
        and(eq(goalTable.recordId, goalId), eq(goalTable.isDeleted, false)),
      )
      .returning({ id: goalTable.recordId });
    if (result.length === 0) {
      throw new Error(`目标不存在或已删除: ${goalId}`);
    }
    this.logger.log(`软删除目标 ${goalId}`);
  }

  /**
   * 打卡/取消打卡习惯（写 habit_log，当天 upsert 语义）
   */
  async toggleHabit(habitId: string, date: string): Promise<{ status: string }> {
    const rows = await this.db
      .select({ recordId: habitTable.recordId })
      .from(habitTable)
      .where(and(eq(habitTable.recordId, habitId), eq(habitTable.isDeleted, false)));
    if (rows.length === 0) {
      throw new Error(`习惯不存在: ${habitId}`);
    }

    const existing = await this.db
      .select({ recordId: habitLogTable.recordId })
      .from(habitLogTable)
      .where(
        and(
          eq(habitLogTable.habitId, habitId),
          eq(habitLogTable.logDate, date),
        ),
      );

    if (existing.length > 0) {
      await this.db
        .delete(habitLogTable)
        .where(eq(habitLogTable.recordId, existing[0].recordId));
      this.logger.log(`习惯取消打卡 ${habitId} @ ${date}`);
      return { status: 'pending' };
    }

    const recordId = `HBL_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    await this.db.insert(habitLogTable).values({
      recordId,
      habitId,
      logDate: date,
      status: 'done',
      completedAt: new Date(),
    });
    this.logger.log(`习惯打卡 ${habitId} @ ${date}`);
    return { status: 'done' };
  }

  /**
   * 标记日程完成/恢复（planned ↔ done）
   */
  async toggleEvent(eventId: string): Promise<{ status: string }> {
    const rows = await this.db
      .select({ status: eventTable.status })
      .from(eventTable)
      .where(and(eq(eventTable.recordId, eventId), eq(eventTable.isDeleted, false)));
    if (rows.length === 0) {
      throw new Error(`日程不存在: ${eventId}`);
    }
    const next = rows[0].status === 'done' ? 'planned' : 'done';
    await this.db
      .update(eventTable)
      .set({ status: next, updatedAt: new Date() })
      .where(eq(eventTable.recordId, eventId));
    this.logger.log(`日程 ${eventId} → ${next}`);
    return { status: next };
  }

  private getWeekRange(date: string): { weekStart: string; weekEnd: string } {
    // Pure UTC date arithmetic: parse date string as UTC midnight, no TZ shift
    const d = new Date(`${date}T00:00:00Z`);
    const jsDay = d.getUTCDay();
    const isoDay = jsDay === 0 ? 7 : jsDay;
    d.setUTCDate(d.getUTCDate() - (isoDay - 1));
    const weekStart = d.toISOString().slice(0, 10);
    d.setUTCDate(d.getUTCDate() + 6);
    const weekEnd = d.toISOString().slice(0, 10);
    return { weekStart, weekEnd };
  }

  private shiftDate(dateStr: string, days: number): string {
    const d = new Date(`${dateStr}T00:00:00Z`);
    d.setUTCDate(d.getUTCDate() + days);
    return d.toISOString().slice(0, 10);
  }
}
