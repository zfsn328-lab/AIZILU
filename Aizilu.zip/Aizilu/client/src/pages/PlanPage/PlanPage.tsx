import { useEffect, useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, ListTodo, Target, Sparkles, Check, CalendarDays, PenLine, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import * as api from '@client/src/api/plan';
import { toggleQuickNoteDone, deleteQuickNote } from '@client/src/api/quick-note';
import type {
  DayTimelineItem,
  EventType,
  GoalItem,
  HabitItem,
  MonthDayData,
  MonthViewData,
  UnscheduledTask,
} from '@shared/api.interface';

const EVENT_COLORS: Record<EventType, string> = {
  meeting: '#9AB0C0',
  course: '#B4A0C8',
  travel: '#C9A87C',
  personal: '#8FB3A0',
  other: '#B5A69C',
};

const EVENT_LABELS: Record<EventType, string> = {
  meeting: '会议',
  course: '课程',
  travel: '出行',
  personal: '个人',
  other: '日程',
};

const WEEKDAY_NAMES = ['一', '二', '三', '四', '五', '六', '日'];

const formatIso = (date: Date): string => {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

const formatMonthLabel = (month: string): string => {
  const [y, m] = month.split('-');
  return `${y}年${Number(m)}月`;
};

const shiftMonth = (month: string, delta: number): string => {
  const [y, m] = month.split('-').map(Number);
  const total = y * 12 + (m - 1) + delta;
  const ny = Math.floor(total / 12);
  const nm = (total % 12) + 1;
  return `${ny}-${String(nm).padStart(2, '0')}`;
};

const monthKey = (d: Date): string => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;

/** 月历格子直接取服务端数据（服务端已含相邻月补位，周一开头） */
const buildCalendarCells = (monthView: MonthViewData): MonthDayData[] =>
  monthView.days;

/** 格子类型：颜色圆点（task/event/note 三类）+ 角标 */
interface DotInfo {
  color: string;
  count: number;
}

const getDots = (day: MonthDayData): DotInfo[] => {
  const dots: DotInfo[] = [];
  if (day.taskCount > 0) dots.push({ color: '#C4877A', count: day.taskCount });
  if (day.eventCount > 0) dots.push({ color: '#B4A0C8', count: day.eventCount });
  if (day.noteCount > 0) dots.push({ color: '#C9A87C', count: day.noteCount });
  return dots;
};

interface DayCellProps {
  day: MonthDayData;
  selected: boolean;
  onClick: () => void;
}

const DayCell = ({ day, selected, onClick }: DayCellProps) => {
  const dayNum = Number(day.date.slice(8, 10));
  const dots = getDots(day);
  const total = day.total;

  return (
    <button
      type="button"
      onClick={onClick}
      className={`relative flex flex-col items-center justify-start pt-1.5 pb-1 rounded-xl transition-colors ${
        selected
          ? 'bg-[#C4877A]'
          : day.isToday
          ? 'bg-[#FDF2EE]'
          : 'hover:bg-[#FBF5EF]'
      } ${day.inMonth ? '' : 'opacity-40'}`}
      style={!selected && day.isToday ? { boxShadow: 'inset 0 0 0 1.5px #C4877A' } : undefined}
      aria-label={day.date}
    >
      <span
        className={`text-[13px] leading-none ${
          selected
            ? 'text-white font-semibold'
            : day.isToday
            ? 'text-[#A96A5C] font-semibold'
            : 'text-[#3F3330]'
        }`}
      >
        {dayNum}
      </span>

      <span className="mt-1 h-[6px] flex items-center gap-[3px]">
        {dots.slice(0, 3).map((dot, i) => (
          <span
            key={i}
            className="w-[5px] h-[5px] rounded-full"
            style={{ backgroundColor: selected ? '#FFFFFF' : dot.color }}
          />
        ))}
      </span>

      {total > 3 && (
        <span
          className={`absolute top-1 right-1 min-w-[15px] h-[15px] rounded-full text-[9px] leading-[15px] px-[3px] text-center font-semibold ${
            selected ? 'bg-white/90 text-[#A96A5C]' : 'bg-[#C4877A] text-white'
          }`}
        >
          {total}
        </span>
      )}
    </button>
  );
};

interface TimelineRowProps {
  item: DayTimelineItem;
  onToggle: (item: DayTimelineItem) => void;
  toggling: boolean;
  onDelete?: (item: DayTimelineItem) => void;
}

const typeStyle = (item: DayTimelineItem) => {
  let dotColor = '#C4877A';
  let tagLabel = '待办小事';
  let tagColor = '#C4877A';
  let tagBg = 'rgba(196, 135, 122, 0.12)';
  let tagIcon: typeof ListTodo = ListTodo;

  if (item.type === 'event') {
    dotColor = '#9AB0C0';
    tagLabel = '今日日程';
    tagColor = '#9AB0C0';
    tagBg = 'rgba(154, 176, 192, 0.15)';
    tagIcon = CalendarDays;
  } else if (item.type === 'habit') {
    dotColor = '#7FA98A';
    tagLabel = '习惯打卡';
    tagColor = '#7FA98A';
    tagBg = 'rgba(127, 169, 138, 0.15)';
    tagIcon = Sparkles;
  } else if (item.type === 'note') {
    dotColor = '#C9A87C';
    tagLabel = '随手记';
    tagColor = '#A8895C';
    tagBg = 'rgba(201, 168, 124, 0.16)';
    tagIcon = PenLine;
  }

  return { dotColor, tagLabel, tagColor, tagBg, tagIcon };
};

const TimelineRow = ({ item, onToggle, toggling, onDelete }: TimelineRowProps) => {
  const { dotColor, tagLabel, tagColor, tagBg, tagIcon: TagIcon } = typeStyle(item);
  const isDone = item.status === 'done';
  const [confirming, setConfirming] = useState(false);
  const isClickable =
    item.type === 'task' ||
    item.type === 'event' ||
    item.type === 'habit' ||
    item.type === 'note';

  return (
    <div className="flex items-center gap-3 px-4 py-3">
      <span className="w-[3px] self-stretch rounded-full flex-shrink-0" style={{ backgroundColor: dotColor }} />
      <div className="flex-1 min-w-0">
        <span
          className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-md font-medium mb-1"
          style={{ color: tagColor, backgroundColor: tagBg }}
        >
          <TagIcon size={10} strokeWidth={2.5} />
          {tagLabel}
        </span>
        <div
          className={`text-[14px] font-medium leading-snug break-words ${
            isDone ? 'line-through text-[#B5A69C]' : 'text-[#3F3330]'
          }`}
        >
          {item.title}
        </div>
      </div>
      <div className="flex flex-col items-end gap-1 flex-shrink-0">
        {item.timeLabel && (
          <span className="text-[12px] text-[#8A7A72]">{item.timeLabel}</span>
        )}
        {isClickable && (
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onToggle(item)}
              disabled={toggling}
              className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all disabled:opacity-50 ${
                isDone
                  ? 'bg-[#7FA98A] border-[#7FA98A]'
                  : 'border-[#E8D8CE] hover:border-[#C4877A]'
              }`}
              aria-label={isDone ? '撤销完成' : '标记完成'}
            >
              {isDone && <Check size={13} color="white" strokeWidth={3} />}
            </button>
            {onDelete && confirming ? (
              <span className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => {
                    setConfirming(false);
                    onDelete(item);
                  }}
                  className="text-[10px] px-2 py-1 rounded-lg bg-[#C96F62] text-white font-medium"
                >
                  确认
                </button>
                <button
                  type="button"
                  onClick={() => setConfirming(false)}
                  className="text-[10px] px-2 py-1 rounded-lg bg-[#FBF5EF] text-[#8A7A72] font-medium"
                >
                  取消
                </button>
              </span>
            ) : (
              onDelete && (
                <button
                  type="button"
                  onClick={() => setConfirming(true)}
                  aria-label="删除"
                  className="w-6 h-6 flex items-center justify-center rounded-lg text-[#C9B8AE] hover:text-[#C96F62] hover:bg-[#FBEDE9] transition-colors"
                >
                  <Trash2 size={14} strokeWidth={2} />
                </button>
              )
            )}
          </div>
        )}
      </div>
    </div>
  );
};

interface HabitRowProps {
  habit: HabitItem;
  onToggle: (habit: HabitItem) => void;
  toggling: boolean;
  onDelete: (habit: HabitItem) => void;
  todayDone: boolean;
}

const HabitRow = ({ habit, onToggle, toggling, onDelete, todayDone }: HabitRowProps) => {
  const [confirming, setConfirming] = useState(false);
  const hasPeriod = habit.periodTotalDays && habit.periodTotalDays > 0;
  const rate = hasPeriod
    ? Math.min(100, habit.periodProgressPercent ?? 0)
    : Math.min(100, habit.completionRate30d ?? 0);
  return (
    <div className="flex items-center gap-3 py-2">
      <div
        className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
        style={{ backgroundColor: 'rgba(127, 169, 138, 0.15)' }}
      >
        <Sparkles size={16} color="#7FA98A" strokeWidth={2} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-1">
          <span className="text-[14px] text-[#3F3330] font-medium truncate">
            {habit.name}
          </span>
          <span className="text-[12px] text-[#7FA98A] flex-shrink-0 ml-2 whitespace-nowrap">
            {hasPeriod
              ? `${habit.periodDoneDays}/${habit.periodTotalDays} 天 · ${Math.round(rate)}%`
              : `${Math.round(rate)}%`}
          </span>
        </div>
        <div className="h-1.5 rounded-full bg-[#F0E6DC] overflow-hidden">
          <div
            className="h-full rounded-full bg-[#7FA98A] transition-all"
            style={{ width: `${rate}%` }}
          />
        </div>
      </div>
      <div className="flex items-center gap-2 flex-shrink-0">
        <button
          type="button"
          onClick={() => onToggle(habit)}
          disabled={toggling}
          className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all disabled:opacity-50 ${
            todayDone
              ? 'bg-[#7FA98A] border-[#7FA98A]'
              : 'border-[#E8D8CE] hover:border-[#C4877A]'
          }`}
          aria-label={todayDone ? '撤销打卡' : '打卡'}
        >
          {todayDone && <Check size={13} color="white" strokeWidth={3} />}
        </button>
        {confirming ? (
          <span className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => {
                setConfirming(false);
                onDelete(habit);
              }}
              className="text-[10px] px-2 py-1 rounded-lg bg-[#C96F62] text-white font-medium"
            >
              确认
            </button>
            <button
              type="button"
              onClick={() => setConfirming(false)}
              className="text-[10px] px-2 py-1 rounded-lg bg-[#FBF5EF] text-[#8A7A72] font-medium"
            >
              取消
            </button>
          </span>
        ) : (
          <button
            type="button"
            onClick={() => setConfirming(true)}
            aria-label="删除"
            className="w-6 h-6 flex items-center justify-center rounded-lg text-[#C9B8AE] hover:text-[#C96F62] hover:bg-[#FBEDE9] transition-colors"
          >
            <Trash2 size={14} strokeWidth={2} />
          </button>
        )}
      </div>
    </div>
  );
};

interface GoalRowProps {
  goal: GoalItem;
  onCheckin: (goal: GoalItem) => void;
  checkingId: string | null;
  onDelete: (goal: GoalItem) => void;
}

const GoalRow = ({ goal, onCheckin, checkingId, onDelete }: GoalRowProps) => {
  const [confirming, setConfirming] = useState(false);
  const percent = Math.min(100, goal.progressPercent ?? 0);
  const done = goal.periodDays ? goal.periodDoneDays : Number(goal.currentValue);
  const total = goal.periodDays ? goal.periodDays : (goal.targetValue ?? '-');
  const isChecking = checkingId === goal.recordId;
  const isOneShot = /元|万元|块钱|斤|公斤|km|kg|千米|公里/.test(goal.title);
  const isAchieved = goal.status === 'achieved' || percent >= 100;
  return (
    <div className="flex items-center gap-3 py-2">
      <div
        className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${isAchieved ? 'opacity-50' : ''}`}
        style={{ backgroundColor: 'rgba(196, 135, 122, 0.15)' }}
      >
        <Target size={16} color="#C4877A" strokeWidth={2} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-1">
          <span className={`text-[14px] font-medium truncate ${isAchieved ? 'text-[#B5A69C] line-through' : 'text-[#3F3330]'}`}>
            {goal.title}
          </span>
          <span className={`text-[12px] flex-shrink-0 ml-2 whitespace-nowrap ${isAchieved ? 'text-[#B5A69C]' : 'text-[#8A7A72]'}`}>
            {goal.periodDays
              ? `已勾 ${done}/${total} 天 · 剩 ${goal.periodRemain} 次`
              : `${goal.currentValue}/${goal.targetValue ?? '-'}${goal.unit}`}
          </span>
        </div>
        <div className="h-1.5 rounded-full bg-[#F0E6DC] overflow-hidden">
          <div
            className={`h-full rounded-full transition-all ${isAchieved ? 'bg-[#B5A69C]' : 'bg-[#C4877A]'}`}
            style={{ width: `${percent}%` }}
          />
        </div>
      </div>
      <div className="flex items-center gap-2 flex-shrink-0">
        <button
          type="button"
          onClick={() => onCheckin(goal)}
          disabled={isChecking || isAchieved}
          aria-label="目标打卡"
          className={`w-7 h-7 rounded-full border-2 flex items-center justify-center transition-colors disabled:opacity-60 ${
            isAchieved
              ? 'bg-[#B5A69C] border-[#B5A69C] text-white'
              : done > 0 && goal.periodDays
                ? 'bg-[#D9A441] border-[#D9A441] text-white'
                : 'border-[#E0D2C8] text-transparent hover:border-[#D9A441] hover:text-[#D9A441]'
          }`}
        >
          <Check size={14} strokeWidth={3} />
        </button>
        {confirming ? (
          <span className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => {
                setConfirming(false);
                onDelete(goal);
              }}
              className="text-[10px] px-2 py-1 rounded-lg bg-[#C96F62] text-white font-medium"
            >
              确认
            </button>
            <button
              type="button"
              onClick={() => setConfirming(false)}
              className="text-[10px] px-2 py-1 rounded-lg bg-[#FBF5EF] text-[#8A7A72] font-medium"
            >
              取消
            </button>
          </span>
        ) : (
          <button
            type="button"
            onClick={() => setConfirming(true)}
            aria-label="删除"
            className="w-6 h-6 flex items-center justify-center rounded-lg text-[#C9B8AE] hover:text-[#C96F62] hover:bg-[#FBEDE9] transition-colors"
          >
            <Trash2 size={14} strokeWidth={2} />
          </button>
        )}
      </div>
    </div>
  );
};

const PlanPage = () => {
  const [viewMonth, setViewMonth] = useState<string>(() => monthKey(new Date()));
  const [selectedDate, setSelectedDate] = useState<string>(() => formatIso(new Date()));
  const [monthView, setMonthView] = useState<MonthViewData | null>(null);
  const [dayItems, setDayItems] = useState<DayTimelineItem[]>([]);
  const [unscheduled, setUnscheduled] = useState<UnscheduledTask[]>([]);
  const [habits, setHabits] = useState<HabitItem[]>([]);
  const [goals, setGoals] = useState<GoalItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [checkingId, setCheckingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [dayLoading, setDayLoading] = useState(false);
  const [togglingId, setTogglingId] = useState<string | null>(null);
  const [confirmingDelId, setConfirmingDelId] = useState<string | null>(null);
  const [habitDoneToday, setHabitDoneToday] = useState<Set<string>>(new Set());

  // 月视图数据
  useEffect(() => {
    let mounted = true;
    const load = async () => {
      try {
        const [mv, us, hb, gl] = await Promise.all([
          api.getMonthView(viewMonth),
          api.getUnscheduledTasks(),
          api.getActiveHabits(),
          api.getActiveGoals(),
        ]);
        if (!mounted) return;
        setMonthView(mv);
        setUnscheduled(us);
        setHabits(hb);
        setGoals(gl);
        setError(null);
      } catch (e: unknown) {
        if (!mounted) return;
        setError('加载失败，请稍后重试');
        logger.error('计划页加载失败', e);
      } finally {
        if (mounted) setLoading(false);
      }
    };
    load();
    // 页面从后台切回/恢复时强制重新拉取，避免看到旧数据
    const onVisible = () => {
      if (!document.hidden) load();
    };
    const onPageShow = (e: PageTransitionEvent) => {
      if (e.persisted) load();
    };
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('pageshow', onPageShow);
    return () => {
      mounted = false;
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('pageshow', onPageShow);
    };
  }, [viewMonth]);

  // 当日时间轴
  useEffect(() => {
    let mounted = true;
    const load = async () => {
      setDayLoading(true);
      try {
        const items = await api.getDayItems(selectedDate);
        if (!mounted) return;
        setDayItems(items);
      } catch (e: unknown) {
        if (!mounted) return;
        logger.error('当日安排加载失败', e);
        setDayItems([]);
      } finally {
        if (mounted) setDayLoading(false);
      }
    };
    load();
    return () => {
      mounted = false;
    };
  }, [selectedDate]);

  const cells = useMemo(
    () => (monthView ? buildCalendarCells(monthView) : []),
    [monthView],
  );

  const todayStr = formatIso(new Date());

  const goToday = () => {
    setViewMonth(monthKey(new Date()));
    setSelectedDate(todayStr);
  };

  const handleGoalCheckin = async (goal: GoalItem) => {
    if (checkingId) return;
    setCheckingId(goal.recordId);
    try {
      const updated = await api.checkinGoal(goal.recordId);
      setGoals((prev) =>
        prev.map((g) => (g.recordId === updated.recordId ? updated : g)),
      );
      const isOneShotGoal = /元|万元|块钱|斤|公斤|km|kg|千米|公里/.test(goal.title);
      toast.success(isOneShotGoal ? '目标已达成，太棒了！' : goal.periodDays ? '已打卡，今天完成' : '目标进度 +1');
    } catch (err: unknown) {
      logger.error('目标打卡失败', err);
      toast.error('打卡失败，请重试');
    } finally {
      setCheckingId(null);
    }
  };

  const goPrevMonth = () => {
    const m = shiftMonth(viewMonth, -1);
    setViewMonth(m);
    // 保持选中日可见：若选中日不属于新月份，切到该月 1 号（若是今天则保留）
    if (!selectedDate.startsWith(m)) {
      const firstDay = `${m}-01`;
      setSelectedDate(firstDay);
    }
  };

  const goNextMonth = () => {
    const m = shiftMonth(viewMonth, 1);
    setViewMonth(m);
    if (!selectedDate.startsWith(m)) {
      const firstDay = `${m}-01`;
      setSelectedDate(firstDay);
    }
  };

  const handleSelectDate = (date: string) => {
    setSelectedDate(date);
    if (!date.startsWith(viewMonth)) {
      setViewMonth(date.slice(0, 7));
    }
  };

  const handleToggle = async (item: DayTimelineItem) => {
    if (togglingId) return;
    setTogglingId(item.id);
    // 乐观更新
    const prevStatus = item.status;
    setDayItems((prev) =>
      prev.map((it) =>
        it.id === item.id
          ? { ...it, status: it.status === 'done' ? 'pending' : 'done' }
          : it,
      ),
    );
    try {
      let status: string;
      if (item.type === 'task') {
        status = await api.togglePlanTask(item.id);
      } else if (item.type === 'event') {
        status = await api.togglePlanEvent(item.id);
      } else if (item.type === 'note') {
        const { isDone } = await toggleQuickNoteDone(item.id);
        status = isDone ? 'done' : 'pending';
      } else {
        status = await api.togglePlanHabit(item.id, selectedDate);
      }
      setDayItems((prev) =>
        prev.map((it) => (it.id === item.id ? { ...it, status } : it)),
      );
      if (status === 'done') {
        toast.success(item.type === 'habit' ? '打卡成功，继续保持' : '已完成，辛苦啦');
      } else {
        toast.success('已撤销完成');
      }
    } catch (e: unknown) {
      // 回滚
      setDayItems((prev) =>
        prev.map((it) => (it.id === item.id ? { ...it, status: prevStatus } : it)),
      );
      logger.error('切换状态失败', e);
      toast.error('操作失败，请重试');
    } finally {
      setTogglingId(null);
    }
  };

  const handleDeleteItem = async (item: DayTimelineItem) => {
    try {
      if (item.type === 'task') await api.deletePlanTask(item.id);
      else if (item.type === 'event') await api.deletePlanEvent(item.id);
      else if (item.type === 'habit') await api.deletePlanHabit(item.id);
      else await deleteQuickNote(item.id);
      setDayItems((prev) => prev.filter((it) => it.id !== item.id));
      toast.success('已删除');
    } catch (e: unknown) {
      logger.error('删除失败', e);
      toast.error('删除失败，请稍后重试');
    }
  };

  // 待安排：勾选完成
  const handleUnscheduledToggle = async (task: UnscheduledTask) => {
    if (togglingId) return;
    setTogglingId(task.recordId);
    try {
      await api.togglePlanTask(task.recordId);
      setUnscheduled(await api.getUnscheduledTasks());
      toast.success('已完成');
    } catch (e: unknown) {
      logger.error('待办完成失败', e);
      toast.error('操作失败，请重试');
    } finally {
      setTogglingId(null);
    }
  };

  // 待安排：删除
  const handleUnscheduledDelete = async (id: string) => {
    try {
      await api.deletePlanTask(id);
      setConfirmingDelId(null);
      setUnscheduled(await api.getUnscheduledTasks());
      toast.success('已删除');
    } catch (e: unknown) {
      logger.error('删除失败', e);
      toast.error('删除失败，请稍后重试');
    }
  };

  // 习惯：打卡
  const handleHabitToggle = async (habit: HabitItem) => {
    if (togglingId) return;
    setTogglingId(habit.recordId);
    const wasDone = habitDoneToday.has(habit.recordId);
    setHabitDoneToday((prev) => {
      const next = new Set(prev);
      if (wasDone) next.delete(habit.recordId);
      else next.add(habit.recordId);
      return next;
    });
    try {
      const today = new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 10);
      const status = await api.togglePlanHabit(habit.recordId, today);
      setHabits(await api.getActiveHabits());
      if (status === 'done') {
        toast.success('打卡成功，继续保持');
      } else {
        setHabitDoneToday((prev) => {
          const next = new Set(prev);
          next.delete(habit.recordId);
          return next;
        });
        toast.success('已撤销打卡');
      }
    } catch (e: unknown) {
      setHabitDoneToday((prev) => {
        const next = new Set(prev);
        if (wasDone) next.add(habit.recordId);
        else next.delete(habit.recordId);
        return next;
      });
      logger.error('习惯打卡失败', e);
      toast.error('操作失败，请重试');
    } finally {
      setTogglingId(null);
    }
  };

  // 习惯：删除
  const handleHabitDelete = async (habit: HabitItem) => {
    try {
      await api.deletePlanHabit(habit.recordId);
      setHabits((prev) => prev.filter((h) => h.recordId !== habit.recordId));
      toast.success('已删除');
    } catch (e: unknown) {
      logger.error('删除习惯失败', e);
      toast.error('删除失败，请稍后重试');
    }
  };

  // 目标：删除
  const handleGoalDelete = async (goal: GoalItem) => {
    try {
      await api.deletePlanGoal(goal.recordId);
      setGoals((prev) => prev.filter((g) => g.recordId !== goal.recordId));
      toast.success('已删除');
    } catch (e: unknown) {
      logger.error('删除目标失败', e);
      toast.error('删除失败，请稍后重试');
    }
  };

  const selectedLabel = useMemo(() => {
    if (!selectedDate) return '';
    const [, m, d] = selectedDate.split('-');
    const dt = new Date(`${selectedDate}T00:00:00Z`);
    const jsDay = dt.getUTCDay();
    const iso = jsDay === 0 ? 7 : jsDay;
    const weekNames = ['日', '一', '二', '三', '四', '五', '六'];
    return `${Number(m)}月${Number(d)}日 · 周${WEEKDAY_NAMES[iso - 1]}`;
  }, [selectedDate]);

  if (loading) {
    return (
      <div className="space-y-5">
        <div className="h-10 bg-white rounded-2xl border border-[#F0E6DC] animate-pulse" />
        <div className="bg-white rounded-2xl border border-[#F0E6DC] p-4 animate-pulse h-72" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-2xl border border-[#F0E6DC] p-8 text-center">
        <p className="text-[#C96F62] text-[15px]">{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* 月历卡片：桌面端靠左，移动端全宽 */}
      <div
        className="bg-white rounded-2xl border border-[#F0E6DC] p-4"
        style={{ boxShadow: '0 2px 10px rgba(196, 135, 122, 0.10)' }}
      >
        {/* 月份标题栏 */}
        <div className="flex items-center justify-between mb-3">
          <h1 className="text-[19px] font-semibold text-[#3F3330]">
            {formatMonthLabel(viewMonth)}
          </h1>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={goToday}
              className="text-[12px] font-medium text-[#A96A5C] bg-[#FDF2EE] border border-[#EBD9CF] rounded-full px-3 py-1.5 hover:bg-[#FBF5EF] transition-colors"
            >
              今天
            </button>
            <button
              type="button"
              onClick={goPrevMonth}
              className="w-8 h-8 rounded-xl bg-white border border-[#F0E6DC] flex items-center justify-center text-[#8A7A72] hover:bg-[#FBF5EF] transition-colors"
            >
              <ChevronLeft size={16} strokeWidth={2} />
            </button>
            <button
              type="button"
              onClick={goNextMonth}
              className="w-8 h-8 rounded-xl bg-white border border-[#F0E6DC] flex items-center justify-center text-[#8A7A72] hover:bg-[#FBF5EF] transition-colors"
            >
              <ChevronRight size={16} strokeWidth={2} />
            </button>
          </div>
        </div>

        {/* 星期表头 */}
        <div className="grid grid-cols-7 gap-1 mb-1">
          {WEEKDAY_NAMES.map((w) => (
            <div key={w} className="text-center text-[11px] text-[#B5A69C] py-1">
              {w}
            </div>
          ))}
        </div>

        {/* 月历格子 */}
        <div className="grid grid-cols-7 gap-1">
          {cells.map((cell) => (
            <DayCell
              key={cell.date}
              day={cell}
              selected={cell.date === selectedDate}
              onClick={() => handleSelectDate(cell.date)}
            />
          ))}
        </div>
      </div>

      {/* 双栏：移动端 当日详情在前（紧随月历），待安排/习惯/目标在后；桌面端左栏固定信息 + 右侧详情 */}
      <div className="flex flex-col md:grid md:grid-cols-[340px_1fr] md:gap-5 md:items-start gap-5">
        {/* 左侧固定信息（待安排/习惯/目标） */}
        <div className="md:block md:sticky md:top-4 md:space-y-5 contents order-2 md:order-1">
          {/* 待安排区 */}
          <div
            className="bg-white rounded-2xl border border-[#F0E6DC] p-5"
            style={{ boxShadow: '0 2px 10px rgba(196, 135, 122, 0.10)' }}
          >
            <div className="flex items-center gap-2 mb-3">
              <ListTodo size={16} color="#C4877A" strokeWidth={2} />
              <h2 className="text-[16px] font-semibold text-[#3F3330]">
                待安排
              </h2>
              <span className="text-[12px] text-[#B5A69C]">
                {unscheduled.length} 条
              </span>
            </div>
            {unscheduled.length === 0 ? (
              <p className="text-[13px] text-[#B5A69C] py-4 text-center">
                暂无待安排的任务
              </p>
            ) : (
              <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
                {unscheduled.map((task) => (
                  <div
                    key={task.recordId}
                    className="flex items-center gap-3 p-3 rounded-xl bg-[#FBF5EF] border border-[#F0E6DC]"
                  >
                    <span className="flex-1 text-[14px] text-[#3F3330] truncate">
                      {task.title}
                    </span>
                    <span className="text-[12px] text-[#B5A69C] flex-shrink-0">
                      {task.estimateMinutes} 分钟
                    </span>
                    <button
                      type="button"
                      onClick={() => handleUnscheduledToggle(task)}
                      disabled={togglingId !== null}
                      className="w-6 h-6 rounded-full border-2 border-[#E8D8CE] hover:border-[#C4877A] flex items-center justify-center flex-shrink-0 transition-all disabled:opacity-50"
                      aria-label="标记完成"
                    />
                    <button
                      type="button"
                      onClick={() => setConfirmingDelId(task.recordId)}
                      aria-label="删除"
                      className="w-6 h-6 flex items-center justify-center rounded-lg text-[#C9B8AE] hover:text-[#C96F62] hover:bg-[#FBEDE9] transition-colors flex-shrink-0"
                    >
                      <Trash2 size={14} strokeWidth={2} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 习惯面板 */}
          <div
            className="bg-white rounded-2xl border border-[#F0E6DC] p-5"
            style={{ boxShadow: '0 2px 10px rgba(196, 135, 122, 0.10)' }}
          >
            <div className="flex items-center gap-2 mb-3">
              <Sparkles size={16} color="#7FA98A" strokeWidth={2} />
              <h2 className="text-[16px] font-semibold text-[#3F3330]">
                习惯
              </h2>
              <span className="text-[12px] text-[#B5A69C]">
                {habits.length} 个进行中
              </span>
            </div>
            {habits.length === 0 ? (
              <p className="text-[13px] text-[#B5A69C] py-4 text-center">
                还没有习惯，慢慢来
              </p>
            ) : (
              <div className="divide-y divide-[#F0E6DC] max-h-[320px] overflow-y-auto pr-1">
                {habits.map((habit) => (
                  <HabitRow
                    key={habit.recordId}
                    habit={habit}
                    onToggle={handleHabitToggle}
                    toggling={togglingId === habit.recordId}
                    onDelete={handleHabitDelete}
                    todayDone={habitDoneToday.has(habit.recordId)}
                  />
                ))}
              </div>
            )}
          </div>

          {/* 目标进度 */}
          <div
            className="bg-white rounded-2xl border border-[#F0E6DC] p-5"
            style={{ boxShadow: '0 2px 10px rgba(196, 135, 122, 0.10)' }}
          >
            <div className="flex items-center gap-2 mb-3">
              <Target size={16} color="#C4877A" strokeWidth={2} />
              <h2 className="text-[16px] font-semibold text-[#3F3330]">
                目标
              </h2>
              <span className="text-[12px] text-[#B5A69C]">
                {goals.length} 个进行中
              </span>
            </div>
            {goals.length === 0 ? (
              <p className="text-[13px] text-[#B5A69C] py-4 text-center">
                还没有目标
              </p>
            ) : (
              <div className="divide-y divide-[#F0E6DC] max-h-[320px] overflow-y-auto pr-1">
                {goals.map((goal) => (
                  <GoalRow
                    key={goal.recordId}
                    goal={goal}
                    onCheckin={handleGoalCheckin}
                    checkingId={checkingId}
                    onDelete={handleGoalDelete}
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        {/* 右侧：当日详情（移动端紧随月历） */}
        <div
          className="bg-white rounded-2xl border border-[#F0E6DC] overflow-hidden order-first md:order-2"
          style={{ boxShadow: '0 2px 10px rgba(196, 135, 122, 0.10)' }}
        >
          <div className="px-4 py-3 border-b border-[#F0E6DC] flex items-center justify-between">
            <span className="text-[15px] font-semibold text-[#3F3330]">
              {selectedLabel}
            </span>
            <span className="text-[12px] text-[#B5A69C]">
              {dayItems.length} 项安排
            </span>
          </div>
          {dayLoading ? (
            <div className="p-6 space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-14 bg-[#FBF5EF] rounded-xl animate-pulse" />
              ))}
            </div>
          ) : dayItems.length === 0 ? (
            <div className="p-8 text-center">
              <p className="text-[14px] text-[#8A7A72] mb-1">
                {selectedDate === todayStr ? '今天' : selectedLabel}还没有安排
              </p>
              <p className="text-[12px] text-[#B5A69C]">
                去今天页随手记一条，或添加任务吧
              </p>
            </div>
          ) : (
            <div className="divide-y divide-[#F0E6DC] max-h-[660px] overflow-y-auto">
              {dayItems.map((item) => (
                <TimelineRow
                  key={item.id}
                  item={item}
                  onToggle={handleToggle}
                  toggling={togglingId === item.id}
                  onDelete={handleDeleteItem}
                />
              ))}
            </div>
          )}
        </div>
      </div>
      {confirmingDelId && (
        <>
          <div
            className="fixed inset-0 z-40 bg-[#3F3330]/25"
            onClick={() => setConfirmingDelId(null)}
            aria-hidden="true"
          />
          <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 bg-white rounded-2xl border border-[#F0E6DC] p-4 shadow-xl w-[260px]">
            <p className="text-[14px] text-[#3F3330] font-medium mb-3">
              确定删除这条待办吗？
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmingDelId(null)}
                className="text-[12px] px-3 py-1.5 rounded-lg bg-[#FBF5EF] text-[#8A7A72] font-medium"
              >
                取消
              </button>
              <button
                type="button"
                onClick={() => handleUnscheduledDelete(confirmingDelId)}
                className="text-[12px] px-3 py-1.5 rounded-lg bg-[#C96F62] text-white font-medium"
              >
                确认删除
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default PlanPage;
