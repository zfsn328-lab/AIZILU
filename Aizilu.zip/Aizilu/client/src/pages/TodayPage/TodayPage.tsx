import { useEffect, useState } from 'react';
import { CalendarDays, ChevronDown, ChevronUp, Sparkles, Sun, Moon, Coffee } from 'lucide-react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import * as api from '@client/src/api/today';
import { createQuickNote, deleteQuickNote, toggleQuickNoteDone } from '@client/src/api/quick-note';
import { togglePlanEvent, togglePlanHabit, deletePlanTask, deletePlanEvent, deletePlanHabit } from '@client/src/api/plan';
import { getCalendarExport } from '@client/src/api/calendar';
import { downloadCalendarIcs } from '@client/src/utils/ics';
import type { QuickNoteType, TodayAiSuggestion, TodayOverview, TodayTimelineItem } from '@shared/api.interface';
import CompletionRing from './CompletionRing';
import OverviewCards from './OverviewCards';
import { TimelineItem } from './TimelineItem';

const getGreetingIcon = () => {
  const hour = new Date().getHours();
  if (hour < 11) return Sun;
  if (hour < 18) return Coffee;
  return Moon;
};

const formatDate = (dateStr: string) => {
  const date = new Date(dateStr);
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const weekdays = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
  const weekday = weekdays[date.getDay()];
  return `${month}月${day}日 ${weekday}`;
};

const TodayPage = () => {
  const [overview, setOverview] = useState<TodayOverview | null>(null);
  const [timeline, setTimeline] = useState<TodayTimelineItem[]>([]);
  const [suggestion, setSuggestion] = useState<TodayAiSuggestion | null>(null);
  const [loading, setLoading] = useState(true);

  const handleCreateNote = async (
    content: string,
    remindAt?: string | null,
    type?: QuickNoteType,
    repeatMonthDaily?: boolean,
    selectedDates?: string[],
    periodDays?: number | null,
  ) => {
    // 「选择日期」多选：为每个选中日期创建一条
    if (selectedDates && selectedDates.length > 0) {
      const base = remindAt ? new Date(remindAt) : new Date();
      let created = 0;
      let past = 0;
      if (type === 'habit' || type === 'goal') {
        // 打卡/目标本身按日打卡，只建一条即可覆盖
        const { remindPast } = await createQuickNote(content, remindAt, type, periodDays);
        created = 1;
        if (remindPast) past = 1;
      } else {
        for (const ds of selectedDates) {
          const [y, m, d] = ds.split('-').map(Number);
          let iso: string | null = null;
          if (remindAt) {
            iso = new Date(y, m - 1, d, base.getHours(), base.getMinutes()).toISOString();
          } else {
            // 未选时间：以每天 09:00 为锚
            iso = new Date(y, m - 1, d, 9, 0).toISOString();
          }
          const { remindPast } = await createQuickNote(content, iso, type);
          created += 1;
          if (remindPast) past += 1;
        }
      }
      try {
        const [ov, tl] = await Promise.all([api.getOverview(), api.getTimeline()]);
        setOverview(ov);
        setTimeline(tl);
      } catch (err: unknown) {
        logger.error('刷新时间轴失败', err);
      }
      toast.success(
        type === 'habit' || type === 'goal'
          ? '已创建，打卡/目标无需按日重复'
          : `已为选中的 ${created} 个日期创建`,
      );
      return { remindPast: past > 0 };
    }
    // 「本月每天」：从所选日期/今天起，到本月最后一天每天创建一条
    if (repeatMonthDaily) {
      const base = remindAt ? new Date(remindAt) : new Date();
      const year = base.getFullYear();
      const month = base.getMonth();
      const lastDay = new Date(year, month + 1, 0).getDate();
      const startDay = base.getDate();
      let created = 0;
      let past = 0;
      if (type === 'habit' || type === 'goal') {
        // 打卡/目标本身按日打卡，只建一条即可覆盖全月
        const { remindPast } = await createQuickNote(content, remindAt, type, periodDays);
        created = 1;
        if (remindPast) past = 1;
      } else {
        for (let d = startDay; d <= lastDay; d++) {
          let iso: string | null = null;
          if (remindAt) {
            const dt = new Date(
              year,
              month,
              d,
              base.getHours(),
              base.getMinutes(),
            );
            iso = dt.toISOString();
          } else {
            // 未选时间：以每天 09:00 为锚，保证每天各占一天（服务端按 +8h 落日期）
            iso = new Date(year, month, d, 9, 0).toISOString();
          }
          const { remindPast } = await createQuickNote(content, iso, type);
          created += 1;
          if (remindPast) past += 1;
        }
      }
      try {
        const [ov, tl] = await Promise.all([api.getOverview(), api.getTimeline()]);
        setOverview(ov);
        setTimeline(tl);
      } catch (err: unknown) {
        logger.error('刷新时间轴失败', err);
      }
      toast.success(
        type === 'habit' || type === 'goal'
          ? `已创建，本月每天自动打卡`
          : `已为本月每天创建 ${created} 条`,
      );
      return { remindPast: past > 0 };
    }
    const { remindPast } = await createQuickNote(content, remindAt, type, periodDays);
    // 保存后刷新时间轴与概览卡：带当天提醒时间的随手记会出现在「今日安排」中
    try {
      const [ov, tl] = await Promise.all([api.getOverview(), api.getTimeline()]);
      setOverview(ov);
      setTimeline(tl);
    } catch (err: unknown) {
      logger.error('刷新时间轴失败', err);
    }
    return { remindPast };
  };
  const [error, setError] = useState<string | null>(null);
  const [showCompleted, setShowCompleted] = useState(false);
  const [togglingId, setTogglingId] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);

  const handleExportCalendar = async () => {
    if (exporting) return;
    setExporting(true);
    try {
      const { items } = await getCalendarExport(90);
      if (items.length === 0) {
        toast('还没有可导出的安排，先记一件吧');
        return;
      }
      const { count, filename } = downloadCalendarIcs(items);
      toast.success(`已导出 ${count} 条安排，打开文件即可导入手机日历`);
    } catch (e: unknown) {
      logger.error('导出日历失败', e);
      toast.error('导出失败，请稍后重试');
    } finally {
      setExporting(false);
    }
  };

  useEffect(() => {
    let mounted = true;
    const loadData = async () => {
      setLoading(true);
      setError(null);
      try {
        const [ov, tl, sg] = await Promise.all([
          api.getOverview(),
          api.getTimeline(),
          api.getSuggestion(),
        ]);
        if (!mounted) return;
        setOverview(ov);
        setTimeline(tl);
        setSuggestion(sg);
      } catch (e: unknown) {
        if (!mounted) return;
        setError('加载失败，请稍后重试');
        logger.error('今日页面加载失败', e);
      } finally {
        if (mounted) setLoading(false);
      }
    };
    loadData();
    // 页面从后台切回/恢复时强制重新拉取，避免看到旧数据
    const onVisible = () => {
      if (!document.hidden) loadData();
    };
    const onPageShow = (e: PageTransitionEvent) => {
      if (e.persisted) loadData();
    };
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('pageshow', onPageShow);
    return () => {
      mounted = false;
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('pageshow', onPageShow);
    };
  }, []);

  const handleToggleTask = async (item: TodayTimelineItem) => {
    if (togglingId) return;
    setTogglingId(item.id);
    // 乐观更新：立即勾选/取消勾选，失败再回滚
    let prevStatus: string | undefined;
    setTimeline((prev) =>
      prev.map((t) => {
        if (t.id === item.id && t.type === item.type) {
          prevStatus = t.status;
          const nextStatus =
            t.type === 'note'
              ? t.status === 'done'
                ? 'pending'
                : 'done'
              : t.status === 'done'
                ? 'todo'
                : 'done';
          return { ...t, status: nextStatus };
        }
        return t;
      }),
    );
    // 任务完成会影响概览卡（完成数/完成率/待办数）；日程/习惯/随手记仅影响时间轴分组
    const isTask = item.type === 'task';
    if (isTask) {
      setOverview((prev) => {
        if (!prev) return prev;
        const delta = prevStatus === 'done' ? -1 : 1;
        return {
          ...prev,
          completedCount: Math.max(0, prev.completedCount + delta),
          pendingTaskCount: Math.max(0, prev.pendingTaskCount - delta),
          totalCount: prev.totalCount,
          completionRate:
            prev.totalCount === 0
              ? 0
              : Math.max(0, prev.completedCount + delta) / prev.totalCount,
        };
      });
    }
    try {
      const todayStr = new Date().toISOString().slice(0, 10);
      let status: string;
      if (item.type === 'task') {
        status = (await api.toggleTask(item.id)).status;
      } else if (item.type === 'event') {
        status = await togglePlanEvent(item.id);
      } else if (item.type === 'note') {
        const { isDone } = await toggleQuickNoteDone(item.id);
        status = isDone ? 'done' : 'pending';
      } else {
        status = await togglePlanHabit(item.id, todayStr);
      }
      const becameDone = status === 'done';
      setTimeline((prev) =>
        prev.map((t) =>
          t.id === item.id && t.type === item.type
            ? { ...t, status }
            : t,
        ),
      );
      toast.success(
        becameDone ? '已完成，辛苦啦' : '已恢复为未完成',
        {
          description: becameDone ? '点一下可以撤销' : '可以继续加油',
          action: {
            label: '撤销',
            onClick: () => {
              const revert = async () => {
                const todayStr2 = new Date().toISOString().slice(0, 10);
                let r: string;
                if (item.type === 'task') {
                  r = (await api.toggleTask(item.id)).status;
                } else if (item.type === 'event') {
                  r = await togglePlanEvent(item.id);
                } else if (item.type === 'note') {
                  const { isDone } = await toggleQuickNoteDone(item.id);
                  r = isDone ? 'done' : 'pending';
                } else {
                  r = await togglePlanHabit(item.id, todayStr2);
                }
                const restored = r === 'done';
                setTimeline((prev) =>
                  prev.map((t) =>
                    t.id === item.id && t.type === item.type
                      ? { ...t, status: r }
                      : t,
                  ),
                );
                if (isTask) {
                  setOverview((ov) => {
                    if (!ov) return ov;
                    const d = restored ? 1 : -1;
                    return {
                      ...ov,
                      completedCount: Math.max(0, ov.completedCount + d),
                      pendingTaskCount: Math.max(0, ov.pendingTaskCount - d),
                      completionRate:
                        ov.totalCount === 0
                          ? 0
                          : Math.max(0, ov.completedCount + d) / ov.totalCount,
                    };
                  });
                }
              };
              void revert();
            },
          },
        },
      );
    } catch (e: unknown) {
      // 失败回滚
      setTimeline((prev) =>
        prev.map((t) =>
          t.id === item.id && t.type === item.type
            ? { ...t, status: prevStatus ?? 'todo' }
            : t,
        ),
      );
      if (isTask) {
        setOverview((prev) => {
          if (!prev) return prev;
          const d = prevStatus === 'done' ? 1 : -1;
          return {
            ...prev,
            completedCount: Math.max(0, prev.completedCount + d),
            pendingTaskCount: Math.max(0, prev.pendingTaskCount - d),
            completionRate:
              prev.totalCount === 0
                ? 0
                : Math.max(0, prev.completedCount + d) / prev.totalCount,
          };
        });
      }
      logger.error('切换状态失败', e);
      toast.error('操作失败，请稍后重试');
    } finally {
      setTogglingId(null);
    }
  };

  const handleDeleteItem = async (item: TodayTimelineItem) => {
    try {
      if (item.type === 'task') await deletePlanTask(item.id);
      else if (item.type === 'event') await deletePlanEvent(item.id);
      else if (item.type === 'habit') await deletePlanHabit(item.id);
      else await deleteQuickNote(item.id);
      const [ov, tl] = await Promise.all([api.getOverview(), api.getTimeline()]);
      setOverview(ov);
      setTimeline(tl);
      toast.success('已删除');
    } catch (e: unknown) {
      logger.error('删除失败', e);
      toast.error('删除失败，请稍后重试');
    }
  };

  const handleAdoptSuggestion = async () => {
    if (!suggestion) return;
    try {
      await api.adoptSuggestion(suggestion.id);
      setSuggestion(null);
    } catch (e: unknown) {
      logger.error('采纳建议失败', e);
    }
  };

  const handleDismissSuggestion = async () => {
    if (!suggestion) return;
    try {
      await api.dismissSuggestion(suggestion.id);
      setSuggestion(null);
    } catch (e: unknown) {
      logger.error('忽略建议失败', e);
    }
  };

  const pendingItems = timeline.filter((t) => t.status !== 'done' && t.status !== 'cancelled');
  const completedItems = timeline.filter((t) => t.status === 'done' || t.status === 'cancelled');
  const totalItems = pendingItems.length + completedItems.length;

  const GreetingIcon = getGreetingIcon();
  const isEmpty = !loading && !error && timeline.length === 0;

  if (loading) {
    return (
      <div className="space-y-5">
        <div className="h-20 bg-white rounded-2xl border border-[#F0E6DC] animate-pulse" />
        <div className="grid grid-cols-3 gap-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-28 bg-white rounded-2xl border border-[#F0E6DC] animate-pulse" />
          ))}
        </div>
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-24 bg-white rounded-2xl border border-[#F0E6DC] animate-pulse" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-2xl border border-[#F0E6DC] p-8 text-center">
        <p className="text-[#C96F62] text-[15px]">{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* 顶部问候区 */}
      <div
        className="bg-white rounded-2xl border border-[#F0E6DC] p-5 flex items-center justify-between"
        style={{ boxShadow: '0 2px 10px rgba(196, 135, 122, 0.10)' }}
      >
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 text-[#8A7A72] text-[13px] mb-1">
            <GreetingIcon size={14} strokeWidth={2} />
            <span>{formatDate(overview?.date ?? new Date().toISOString())}</span>
          </div>
          <h1 className="text-[22px] md:text-[24px] font-semibold text-[#3F3330] leading-tight">
            {overview?.greeting ?? '你好呀'}
          </h1>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
           onClick={handleExportCalendar}
             disabled={exporting}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#FBF5EF] border border-[#F0E6DC] text-[#8A7A72] text-[13px] font-medium hover:bg-[#F0E6DC] hover:text-[#3F3330] transition-colors disabled:opacity-60"
            title="导出未来 90 天安排为日历文件，导入手机日历"
          >
            <CalendarDays size={15} strokeWidth={2} />
            <span>{exporting ? '导出中…' : '导出日历'}</span>
          </button>
          <CompletionRing
            rate={totalItems > 0 ? completedItems.length / totalItems : 0}
            completed={completedItems.length}
            total={totalItems}
          />
        </div>
      </div>

      {/* 概览三卡 */}
      <OverviewCards
        pendingTaskCount={overview?.pendingTaskCount ?? 0}
        eventCount={overview?.eventCount ?? 0}
        habitCount={overview?.habitCount ?? 0}
        activeGoalsCount={overview?.activeGoalsCount ?? 0}
      />

      {/* AI 今日建议卡 */}
      {suggestion && (
        <div
          className="bg-white rounded-2xl border border-[#F0E6DC] p-5 relative overflow-hidden"
          style={{ boxShadow: '0 2px 10px rgba(196, 135, 122, 0.10)' }}
        >
          <div className="absolute left-0 top-0 bottom-0 w-[3px] bg-[#C4877A]" />
          <div className="pl-1">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles size={16} color="#C4877A" strokeWidth={2} />
              <span className="text-[13px] font-medium text-[#C4877A]">
                AI 今日建议
              </span>
            </div>
            <p className="text-[15px] text-[#3F3330] leading-relaxed mb-2">
              {suggestion.content}
            </p>
            <p className="text-[13px] text-[#B5A69C] mb-4">
              数据来源：{suggestion.dataSource}
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleAdoptSuggestion}
                className="px-4 py-2 rounded-xl bg-[#C4877A] text-white text-[14px] font-medium hover:bg-[#A96A5C] transition-colors"
              >
                采用
              </button>
              <button
                type="button"
                onClick={handleDismissSuggestion}
                className="px-4 py-2 rounded-xl bg-[#FBF5EF] text-[#8A7A72] text-[14px] hover:bg-[#F0E6DC] transition-colors"
              >
                忽略
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 空状态 */}
      {isEmpty && (
        <div className="bg-white rounded-2xl border border-[#F0E6DC] p-8 text-center"
          style={{ boxShadow: '0 2px 10px rgba(196, 135, 122, 0.10)' }}
        >
          <div className="w-12 h-12 mx-auto mb-3 rounded-xl bg-[#FBF5EF] flex items-center justify-center">
            <Sparkles size={22} color="#C4877A" strokeWidth={2} />
          </div>
          <p className="text-[15px] text-[#3F3330] mb-2">
            今天还没有安排。
          </p>
          <p className="text-[13px] text-[#8A7A72] mb-4">
            对着豆包说一句话试试。
          </p>
          <button
            type="button"
            className="px-4 py-2 rounded-xl bg-[#C4877A] text-white text-[14px] font-medium hover:bg-[#A96A5C] transition-colors"
          >
            下午三点开会
          </button>
        </div>
      )}

      {/* 时间轴 */}
      {pendingItems.length > 0 && (
        <div>
          <h2 className="text-[18px] font-semibold text-[#3F3330] mb-4 px-1">
            今日安排
          </h2>
          <div className="space-y-0">
            {pendingItems.map((item) => (
              <TimelineItem
                key={item.id}
                item={item}
                onToggle={() => handleToggleTask(item)}
                onDelete={() => handleDeleteItem(item)}
              />
            ))}
          </div>
        </div>
      )}

      {/* 已完成折叠区 */}
      {completedItems.length > 0 && (
        <div>
          <button
            type="button"
            onClick={() => setShowCompleted((v) => !v)}
            className="flex items-center gap-2 text-[13px] text-[#8A7A72] hover:text-[#3F3330] transition-colors px-1 mb-2"
          >
            {showCompleted ? (
              <ChevronUp size={14} strokeWidth={2} />
            ) : (
              <ChevronDown size={14} strokeWidth={2} />
            )}
            <span>查看已完成 {completedItems.length} 项</span>
          </button>
          {showCompleted && (
            <div className="space-y-0">
              {completedItems.map((item) => (
                <TimelineItem
                  key={item.id}
                  item={item}
                  onToggle={() => handleToggleTask(item)}
                  onDelete={() => handleDeleteItem(item)}
                />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default TodayPage;
