import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  DayTimelineItem,
  GoalItem,
  HabitItem,
  HabitProgressItem,
  MonthViewData,
  UnscheduledTask,
  WeekViewData,
} from '@shared/api.interface';

export async function getHabitProgress(month: string): Promise<HabitProgressItem[]> {
  try {
    const { data } = await axiosForBackend.get<HabitProgressItem[]>(
      '/api/plan/habit-progress',
      { params: { month } },
    );
    return data;
  } catch (error: unknown) {
    logger.error('获取习惯进度失败', error);
    throw error;
  }
}

export async function getWeekView(date: string): Promise<WeekViewData> {
  try {
    const { data } = await axiosForBackend.get<WeekViewData>(
      '/api/plan/week',
      { params: { date } },
    );
    return data;
  } catch (error: unknown) {
    logger.error('获取周视图失败', error);
    throw error;
  }
}

export async function getMonthView(month: string): Promise<MonthViewData> {
  try {
    const { data } = await axiosForBackend.get<MonthViewData>(
      '/api/plan/month',
      { params: { month } },
    );
    return data;
  } catch (error: unknown) {
    logger.error('获取月视图失败', error);
    throw error;
  }
}

export async function getDayItems(date: string): Promise<DayTimelineItem[]> {
  try {
    const { data } = await axiosForBackend.get<{ items: DayTimelineItem[] }>(
      '/api/plan/day',
      { params: { date, _t: Date.now() } },
    );
    return data.items;
  } catch (error: unknown) {
    logger.error('获取当日安排失败', error);
    throw error;
  }
}

export async function togglePlanTask(id: string): Promise<string> {
  try {
    const { data } = await axiosForBackend.post<{ status: string }>(
      `/api/today/tasks/${id}/toggle`,
    );
    return data.status;
  } catch (error: unknown) {
    logger.error('切换任务状态失败', error);
    throw error;
  }
}

export async function togglePlanHabit(id: string, date: string): Promise<string> {
  try {
    const { data } = await axiosForBackend.post<{ status: string }>(
      `/api/plan/habits/${id}/toggle`,
      { date },
    );
    return data.status;
  } catch (error: unknown) {
    logger.error('打卡失败', error);
    throw error;
  }
}

export async function togglePlanEvent(id: string): Promise<string> {
  try {
    const { data } = await axiosForBackend.post<{ status: string }>(
      `/api/plan/events/${id}/toggle`,
    );
    return data.status;
  } catch (error: unknown) {
    logger.error('切换日程状态失败', error);
    throw error;
  }
}

export async function deletePlanTask(id: string): Promise<void> {
  try {
    await axiosForBackend.delete(`/api/plan/tasks/${id}`);
  } catch (error: unknown) {
    logger.error('删除任务失败', error);
    throw error;
  }
}

export async function deletePlanEvent(id: string): Promise<void> {
  try {
    await axiosForBackend.delete(`/api/plan/events/${id}`);
  } catch (error: unknown) {
    logger.error('删除日程失败', error);
    throw error;
  }
}

export async function deletePlanHabit(id: string): Promise<void> {
  try {
    await axiosForBackend.delete(`/api/plan/habits/${id}`);
  } catch (error: unknown) {
    logger.error('删除习惯失败', error);
    throw error;
  }
}

export async function deletePlanGoal(id: string): Promise<void> {
  try {
    await axiosForBackend.delete(`/api/plan/goals/${id}`);
  } catch (error: unknown) {
    logger.error('删除目标失败', error);
    throw error;
  }
}

export async function getUnscheduledTasks(): Promise<UnscheduledTask[]> {
  try {
    const { data } = await axiosForBackend.get<UnscheduledTask[]>(
      '/api/plan/unscheduled',
    );
    return data;
  } catch (error: unknown) {
    logger.error('获取待安排任务失败', error);
    throw error;
  }
}

export async function getActiveHabits(): Promise<HabitItem[]> {
  try {
    const { data } = await axiosForBackend.get<HabitItem[]>(
      '/api/plan/habits',
    );
    return data;
  } catch (error: unknown) {
    logger.error('获取习惯列表失败', error);
    throw error;
  }
}

export async function getActiveGoals(): Promise<GoalItem[]> {
  try {
    const { data } = await axiosForBackend.get<GoalItem[]>(
      '/api/plan/goals',
    );
    return data;
  } catch (error: unknown) {
    logger.error('获取目标列表失败', error);
    throw error;
  }
}

export async function checkinGoal(id: string, date?: string): Promise<GoalItem> {
  try {
    const { data } = await axiosForBackend.post<GoalItem>(
      `/api/plan/goals/${id}/checkin`,
      null,
      { params: date ? { date } : {} },
    );
    return data;
  } catch (error: unknown) {
    logger.error('目标打卡失败', error);
    throw error;
  }
}
