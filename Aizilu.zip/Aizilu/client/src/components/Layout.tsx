import { NavLink, Outlet } from 'react-router-dom';
import {
  CalendarDays,
  LayoutGrid,
  BarChart3,
} from 'lucide-react';
import { ReminderCenter } from '@client/src/components/ReminderCenter';

const navItems = [
  {
    path: '/today',
    label: '今天',
    icon: CalendarDays,
  },
  {
    path: '/plan',
    label: '计划',
    icon: LayoutGrid,
  },
  {
    path: '/review',
    label: '复盘',
    icon: BarChart3,
  },
];

const Layout = () => {
  return (
    <div className="min-h-screen bg-[#FBF5EF] text-[#3F3330]">
      <ReminderCenter />
      {/* 桌面端左侧导航 */}
      <aside className="hidden lg:flex lg:flex-col lg:fixed lg:left-0 lg:top-0 lg:h-screen lg:w-[240px] lg:bg-white lg:border-r lg:border-[#F0E6DC] lg:z-40 layout-sidebar">
        <div className="px-6 pt-8 pb-6">
          <h1 className="text-[20px] font-semibold text-[#3F3330] tracking-wide">
            AI自律执行工作台
          </h1>
          <p className="text-[13px] text-[#8A7A72] mt-1">让自律变成日常</p>
        </div>

        <nav className="flex-1 px-3 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const showBadge = false;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-4 py-2.5 rounded-xl text-[15px] transition-colors relative ${
                    isActive
                      ? 'bg-[#FBF5EF] text-[#C4877A] font-medium'
                      : 'text-[#3F3330] hover:bg-[#FBF5EF]'
                  }`
                }
              >
                <Icon size={18} strokeWidth={2} />
                <span>{item.label}</span>
              </NavLink>
            );
          })}
        </nav>
      </aside>

      {/* 主内容区 */}
      <main className="lg:ml-[240px] pb-[calc(96px+env(safe-area-inset-bottom))] lg:pb-0 min-h-screen">
        <div className="max-w-[720px] mx-auto px-4 lg:px-6 py-6">
          <Outlet />
        </div>
      </main>

      {/* 移动端底部 Tab */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-[#F0E6DC] z-[2147483647] layout-tabbar">
        <div className="flex items-center px-1 py-2 pb-[max(8px,env(safe-area-inset-bottom))]">
          {navItems.map((item) => {
            const Icon = item.icon;
            const showBadge = false;
            return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) =>
                    `flex-1 flex flex-col items-center gap-1 py-1 rounded-lg relative ${
                      isActive ? 'text-[#C4877A]' : 'text-[#8A7A72]'
                    }`
                  }
              >
                <div className="relative">
                  <Icon size={20} strokeWidth={2} />
                </div>
                <span className="text-[11px]">{item.label}</span>
              </NavLink>
            );
          })}
        </div>
      </nav>
    </div>
  );
};

export default Layout;
