// 前后端共享的类型定义

// ========== 通用 ==========
export interface PagedResponse<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

export type TaskStatus = 'todo' | 'doing' | 'done' | 'cancelled';
export type TaskPriority = 'P0' | 'P1' | 'P2' | 'P3';
export type EventStatus = 'planned' | 'done' | 'cancelled';
export type EventType = 'meeting' | 'course' | 'travel' | 'personal' | 'other';
export type HabitStatus = 'active' | 'paused' | 'archived';
export type HabitLogStatus = 'done' | 'missed' | 'makeup' | 'skipped';
export type GoalStatus = 'active' | 'paused' | 'achieved' | 'abandoned';
export type InboxStatus = 'pending' | 'confirmed' | 'ignored' | 'expired';
export type ReviewType = 'daily' | 'weekly' | 'monthly';

// ========== Task ==========
export interface TaskItem {
  recordId: string;
  title: string;
  description: string | null;
  dueDate: string | null;
  dueTime: string | null;
  dueType: string;
  estimateMinutes: number;
  priority: TaskPriority;
  status: TaskStatus;
  goalId: string | null;
  tags: string[];
  context: string | null;
  scheduledSlot: string | null;
  isPinned: boolean;
  completedAt: string | null;
  sourceText: string | null;
  createdAt: string;
  updatedAt: string;
}

// ========== Event ==========
export interface EventItem {
  recordId: string;
  title: string;
  description: string | null;
  startDatetime: string;
  endDatetime: string | null;
  isAllDay: boolean;
  durationMinutes: number;
  location: string | null;
  participants: string | null;
  eventType: EventType;
  leadMinutes: number;
  status: EventStatus;
  sourceTaskId: string | null;
  timezone: string;
  createdAt: string;
  updatedAt: string;
}

// ========== Habit ==========
export interface HabitItem {
  recordId: string;
  name: string;
  frequencyType: string;
  frequencyValue: number;
  targetWeekdays: string[];
  catchUpWindow: number;
  timeSlot: string;
  suggestedTime: string | null;
  durationMinutes: number;
  cue: string | null;
  goalId: string | null;
  startDate: string;
  endDate: string | null;
  periodDays: number | null;
  periodDoneDays: number;
  periodTotalDays: number | null;
  periodProgressPercent: number;
  status: HabitStatus;
  currentStreak: number;
  bestStreak: number;
  completionRate30d: number;
  reminderEnabled: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface HabitLogItem {
  recordId: string;
  habitId: string;
  logDate: string;
  status: HabitLogStatus;
  completedAt: string | null;
  note: string | null;
}

// ========== Goal ==========
export interface GoalItem {
  recordId: string;
  title: string;
  description: string | null;
  category: string;
  metricType: string;
  targetValue: number | null;
  currentValue: number;
  unit: string;
  progressSource: string;
  startDate: string;
  targetDate: string;
  periodDays: number | null;
  periodDoneDays: number;
  periodRemain: number;
  status: GoalStatus;
  progressPercent: number;
  achievedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

// ========== Inbox ==========
export interface InboxItem {
  recordId: string;
  rawInput: string;
  inputType: string;
  sourceImageUrl: string | null;
  parsedJson: string | null;
  suggestedType: string | null;
  draftPayload: string | null;
  confidence: number | null;
  confidenceDetail: string | null;
  ambiguityReason: string[];
  questionText: string | null;
  questionOptions: string[] | null;
  batchId: string | null;
  batchIndex: number | null;
  status: InboxStatus;
  resolvedTargetType: string | null;
  resolvedTargetId: string | null;
  nudgeCount: number;
  createdAt: string;
  updatedAt: string;
  expireAt: string;
}

export interface InboxBatchItem {
  batchId: string;
  items: InboxItem[];
  totalCount: number;
}

// ========== Review ==========
export interface ReviewItem {
  recordId: string;
  reviewType: ReviewType;
  periodStart: string;
  periodEnd: string;
  plannedCount: number;
  completedCount: number;
  newAddedCount: number;
  completionRate: number;
  completionRateInclNew: number;
  delayedCount: number;
  newDelayedCount: number;
  cancelledCount: number;
  estDeepWorkMinutes: number;
  actualTrackedMinutes: number;
  eventHours: number;
  habitTotal: number;
  habitDone: number;
  habitRate: number;
  topDelayedTasks: string | null;
  goalProgress: string | null;
  highlights: string | null;
  issues: string | null;
  adviceItems: string | null;
  weekdayHeatmap: string | null;
  summaryText: string | null;
  generatedAt: string;
  laterUpdateCount: number;
  deliveryStatus: string;
  userRead: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DailyMetricItem {
  recordId: string;
  metricDate: string;
  plannedCount: number;
  completedCount: number;
  newAddedCount: number;
  delayedCount: number;
  completionRate: number;
  estDeepWorkMinutes: number;
  eventCount: number;
  habitTotal: number;
  habitDone: number;
  inboxPending: number;
  snapshotAt: string | null;
  isFinal: boolean;
}

// ========== 「今天」页面聚合 ==========
export interface TodayOverview {
  date: string;
  greeting: string;
  completionRate: number;
  completedCount: number;
  totalCount: number;
  pendingTaskCount: number;
  eventCount: number;
  habitCount: number;
  habitDoneCount: number;
  pendingInboxCount: number;
  activeGoalsCount: number;
}

export interface TodayTimelineItem {
  id: string;
  type: 'task' | 'event' | 'habit' | 'note';
  timeLabel: string;
  sortTime: string;
  title: string;
  status: string;
  subtitle?: string;
  eventType?: EventType;
  priority?: TaskPriority;
}

export interface TodayAiSuggestion {
  id: string;
  content: string;
  dataSource: string;
  action: string;
}

// ========== 「计划」周视图 ==========
export interface WeekViewData {
  weekStart: string;
  weekEnd: string;
  days: WeekDayData[];
}

export interface WeekDayData {
  date: string;
  weekday: number;
  isToday: boolean;
  morning: WeekSlotItem[];
  afternoon: WeekSlotItem[];
  evening: WeekSlotItem[];
}

export interface WeekSlotItem {
  id: string;
  type: 'task' | 'event' | 'habit' | 'note';
  title: string;
  status: string;
  eventType?: EventType;
  timeLabel?: string;
}

export interface UnscheduledTask {
  recordId: string;
  title: string;
  estimateMinutes: number;
  priority: TaskPriority;
}

// ========== 月历视图 ==========
export interface MonthDayData {
  date: string;          // YYYY-MM-DD
  weekday: number;       // ISO 1=Mon..7=Sun
  isToday: boolean;
  inMonth: boolean;      // 是否属于当前月（相邻月补位日期为 false）
  taskCount: number;
  eventCount: number;
  noteCount: number;
  total: number;
}

export interface MonthViewData {
  month: string;         // YYYY-MM
  year: number;
  monthIndex: number;    // 1-12
  days: MonthDayData[];  // 从当月1号到月末
}

export interface DayTimelineItem {
  id: string;
  type: 'task' | 'event' | 'habit' | 'note';
  title: string;
  status: string;
  timeLabel?: string;
  eventType?: EventType;
}

export interface HabitProgressItem {
  recordId: string;
  name: string;
  dueDays: number;   // 当月应打卡天数
  doneDays: number;  // 当月已打卡天数
  rate: number;      // 0-1
}

// ========== Quick Note 随手记 ==========
export interface QuickNoteItem {
  recordId: string;
  content: string;
  noteDate: string;
  noteTime: string | null;
  remindAt: string | null;
  createdAt: string;
  isDone?: boolean;
  type?: QuickNoteType;
}

export type QuickNoteType = 'note' | 'task' | 'event' | 'habit' | 'goal';

// ========== 「复盘」指标 ==========
export interface ReviewMetrics {
  period: 'today' | 'week' | 'month';
  completionRate: number;
  completedCount: number;
  delayedCount: number;
  estDeepWorkMinutes: number;
}

// ========== 日历导出 ==========
export interface CalendarExportItem {
  type: 'event' | 'task' | 'note';
  title: string;
  description?: string;
  /** ISO 时间（带时间）或 YYYY-MM-DD（全天） */
  start: string;
  /** ISO 时间或 undefined */
  end?: string;
  isAllDay?: boolean;
  reminderMinutes?: number;
  location?: string;
}

// ========== 目标拆解 ==========
export interface BreakdownStep {
  id: string;
  text: string;
  dueDate: string;
  dueLabel: string;
  done: boolean;
}

export type BreakdownStatus = 'pending' | 'confirmed' | 'done';

export interface BreakdownItem {
  recordId: string;
  title: string;
  steps: BreakdownStep[];
  status: BreakdownStatus;
  confirmedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface UpdateBreakdownTitleRequest {
  title: string;
}

export interface UpdateBreakdownStepInput {
  id?: string;
  text: string;
}

export interface UpdateBreakdownRequest {
  title: string;
  steps?: UpdateBreakdownStepInput[];
}
