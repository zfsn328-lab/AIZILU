import { useEffect, useRef, useState } from 'react';
import {
  Workflow,
  CheckCircle2,
  Sparkles,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import * as api from '@client/src/api/breakdown';
import type { BreakdownItem } from '@shared/api.interface';
import BreakdownItemActions from './BreakdownItemActions';

interface ChatMsg {
  role: 'user' | 'ai';
  text: string;
  breakdown?: BreakdownItem;
}

const BreakdownPage = () => {
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [list, setList] = useState<BreakdownItem[]>([]);
  const [confirmingId, setConfirmingId] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let mounted = true;
    api
      .getBreakdowns()
      .then((items) => {
        if (!mounted) return;
        setList(items);
      })
      .catch((err: unknown) => logger.error('加载拆解列表失败', err));
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, list]);

  const handleConfirm = async (item: BreakdownItem) => {
    if (confirmingId) return;
    setConfirmingId(item.recordId);
    try {
      const updated = await api.confirmBreakdown(item.recordId);
      setList((prev) =>
        prev.map((b) => (b.recordId === updated.recordId ? updated : b)),
      );
      setMessages((prev) =>
        prev.map((m) =>
          m.breakdown?.recordId === updated.recordId
            ? { ...m, breakdown: updated }
            : m,
        ),
      );
      setMessages((prev) => [
        ...prev,
        {
          role: 'ai',
          text: `好的，已经把「${item.title}」拆好的任务放进待办啦！一步一步来，你可以的！`,
        },
      ]);
    } catch (err: unknown) {
      logger.error('确认拆解失败', err);
    } finally {
      setConfirmingId(null);
    }
  };

  const handleUpdated = (updated: BreakdownItem) => {
    setList((prev) =>
      prev.map((b) => (b.recordId === updated.recordId ? updated : b)),
    );
  };

  const handleDeleted = (id: string) => {
    setList((prev) => prev.filter((b) => b.recordId !== id));
  };

  const confirmedList = list.filter(
    (b) => b.status === 'confirmed' || b.status === 'done',
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center"
          style={{ backgroundColor: 'rgba(196, 135, 122, 0.15)' }}
        >
          <Workflow size={20} color="#C4877A" strokeWidth={2} />
        </div>
        <div>
          <h1 className="text-[18px] font-semibold text-[#3F3330]">
            目标拆解
          </h1>
          <p className="text-[13px] text-[#8A7A72]">
            大目标一步步走 · 帮你拆成可行的小动作
          </p>
        </div>
      </div>

      {messages.length === 0 && list.length === 0 && (
        <div className="bg-white border border-[#F0E6DC] rounded-2xl py-10 px-6 flex flex-col items-center text-center">
          <div
            className="w-14 h-14 rounded-full flex items-center justify-center mb-4"
            style={{ backgroundColor: 'rgba(196, 135, 122, 0.12)' }}
          >
            <Sparkles size={26} color="#C4877A" strokeWidth={2} />
          </div>
          <div className="text-[16px] font-medium text-[#3F3330]">
            还没有拆解目标。
          </div>
          <div className="text-[13px] text-[#8A7A72] mt-1.5">
            对着豆包说一句话试试。
          </div>
          <button
            type="button"
            className="mt-5 px-6 py-2.5 rounded-full text-[14px] font-medium text-white"
            style={{ backgroundColor: '#C4877A' }}
          >
            三个月存两万块
          </button>
        </div>
      )}

      {messages.length > 0 && (
        <div className="bg-white border border-[#F0E6DC] rounded-2xl p-4 space-y-3">
          {messages.map((m, i) => (
            <div
              key={i}
              className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 text-[14px] leading-relaxed ${
                  m.role === 'user'
                    ? 'bg-[#C4877A] text-white rounded-br-md'
                    : 'bg-[#FBF5EF] text-[#3F3330] rounded-bl-md border border-[#F0E6DC]'
                }`}
              >
                <div className="flex items-start gap-2">
                  {m.role === 'ai' && (
                    <Sparkles
                      size={16}
                      color="#C4877A"
                      strokeWidth={2}
                      className="mt-0.5 flex-shrink-0"
                    />
                  )}
                  <div className="min-w-0">
                    <span className="whitespace-pre-wrap">{m.text}</span>
                    {m.breakdown && (
                      <div className="mt-3 space-y-2">
                        <div className="text-[13px] font-medium text-[#C4877A]">
                          任务拆解：{m.breakdown.title}
                        </div>
                        {m.breakdown.steps.map((s, idx) => (
                          <div
                            key={s.id}
                            className="flex items-start gap-2 bg-white border border-[#F0E6DC] rounded-xl px-3 py-2"
                          >
                            <span
                              className="w-5 h-5 rounded-full flex items-center justify-center text-[11px] font-semibold flex-shrink-0"
                              style={{
                                backgroundColor: 'rgba(196, 135, 122, 0.12)',
                                color: '#C4877A',
                              }}
                            >
                              {idx + 1}
                            </span>
                            <div className="min-w-0 flex-1">
                              <div className="text-[13px] text-[#3F3330]">
                                {s.text}
                              </div>
                              <div className="text-[11px] text-[#8A7A72] mt-0.5">
                                {s.dueLabel}
                              </div>
                            </div>
                          </div>
                        ))}
                        {m.breakdown.status === 'pending' ? (
                          <button
                            type="button"
                            onClick={() => handleConfirm(m.breakdown!)}
                            disabled={confirmingId !== null}
                            className="w-full mt-1 py-2 rounded-xl text-[14px] font-medium text-white disabled:opacity-60"
                            style={{ backgroundColor: '#C4877A' }}
                          >
                            {confirmingId === m.breakdown.recordId
                              ? '正在放入待办…'
                              : '就这么定'}
                          </button>
                        ) : (
                          <div className="flex items-center gap-1.5 text-[12px] text-[#7FA98A] font-medium">
                            <CheckCircle2 size={14} />
                            已拆好放进待办啦
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>
      )}

      {confirmedList.length > 0 && (
        <div className="bg-white border border-[#F0E6DC] rounded-2xl p-4">
          <h2 className="text-[14px] font-semibold text-[#3F3330] mb-3">
            已拆解的目标
          </h2>
          <div className="space-y-3">
            {confirmedList.map((b) => {
              const expanded = expandedId === b.recordId;
              const isDone = b.status === 'done';
              return (
                <div
                  key={b.recordId}
                  className="border border-[#F0E6DC] rounded-xl overflow-hidden"
                >
                  <div
                    className="flex items-center gap-2 px-3 py-3 hover:bg-[#FBF5EF] transition-colors cursor-pointer"
                    onClick={() =>
                      setExpandedId((prev) =>
                        prev === b.recordId ? null : b.recordId,
                      )
                    }
                  >
                    <BreakdownItemActions
                      item={b}
                      onUpdated={handleUpdated}
                      onDeleted={handleDeleted}
                    />

                    <span
                      className={`text-[14px] font-medium truncate flex-1 min-w-0 ${
                        isDone
                          ? 'text-[#B5A69C] line-through'
                          : 'text-[#3F3330]'
                      }`}
                    >
                      {b.title}
                    </span>

                    <span className="flex items-center gap-2 flex-shrink-0">
                      <span className="text-[11px] text-[#7FA98A] flex items-center gap-1">
                        <CheckCircle2 size={12} /> 已入待办 {b.steps.length} 步
                      </span>
                      {expanded ? (
                        <ChevronUp
                          size={15}
                          color="#B5A69C"
                          strokeWidth={2}
                        />
                      ) : (
                        <ChevronDown
                          size={15}
                          color="#B5A69C"
                          strokeWidth={2}
                        />
                      )}
                    </span>
                  </div>
                  {expanded && (
                    <div className="px-3 pb-3 pt-1 space-y-1.5">
                      {b.steps.map((s, idx) => (
                        <div
                          key={s.id}
                          className="flex items-center gap-2 text-[13px] text-[#8A7A72]"
                        >
                          <span
                            className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] font-semibold flex-shrink-0 ${
                              s.done
                                ? 'bg-[#7FA98A] text-white'
                                : 'bg-[#FBF5EF] text-[#C4877A]'
                            }`}
                          >
                            {s.done ? '✓' : idx + 1}
                          </span>
                          <span className="flex-1">{s.text}</span>
                          <span
                            className={`text-[11px] flex-shrink-0 ${
                              s.done ? 'text-[#7FA98A]' : 'text-[#B5A69C]'
                            }`}
                          >
                            {s.done ? '已完成' : s.dueLabel}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default BreakdownPage;
