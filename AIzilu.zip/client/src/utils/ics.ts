import type { CalendarExportItem } from '@shared/api.interface';

/** 生成 YYYYMMDD 紧凑日期 */
const compactDate = (d: Date): string => {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}${m}${day}`;
};

/** ICS 时间戳（UTC，YYYYMMDDTHHMMSSZ） */
const icsStamp = (): string => {
  return new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
};

const escapeText = (text: string): string => {
  return text
    .replace(/\\/g, '\\\\')
    .replace(/;/g, '\\;')
    .replace(/,/g, '\\,')
    .replace(/\r?\n/g, '\\n');
};

/** 转义后截断，避免单行过长 */
const clip = (text: string, max = 80): string => {
  const cleaned = escapeText(text);
  return cleaned.length > max ? `${cleaned.slice(0, max)}…` : cleaned;
};

/** ISO 字符串或 YYYY-MM-DD 统一转成 UTC Date */
const toDate = (start: string): Date => {
  if (/^\d{4}-\d{2}-\d{2}$/.test(start)) {
    return new Date(`${start}T00:00:00Z`);
  }
  return new Date(start);
};

/** 全天事件：DTSTART;VALUE=DATE:YYYYMMDD */
const dateOnly = (d: Date): string => compactDate(d);

/** 时间事件：DTSTART;TZID=Asia/Shanghai:YYYYMMDDTHHMMSS（用北京时间显示） */
const withTime = (start: string): string => {
  const d = new Date(start);
  if (Number.isNaN(d.getTime())) return dateOnly(new Date(`${start.slice(0, 10)}T00:00:00Z`));
  const y = d.getFullYear();
  const mo = String(d.getMonth() + 1).padStart(2, '0');
  const da = String(d.getDate()).padStart(2, '0');
  const h = String(d.getHours()).padStart(2, '0');
  const mi = String(d.getMinutes()).padStart(2, '0');
  return `${y}${mo}${da}T${h}${mi}00`;
};

/** 生成 .ics 文件内容并触发下载（对标旧应用「导出日历」体验） */
export function downloadCalendarIcs(items: CalendarExportItem[]): { count: number; filename: string } {
  if (items.length === 0) {
    throw new Error('empty');
  }

  const nowStamp = icsStamp();
  const lines: string[] = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Xiao Richang//CN',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
    'X-WR-CALNAME:AI自律执行工作台',
  ];

  const usedUids = new Set<string>();
  items.forEach((it, idx) => {
    const isAllDay = it.isAllDay || /^\d{4}-\d{2}-\d{2}$/.test(it.start);
    const uidBase = `xrc-${String(it.type)}-${String(idx)}-${compactDate(toDate(it.start))}`;
    let uid = uidBase;
    let n = 1;
    while (usedUids.has(uid)) {
      uid = `${uidBase}-${n}`;
      n += 1;
    }
    usedUids.add(uid);

    const summaryPrefix = it.type === 'event' ? '' : it.type === 'task' ? '【待办】' : '【随手记】';
    const summary = `${summaryPrefix}${clip(it.title, 60)}`;

    lines.push('BEGIN:VEVENT');
    lines.push(`UID:${uid}@xiaorichang.local`);
    lines.push(`DTSTAMP:${nowStamp}`);

    if (isAllDay) {
      lines.push(`DTSTART;VALUE=DATE:${dateOnly(toDate(it.start))}`);
      const endDate = it.end && !/^\d{4}-\d{2}-\d{2}$/.test(it.end)
        ? new Date(it.end)
        : new Date(toDate(it.start).getTime() + 24 * 3600 * 1000);
      lines.push(`DTEND;VALUE=DATE:${dateOnly(endDate)}`);
    } else {
      lines.push(`DTSTART;TZID=Asia/Shanghai:${withTime(it.start)}`);
      if (it.end) {
        lines.push(`DTEND;TZID=Asia/Shanghai:${withTime(it.end)}`);
      }
    }

    lines.push(`SUMMARY:${summary}`);
    if (it.location) {
      lines.push(`LOCATION:${clip(it.location, 60)}`);
    }
    if (it.description) {
      lines.push(`DESCRIPTION:${clip(it.description, 120)}`);
    }

    // 提醒：提前 reminderMinutes 分钟（日程默认 15 分钟，待办 30 分钟，随手记到点即提醒）
    if (isAllDay) {
      // 全天事件：提前 reminderMinutes 分钟，或默认当天 09:00
      const minutes = it.reminderMinutes ?? 0;
      const triggerMinutes = minutes > 0 ? minutes : 0;
      const trigger = triggerMinutes > 0 ? `-PT${triggerMinutes}M` : 'PT0S';
      lines.push('BEGIN:VALARM');
      lines.push('TRIGGER:' + trigger);
      lines.push('ACTION:DISPLAY');
      lines.push(`DESCRIPTION:${summary}`);
      lines.push('END:VALARM');
    } else {
      const minutes = it.reminderMinutes ?? 0;
      if (minutes > 0) {
        lines.push('BEGIN:VALARM');
        lines.push(`TRIGGER:-PT${minutes}M`);
        lines.push('ACTION:DISPLAY');
        lines.push(`DESCRIPTION:${summary}`);
        lines.push('END:VALARM');
      } else {
        // 到点提醒（随手记）
        lines.push('BEGIN:VALARM');
        lines.push('TRIGGER:PT0S');
        lines.push('ACTION:DISPLAY');
        lines.push(`DESCRIPTION:${summary}`);
        lines.push('END:VALARM');
      }
    }

    lines.push('END:VEVENT');
  });

  lines.push('END:VCALENDAR');
  const content = lines.join('\r\n') + '\r\n';

  const blob = new Blob([content], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const filename = `xiaorichang-calendar-${compactDate(new Date())}.ics`;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);

  return { count: items.length, filename };
}
