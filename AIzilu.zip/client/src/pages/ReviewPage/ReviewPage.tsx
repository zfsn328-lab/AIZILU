import { useEffect, useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, Clock, CheckCircle, CalendarDays, Timer, Sparkles, Info, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import * as api from '@client/src/api/review';
import type { ReviewItem, ReviewMetrics } from '@shared/api.interface';

interface MetricCardProps {
  label: string;
  value: string;
  subValue?: string;
  icon: typeof CheckCircle;
  accent: string;
  tooltip?: string;
}

const MetricCard = ({ label, value, subValue, icon: Icon, accent, tooltip }: MetricCardProps) => {
  return (
    <div
      className="bg-white rounded-2xl border border-[#F0E6DC] p-4 relative"
      style={{ boxShadow: '0 2px 10px rgba(196, 135, 122, 0.10)' }}
    >
      <div className="flex items-center gap-2 mb-2">
        <div
          className="w-7 h-7 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: `${accent}18` }}
        >
          <Icon size={14} color={accent} strokeWidth={2} />
        </div>
        <span className="text-[12px] text-[#8A7A72] flex items-center gap-1">
          {label}
          {tooltip && (
            <span className="group relative">
              <Info size={11} color="#B5A69C" strokeWidth={2} />
              <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 px-2 py-1 rounded-lg bg-[#3F3330] text-white text-[11px] whitespace-nowrap opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-opacity z-10">
                {tooltip}
              </span>
            </span>
          )}
        </span>
      </div>
      <div className="text-[22px] font-semibold text-[#3F3330] leading-tight">
        {value}
      </div>
      {subValue && (
        <div className="text-[11px] text-[#B5A69C] mt-0.5">{subValue}</div>
      )}
    </div>
  );
};

interface WeekdayHeatmapProps {
  data: number[]; // 7 values (Mon-Sun)
}

const WeekdayHeatmap = ({ data }: WeekdayHeatmapProps) => {
  const max = Math.max(...data, 1);
  const names = ['一', '二', '三', '四', '五', '六', '日'];

  const getColor = (val: number): string => {
    const ratio = val / max;
    if (ratio === 0) return '#F5EEE8';
    if (ratio < 0.3) return '#E8D5CC';
    if (ratio < 0.6) return '#D4B0A3';
    if (ratio < 0.85) return '#C4877A';
    return '#A96A5C';
  };

  return (
    <div className="grid grid-cols-7 gap-2">
      {data.map((val, i) => (
        <div key={i} className="flex flex-col items-center gap-1">
          <div
            className="w-full aspect-square rounded-lg flex items-center justify-center text-[12px] font-medium text-white"
            style={{ backgroundColor: getColor(val) }}
          >
            {val > 0 ? val : ''}
          </div>
          <span className="text-[11px] text-[#B5A69C]">{names[i]}</span>
        </div>
      ))}
    </div>
  );
};

const ReviewPage = () => {
  const [tab, setTab] = useState<'daily' | 'weekly'>('daily');
  const [currentDate, setCurrentDate] = useState<Date>(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
  });
  const [metrics, setMetrics] = useState<ReviewMetrics | null>(null);
  const [detail, setDetail] = useState<ReviewItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);

  const handleManualGenerate = async () => {
    if (generating) return;
    setGenerating(true);
    try {
      const dateStr = dateStrOf(currentDate);
      const d = await api.generateDaily(dateStr);
      setDetail(d);
      const period: 'today' | 'week' = tab === 'daily' ? 'today' : 'week';
      const m = await api.getMetrics(period, dateStr);
      setMetrics(m);
      toast.success('日报已生成');
    } catch (err: unknown) {
      logger.error('生成日报失败', err);
      toast.error('生成失败，请重试');
    } finally {
      setGenerating(false);
    }
  };

  const dateLabel = useMemo(() => {
    if (tab === 'daily') {
      const m = currentDate.getMonth() + 1;
      const d = currentDate.getDate();
      return `${m}月${d}日`;
    }
    // 周：显示起止
    const day = currentDate.getDay();
    const diff = day === 0 ? -6 : 1 - day;
    const start = new Date(currentDate);
    start.setDate(start.getDate() + diff);
    const end = new Date(start);
    end.setDate(end.getDate() + 6);
    return `${start.getMonth() + 1}月${start.getDate()}日 - ${end.getMonth() + 1}月${end.getDate()}日`;
  }, [currentDate, tab]);

  const dateStrOf = (d: Date): string =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
      d.getDate(),
    ).padStart(2, '0')}`;

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      setLoading(true);
      setError(null);
      try {
        const dateStr = dateStrOf(currentDate);
        const period: 'today' | 'week' = tab === 'daily' ? 'today' : 'week';
        const [m, d] = await Promise.all([
          api.getMetrics(period, dateStr),
          api.getDetail(tab, dateStr),
        ]);
        if (!mounted) return;
        setMetrics(m);
        setDetail(d);
      } catch (e: unknown) {
        if (!mounted) return;
        setError('加载失败，请稍后重试');
        logger.error('复盘页加载失败', e);
      } finally {
        if (mounted) setLoading(false);
      }
    };
    load();
    return () => {
      mounted = false;
    };
  }, [tab, currentDate]);

  const goPrev = () => {
    const d = new Date(currentDate);
    if (tab === 'daily') {
      d.setDate(d.getDate() - 1);
    } else {
      d.setDate(d.getDate() - 7);
    }
    setCurrentDate(d);
  };

  const goNext = () => {
    const d = new Date(currentDate);
    if (tab === 'daily') {
      d.setDate(d.getDate() + 1);
    } else {
      d.setDate(d.getDate() + 7);
    }
    setCurrentDate(d);
  };

  const weekdayHeat = useMemo(() => {
    if (!detail?.weekdayHeatmap) return [0, 0, 0, 0, 0, 0, 0];
    try {
      const parsed = JSON.parse(detail.weekdayHeatmap);
      if (Array.isArray(parsed) && parsed.length === 7) {
        return parsed.map(Number);
      }
    } catch {
      // ignore
    }
    return [0, 0, 0, 0, 0, 0, 0];
  }, [detail]);

  const adviceItems = useMemo(() => {
    if (!detail?.adviceItems) return [];
    try {
      const parsed = JSON.parse(detail.adviceItems);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }, [detail]);

  const isEmpty = !loading && !error && !detail;

  if (loading) {
    return (
      <div className="space-y-5">
        <div className="h-12 bg-white rounded-2xl border border-[#F0E6DC] animate-pulse" />
        <div className="grid grid-cols-2 gap-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-24 bg-white rounded-2xl border border-[#F0E6DC] animate-pulse" />
          ))}
        </div>
        <div className="h-40 bg-white rounded-2xl border border-[#F0E6DC] animate-pulse" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-2xl border border-[#F0E6DC] p-8 text-center">
        <p className="text-[#C96F62] text-[15px]">{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* 标题 + Tab */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-[24px] font-semibold text-[#3F3330]">复盘</h1>
        <div className="flex items-center gap-1 p-1 bg-white rounded-xl border border-[#F0E6DC]">
          <button
            type="button"
            onClick={() => setTab('daily')}
            className={`px-4 py-1.5 rounded-lg text-[14px] transition-colors ${
              tab === 'daily'
                ? 'bg-[#C4877A] text-white font-medium'
                : 'text-[#8A7A72]'
            }`}
          >
            日报
          </button>
          <button
            type="button"
            onClick={() => setTab('weekly')}
            className={`px-4 py-1.5 rounded-lg text-[14px] transition-colors ${
              tab === 'weekly'
                ? 'bg-[#C4877A] text-white font-medium'
                : 'text-[#8A7A72]'
            }`}
          >
            周报
          </button>
        </div>
      </div>

      {/* 日期切换 */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={goPrev}
          className="w-8 h-8 rounded-xl bg-white border border-[#F0E6DC] flex items-center justify-center text-[#8A7A72] hover:bg-[#FBF5EF] transition-colors"
        >
          <ChevronLeft size={16} strokeWidth={2} />
        </button>
        <span className="text-[16px] font-medium text-[#3F3330]">
          {dateLabel}
        </span>
        <button
          type="button"
          onClick={goNext}
          className="w-8 h-8 rounded-xl bg-white border border-[#F0E6DC] flex items-center justify-center text-[#8A7A72] hover:bg-[#FBF5EF] transition-colors"
        >
          <ChevronRight size={16} strokeWidth={2} />
        </button>
      </div>

      {/* 空状态 */}
      {isEmpty && (
        <div
          className="bg-white rounded-2xl border border-[#F0E6DC] p-8 text-center"
          style={{ boxShadow: '0 2px 10px rgba(196, 135, 122, 0.10)' }}
        >
          <div className="w-12 h-12 mx-auto mb-3 rounded-xl bg-[#FBF5EF] flex items-center justify-center">
            <Sparkles size={22} color="#C4877A" strokeWidth={2} />
          </div>
          <p className="text-[15px] text-[#3F3330] mb-1">
            {tab === 'daily' ? '还没有生成日报。' : '本周还没有周报。'}
          </p>
          <p className="text-[13px] text-[#8A7A72] mb-4">
            {tab === 'daily'
              ? '每天 21:30 自动生成，也可以现在点按钮立即生成'
              : '记录你的每一天，慢慢看见成长'}
          </p>
          {tab === 'daily' && (
            <button
              type="button"
              onClick={handleManualGenerate}
              disabled={generating}
              className="px-6 py-2.5 rounded-xl bg-[#C4877A] text-white text-[14px] font-medium hover:bg-[#A96A5C] disabled:opacity-60 disabled:cursor-wait transition-colors"
            >
              {generating ? '生成中…' : '手动生成'}
            </button>
          )}
        </div>
      )}

      {detail && (
        <>
          {/* 更新提示 */}
          {detail.laterUpdateCount && detail.laterUpdateCount > 0 && (
            <div className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-[#FFFBF2] border border-[#F0E6DC]">
              <AlertTriangle size={16} color="#D2A454" strokeWidth={2} />
              <span className="text-[13px] text-[#D2A454]">
                生成后有 {detail.laterUpdateCount} 条更新，数据可能略有变化
              </span>
            </div>
          )}

          {/* 4 指标卡：有日报详情时以日报实时统计为准 */}
          <div className="grid grid-cols-2 gap-3">
            <MetricCard
              label="完成率"
              value={`${Math.round(
                (detail ? detail.completionRate : (metrics?.completionRate ?? 0)) * 100,
              )}%`}
              icon={CheckCircle}
              accent="#7FA98A"
            />
            <MetricCard
              label="完成数"
              value={String(detail ? detail.completedCount : (metrics?.completedCount ?? 0))}
              subValue={`计划 ${detail.plannedCount} 件`}
              icon={CalendarDays}
              accent="#C4877A"
            />
            <MetricCard
              label="延期数"
              value={String(detail ? detail.delayedCount : (metrics?.delayedCount ?? 0))}
              icon={Clock}
              accent="#D2A454"
            />
            <MetricCard
              label="预估专注"
              value={`${
                Math.round(
                  ((detail ? detail.estDeepWorkMinutes : (metrics?.estDeepWorkMinutes ?? 0)) / 60) * 10,
                ) / 10
              } 小时`}
              subValue="预估"
              icon={Timer}
              accent="#9AB0C0"
              tooltip="按当天日程+待办+习惯的预估时长合计，仅供参考"
            />
          </div>

          {/* 星期热力（周报） */}
          {tab === 'weekly' && (
            <div
              className="bg-white rounded-2xl border border-[#F0E6DC] p-5"
              style={{ boxShadow: '0 2px 10px rgba(196, 135, 122, 0.10)' }}
            >
              <div className="flex items-center gap-2 mb-4">
                <CalendarDays size={16} color="#C4877A" strokeWidth={2} />
                <h2 className="text-[16px] font-semibold text-[#3F3330]">
                  完成分布
                </h2>
              </div>
              <WeekdayHeatmap data={weekdayHeat} />
            </div>
          )}

          {/* AI 发现与建议 */}
          {adviceItems.length > 0 && (
            <div
              className="bg-white rounded-2xl border border-[#F0E6DC] p-5 relative overflow-hidden"
              style={{ boxShadow: '0 2px 10px rgba(196, 135, 122, 0.10)' }}
            >
              <div className="absolute left-0 top-0 bottom-0 w-[3px] bg-[#C4877A]" />
              <div className="pl-1">
                <div className="flex items-center gap-2 mb-4">
                  <Sparkles size={16} color="#C4877A" strokeWidth={2} />
                  <h2 className="text-[16px] font-semibold text-[#3F3330]">
                    AI 发现与建议
                  </h2>
                </div>
                <ul className="space-y-3">
                  {adviceItems.map((item: string, i: number) => (
                    <li key={i} className="flex gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#C4877A] mt-2 flex-shrink-0" />
                      <span className="text-[14px] text-[#3F3330] leading-relaxed">
                        {item}
                      </span>
                    </li>
                  ))}
                </ul>
                {detail.summaryText && (
                  <p className="text-[13px] text-[#8A7A72] mt-4 pt-4 border-t border-[#F0E6DC]">
                    {detail.summaryText}
                  </p>
                )}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default ReviewPage;
