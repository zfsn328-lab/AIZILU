import { Pencil, Trash2, Plus } from 'lucide-react';
import { useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import * as api from '@client/src/api/breakdown';
import type { BreakdownItem, BreakdownStep } from '@shared/api.interface';

interface BreakdownItemActionsProps {
  item: BreakdownItem;
  onUpdated: (item: BreakdownItem) => void;
  onDeleted: (id: string) => void;
}

const BreakdownItemActions = ({ item, onUpdated, onDeleted }: BreakdownItemActionsProps) => {
  const [toggling, setToggling] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [editTitle, setEditTitle] = useState(item.title);
  const [editSteps, setEditSteps] = useState<BreakdownStep[]>(item.steps);
  const [editLoading, setEditLoading] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [deleteStepId, setDeleteStepId] = useState<string | null>(null);
  const isDone = item.status === 'done';

  const handleToggle = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (toggling) return;
    setToggling(true);
    try {
      const updated = await api.toggleBreakdownDone(item.recordId);
      onUpdated(updated);
    } catch (err: unknown) {
      logger.error('切换完成状态失败', err);
    } finally {
      setToggling(false);
    }
  };

  const openEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditTitle(item.title);
    setEditSteps(item.steps);
    setEditOpen(true);
  };

  const hasEmptyStep = editSteps.some((s) => !s.text.trim());

  const handleSave = async () => {
    if (editLoading) return;
    const trimmedTitle = editTitle.trim();
    if (!trimmedTitle || hasEmptyStep) return;
    setEditLoading(true);
    try {
      const stepsInput = editSteps.map((s) => {
        const base: { id?: string; text: string } = { text: s.text.trim() };
        if (!s.id.startsWith('new_')) base.id = s.id;
        return base;
      });
      const updated = await api.updateBreakdown(item.recordId, trimmedTitle, stepsInput);
      onUpdated(updated);
      setEditOpen(false);
    } catch (err: unknown) {
      logger.error('修改目标失败', err);
    } finally {
      setEditLoading(false);
    }
  };

  const handleStepTextChange = (stepId: string, value: string) => {
    setEditSteps((prev) =>
      prev.map((s) => (s.id === stepId ? { ...s, text: value } : s)),
    );
  };

  const handleRemoveStep = (stepId: string) => {
    if (editSteps.length <= 1) return;
    setDeleteStepId(stepId);
  };

  const handleConfirmRemoveStep = () => {
    if (!deleteStepId) return;
    setEditSteps((prev) => prev.filter((s) => s.id !== deleteStepId));
    setDeleteStepId(null);
  };

  const handleAddStep = () => {
    const tempId = `new_${Date.now()}`;
    setEditSteps((prev) => [
      ...prev,
      {
        id: tempId,
        text: '',
        dueDate: '',
        dueLabel: '',
        done: false,
      },
    ]);
  };

  const openDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    setDeleteOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (deleteLoading) return;
    setDeleteLoading(true);
    try {
      await api.removeBreakdown(item.recordId);
      onDeleted(item.recordId);
      setDeleteOpen(false);
    } catch (err: unknown) {
      logger.error('删除失败', err);
    } finally {
      setDeleteLoading(false);
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={handleToggle}
        disabled={toggling}
        className="w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-colors disabled:opacity-60"
        style={{
          borderColor: isDone ? '#7FA98A' : '#D9CDC4',
          backgroundColor: isDone ? '#7FA98A' : 'transparent',
        }}
        aria-label={isDone ? '取消完成' : '标记完成'}
      >
        {isDone && (
          <svg
            width="12"
            height="12"
            viewBox="0 0 12 12"
            fill="none"
            aria-hidden
          >
            <path
              d="M2.5 6.5L5 9L9.5 3.5"
              stroke="white"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        )}
      </button>

      <span className="flex items-center gap-1 flex-shrink-0">
        <button
          type="button"
          onClick={openEdit}
          className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-[#FBF5EF] transition-colors"
          aria-label="修改"
        >
          <Pencil size={14} color="#8A7A72" strokeWidth={2} />
        </button>
        <button
          type="button"
          onClick={openDelete}
          className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-[#FBF5EF] transition-colors"
          aria-label="删除"
        >
          <Trash2 size={14} color="#C96F62" strokeWidth={2} />
        </button>
      </span>

      {editOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center px-6"
          style={{ backgroundColor: 'rgba(63, 51, 48, 0.5)' }}
          onClick={() => !editLoading && setEditOpen(false)}
        >
          <div
            className="w-full max-w-sm bg-white rounded-2xl p-5 space-y-4 flex flex-col max-h-[80vh]"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-[16px] font-semibold text-[#3F3330] flex-shrink-0">
              修改目标
            </h3>

            <div className="overflow-y-auto flex-1 space-y-4 pr-1 -mr-1">
              <div className="space-y-1.5">
                <label className="text-[13px] font-medium text-[#3F3330]">
                  目标名称
                </label>
                <input
                  type="text"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-[#F0E6DC] text-[14px] text-[#3F3330] outline-none focus:border-[#C4877A] transition-colors bg-white"
                  placeholder="请输入目标名称"
                />
              </div>

              <div className="space-y-2">
                <label className="text-[13px] font-medium text-[#3F3330]">
                  执行步骤
                </label>
                <div className="space-y-2">
                  {editSteps.map((s, idx) => (
                    <div key={s.id} className="flex items-start gap-2">
                      <span
                        className="w-6 h-6 rounded-full flex items-center justify-center text-[11px] font-semibold flex-shrink-0 mt-1.5"
                        style={{
                          backgroundColor: 'rgba(196, 135, 122, 0.12)',
                          color: '#C4877A',
                        }}
                      >
                        {idx + 1}
                      </span>
                      <div className="flex-1 min-w-0">
                        <input
                          type="text"
                          value={s.text}
                          onChange={(e) => handleStepTextChange(s.id, e.target.value)}
                          className="w-full px-3 py-2 rounded-xl border border-[#F0E6DC] text-[13px] text-[#3F3330] outline-none focus:border-[#C4877A] transition-colors bg-white"
                          placeholder={s.id.startsWith('new_') ? '输入新的步骤内容' : `步骤 ${idx + 1} 内容`}
                        />
                        {!s.text.trim() && (
                          <p className="text-[11px] text-[#C96F62] mt-1">
                            步骤内容不能为空
                          </p>
                        )}
                      </div>
                      {editSteps.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveStep(s.id)}
                          className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 mt-1 hover:bg-[#FBF5EF] transition-colors"
                          aria-label="删除步骤"
                        >
                          <Trash2 size={14} color="#B5A69C" strokeWidth={2} />
                        </button>
                      )}
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={handleAddStep}
                    className="w-full py-2.5 rounded-xl border border-dashed border-[#E8D9CC] text-[13px] text-[#8A7A72] flex items-center justify-center gap-1 hover:bg-[#FBF5EF] transition-colors"
                  >
                    <Plus size={14} strokeWidth={2} />
                    <span>增加步骤</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 flex-shrink-0">
              <button
                type="button"
                onClick={() => setEditOpen(false)}
                disabled={editLoading}
                className="flex-1 py-2.5 rounded-xl text-[14px] font-medium text-[#8A7A72] bg-[#FBF5EF] border border-[#F0E6DC] disabled:opacity-60"
              >
                取消
              </button>
              <button
                type="button"
                onClick={handleSave}
                disabled={editLoading || !editTitle.trim() || hasEmptyStep}
                className="flex-1 py-2.5 rounded-xl text-[14px] font-medium text-white disabled:opacity-60"
                style={{ backgroundColor: '#C4877A' }}
              >
                {editLoading ? '保存中…' : '保存'}
              </button>
            </div>
          </div>
        </div>
      )}

      {deleteStepId && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center px-6"
          style={{ backgroundColor: 'rgba(63, 51, 48, 0.5)' }}
          onClick={() => setDeleteStepId(null)}
        >
          <div
            className="w-full max-w-sm bg-white rounded-2xl p-5 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-[16px] font-semibold text-[#3F3330]">
              删除步骤
            </h3>
            <div className="space-y-1">
              <p className="text-[14px] text-[#3F3330]">
                确定删除这个步骤吗？
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setDeleteStepId(null)}
                className="flex-1 py-2.5 rounded-xl text-[14px] font-medium text-[#8A7A72] bg-[#FBF5EF] border border-[#F0E6DC]"
              >
                取消
              </button>
              <button
                type="button"
                onClick={handleConfirmRemoveStep}
                className="flex-1 py-2.5 rounded-xl text-[14px] font-medium text-white"
                style={{ backgroundColor: '#C96F62' }}
              >
                确认删除
              </button>
            </div>
          </div>
        </div>
      )}

      {deleteOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center px-6"
          style={{ backgroundColor: 'rgba(63, 51, 48, 0.5)' }}
          onClick={() => !deleteLoading && setDeleteOpen(false)}
        >
          <div
            className="w-full max-w-sm bg-white rounded-2xl p-5 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-[16px] font-semibold text-[#3F3330]">
              删除目标
            </h3>
            <div className="space-y-1">
              <p className="text-[14px] text-[#3F3330]">
                确定删除这个目标吗？
              </p>
              <p className="text-[12px] text-[#8A7A72]">
                删除后无法恢复，已加入待办的任务也会一并删除。
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setDeleteOpen(false)}
                disabled={deleteLoading}
                className="flex-1 py-2.5 rounded-xl text-[14px] font-medium text-[#8A7A72] bg-[#FBF5EF] border border-[#F0E6DC] disabled:opacity-60"
              >
                取消
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={deleteLoading}
                className="flex-1 py-2.5 rounded-xl text-[14px] font-medium text-white disabled:opacity-60"
                style={{ backgroundColor: '#C96F62' }}
              >
                {deleteLoading ? '删除中…' : '确认删除'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default BreakdownItemActions;
