import { useRef, useState } from 'react';
import { PenLine, ChevronDown, CalendarRange, ChevronLeft, ChevronRight, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type { QuickNoteType } from '@shared/api.interface';

interface QuickNoteSectionProps {
  onCreate: (
    content: string,
    remindAt?: string | null,
    type?: QuickNoteType,
    repeatMonthDaily?: boolean,
    selectedDates?: string[],
    periodDays?: number | null,
  ) => Promise<{ remindPast: boolean }>;
}

const TYPE_OPTIONS: { value: QuickNoteType | ''; label: string; color: string }[] = [
  { value: '', label: '类型（可选）', color: '#B5A69C' },
  { value: 'task', label: '待办', color: '#C4877A' },
  { value: 'event', label: '日程', color: '#B4A0C8' },
  { value: 'habit', label: '打卡', color: '#7FA98A' },
  { value: 'goal', label: '目标', color: '#D9A441' },
];

const PERIOD_OPTIONS = [7, 15, 30, 60, 90];

const formatRemindDisplay = (v: string): string => {
  if (!v) return '年/月/日 --:--';
  const d = new Date(v);
  if (isNaN(d.getTime())) return '年/月/日 --:--';
  const m = d.getMonth() + 1;
  const day = d.getDate();
  const h = String(d.getHours()).padStart(2, '0');
  const min = String(d.getMinutes()).padStart(2, '0');
  return `${m}月${day}日 ${h}:${min}`;
};

const QuickNoteSection = ({ onCreate }: QuickNoteSectionProps) => {
  const [value, setValue] = useState('');
  const [noteType, setNoteType] = useState<QuickNoteType | ''>('');
  const [remindValue, setRemindValue] = useState('');
  const [remindTouched, setRemindTouched] = useState(false);
  const [repeatMonth, setRepeatMonth] = useState(false);
  const [periodDays, setPeriodDays] = useState<number | null>(null);
  const repeatMonthRef = useRef(false);
  const [submitting, setSubmitting] = useState(false);
  // 自定义时间选择弹窗（替代原生 datetime-local，弹窗内可多选日期/本月每天提醒）
  const [pickerOpen, setPickerOpen] = useState(false);
  const [multiDates, setMultiDates] = useState<string[]>([]);
  const nowD = new Date();
  const [multiMonth, setMultiMonth] = useState(
    `${nowD.getFullYear()}-${String(nowD.getMonth() + 1).padStart(2, '0')}`,
  );
  const [hourSel, setHourSel] = useState<number | null>(null);
  const [minSel, setMinSel] = useState<number | null>(null);

  const pad2 = (n: number) => String(n).padStart(2, '0');
  const toggleDate = (ds: string) => {
    setMultiDates((prev) =>
      prev.includes(ds) ? prev.filter((d) => d !== ds) : [...prev, ds].sort(),
    );
    // 选了日期则取消本月每天
    repeatMonthRef.current = false;
    setRepeatMonth(false);
  };
  const shiftMultiMonth = (delta: number) => {
    const [y, m] = multiMonth.split('-').map(Number);
    const nd = new Date(y, m - 1 + delta, 1);
    setMultiMonth(`${nd.getFullYear()}-${pad2(nd.getMonth() + 1)}`);
  };

  // 打开弹窗：时间默认当前 +1 小时（提前一小时）
  const openPicker = () => {
    const base = new Date(Date.now() + 3600 * 1000);
    setHourSel(base.getHours());
    setMinSel(base.getMinutes());
    setPickerOpen(true);
  };

  const toggleRepeatMonthInPicker = () => {
    const next = !repeatMonthRef.current;
    repeatMonthRef.current = next;
    setRepeatMonth(next);
    if (next) setMultiDates([]);
  };

  // 确定：合成提醒时间（首个选中日期/今天 + 时:分），多选日期一并应用
  const confirmPicker = () => {
    const today = `${nowD.getFullYear()}-${pad2(nowD.getMonth() + 1)}-${pad2(nowD.getDate())}`;
    const dateStr = multiDates.length > 0 ? multiDates[0] : today;
    const h = hourSel ?? new Date(Date.now() + 3600 * 1000).getHours();
    const m = minSel ?? 0;
    setRemindValue(`${dateStr}T${pad2(h)}:${pad2(m)}`);
    setRemindTouched(true);
    setPickerOpen(false);
  };

  // 关闭弹窗（不改变已选状态）
  const closePicker = () => setPickerOpen(false);

  // 清除：清空日期选择与本月每天（保留弹窗）
  const clearPicker = () => {
    setMultiDates([]);
    repeatMonthRef.current = false;
    setRepeatMonth(false);
    setRemindValue('');
    setRemindTouched(false);
    setPickerOpen(false);
  };

  // 今天：选中今天
  const pickToday = () => {
    setMultiMonth(`${nowD.getFullYear()}-${pad2(nowD.getMonth() + 1)}`);
    const today = `${nowD.getFullYear()}-${pad2(nowD.getMonth() + 1)}-${pad2(nowD.getDate())}`;
    setMultiDates([today]);
    repeatMonthRef.current = false;
    setRepeatMonth(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = value.trim();
    if (!trimmed || submitting) return;

    const remindAtIso = remindTouched && remindValue
      ? new Date(remindValue).toISOString()
      : null;

    setSubmitting(true);
    try {
      const { remindPast } = await onCreate(
        trimmed,
        remindAtIso,
        noteType || undefined,
        repeatMonthRef.current,
        multiDates,
        noteType === 'habit' ? periodDays : null,
      );
      setValue('');
      setNoteType('');
      setRemindValue('');
      setRemindTouched(false);
      setRepeatMonth(false);
      repeatMonthRef.current = false;
      setMultiDates([]);
      setPickerOpen(false);
      setPeriodDays(null);
      if (remindPast) {
        toast.warning('提醒时间已过，仅记录不提醒');
      } else if (noteType === 'task') {
        toast.success('已添加为待办');
      } else if (noteType === 'event') {
        toast.success('已添加为日程');
      } else if (noteType === 'habit') {
        toast.success('已添加为习惯');
      } else if (noteType === 'goal') {
        toast.success('已添加为目标');
      } else {
        toast.success('已保存');
      }
    } catch (err: unknown) {
      logger.error('提交随手记失败', err);
      toast.error('保存失败，请重试');
    } finally {
      setSubmitting(false);
    }
  };

  const handleClearRemind = () => {
    setRemindValue('');
    setRemindTouched(false);
    setMultiDates([]);
    repeatMonthRef.current = false;
    setRepeatMonth(false);
  };

  return (
    <div
      className="bg-white rounded-2xl border border-[#F0E6DC] p-5"
      style={{ boxShadow: '0 2px 10px rgba(196, 135, 122, 0.10)' }}
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <PenLine size={16} color="#A96A5C" strokeWidth={2} />
          <h2 className="text-[16px] font-semibold text-[#A96A5C]">随手记</h2>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
          <div className="flex flex-col md:flex-row md:items-start gap-3">
            <input
              type="text"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder="随手记一句吧，好想法不等人"
              maxLength={500}
              className="w-full md:flex-1 md:min-w-0 px-4 py-2.5 bg-white border border-[#F0E6DC] rounded-xl text-[14px] text-[#3F3330] placeholder:text-[#B5A69C] focus:outline-none focus:border-[#C4877A] transition-colors"
            />
            <div className="flex items-start gap-2 md:flex-shrink-0">
              <div className="flex-1 min-w-0 md:w-[190px] md:flex-none flex flex-col relative">
                 <div className="relative w-full h-[42px]">
                   <button
                     type="button"
                     onClick={openPicker}
                     className={`absolute inset-0 w-full flex items-center px-3 bg-white border border-[#F0E6DC] rounded-xl text-[13px] cursor-pointer select-none text-left transition-colors hover:border-[#C4877A] ${
                       remindTouched && remindValue
                         ? 'text-[#3F3330]'
                         : 'text-[#B5A69C]'
                     }`}
                     aria-label="选择提醒时间"
                   >
                     {remindTouched && remindValue
                       ? formatRemindDisplay(remindValue)
                       : '可选时间提醒'}
                   </button>
                  {remindTouched && remindValue && (
                    <button
                      type="button"
                      onClick={handleClearRemind}
                      className="absolute right-2 top-1/2 -translate-y-1/2 w-5 h-5 rounded-full bg-[#F0E6DC] text-[#8A7A72] text-[12px] leading-none flex items-center justify-center hover:bg-[#E8D9CC] transition-colors"
                      aria-label="清除提醒时间"
                    >
                      ×
                    </button>
                  )}
                </div>

                {(noteType === 'habit' || noteType === 'goal') && (
                  <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                    <span className="text-[11px] text-[#8A7A72]">周期天数</span>
                    {PERIOD_OPTIONS.map((d) => (
                      <button
                        key={d}
                        type="button"
                        onClick={() =>
                          setPeriodDays((prev) => (prev === d ? null : d))
                        }
                        className={`inline-flex items-center text-[12px] px-2.5 py-1 rounded-lg border transition-colors ${
                          periodDays === d
                            ? 'bg-[#7FA98A] border-[#7FA98A] text-white'
                            : 'bg-white border-[#F0E6DC] text-[#8A7A72] hover:border-[#7FA98A] hover:text-[#3F3330]'
                        }`}
                        aria-pressed={periodDays === d}
                      >
                        {d}天
                      </button>
                    ))}
                    {periodDays ? (
                      <span className="text-[11px] text-[#7FA98A]">
                        按 {periodDays} 天计算进度
                      </span>
                    ) : (
                      <span className="text-[11px] text-[#B5A69C]">
                        不设周期则显示进行中
                      </span>
                    )}
                  </div>
                )}

                {pickerOpen && (
                  <>
                    <div
                      className="fixed inset-0 z-40 bg-[#3F3330]/25"
                      onClick={closePicker}
                      aria-hidden="true"
                    />
                    <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[320px] max-w-[90vw] max-h-[88vh] overflow-y-auto bg-white border border-[#F0E6DC] rounded-2xl p-3 shadow-xl">
                    {/* 日历：可多选日期 */}
                    <div className="flex items-center justify-between mb-2">
                      <button
                        type="button"
                        onClick={() => shiftMultiMonth(-1)}
                        className="w-6 h-6 flex items-center justify-center rounded-lg text-[#8A7A72] hover:bg-[#FBF5EF]"
                        aria-label="上个月"
                      >
                        <ChevronLeft size={15} strokeWidth={2} />
                      </button>
                      <span className="text-[13px] font-semibold text-[#3F3330]">
                        {multiMonth.replace('-', '年')}月
                      </span>
                      <button
                        type="button"
                        onClick={() => shiftMultiMonth(1)}
                        className="w-6 h-6 flex items-center justify-center rounded-lg text-[#8A7A72] hover:bg-[#FBF5EF]"
                        aria-label="下个月"
                      >
                        <ChevronRight size={15} strokeWidth={2} />
                      </button>
                    </div>
                    <div className="grid grid-cols-7 gap-1 text-center mb-1">
                      {['一', '二', '三', '四', '五', '六', '日'].map((w) => (
                        <span key={w} className="text-[10px] text-[#B5A69C] py-0.5">
                          {w}
                        </span>
                      ))}
                    </div>
                    <div className="grid grid-cols-7 gap-1">
                      {(() => {
                        const [y, m] = multiMonth.split('-').map(Number);
                        const first = new Date(y, m - 1, 1);
                        const startWeekday = (first.getDay() + 6) % 7;
                        const daysInMonth = new Date(y, m, 0).getDate();
                        const todayStr = `${nowD.getFullYear()}-${pad2(nowD.getMonth() + 1)}-${pad2(nowD.getDate())}`;
                        const cells: (number | null)[] = [
                          ...Array(startWeekday).fill(null),
                          ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
                        ];
                        return cells.map((d, idx) => {
                          if (d === null) return <span key={`e${idx}`} />;
                          const ds = `${multiMonth}-${pad2(d)}`;
                          const selected = multiDates.includes(ds);
                          const isToday = ds === todayStr;
                          return (
                            <button
                              key={ds}
                              type="button"
                              onClick={() => toggleDate(ds)}
                              className={`h-8 rounded-lg text-[12px] transition-colors ${
                                selected
                                  ? 'bg-[#C4877A] text-white font-medium'
                                  : isToday
                                    ? 'bg-[#FBF5EF] text-[#C4877A] font-semibold ring-1 ring-[#E8D9CC]'
                                    : 'text-[#3F3330] hover:bg-[#FBF5EF]'
                              }`}
                            >
                              {d}
                            </button>
                          );
                        });
                      })()}
                    </div>
                    {/* 时间选择（时:分） */}
                    <div className="flex items-center gap-2 mt-2 pt-2 border-t border-[#F0E6DC]">
                      <Clock size={14} color="#B5A69C" strokeWidth={2} />
                      <select
                        value={hourSel ?? 0}
                        onChange={(e) => setHourSel(Number(e.target.value))}
                        className="flex-1 appearance-none pl-2 pr-6 py-1.5 bg-[#FBF5EF] border border-[#F0E6DC] rounded-lg text-[13px] text-[#3F3330] focus:outline-none focus:border-[#C4877A] cursor-pointer"
                        aria-label="时"
                      >
                        {Array.from({ length: 24 }, (_, i) => (
                          <option key={i} value={i}>
                            {pad2(i)} 时
                          </option>
                        ))}
                      </select>
                      <span className="text-[#B5A69C]">:</span>
                      <select
                        value={minSel ?? 0}
                        onChange={(e) => setMinSel(Number(e.target.value))}
                        className="flex-1 appearance-none pl-2 pr-6 py-1.5 bg-[#FBF5EF] border border-[#F0E6DC] rounded-lg text-[13px] text-[#3F3330] focus:outline-none focus:border-[#C4877A] cursor-pointer"
                        aria-label="分"
                      >
                        {Array.from({ length: 60 }, (_, i) => (
                          <option key={i} value={i}>
                            {pad2(i)} 分
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#F0E6DC]">
                      <button
                        type="button"
                        onClick={toggleRepeatMonthInPicker}
                        className={`inline-flex items-center gap-1.5 text-[12px] px-2.5 py-1.5 rounded-lg border transition-colors ${
                          repeatMonth
                            ? 'bg-[#C4877A] border-[#C4877A] text-white'
                            : 'bg-white border-[#F0E6DC] text-[#8A7A72] hover:border-[#C4877A] hover:text-[#3F3330]'
                        }`}
                        aria-pressed={repeatMonth}
                      >
                        <CalendarRange size={13} strokeWidth={2} />
                        本月每天提醒
                      </button>
                      <button
                        type="button"
                        onClick={pickToday}
                        className="text-[12px] text-[#8A7A72] hover:text-[#C4877A] transition-colors"
                      >
                        今天
                      </button>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={clearPicker}
                          className="text-[12px] text-[#8A7A72] hover:text-[#C96F62] transition-colors"
                        >
                          清除
                        </button>
                        <button
                          type="button"
                          onClick={confirmPicker}
                          className="text-[12px] px-3 py-1.5 rounded-lg bg-[#C4877A] text-white font-medium"
                        >
                          确定
                        </button>
                      </div>
                    </div>
                  </div>
                  </>
                )}
              </div>
              <div className="relative flex-shrink-0 mt-[1px]">
                <select
                  value={noteType}
                  onChange={(e) => setNoteType(e.target.value as QuickNoteType | '')}
                  className="appearance-none pl-3 pr-8 py-[10px] h-[42px] bg-white border border-[#F0E6DC] rounded-xl text-[13px] text-[#8A7A72] focus:outline-none focus:border-[#C4877A] transition-colors cursor-pointer"
                  aria-label="记录类型（可选）"
                >
                  {TYPE_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
                <ChevronDown
                  size={14}
                  color="#B5A69C"
                  strokeWidth={2}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none"
                />
              </div>
              <button
                type="submit"
                disabled={submitting || !value.trim()}
                className="flex-shrink-0 px-5 py-2.5 bg-[#C4877A] text-white text-[14px] font-medium rounded-xl hover:bg-[#A96A5C] disabled:opacity-40 disabled:cursor-not-allowed transition-colors whitespace-nowrap mt-[1px]"
              >
                保存
              </button>
            </div>
          </div>
      </form>
    </div>
  );
};

export default QuickNoteSection;
