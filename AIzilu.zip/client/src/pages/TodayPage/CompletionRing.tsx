interface CompletionRingProps {
  rate: number;
  completed: number;
  total: number;
  size?: number;
}

const CompletionRing = ({
  rate,
  completed,
  total,
  size = 72,
}: CompletionRingProps) => {
  const strokeWidth = 6;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  // rate 为 0~1 比例（如 0.5 = 50%）
  const offset = circumference * (1 - rate);
  const displayRate = Math.round(rate * 100);

  return (
    <div className="relative flex-shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="#F0E0D8"
          strokeWidth={strokeWidth}
          fill="none"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="#C4877A"
          strokeWidth={strokeWidth}
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 0.6s ease' }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-[15px] font-semibold text-[#3F3330] leading-tight">
          {displayRate}%
        </span>
        <span className="text-[10px] text-[#8A7A72] leading-tight mt-0.5">
          已完成 {completed}/{total}
        </span>
      </div>
    </div>
  );
};

export default CompletionRing;
