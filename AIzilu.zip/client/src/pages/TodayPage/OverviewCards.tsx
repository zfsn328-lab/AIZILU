import { ListTodo, CalendarDays, Sparkles, Target } from 'lucide-react';

interface OverviewCard {
  label: string;
  count: number;
  icon: typeof ListTodo;
  accent: string;
}

interface OverviewCardsProps {
  pendingTaskCount: number;
  eventCount: number;
  habitCount: number;
  activeGoalsCount: number;
}

const OverviewCards = ({
  pendingTaskCount,
  eventCount,
  habitCount,
  activeGoalsCount,
}: OverviewCardsProps) => {
  const cards: OverviewCard[] = [
    {
      label: '待办小事',
      count: pendingTaskCount,
      icon: ListTodo,
      accent: '#C4877A',
    },
    {
      label: '今日日程',
      count: eventCount,
      icon: CalendarDays,
      accent: '#9AB0C0',
    },
    {
      label: '习惯打卡',
      count: habitCount,
      icon: Sparkles,
      accent: '#7FA98A',
    },
    {
      label: '目标',
      count: activeGoalsCount,
      icon: Target,
      accent: '#D9A441',
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {cards.map((card) => {
        const Icon = card.icon;
        return (
          <div
            key={card.label}
            className="bg-white rounded-2xl border border-[#F0E6DC] p-4 flex flex-col items-center text-center"
            style={{ boxShadow: '0 2px 10px rgba(196, 135, 122, 0.10)' }}
          >
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center mb-2"
              style={{ backgroundColor: `${card.accent}15` }}
            >
              <Icon size={20} color={card.accent} strokeWidth={2} />
            </div>
            <div className="text-[20px] font-semibold text-[#3F3330] leading-tight">
              {card.count}
            </div>
            <div className="text-[13px] text-[#8A7A72] mt-0.5">
              {card.label}
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default OverviewCards;
