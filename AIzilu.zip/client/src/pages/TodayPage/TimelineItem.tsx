import { useState } from 'react';
import { Check, ListTodo, CalendarDays, Sparkles, PenLine, Trash2 } from 'lucide-react';
import type { EventType, TodayTimelineItem } from '@shared/api.interface';

interface TimelineItemProps {
  item: TodayTimelineItem;
  onToggle: (id: string) => void;
  onDelete?: (id: string) => void;
}

const EVENT_COLORS: Record<EventType, string> = {
  meeting: '#9AB0C0',
  course: '#B4A0C8',
  travel: '#C9A87C',
  personal: '#8FB3A0',
  other: '#B5A69C',
};

const EVENT_LABELS: Record<EventType, string> = {
  meeting: '会议',
  course: '课程',
  travel: '出行',
  personal: '个人',
  other: '日程',
};

const TimelineItem = ({ item, onToggle, onDelete }: TimelineItemProps) => {
  const isDone = item.status === 'done';
  const isCancelled = item.status === 'cancelled';
  const [confirming, setConfirming] = useState(false);

  let dotColor = '#C4877A';
  let tagLabel = '待办小事';
  let tagColor = '#C4877A';
  let tagBg = 'rgba(196, 135, 122, 0.12)';
  let tagIcon: typeof ListTodo = ListTodo;

  if (item.type === 'event') {
    dotColor = '#9AB0C0';
    tagLabel = '今日日程';
    tagColor = '#9AB0C0';
    tagBg = 'rgba(154, 176, 192, 0.15)';
    tagIcon = CalendarDays;
  } else if (item.type === 'habit') {
    dotColor = '#7FA98A';
    tagLabel = '习惯打卡';
    tagColor = '#7FA98A';
    tagBg = 'rgba(127, 169, 138, 0.15)';
    tagIcon = Sparkles;
  } else if (item.type === 'note') {
    dotColor = '#C9A87C';
    tagLabel = '随手记';
    tagColor = '#A8895C';
    tagBg = 'rgba(201, 168, 124, 0.16)';
    tagIcon = PenLine;
  } else {
    dotColor = isDone ? '#7FA98A' : '#C4877A';
    tagColor = isDone ? '#7FA98A' : '#C4877A';
    tagBg = isDone ? 'rgba(127, 169, 138, 0.15)' : 'rgba(196, 135, 122, 0.12)';
  }

  // 任务类型点击整卡也可切换；其他类型只点右侧圈
  const isClickable = item.type === 'task';
  const TagIcon = tagIcon;

  const handleCardClick = () => {
    if (isClickable) {
      onToggle(item.id);
    }
  };

  const handleCircleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggle(item.id);
  };

  return (
    <div className="flex gap-3">
      {/* 时间列 + 圆点 */}
      <div className="flex flex-col items-center flex-shrink-0 w-12">
        <span className="text-[13px] text-[#8A7A72] font-medium h-5 leading-5">
          {item.timeLabel}
        </span>
        <div
          className="w-3 h-3 rounded-full mt-1.5 flex-shrink-0 ring-2 ring-white"
          style={{ backgroundColor: dotColor }}
        />
        <div className="w-px flex-1 bg-[#F0E6DC] mt-1" />
      </div>

      {/* 卡片 */}
      <div
        className={`flex-1 mb-4 rounded-2xl border border-[#F0E6DC] bg-white p-4 ${
          isClickable ? 'cursor-pointer hover:shadow-sm transition-shadow' : ''
        } ${isDone || isCancelled ? 'opacity-60' : ''}`}
        style={{ boxShadow: '0 2px 10px rgba(196, 135, 122, 0.10)' }}
        onClick={handleCardClick}
      >
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1.5">
              <span
                className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-md font-medium"
                style={{ color: tagColor, backgroundColor: tagBg }}
              >
                <TagIcon size={11} strokeWidth={2.5} />
                {tagLabel}
              </span>
            </div>
            <h4
              className={`text-[15px] font-medium text-[#3F3330] leading-snug ${
                isDone ? 'line-through text-[#B5A69C]' : ''
              }`}
            >
              {item.title}
            </h4>
            {item.subtitle && (
              <p className="text-[13px] text-[#8A7A72] mt-1">{item.subtitle}</p>
            )}
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              type="button"
              onClick={handleCircleClick}
              aria-label={isDone ? '撤销完成' : '标记完成'}
              className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                isDone
                  ? 'bg-[#7FA98A] border-[#7FA98A]'
                  : 'border-[#E8D8CE] hover:border-[#C4877A]'
              }`}
            >
              {isDone && <Check size={14} color="white" strokeWidth={3} />}
            </button>
            {onDelete && confirming ? (
              <span className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => {
                    setConfirming(false);
                    onDelete(item.id);
                  }}
                  className="text-[11px] px-2 py-1 rounded-lg bg-[#C96F62] text-white font-medium"
                >
                  确认删除
                </button>
                <button
                  type="button"
                  onClick={() => setConfirming(false)}
                  className="text-[11px] px-2 py-1 rounded-lg bg-[#FBF5EF] text-[#8A7A72] font-medium"
                >
                  取消
                </button>
              </span>
            ) : (
              onDelete && (
                <button
                  type="button"
                  onClick={() => setConfirming(true)}
                  aria-label="删除"
                  className="w-6 h-6 flex items-center justify-center rounded-lg text-[#C9B8AE] hover:text-[#C96F62] hover:bg-[#FBEDE9] transition-colors"
                >
                  <Trash2 size={14} strokeWidth={2} />
                </button>
              )
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export { TimelineItem, EVENT_COLORS, EVENT_LABELS };
