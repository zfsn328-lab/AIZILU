import { useEffect, useState } from 'react';
import { Inbox, ChevronDown, ChevronUp, AlertCircle } from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import * as api from '@client/src/api/inbox';
import type { InboxBatchItem, InboxItem } from '@shared/api.interface';
import { Image } from '@client/src/components/ui/image';

const ConfidenceBadge = ({ confidence }: { confidence: number | null }) => {
  if (confidence === null) return null;
  const percent = Math.round(confidence * 100);
  let color = '#7FA98A';
  let label = '高置信';
  if (confidence < 0.5) {
    color = '#C96F62';
    label = '低置信';
  } else if (confidence < 0.8) {
    color = '#D2A454';
    label = '中置信';
  }
  return (
    <span
      className="text-[11px] px-2 py-0.5 rounded-md font-medium"
      style={{ color, backgroundColor: `${color}18` }}
    >
      {label} {percent}%
    </span>
  );
};

interface InboxCardProps {
  item: InboxItem;
  onConfirm: (id: string) => void;
  onIgnore: (id: string) => void;
}

const InboxCard = ({ item, onConfirm, onIgnore }: InboxCardProps) => {
  const isLowConfidence = item.confidence !== null && item.confidence < 0.5;
  const suggestedType = item.suggestedType ?? '待办';
  const hasAmbiguity = item.ambiguityReason && item.ambiguityReason.length > 0;

  return (
    <div
      className={`bg-white rounded-2xl border border-[#F0E6DC] p-4 relative ${
        isLowConfidence ? 'opacity-70' : ''
      }`}
      style={{ boxShadow: '0 2px 10px rgba(196, 135, 122, 0.10)' }}
    >
      {/* 置信度徽标 */}
      <div className="absolute top-4 right-4">
        <ConfidenceBadge confidence={item.confidence} />
      </div>

      {/* 原文 */}
      <p className="text-[13px] text-[#B5A69C] mb-3 pr-24 line-clamp-2">
        「{item.rawInput}」
      </p>

      {/* AI 理解 */}
      <div className="mb-3">
        <div className="flex items-center gap-2 mb-1.5">
          <span
            className="text-[11px] px-2 py-0.5 rounded-md font-medium"
            style={{ color: '#C4877A', backgroundColor: 'rgba(196, 135, 122, 0.12)' }}
          >
            {suggestedType}
          </span>
          <span className="text-[11px] text-[#B5A69C]">AI 理解</span>
        </div>
        <p className="text-[15px] text-[#3F3330] font-medium leading-relaxed">
          {item.questionText ?? '解析为一条' + suggestedType}
        </p>
      </div>

      {/* 缺失项 / 歧义 */}
      {hasAmbiguity && (
        <div className="flex items-start gap-2 mb-3 p-3 rounded-xl bg-[#FFFBF2] border border-[#F0E6DC]">
          <AlertCircle size={14} color="#D2A454" strokeWidth={2} className="flex-shrink-0 mt-0.5" />
          <div className="flex-1 min-w-0">
            <p className="text-[12px] text-[#D2A454] font-medium mb-1">信息不足</p>
            <p className="text-[13px] text-[#8A7A72]">
              {item.ambiguityReason.join('；')}
            </p>
          </div>
        </div>
      )}

      {/* 操作按钮 */}
      <div className="flex items-center gap-2 pt-1">
        <button
          type="button"
          onClick={() => onConfirm(item.recordId)}
          className="px-4 py-2 rounded-xl bg-[#C4877A] text-white text-[14px] font-medium hover:bg-[#A96A5C] transition-colors flex-1"
        >
          确认导入
        </button>
        <button
          type="button"
          onClick={() => onIgnore(item.recordId)}
          className="px-3 py-2 rounded-xl bg-[#FBF5EF] text-[#8A7A72] text-[14px] hover:bg-[#F0E6DC] transition-colors"
        >
          忽略
        </button>
      </div>
    </div>
  );
};

interface BatchCardProps {
  batch: InboxBatchItem;
  onConfirmAll: (batchId: string) => void;
  onIgnoreAll: (batchId: string) => void;
}

const BatchCard = ({ batch, onConfirmAll, onIgnoreAll }: BatchCardProps) => {
  const firstItem = batch.items[0];
  const hasImage = firstItem?.sourceImageUrl;

  return (
    <div
      className="bg-white rounded-2xl border border-[#F0E6DC] overflow-hidden"
      style={{ boxShadow: '0 2px 10px rgba(196, 135, 122, 0.10)' }}
    >
      {hasImage && (
        <div className="w-full h-36 bg-[#FBF5EF] flex items-center justify-center overflow-hidden">
          <Image
            src={firstItem.sourceImageUrl!}
            alt="来源图片"
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = 'none';
            }}
          />
        </div>
      )}

      <div className="p-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-[13px] text-[#8A7A72]">
            图片批次 · {batch.totalCount} 条
          </span>
          <ConfidenceBadge confidence={firstItem?.confidence ?? null} />
        </div>

        <ul className="space-y-2 mb-4">
          {batch.items.slice(0, 5).map((it) => (
            <li key={it.recordId} className="flex items-center gap-2 text-[14px] text-[#3F3330]">
              <div className="w-4 h-4 rounded border-2 border-[#C4877A] bg-[#C4877A]/10 flex-shrink-0" />
              <span className="truncate">{it.questionText ?? it.rawInput}</span>
            </li>
          ))}
          {batch.totalCount > 5 && (
            <li className="text-[13px] text-[#B5A69C] pl-6">
              还有 {batch.totalCount - 5} 条…
            </li>
          )}
        </ul>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onConfirmAll(batch.batchId)}
            className="px-4 py-2 rounded-xl bg-[#C4877A] text-white text-[14px] font-medium hover:bg-[#A96A5C] transition-colors flex-1"
          >
            确认导入 {batch.totalCount} 条
          </button>
          <button
            type="button"
            onClick={() => onIgnoreAll(batch.batchId)}
            className="px-3 py-2 rounded-xl bg-[#FBF5EF] text-[#8A7A72] text-[14px] hover:bg-[#F0E6DC] transition-colors"
          >
            整批忽略
          </button>
        </div>
      </div>
    </div>
  );
};

const InboxPage = () => {
  const [pendingItems, setPendingItems] = useState<InboxItem[]>([]);
  const [batches, setBatches] = useState<InboxBatchItem[]>([]);
  const [ignoredItems, setIgnoredItems] = useState<InboxItem[]>([]);
  const [expiredItems, setExpiredItems] = useState<InboxItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showIgnored, setShowIgnored] = useState(false);
  const [showExpired, setShowExpired] = useState(false);

  const loadData = async () => {
    try {
      const [pending, batchList, ignored, expired] = await Promise.all([
        api.getPendingItems(),
        api.getBatches(),
        api.getIgnoredItems(),
        api.getExpiredItems(),
      ]);
      // 过滤掉属于批次的单条（批次单独展示）
      const batchIds = new Set(batchList.map((b) => b.batchId));
      const standalone = pending.filter((p) => !p.batchId || !batchIds.has(p.batchId));
      setPendingItems(standalone);
      setBatches(batchList);
      setIgnoredItems(ignored);
      setExpiredItems(expired);
    } catch (e: unknown) {
      setError('加载失败，请稍后重试');
      logger.error('收件箱加载失败', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let mounted = true;
    loadData().then(() => {
      if (!mounted) return;
    });
    return () => {
      mounted = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleConfirm = async (id: string) => {
    try {
      await api.confirmItem(id);
      setPendingItems((prev) => prev.filter((it) => it.recordId !== id));
    } catch (e: unknown) {
      logger.error('确认失败', e);
    }
  };

  const handleIgnore = async (id: string) => {
    try {
      await api.ignoreItem(id);
      setPendingItems((prev) => prev.filter((it) => it.recordId !== id));
    } catch (e: unknown) {
      logger.error('忽略失败', e);
    }
  };

  const handleConfirmBatch = async (batchId: string) => {
    try {
      await api.confirmBatch(batchId);
      setBatches((prev) => prev.filter((b) => b.batchId !== batchId));
    } catch (e: unknown) {
      logger.error('批量确认失败', e);
    }
  };

  const handleIgnoreBatch = async (batchId: string) => {
    try {
      await api.ignoreBatch(batchId);
      setBatches((prev) => prev.filter((b) => b.batchId !== batchId));
    } catch (e: unknown) {
      logger.error('批量忽略失败', e);
    }
  };

  const isEmpty =
    !loading && !error && pendingItems.length === 0 && batches.length === 0;

  if (loading) {
    return (
      <div className="space-y-4">
        <h1 className="text-[24px] font-semibold text-[#3F3330]">AI 收件箱</h1>
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-40 bg-white rounded-2xl border border-[#F0E6DC] animate-pulse" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-2xl border border-[#F0E6DC] p-8 text-center">
        <p className="text-[#C96F62] text-[15px]">{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-[24px] font-semibold text-[#3F3330] mb-1">
          AI 收件箱
        </h1>
        <p className="text-[13px] text-[#8A7A72]">
          AI 不确定的事会放在这里，等你确认
        </p>
      </div>

      {/* 空状态 */}
      {isEmpty && (
        <div
          className="bg-white rounded-2xl border border-[#F0E6DC] p-8 text-center"
          style={{ boxShadow: '0 2px 10px rgba(196, 135, 122, 0.10)' }}
        >
          <div className="w-12 h-12 mx-auto mb-3 rounded-xl bg-[#FBF5EF] flex items-center justify-center">
            <Inbox size={22} color="#C4877A" strokeWidth={2} />
          </div>
          <p className="text-[15px] text-[#3F3330] mb-1">
            没有需要确认的事。
          </p>
          <p className="text-[13px] text-[#8A7A72]">
            AI 不确定时会放在这里。
          </p>
        </div>
      )}

      {/* 批次卡片 */}
      {batches.length > 0 && (
        <div className="space-y-4">
          {batches.map((batch) => (
            <BatchCard
              key={batch.batchId}
              batch={batch}
              onConfirmAll={handleConfirmBatch}
              onIgnoreAll={handleIgnoreBatch}
            />
          ))}
        </div>
      )}

      {/* 待确认单条卡片流 */}
      {pendingItems.length > 0 && (
        <div className="space-y-4">
          {pendingItems.map((item) => (
            <InboxCard
              key={item.recordId}
              item={item}
              onConfirm={handleConfirm}
              onIgnore={handleIgnore}
            />
          ))}
        </div>
      )}

      {/* 已忽略折叠区 */}
      {ignoredItems.length > 0 && (
        <div>
          <button
            type="button"
            onClick={() => setShowIgnored((v) => !v)}
            className="flex items-center gap-2 text-[13px] text-[#8A7A72] hover:text-[#3F3330] transition-colors px-1 mb-2"
          >
            {showIgnored ? (
              <ChevronUp size={14} strokeWidth={2} />
            ) : (
              <ChevronDown size={14} strokeWidth={2} />
            )}
            <span>已忽略 {ignoredItems.length} 条</span>
          </button>
          {showIgnored && (
            <div className="space-y-3 opacity-60">
              {ignoredItems.map((item) => (
                <div
                  key={item.recordId}
                  className="bg-white rounded-2xl border border-[#F0E6DC] p-4"
                >
                  <p className="text-[14px] text-[#8A7A72] line-clamp-2">
                    {item.rawInput}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 已过期折叠区 */}
      {expiredItems.length > 0 && (
        <div>
          <button
            type="button"
            onClick={() => setShowExpired((v) => !v)}
            className="flex items-center gap-2 text-[13px] text-[#8A7A72] hover:text-[#3F3330] transition-colors px-1 mb-2"
          >
            {showExpired ? (
              <ChevronUp size={14} strokeWidth={2} />
            ) : (
              <ChevronDown size={14} strokeWidth={2} />
            )}
            <span>已过期 {expiredItems.length} 条</span>
          </button>
          {showExpired && (
            <div className="space-y-3 opacity-60">
              {expiredItems.map((item) => (
                <div
                  key={item.recordId}
                  className="bg-white rounded-2xl border border-[#F0E6DC] p-4"
                >
                  <p className="text-[14px] text-[#8A7A72] line-clamp-2">
                    {item.rawInput}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default InboxPage;
