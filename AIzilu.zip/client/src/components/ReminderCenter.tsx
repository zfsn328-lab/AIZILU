import { useEffect, useRef, useState } from 'react';
import { Bell, X, Check } from 'lucide-react';
import {
  getPendingReminders,
  getReminderHistory,
  markReminderRead,
  type ReminderItem,
} from '@client/src/api/reminders';

const POLL_INTERVAL = 30_000;

function fmtTime(iso: string): string {
  try {
    const d = new Date(iso);
    const now = new Date();
    const sameDay = d.toDateString() === now.toDateString();
    const hm = `${String(d.getHours()).padStart(2, '0')}:${String(
      d.getMinutes(),
    ).padStart(2, '0')}`;
    if (sameDay) return `今天 ${hm}`;
    return `${String(d.getMonth() + 1).padStart(2, '0')}-${String(
      d.getDate(),
    ).padStart(2, '0')} ${hm}`;
  } catch {
    return '';
  }
}

/**
 * 全局到点提醒中心：
 * 30s 轮询服务端未读提醒，弹出顶部横幅；铃铛入口可查看未读与历史。
 */
export const ReminderCenter = () => {
  const [banner, setBanner] = useState<ReminderItem | null>(null);
  const [open, setOpen] = useState(false);
  const [list, setList] = useState<ReminderItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [badgeCount, setBadgeCount] = useState(0);
  const shownRef = useRef<Set<string>>(new Set());
  const bannerTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const refreshPending = async (silent = false) => {
    const items = await getPendingReminders();
    setBadgeCount(items.filter((it) => !it.isRead).length);
    if (items.length > 0 && !silent && !banner && !open) {
      // 弹出尚未展示过的最新一条
      const fresh = items.find((it) => !shownRef.current.has(it.id)) ?? items[0];
      setBanner(fresh);
      if (bannerTimerRef.current) clearTimeout(bannerTimerRef.current);
      bannerTimerRef.current = setTimeout(() => setBanner(null), 6000);
    }
    shownRef.current = new Set([...items.map((it) => it.id), ...shownRef.current]);
    if (open) {
      const hist = showHistory ? await getReminderHistory() : items;
      setList(hist);
    }
  };

  useEffect(() => {
    refreshPending();
    const timer = setInterval(() => refreshPending(), POLL_INTERVAL);
    return () => {
      clearInterval(timer);
      if (bannerTimerRef.current) clearTimeout(bannerTimerRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, showHistory]);

  const closeBanner = async (id: string) => {
    setBanner(null);
    await markReminderRead(id);
    // 关掉当前横幅后，若还有其他未读提醒，立即弹下一条
    refreshPending();
  };

  const openCenter = async () => {
    setOpen(true);
    setShowHistory(false);
    setList(await getPendingReminders());
  };

  const readItem = async (id: string) => {
    await markReminderRead(id);
    setList((prev) => prev.map((it) => (it.id === id ? { ...it, isRead: true } : it)));
    refreshPending(true);
  };

  const unreadCount = open
    ? list.filter((it) => !it.isRead).length
    : badgeCount;

  return (
    <>
      {/* 顶部到点提醒横幅 */}
      {banner && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[100] w-[min(92vw,420px)] animate-[slideDown_.3s_ease]">
          <div className="bg-[#3F3330] text-white rounded-2xl shadow-xl px-4 py-3 flex items-start gap-3">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <Bell size={15} className="text-[#F4C6A8] shrink-0" />
                <span className="text-[12px] text-[#E8D9CC]">
                  到点提醒 · {fmtTime(banner.remindAt)}
                </span>
              </div>
              <p className="text-[15px] font-medium mt-1 leading-snug break-all">
                {banner.content}
              </p>
            </div>
            <button
              onClick={() => closeBanner(banner.id)}
              className="shrink-0 flex items-center gap-1 text-[12px] px-2.5 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 transition-colors"
            >
              <Check size={13} />
              知道了
            </button>
            <button
              onClick={() => closeBanner(banner.id)}
              aria-label="关闭提醒"
              className="shrink-0 text-white/60 hover:text-white"
            >
              <X size={16} />
            </button>
          </div>
        </div>
      )}

      {/* 铃铛入口 */}
      <div className="fixed top-3 right-3 z-[60]">
        <button
          onClick={openCenter}
          className="relative w-9 h-9 flex items-center justify-center rounded-xl bg-white border border-[#F0E6DC] text-[#8A7A72] hover:border-[#C4877A] hover:text-[#3F3330] transition-colors"
          style={{ boxShadow: '0 1px 6px rgba(196, 135, 122, 0.18)' }}
          aria-label="提醒中心"
        >
          <Bell size={18} strokeWidth={2} />
          {unreadCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-[#C96F62] text-white text-[10px] leading-4 text-center">
              {unreadCount > 99 ? '99+' : unreadCount}
            </span>
          )}
        </button>
      </div>

      {/* 提醒面板 */}
      {open && (
        <>
          <div
            className="fixed inset-0 z-[90] bg-black/20"
            onClick={() => setOpen(false)}
          />
          <div className="fixed top-0 right-0 bottom-0 z-[95] w-[min(92vw,360px)] bg-white rounded-l-2xl shadow-xl flex flex-col">
            <div className="flex items-center justify-between px-4 py-3 border-b border-[#F0E6DC]">
              <h3 className="text-[15px] font-semibold text-[#3F3330]">
                提醒中心
              </h3>
              <button
                onClick={() => setOpen(false)}
                aria-label="关闭"
                className="w-8 h-8 flex items-center justify-center rounded-lg text-[#8A7A72] hover:bg-[#FBF5EF]"
              >
                <X size={17} />
              </button>
            </div>
            <div className="flex gap-1 px-3 pt-3 pb-2">
              <button
                onClick={() => {
                  setShowHistory(false);
                  setList([]);
                  refreshPending(true);
                }}
                className={`text-[12px] px-3 py-1.5 rounded-lg transition-colors ${
                  !showHistory
                    ? 'bg-[#C4877A] text-white'
                    : 'bg-[#FBF5EF] text-[#8A7A72]'
                }`}
              >
                未读
              </button>
              <button
                onClick={async () => {
                  setShowHistory(true);
                  setList(await getReminderHistory());
                }}
                className={`text-[12px] px-3 py-1.5 rounded-lg transition-colors ${
                  showHistory
                    ? 'bg-[#C4877A] text-white'
                    : 'bg-[#FBF5EF] text-[#8A7A72]'
                }`}
              >
                历史
              </button>
            </div>
            <div className="flex-1 overflow-y-auto px-3 pb-4">
              {list.length === 0 && (
                <p className="text-[13px] text-[#B5A69C] text-center pt-10">
                  {showHistory ? '还没有提醒记录' : '没有未读提醒'}
                </p>
              )}
              {list.map((it) => (
                <div
                  key={it.id}
                  className={`flex items-start gap-2.5 px-3 py-2.5 rounded-xl mb-1.5 ${
                    it.isRead ? 'bg-[#FBF5EF]' : 'bg-[#F6EBE3]'
                  }`}
                >
                  <div className="flex-1 min-w-0">
                    <p
                      className={`text-[14px] leading-snug break-all ${
                        it.isRead ? 'text-[#8A7A72]' : 'text-[#3F3330] font-medium'
                      }`}
                    >
                      {it.content}
                    </p>
                    <p className="text-[11px] text-[#B5A69C] mt-0.5">
                      {fmtTime(it.remindAt)}
                    </p>
                  </div>
                  {!it.isRead && (
                    <button
                      onClick={() => readItem(it.id)}
                      className="shrink-0 text-[11px] px-2 py-1 rounded-md bg-[#C4877A] text-white"
                    >
                      已读
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </>
  );
};
