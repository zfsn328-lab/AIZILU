import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  TodayAiSuggestion,
  TodayOverview,
  TodayTimelineItem,
} from '@shared/api.interface';

function getTodayStr(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export async function getOverview(): Promise<TodayOverview> {
  try {
    const { data } = await axiosForBackend.get<TodayOverview>(
      '/api/today/overview',
      { params: { date: getTodayStr(), _t: Date.now() } },
    );
    return data;
  } catch (error: unknown) {
    logger.error('获取今日概览失败', error);
    throw error;
  }
}

export async function getTimeline(): Promise<TodayTimelineItem[]> {
  try {
    const { data } = await axiosForBackend.get<TodayTimelineItem[]>(
      '/api/today/timeline',
      { params: { date: getTodayStr(), _t: Date.now() } },
    );
    return data;
  } catch (error: unknown) {
    logger.error('获取今日时间轴失败', error);
    throw error;
  }
}

export async function getSuggestion(): Promise<TodayAiSuggestion | null> {
  try {
    const { data } = await axiosForBackend.get<TodayAiSuggestion | null>(
      '/api/today/ai-suggestion',
      { params: { date: getTodayStr() } },
    );
    return data;
  } catch (error: unknown) {
    logger.error('获取AI建议失败', error);
    throw error;
  }
}

export async function toggleTask(taskId: string): Promise<{ status: string }> {
  try {
    const { data } = await axiosForBackend.post<{ status: string }>(
      `/api/today/tasks/${taskId}/toggle`,
    );
    return data;
  } catch (error: unknown) {
    logger.error('切换任务状态失败', error);
    throw error;
  }
}

export async function adoptSuggestion(id: string): Promise<void> {
  try {
    await axiosForBackend.post(`/api/inbox/${id}/confirm`, {
      targetType: 'task',
    });
  } catch (error: unknown) {
    logger.error('采纳AI建议失败', error);
    throw error;
  }
}

export async function dismissSuggestion(id: string): Promise<void> {
  try {
    await axiosForBackend.post(`/api/inbox/${id}/ignore`);
  } catch (error: unknown) {
    logger.error('忽略AI建议失败', error);
    throw error;
  }
}
