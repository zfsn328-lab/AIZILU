import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';

export interface ReminderItem {
  id: string;
  itemType: string;
  itemId: string;
  content: string;
  remindAt: string;
  notifiedAt: string;
  isRead: boolean;
}

export async function getPendingReminders(): Promise<ReminderItem[]> {
  try {
    const { data } = await axiosForBackend.get<ReminderItem[]>(
      '/api/reminders/pending',
      { params: { _t: Date.now() } },
    );
    return data;
  } catch (error: unknown) {
    logger.error('获取未读提醒失败', error);
    return [];
  }
}

export async function getReminderHistory(): Promise<ReminderItem[]> {
  try {
    const { data } = await axiosForBackend.get<ReminderItem[]>(
      '/api/reminders/history',
      { params: { _t: Date.now() } },
    );
    return data;
  } catch (error: unknown) {
    logger.error('获取提醒历史失败', error);
    return [];
  }
}

export async function markReminderRead(id: string): Promise<void> {
  try {
    await axiosForBackend.post(`/api/reminders/${id}/read`);
  } catch (error: unknown) {
    logger.error('标记提醒已读失败', error);
  }
}
