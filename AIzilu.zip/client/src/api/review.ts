import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  DailyMetricItem,
  ReviewItem,
  ReviewMetrics,
} from '@shared/api.interface';

export async function getMetrics(
  period: 'today' | 'week',
  _date?: string,
): Promise<ReviewMetrics> {
  try {
    const { data } = await axiosForBackend.get<ReviewMetrics>(
      '/api/review/metrics',
      { params: { period } },
    );
    return data;
  } catch (error: unknown) {
    logger.error('获取复盘指标失败', error);
    throw error;
  }
}

export async function getDetail(
  period: 'daily' | 'weekly',
  date: string,
): Promise<ReviewItem | null> {
  try {
    if (period === 'daily') {
      const { data } = await axiosForBackend.get<ReviewItem | null>(
        '/api/review/daily',
        { params: { date } },
      );
      return data;
    }
    const { data } = await axiosForBackend.get<ReviewItem | null>(
      '/api/review/weekly',
      { params: { weekStart: date } },
    );
    return data;
  } catch (error: unknown) {
    logger.error('获取复盘详情失败', error);
    throw error;
  }
}

export async function getDailyMetrics(
  start: string,
  end: string,
): Promise<DailyMetricItem[]> {
  try {
    const { data } = await axiosForBackend.get<DailyMetricItem[]>(
      '/api/review/daily-metrics',
      { params: { start, end } },
    );
    return data;
  } catch (error: unknown) {
    logger.error('获取每日指标失败', error);
    throw error;
  }
}

export async function generateDaily(date: string): Promise<ReviewItem> {
  try {
    const { data } = await axiosForBackend.post<ReviewItem>(
      '/api/review/daily/generate',
      null,
      { params: { date } },
    );
    return data;
  } catch (error: unknown) {
    logger.error('手动生成日报失败', error);
    throw error;
  }
}
