import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type { CalendarExportItem } from '@shared/api.interface';

export interface CalendarExportResponse {
  items: CalendarExportItem[];
  exportedAt: string;
  horizonDays: number;
}

export async function getCalendarExport(days = 90): Promise<CalendarExportResponse> {
  try {
    const { data } = await axiosForBackend.get<CalendarExportResponse>(
      '/api/calendar/export',
      { params: { days } },
    );
    return data;
  } catch (error: unknown) {
    logger.error('获取日历导出失败', error);
    throw error;
  }
}
