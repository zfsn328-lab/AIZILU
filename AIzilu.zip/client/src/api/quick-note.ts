import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type { QuickNoteItem, QuickNoteType } from '@shared/api.interface';

export async function getQuickNotes(): Promise<QuickNoteItem[]> {
  try {
    const { data } = await axiosForBackend.get<{ items: QuickNoteItem[] }>(
      '/api/quick-note',
    );
    return data.items;
  } catch (error: unknown) {
    logger.error('获取随手记失败', error);
    throw error;
  }
}

export async function createQuickNote(
  content: string,
  remindAt?: string | null,
  type?: QuickNoteType,
  periodDays?: number | null,
): Promise<{ item: QuickNoteItem; remindPast: boolean }> {
  try {
    const { data } = await axiosForBackend.post<{
      item: QuickNoteItem;
      remindPast: boolean;
    }>('/api/quick-note', { content, remindAt, type, periodDays });
    return data;
  } catch (error: unknown) {
    logger.error('创建随手记失败', error);
    throw error;
  }
}

export async function deleteQuickNote(id: string): Promise<void> {
  try {
    await axiosForBackend.delete(`/api/quick-note/${id}`);
  } catch (error: unknown) {
    logger.error('删除随手记失败', error);
    throw error;
  }
}

export async function toggleQuickNoteDone(id: string): Promise<{ isDone: boolean }> {
  try {
    const { data } = await axiosForBackend.post<{ isDone: boolean }>(
      `/api/quick-note/${id}/toggle`,
    );
    return data;
  } catch (error: unknown) {
    logger.error('勾选随手记失败', error);
    throw error;
  }
}
