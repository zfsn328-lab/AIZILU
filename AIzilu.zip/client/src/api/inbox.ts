import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type { InboxBatchItem, InboxItem } from '@shared/api.interface';

export async function getPendingItems(): Promise<InboxItem[]> {
  try {
    const { data } = await axiosForBackend.get<{
      items: InboxItem[];
      batches: InboxBatchItem[];
    }>('/api/inbox/pending');
    return data.items;
  } catch (error: unknown) {
    logger.error('获取待确认收件箱失败', error);
    throw error;
  }
}

export async function getBatches(): Promise<InboxBatchItem[]> {
  try {
    const { data } = await axiosForBackend.get<{
      items: InboxItem[];
      batches: InboxBatchItem[];
    }>('/api/inbox/pending');
    return data.batches;
  } catch (error: unknown) {
    logger.error('获取批次列表失败', error);
    throw error;
  }
}

export async function getIgnoredItems(): Promise<InboxItem[]> {
  try {
    const { data } = await axiosForBackend.get<{
      items: InboxItem[];
      total: number;
    }>('/api/inbox/history', { params: { status: 'ignored', page: 1, pageSize: 50 } });
    return data.items;
  } catch (error: unknown) {
    logger.error('获取已忽略条目失败', error);
    throw error;
  }
}

export async function getExpiredItems(): Promise<InboxItem[]> {
  try {
    const { data } = await axiosForBackend.get<{
      items: InboxItem[];
      total: number;
    }>('/api/inbox/history', { params: { status: 'expired', page: 1, pageSize: 50 } });
    return data.items;
  } catch (error: unknown) {
    logger.error('获取已过期条目失败', error);
    throw error;
  }
}

export async function confirmItem(id: string): Promise<void> {
  try {
    await axiosForBackend.post(`/api/inbox/${id}/confirm`, {
      targetType: 'task',
    });
  } catch (error: unknown) {
    logger.error('确认收件箱条目失败', error);
    throw error;
  }
}

export async function ignoreItem(id: string): Promise<void> {
  try {
    await axiosForBackend.post(`/api/inbox/${id}/ignore`);
  } catch (error: unknown) {
    logger.error('忽略收件箱条目失败', error);
    throw error;
  }
}

export async function confirmBatch(batchId: string): Promise<void> {
  try {
    await axiosForBackend.post(`/api/inbox/batch/${batchId}/confirm`);
  } catch (error: unknown) {
    logger.error('确认批次失败', error);
    throw error;
  }
}

export async function ignoreBatch(batchId: string): Promise<void> {
  try {
    await axiosForBackend.post(`/api/inbox/batch/${batchId}/ignore`);
  } catch (error: unknown) {
    logger.error('忽略批次失败', error);
    throw error;
  }
}
