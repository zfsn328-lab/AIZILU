import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type { BreakdownItem, UpdateBreakdownStepInput } from '@shared/api.interface';

export async function createBreakdown(title: string): Promise<BreakdownItem> {
  try {
    const { data } = await axiosForBackend.post<BreakdownItem>(
      '/api/breakdown',
      { title },
    );
    return data;
  } catch (error: unknown) {
    logger.error('创建目标拆解失败', error);
    throw error;
  }
}

export async function getBreakdowns(): Promise<BreakdownItem[]> {
  try {
    const { data } = await axiosForBackend.get<BreakdownItem[]>('/api/breakdown');
    return data;
  } catch (error: unknown) {
    logger.error('获取目标拆解列表失败', error);
    throw error;
  }
}

export async function confirmBreakdown(id: string): Promise<BreakdownItem> {
  try {
    const { data } = await axiosForBackend.post<BreakdownItem>(
      `/api/breakdown/${id}/confirm`,
    );
    return data;
  } catch (error: unknown) {
    logger.error('确认目标拆解失败', error);
    throw error;
  }
}

export async function updateBreakdownTitle(
  id: string,
  title: string,
): Promise<BreakdownItem> {
  try {
    const { data } = await axiosForBackend.patch<BreakdownItem>(
      `/api/breakdown/${id}/title`,
      { title },
    );
    return data;
  } catch (error: unknown) {
    logger.error('修改拆解目标名称失败', error);
    throw error;
  }
}

export async function updateBreakdown(
  id: string,
  title: string,
  steps?: UpdateBreakdownStepInput[],
): Promise<BreakdownItem> {
  try {
    const body: { title: string; steps?: UpdateBreakdownStepInput[] } = { title };
    if (steps) body.steps = steps;
    const { data } = await axiosForBackend.patch<BreakdownItem>(
      `/api/breakdown/${id}`,
      body,
    );
    return data;
  } catch (error: unknown) {
    logger.error('修改拆解目标失败', error);
    throw error;
  }
}

export async function toggleBreakdownDone(id: string): Promise<BreakdownItem> {
  try {
    const { data } = await axiosForBackend.post<BreakdownItem>(
      `/api/breakdown/${id}/toggle-done`,
    );
    return data;
  } catch (error: unknown) {
    logger.error('切换拆解完成状态失败', error);
    throw error;
  }
}

export async function removeBreakdown(id: string): Promise<void> {
  try {
    await axiosForBackend.delete(`/api/breakdown/${id}`);
  } catch (error: unknown) {
    logger.error('删除拆解目标失败', error);
    throw error;
  }
}
