import { APP_FILTER } from '@nestjs/core';
import { Module } from '@nestjs/common';
import { PlatformModule } from '@lark-apaas/fullstack-nestjs-core';

import { GlobalExceptionFilter } from './common/filters/exception.filter';
import { CalendarModule } from './modules/calendar/calendar.module';
import { BreakdownModule } from './modules/breakdown/breakdown.module';
import { DbInitModule } from './modules/db-init/db-init.module';
import { DemoModule } from './modules/demo/demo.module';
import { InboxModule } from './modules/inbox/inbox.module';
import { PlanModule } from './modules/plan/plan.module';
import { QuickNoteModule } from './modules/quick-note/quick-note.module';
import { ReminderModule } from './modules/reminder/reminder.module';
import { ReviewModule } from './modules/review/review.module';
import { TodayModule } from './modules/today/today.module';
import { ViewModule } from './modules/view/view.module';

@Module({
  imports: [
    // 平台 Module，提供平台能力
    PlatformModule.forRoot(),
    // ====== @route-section: business-modules START ======
    // Place all business modules here.Do NOT add fallback modules here.
    DbInitModule,
    TodayModule,
    InboxModule,
    BreakdownModule,
    PlanModule,
    QuickNoteModule,
    ReminderModule,
    ReviewModule,
    CalendarModule,
    DemoModule,
    // ====== @route-section: business-modules END ======

    // ⚠️ @route-order: last
    // ViewModule is the fallback route module, must be registered last.
    ViewModule,
  ],
  providers: [
    {
      provide: APP_FILTER,
      useClass: GlobalExceptionFilter,
    },
  ],
})
export class AppModule {}
