/* eslint-disable */
/** auto generated, do not edit */
import { sql } from 'drizzle-orm';
import { boolean, date, index, integer, numeric, pgTable, text, time, uniqueIndex, customType } from "drizzle-orm/pg-core"

export const customTimestamptz = customType<{
  data: Date;
  driverData: string;
  config: { precision?: number };
}>({
  dataType(config) {
    const precision = typeof config?.precision !== 'undefined'
      ? ` (${config.precision})`
      : '';
    return `timestamptz${precision}`;
  },
  toDriver(value: Date | string | number) {
    if (value == null) return value as any;
    if (typeof value === 'number') return new Date(value).toISOString();
    if (typeof value === 'string') return value;
    if (value instanceof Date) return value.toISOString();
    throw new Error('Invalid timestamp value');
  },
  fromDriver(value: string | Date): Date {
    if (value instanceof Date) return value;
    return new Date(value);
  },
});

export const userProfile = customType<{
  data: string;
  driverData: string;
}>({
  dataType() {
    return 'user_profile';
  },
  toDriver(value: string) {
    return sql`ROW(${value})::user_profile`;
  },
  fromDriver(value: string) {
    const [userId] = value.slice(1, -1).split(',');
    return userId.trim();
  },
});

export type FileAttachment = {
  bucket_id: string;
  file_path: string;
};

export const fileAttachment = customType<{
  data: FileAttachment;
  driverData: string;
}>({
  dataType() {
    return 'file_attachment';
  },
  toDriver(value: FileAttachment) {
    return sql`ROW(${value.bucket_id},${value.file_path})::file_attachment`;
  },
  fromDriver(value: string): FileAttachment {
    const [bucketId, filePath] = value.slice(1, -1).split(',');
    return { bucket_id: bucketId.trim(), file_path: filePath.trim() };
  },
});

export function escapeLiteral(str: string): string {
  return "'" + str.replace(/'/g, "''") + "'";
}

export const userProfileArray = customType<{
  data: string[];
  driverData: string;
}>({
  dataType() {
    return 'user_profile[]';
  },
  toDriver(value: string[]) {
    if (!value || value.length === 0) {
      return sql`'{}'::user_profile[]`;
    }
    const elements = value.map(id => `ROW(${escapeLiteral(id)})::user_profile`).join(',');
    return sql.raw(`ARRAY[${elements}]::user_profile[]`);
  },
  fromDriver(value: string): string[] {
    if (!value || value === '{}') return [];
    const inner = value.slice(1, -1);
    const matches = inner.match(/\([^)]*\)/g) || [];
    return matches.map(m => m.slice(1, -1).split(',')[0].trim());
  },
});

export const fileAttachmentArray = customType<{
  data: FileAttachment[];
  driverData: string;
}>({
  dataType() {
    return 'file_attachment[]';
  },
  toDriver(value: FileAttachment[]) {
    if (!value || value.length === 0) {
      return sql`'{}'::file_attachment[]`;
    }
    const elements = value.map(f =>
      `ROW(${escapeLiteral(f.bucket_id)},${escapeLiteral(f.file_path)})::file_attachment`
    ).join(',');
    return sql.raw(`ARRAY[${elements}]::file_attachment[]`);
  },
  fromDriver(value: string): FileAttachment[] {
    if (!value || value === '{}') return [];
    const inner = value.slice(1, -1);
    const matches = inner.match(/\([^)]*\)/g) || [];
    return matches.map(m => {
      const [bucketId, filePath] = m.slice(1, -1).split(',');
      return { bucket_id: bucketId.trim(), file_path: filePath.trim() };
    });
  },
});

export const breakdown = pgTable("breakdown", {
  recordId: text("record_id").primaryKey(),
  title: text("title").notNull(),
  steps: text("steps").notNull(),
  status: text("status").notNull().default('pending'),
  confirmedAt: customTimestamptz("confirmed_at", { precision: 6 }),
  isDeleted: boolean("is_deleted").default(false),
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_breakdown_status").on(table.status),
  index("idx_breakdown_is_deleted").on(table.isDeleted),
]);

export const goalLog = pgTable("goal_log", {
  recordId: text("record_id").primaryKey(),
  goalId: text("goal_id").notNull(),
  logDate: date("log_date").notNull(),
  status: text("status").notNull(),
  completedAt: customTimestamptz("completed_at", { precision: 6 }),
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("idx_goal_log_unique").on(table.goalId, table.logDate),
  index("idx_goal_log_goal").on(table.goalId),
]);

export const reminderNotification = pgTable("reminder_notification", {
  id: text("id").primaryKey(),
  itemType: text("item_type").notNull(),
  itemId: text("item_id").notNull(),
  content: text("content").notNull(),
  remindAt: customTimestamptz("remind_at", { precision: 6 }).notNull(),
  notifiedAt: customTimestamptz("notified_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  isRead: boolean("is_read").notNull().default(false),
}, (table) => [
  uniqueIndex("idx_reminder_uniq").on(table.itemType, table.itemId, table.remindAt),
  index("idx_reminder_is_read").on(table.isRead),
]);

export const quickNote = pgTable("quick_note", {
  recordId: text("record_id").primaryKey(),
  content: text("content").notNull(),
  noteDate: date("note_date").notNull(),
  noteTime: text("note_time"),
  isDeleted: boolean("is_deleted").notNull().default(false),
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  remindAt: customTimestamptz("remind_at", { precision: 6 }),
  isDone: boolean("is_done").notNull().default(false),
}, (table) => [
  index("idx_quick_note_created_at").on(table.createdAt),
  index("idx_quick_note_is_deleted").on(table.isDeleted),
]);

export const dailyMetric = pgTable("daily_metric", {
  recordId: text("record_id").primaryKey(),
  metricDate: date("metric_date").notNull().unique(),
  plannedCount: integer("planned_count").default(0),
  completedCount: integer("completed_count").default(0),
  newAddedCount: integer("new_added_count").default(0),
  delayedCount: integer("delayed_count").default(0),
  completionRate: numeric("completion_rate").default('0'),
  estDeepWorkMinutes: integer("est_deep_work_minutes").default(0),
  eventCount: integer("event_count").default(0),
  habitTotal: integer("habit_total").default(0),
  habitDone: integer("habit_done").default(0),
  inboxPending: integer("inbox_pending").default(0),
  snapshotAt: customTimestamptz("snapshot_at", { precision: 6 }),
  isFinal: boolean("is_final").default(false),
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("daily_metric_metric_date_key").on(table.metricDate),
  index("idx_daily_metric_metric_date").on(table.metricDate),
]);

export const activityLog = pgTable("activity_log", {
  recordId: text("record_id").primaryKey(),
  action: text("action").notNull(),
  targetType: text("target_type").notNull(),
  targetId: text("target_id").notNull(),
  beforeJson: text("before_json"),
  afterJson: text("after_json"),
  changedFields: text("changed_fields").default('[]'),
  sessionId: text("session_id").notNull(),
  triggerSource: text("trigger_source").notNull(),
  confidence: numeric("confidence"),
  batchId: text("batch_id"),
  isUndone: boolean("is_undone").default(false),
  undoneAt: customTimestamptz("undone_at", { precision: 6 }),
  idempotencyKey: text("idempotency_key").notNull(),
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_activity_log_target").on(table.targetType, table.targetId),
  index("idx_activity_log_created_at").on(table.createdAt),
  index("idx_activity_log_batch_id").on(table.batchId),
  index("idx_activity_log_idempotency_key").on(table.idempotencyKey),
]);

export const review = pgTable("review", {
  recordId: text("record_id").primaryKey(),
  reviewType: text("review_type").notNull(),
  periodStart: date("period_start").notNull(),
  periodEnd: date("period_end").notNull(),
  plannedCount: integer("planned_count").default(0),
  completedCount: integer("completed_count").default(0),
  newAddedCount: integer("new_added_count").default(0),
  completionRate: numeric("completion_rate").default('0'),
  completionRateInclNew: numeric("completion_rate_incl_new").default('0'),
  delayedCount: integer("delayed_count").default(0),
  newDelayedCount: integer("new_delayed_count").default(0),
  cancelledCount: integer("cancelled_count").default(0),
  estDeepWorkMinutes: integer("est_deep_work_minutes").default(0),
  actualTrackedMinutes: integer("actual_tracked_minutes").default(0),
  eventHours: numeric("event_hours").default('0'),
  habitTotal: integer("habit_total").default(0),
  habitDone: integer("habit_done").default(0),
  habitRate: numeric("habit_rate").default('0'),
  topDelayedTasks: text("top_delayed_tasks"),
  goalProgress: text("goal_progress"),
  highlights: text("highlights"),
  issues: text("issues"),
  adviceItems: text("advice_items"),
  weekdayHeatmap: text("weekday_heatmap"),
  summaryText: text("summary_text"),
  generatedAt: customTimestamptz("generated_at", { precision: 6 }).notNull(),
  laterUpdateCount: integer("later_update_count").default(0),
  deliveryStatus: text("delivery_status").default('pending'),
  userRead: boolean("user_read").default(false),
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_review_type_period").on(table.reviewType, table.periodStart, table.periodEnd),
]);

export const inbox = pgTable("inbox", {
  recordId: text("record_id").primaryKey(),
  rawInput: text("raw_input").notNull(),
  inputType: text("input_type").notNull(),
  sourceImageUrl: text("source_image_url"),
  parsedJson: text("parsed_json"),
  suggestedType: text("suggested_type"),
  draftPayload: text("draft_payload"),
  confidence: numeric("confidence"),
  confidenceDetail: text("confidence_detail"),
  ambiguityReason: text("ambiguity_reason").default('[]'),
  questionText: text("question_text"),
  questionOptions: text("question_options"),
  batchId: text("batch_id"),
  batchIndex: integer("batch_index"),
  status: text("status").notNull().default('pending'),
  resolvedTargetType: text("resolved_target_type"),
  resolvedTargetId: text("resolved_target_id"),
  nudgeCount: integer("nudge_count").default(0),
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  expireAt: customTimestamptz("expire_at", { precision: 6 }).notNull().default(sql`(CURRENT_TIMESTAMP + '7 days'::interval)`),
  isDeleted: boolean("is_deleted").default(false),
}, (table) => [
  index("idx_inbox_status").on(table.status),
  index("idx_inbox_is_deleted").on(table.isDeleted),
  index("idx_inbox_batch_id").on(table.batchId),
  index("idx_inbox_expire_at").on(table.expireAt),
]);

export const goal = pgTable("goal", {
  recordId: text("record_id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category").default('other'),
  metricType: text("metric_type").default('count'),
  targetValue: numeric("target_value"),
  currentValue: numeric("current_value").default('0'),
  unit: text("unit").default('次'),
  progressSource: text("progress_source").default('manual'),
  autoFilterTags: text("auto_filter_tags").default('[]'),
  autoHabitId: text("auto_habit_id"),
  startDate: date("start_date").notNull(),
  targetDate: date("target_date").notNull(),
  status: text("status").default('active'),
  progressPercent: numeric("progress_percent").default('0'),
  achievedAt: customTimestamptz("achieved_at", { precision: 6 }),
  isDeleted: boolean("is_deleted").default(false),
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  periodDays: integer("period_days"),
}, (table) => [
  index("idx_goal_status").on(table.status),
  index("idx_goal_is_deleted").on(table.isDeleted),
]);

export const habitLog = pgTable("habit_log", {
  recordId: text("record_id").primaryKey(),
  habitId: text("habit_id").notNull(),
  logDate: date("log_date").notNull(),
  status: text("status").notNull(),
  completedAt: customTimestamptz("completed_at", { precision: 6 }),
  note: text("note"),
  weekIndex: text("week_index"),
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("idx_habit_log_habit_id_log_date").on(table.habitId, table.logDate),
  index("idx_habit_log_log_date").on(table.logDate),
]);

export const habit = pgTable("habit", {
  recordId: text("record_id").primaryKey(),
  name: text("name").notNull(),
  frequencyType: text("frequency_type").notNull(),
  frequencyValue: integer("frequency_value").default(1),
  targetWeekdays: text("target_weekdays").default('[]'),
  catchUpWindow: integer("catch_up_window").default(0),
  timeSlot: text("time_slot").default('any'),
  suggestedTime: text("suggested_time"),
  durationMinutes: integer("duration_minutes").default(30),
  cue: text("cue"),
  goalId: text("goal_id"),
  startDate: date("start_date").notNull(),
  endDate: date("end_date"),
  status: text("status").default('active'),
  currentStreak: integer("current_streak").default(0),
  bestStreak: integer("best_streak").default(0),
  completionRate30d: numeric("completion_rate_30d").default('0'),
  reminderEnabled: boolean("reminder_enabled").default(true),
  isDeleted: boolean("is_deleted").default(false),
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  periodDays: integer("period_days"),
}, (table) => [
  index("idx_habit_status").on(table.status),
  index("idx_habit_is_deleted").on(table.isDeleted),
]);

export const event = pgTable("event", {
  recordId: text("record_id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  startDatetime: customTimestamptz("start_datetime", { precision: 6 }).notNull(),
  endDatetime: customTimestamptz("end_datetime", { precision: 6 }),
  isAllDay: boolean("is_all_day").default(false),
  durationMinutes: integer("duration_minutes").default(60),
  location: text("location"),
  participants: text("participants"),
  eventType: text("event_type").default('other'),
  leadMinutes: integer("lead_minutes").default(15),
  reminderSentCount: integer("reminder_sent_count").default(0),
  calendarEventId: text("calendar_event_id"),
  calendarSyncStatus: text("calendar_sync_status").default('none'),
  status: text("status").default('planned'),
  sourceTaskId: text("source_task_id"),
  timezone: text("timezone").default('Asia/Shanghai'),
  confidence: numeric("confidence"),
  sourceText: text("source_text"),
  idempotencyKey: text("idempotency_key"),
  isDeleted: boolean("is_deleted").default(false),
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_event_start_datetime").on(table.startDatetime),
  index("idx_event_status").on(table.status),
  index("idx_event_is_deleted").on(table.isDeleted),
]);

export const task = pgTable("task", {
  recordId: text("record_id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  dueDate: date("due_date"),
  dueTime: text("due_time"),
  dueType: text("due_type").notNull().default('soft'),
  estimateMinutes: integer("estimate_minutes").default(45),
  priority: text("priority").notNull().default('P2'),
  status: text("status").notNull().default('todo'),
  goalId: text("goal_id"),
  tags: text("tags").default('[]'),
  context: text("context"),
  rolloverCount: integer("rollover_count").default(0),
  originalDueDate: date("original_due_date"),
  scheduledSlot: text("scheduled_slot"),
  isPinned: boolean("is_pinned").default(false),
  completedAt: customTimestamptz("completed_at", { precision: 6 }),
  completedChannel: text("completed_channel"),
  reminderSentCount: integer("reminder_sent_count").default(0),
  confidence: numeric("confidence").default('0'),
  sourceText: text("source_text"),
  idempotencyKey: text("idempotency_key"),
  isDeleted: boolean("is_deleted").default(false),
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_task_status").on(table.status),
  index("idx_task_due_date").on(table.dueDate),
  index("idx_task_is_deleted").on(table.isDeleted),
]);

export const appProfile = pgTable("app_profile", {
  recordId: text("record_id").primaryKey(),
  wakeTime: time("wake_time").default('07:00:00'),
  sleepTime: time("sleep_time").default('23:30:00'),
  workStart: time("work_start").default('09:00:00'),
  workEnd: time("work_end").default('18:00:00'),
  workDays: text("work_days").default('["1","2","3","4","5"]'),
  deepWorkSlot: text("deep_work_slot").default('any'),
  morningBriefTime: time("morning_brief_time").default('08:00:00'),
  eveningReviewTime: time("evening_review_time").default('21:30:00'),
  weeklyReviewDay: text("weekly_review_day").default('周日'),
  weeklyReviewTime: time("weekly_review_time").default('20:30:00'),
  dndStart: time("dnd_start"),
  dndEnd: time("dnd_end"),
  reminderChannel: text("reminder_channel").default('["doubao"]'),
  eventLeadMinutes: integer("event_lead_minutes").default(15),
  autoConfirmThreshold: numeric("auto_confirm_threshold").default('0.80'),
  inboxAskThreshold: numeric("inbox_ask_threshold").default('0.45'),
  initCompleted: boolean("init_completed").default(false),
  initStep: integer("init_step").default(0),
  onboardDate: date("onboard_date"),
  schemaVersion: text("schema_version").default('4.0'),
  remindWebhookUrl: text("remind_webhook_url"),
  lastRemindRunAt: customTimestamptz("last_remind_run_at", { precision: 6 }),
  installStatus: text("install_status").default('installing'),
  notifyMode: text("notify_mode").default('doubao_proactive'),
  maxDailyPush: integer("max_daily_push").default(6),
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

// table aliases
export const activityLogTable = activityLog;
export const appProfileTable = appProfile;
export const breakdownTable = breakdown;
export const dailyMetricTable = dailyMetric;
export const eventTable = event;
export const goalTable = goal;
export const goalLogTable = goalLog;
export const habitTable = habit;
export const habitLogTable = habitLog;
export const inboxTable = inbox;
export const quickNoteTable = quickNote;
export const reminderNotificationTable = reminderNotification;
export const reviewTable = review;
export const taskTable = task;
