-- ============================================================
-- AI 执行工作台 - 启动自动建表 SQL（幂等）
-- 应用启动时由 DbInitService 执行，已存在的表不会重复创建
-- ============================================================

-- ============================================================
-- 表1: app_profile — 个人配置 + 系统状态（单行，record_id 固定 'main'）
-- 注：原规格表名为 user_profile，因与平台 user_profile 复合类型重名而改名为 app_profile
-- ============================================================
CREATE TABLE IF NOT EXISTS app_profile (
  record_id            text PRIMARY KEY,
  wake_time            time DEFAULT '07:00',
  sleep_time           time DEFAULT '23:30',
  work_start           time DEFAULT '09:00',
  work_end             time DEFAULT '18:00',
  work_days            text DEFAULT '["1","2","3","4","5"]',
  deep_work_slot       text DEFAULT 'any',
  morning_brief_time   time DEFAULT '08:00',
  evening_review_time  time DEFAULT '21:30',
  weekly_review_day    text DEFAULT '周日',
  weekly_review_time   time DEFAULT '20:30',
  dnd_start            time,
  dnd_end              time,
  reminder_channel     text DEFAULT '["doubao"]',
  event_lead_minutes   integer DEFAULT 15,
  auto_confirm_threshold numeric DEFAULT 0.80,
  inbox_ask_threshold  numeric DEFAULT 0.45,
  init_completed       boolean DEFAULT false,
  init_step            integer DEFAULT 0,
  onboard_date         date,
  schema_version       text DEFAULT '4.0',
  remind_webhook_url   text,
  last_remind_run_at   timestamptz,
  install_status       text DEFAULT 'installing',
  notify_mode          text DEFAULT 'doubao_proactive',
  max_daily_push       integer DEFAULT 6,
  created_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE app_profile ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'app_profile' AND policyname = 'app_profile_service_role_bypass') THEN
    CREATE POLICY "app_profile_service_role_bypass" ON app_profile TO service_role USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'app_profile' AND policyname = 'app_profile_anon_all') THEN
    CREATE POLICY "app_profile_anon_all" ON app_profile AS PERMISSIVE FOR ALL TO anon USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'app_profile' AND policyname = 'app_profile_authenticated_all') THEN
    CREATE POLICY "app_profile_authenticated_all" ON app_profile AS PERMISSIVE FOR ALL TO authenticated USING (true) WITH CHECK (true);
  END IF;
END $$;

INSERT INTO app_profile (record_id, install_status)
VALUES ('main', 'installing')
ON CONFLICT (record_id) DO NOTHING;

-- ============================================================
-- 表2: task — 一次性任务（核心表）
-- ============================================================
CREATE TABLE IF NOT EXISTS task (
  record_id            text PRIMARY KEY,
  title                text NOT NULL,
  description          text,
  due_date             date,
  due_time             text,
  due_type             text NOT NULL DEFAULT 'soft',
  estimate_minutes     integer DEFAULT 45,
  priority             text NOT NULL DEFAULT 'P2',
  status               text NOT NULL DEFAULT 'todo',
  goal_id              text,
  tags                 text DEFAULT '[]',
  context              text,
  rollover_count       integer DEFAULT 0,
  original_due_date    date,
  scheduled_slot       text,
  is_pinned            boolean DEFAULT false,
  completed_at         timestamptz,
  completed_channel    text,
  reminder_sent_count  integer DEFAULT 0,
  confidence           numeric DEFAULT 0,
  source_text          text,
  idempotency_key      text,
  is_deleted           boolean DEFAULT false,
  created_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE task ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'task' AND policyname = 'task_service_role_bypass') THEN
    CREATE POLICY "task_service_role_bypass" ON task TO service_role USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'task' AND policyname = 'task_anon_all') THEN
    CREATE POLICY "task_anon_all" ON task AS PERMISSIVE FOR ALL TO anon USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'task' AND policyname = 'task_authenticated_all') THEN
    CREATE POLICY "task_authenticated_all" ON task AS PERMISSIVE FOR ALL TO authenticated USING (true) WITH CHECK (true);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_task_status ON task(status);
CREATE INDEX IF NOT EXISTS idx_task_due_date ON task(due_date);
CREATE INDEX IF NOT EXISTS idx_task_is_deleted ON task(is_deleted);

-- ============================================================
-- 表3: event — 日程（有明确开始时间）
-- ============================================================
CREATE TABLE IF NOT EXISTS event (
  record_id            text PRIMARY KEY,
  title                text NOT NULL,
  description          text,
  start_datetime       timestamptz NOT NULL,
  end_datetime         timestamptz,
  is_all_day           boolean DEFAULT false,
  duration_minutes     integer DEFAULT 60,
  location             text,
  participants         text,
  event_type           text DEFAULT 'other',
  lead_minutes         integer DEFAULT 15,
  reminder_sent_count  integer DEFAULT 0,
  calendar_event_id    text,
  calendar_sync_status text DEFAULT 'none',
  status               text DEFAULT 'planned',
  source_task_id       text,
  timezone             text DEFAULT 'Asia/Shanghai',
  confidence           numeric,
  source_text          text,
  idempotency_key      text,
  is_deleted           boolean DEFAULT false,
  created_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE event ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'event' AND policyname = 'event_service_role_bypass') THEN
    CREATE POLICY "event_service_role_bypass" ON event TO service_role USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'event' AND policyname = 'event_anon_all') THEN
    CREATE POLICY "event_anon_all" ON event AS PERMISSIVE FOR ALL TO anon USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'event' AND policyname = 'event_authenticated_all') THEN
    CREATE POLICY "event_authenticated_all" ON event AS PERMISSIVE FOR ALL TO authenticated USING (true) WITH CHECK (true);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_event_start_datetime ON event(start_datetime);
CREATE INDEX IF NOT EXISTS idx_event_status ON event(status);
CREATE INDEX IF NOT EXISTS idx_event_is_deleted ON event(is_deleted);

-- ============================================================
-- 表4: habit — 习惯规则
-- ============================================================
CREATE TABLE IF NOT EXISTS habit (
  record_id            text PRIMARY KEY,
  name                 text NOT NULL,
  frequency_type       text NOT NULL,
  frequency_value      integer DEFAULT 1,
  target_weekdays      text DEFAULT '[]',
  catch_up_window      integer DEFAULT 0,
  time_slot            text DEFAULT 'any',
  suggested_time       text,
  duration_minutes     integer DEFAULT 30,
  cue                  text,
  goal_id              text,
  start_date           date NOT NULL,
  end_date             date,
  status               text DEFAULT 'active',
  current_streak       integer DEFAULT 0,
  best_streak          integer DEFAULT 0,
  completion_rate_30d  numeric DEFAULT 0,
  reminder_enabled     boolean DEFAULT true,
  is_deleted           boolean DEFAULT false,
  created_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE habit ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'habit' AND policyname = 'habit_service_role_bypass') THEN
    CREATE POLICY "habit_service_role_bypass" ON habit TO service_role USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'habit' AND policyname = 'habit_anon_all') THEN
    CREATE POLICY "habit_anon_all" ON habit AS PERMISSIVE FOR ALL TO anon USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'habit' AND policyname = 'habit_authenticated_all') THEN
    CREATE POLICY "habit_authenticated_all" ON habit AS PERMISSIVE FOR ALL TO authenticated USING (true) WITH CHECK (true);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_habit_status ON habit(status);
CREATE INDEX IF NOT EXISTS idx_habit_is_deleted ON habit(is_deleted);

-- ============================================================
-- 表5: habit_log — 习惯执行记录（唯一约束：habit_id + log_date）
-- ============================================================
CREATE TABLE IF NOT EXISTS habit_log (
  record_id            text PRIMARY KEY,
  habit_id             text NOT NULL,
  log_date             date NOT NULL,
  status               text NOT NULL,
  completed_at         timestamptz,
  note                 text,
  week_index           text,
  created_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE habit_log ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'habit_log' AND policyname = 'habit_log_service_role_bypass') THEN
    CREATE POLICY "habit_log_service_role_bypass" ON habit_log TO service_role USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'habit_log' AND policyname = 'habit_log_anon_all') THEN
    CREATE POLICY "habit_log_anon_all" ON habit_log AS PERMISSIVE FOR ALL TO anon USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'habit_log' AND policyname = 'habit_log_authenticated_all') THEN
    CREATE POLICY "habit_log_authenticated_all" ON habit_log AS PERMISSIVE FOR ALL TO authenticated USING (true) WITH CHECK (true);
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS idx_habit_log_habit_id_log_date ON habit_log(habit_id, log_date);
CREATE INDEX IF NOT EXISTS idx_habit_log_log_date ON habit_log(log_date);

-- ============================================================
-- 表6: goal — 中长期目标
-- ============================================================
CREATE TABLE IF NOT EXISTS goal (
  record_id            text PRIMARY KEY,
  title                text NOT NULL,
  description          text,
  category             text DEFAULT 'other',
  metric_type          text DEFAULT 'count',
  target_value         numeric,
  current_value        numeric DEFAULT 0,
  unit                 text DEFAULT '次',
  progress_source      text DEFAULT 'manual',
  auto_filter_tags     text DEFAULT '[]',
  auto_habit_id        text,
  start_date           date NOT NULL,
  target_date          date NOT NULL,
  status               text DEFAULT 'active',
  progress_percent     numeric DEFAULT 0,
  achieved_at          timestamptz,
  is_deleted           boolean DEFAULT false,
  created_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE goal ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'goal' AND policyname = 'goal_service_role_bypass') THEN
    CREATE POLICY "goal_service_role_bypass" ON goal TO service_role USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'goal' AND policyname = 'goal_anon_all') THEN
    CREATE POLICY "goal_anon_all" ON goal AS PERMISSIVE FOR ALL TO anon USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'goal' AND policyname = 'goal_authenticated_all') THEN
    CREATE POLICY "goal_authenticated_all" ON goal AS PERMISSIVE FOR ALL TO authenticated USING (true) WITH CHECK (true);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_goal_status ON goal(status);
CREATE INDEX IF NOT EXISTS idx_goal_is_deleted ON goal(is_deleted);

-- ============================================================
-- 表7: inbox — AI 收件箱
-- ============================================================
CREATE TABLE IF NOT EXISTS inbox (
  record_id            text PRIMARY KEY,
  raw_input            text NOT NULL,
  input_type           text NOT NULL,
  source_image_url     text,
  parsed_json          text,
  suggested_type       text,
  draft_payload        text,
  confidence           numeric,
  confidence_detail    text,
  ambiguity_reason     text DEFAULT '[]',
  question_text        text,
  question_options     text,
  batch_id             text,
  batch_index          integer,
  status               text NOT NULL DEFAULT 'pending',
  resolved_target_type text,
  resolved_target_id   text,
  nudge_count          integer DEFAULT 0,
  created_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expire_at            timestamptz NOT NULL DEFAULT (CURRENT_TIMESTAMP + INTERVAL '7 days'),
  is_deleted           boolean DEFAULT false
);

ALTER TABLE inbox ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'inbox' AND policyname = 'inbox_service_role_bypass') THEN
    CREATE POLICY "inbox_service_role_bypass" ON inbox TO service_role USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'inbox' AND policyname = 'inbox_anon_all') THEN
    CREATE POLICY "inbox_anon_all" ON inbox AS PERMISSIVE FOR ALL TO anon USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'inbox' AND policyname = 'inbox_authenticated_all') THEN
    CREATE POLICY "inbox_authenticated_all" ON inbox AS PERMISSIVE FOR ALL TO authenticated USING (true) WITH CHECK (true);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_inbox_status ON inbox(status);
CREATE INDEX IF NOT EXISTS idx_inbox_is_deleted ON inbox(is_deleted);
CREATE INDEX IF NOT EXISTS idx_inbox_batch_id ON inbox(batch_id);
CREATE INDEX IF NOT EXISTS idx_inbox_expire_at ON inbox(expire_at);

-- ============================================================
-- 表8: review — 复盘报告
-- ============================================================
CREATE TABLE IF NOT EXISTS review (
  record_id            text PRIMARY KEY,
  review_type          text NOT NULL,
  period_start         date NOT NULL,
  period_end           date NOT NULL,
  planned_count        integer DEFAULT 0,
  completed_count      integer DEFAULT 0,
  new_added_count      integer DEFAULT 0,
  completion_rate      numeric DEFAULT 0,
  completion_rate_incl_new numeric DEFAULT 0,
  delayed_count        integer DEFAULT 0,
  new_delayed_count    integer DEFAULT 0,
  cancelled_count      integer DEFAULT 0,
  est_deep_work_minutes integer DEFAULT 0,
  actual_tracked_minutes integer DEFAULT 0,
  event_hours          numeric DEFAULT 0,
  habit_total          integer DEFAULT 0,
  habit_done           integer DEFAULT 0,
  habit_rate           numeric DEFAULT 0,
  top_delayed_tasks    text,
  goal_progress        text,
  highlights           text,
  issues               text,
  advice_items         text,
  weekday_heatmap      text,
  summary_text         text,
  generated_at         timestamptz NOT NULL,
  later_update_count   integer DEFAULT 0,
  delivery_status      text DEFAULT 'pending',
  user_read            boolean DEFAULT false,
  created_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE review ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'review' AND policyname = 'review_service_role_bypass') THEN
    CREATE POLICY "review_service_role_bypass" ON review TO service_role USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'review' AND policyname = 'review_anon_all') THEN
    CREATE POLICY "review_anon_all" ON review AS PERMISSIVE FOR ALL TO anon USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'review' AND policyname = 'review_authenticated_all') THEN
    CREATE POLICY "review_authenticated_all" ON review AS PERMISSIVE FOR ALL TO authenticated USING (true) WITH CHECK (true);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_review_type_period ON review(review_type, period_start, period_end);

-- ============================================================
-- 表9: activity_log — 操作日志（信任根，只追加，无 updated_at / is_deleted）
-- ============================================================
CREATE TABLE IF NOT EXISTS activity_log (
  record_id            text PRIMARY KEY,
  action               text NOT NULL,
  target_type          text NOT NULL,
  target_id            text NOT NULL,
  before_json          text,
  after_json           text,
  changed_fields       text DEFAULT '[]',
  session_id           text NOT NULL,
  trigger_source       text NOT NULL,
  confidence           numeric,
  batch_id             text,
  is_undone            boolean DEFAULT false,
  undone_at            timestamptz,
  idempotency_key      text NOT NULL,
  created_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE activity_log ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'activity_log' AND policyname = 'activity_log_service_role_bypass') THEN
    CREATE POLICY "activity_log_service_role_bypass" ON activity_log TO service_role USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'activity_log' AND policyname = 'activity_log_anon_all') THEN
    CREATE POLICY "activity_log_anon_all" ON activity_log AS PERMISSIVE FOR ALL TO anon USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'activity_log' AND policyname = 'activity_log_authenticated_all') THEN
    CREATE POLICY "activity_log_authenticated_all" ON activity_log AS PERMISSIVE FOR ALL TO authenticated USING (true) WITH CHECK (true);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_activity_log_target ON activity_log(target_type, target_id);
CREATE INDEX IF NOT EXISTS idx_activity_log_created_at ON activity_log(created_at);
CREATE INDEX IF NOT EXISTS idx_activity_log_batch_id ON activity_log(batch_id);
CREATE INDEX IF NOT EXISTS idx_activity_log_idempotency_key ON activity_log(idempotency_key);

-- ============================================================
-- 表10: daily_metric — 每日指标快照
-- ============================================================
CREATE TABLE IF NOT EXISTS daily_metric (
  record_id            text PRIMARY KEY,
  metric_date          date NOT NULL UNIQUE,
  planned_count        integer DEFAULT 0,
  completed_count      integer DEFAULT 0,
  new_added_count      integer DEFAULT 0,
  delayed_count        integer DEFAULT 0,
  completion_rate      numeric DEFAULT 0,
  est_deep_work_minutes integer DEFAULT 0,
  event_count          integer DEFAULT 0,
  habit_total          integer DEFAULT 0,
  habit_done           integer DEFAULT 0,
  inbox_pending        integer DEFAULT 0,
  snapshot_at          timestamptz,
  is_final             boolean DEFAULT false,
  created_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at           timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE daily_metric ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'daily_metric' AND policyname = 'daily_metric_service_role_bypass') THEN
    CREATE POLICY "daily_metric_service_role_bypass" ON daily_metric TO service_role USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'daily_metric' AND policyname = 'daily_metric_anon_all') THEN
    CREATE POLICY "daily_metric_anon_all" ON daily_metric AS PERMISSIVE FOR ALL TO anon USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'daily_metric' AND policyname = 'daily_metric_authenticated_all') THEN
    CREATE POLICY "daily_metric_authenticated_all" ON daily_metric AS PERMISSIVE FOR ALL TO authenticated USING (true) WITH CHECK (true);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_daily_metric_metric_date ON daily_metric(metric_date);
