import { Inject, Injectable, Logger } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, count } from 'drizzle-orm';
import { taskTable, eventTable, habitTable } from '@server/database/schema';

const PREFIX = 'SEED';

function rid(prefix: string): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

export interface SeedResult {
  seeded: boolean;
  inserted: { tasks: number; events: number; habits: number };
  skippedReason?: string;
}

@Injectable()
export class SeedService {
  private readonly logger = new Logger(SeedService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  /**
   * 幂等插入示例数据：仅当三张表都为空（或 force=true）时插入，
   * 已有用户数据时不重复写入。
   */
  async seedDemoData(force = false): Promise<SeedResult> {
    // 计算当前未删除数据量（全表，含软删标记避免重复播种）
    const [taskCnt, eventCnt, habitCnt] = await Promise.all([
      this.db.select({ n: count() }).from(taskTable),
      this.db.select({ n: count() }).from(eventTable),
      this.db.select({ n: count() }).from(habitTable),
    ]);
    const t = Number(taskCnt[0]?.n ?? 0);
    const e = Number(eventCnt[0]?.n ?? 0);
    const h = Number(habitCnt[0]?.n ?? 0);

    if (!force && (t > 0 || e > 0 || h > 0)) {
      return {
        seeded: false,
        inserted: { tasks: 0, events: 0, habits: 0 },
        skippedReason: `已有数据（待办 ${t} / 日程 ${e} / 习惯 ${h}），为避免覆盖用户数据已跳过。如需重置请传 force=true`,
      };
    }

    const today = new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 10);
    const tomorrow = new Date(Date.now() + 32 * 3600 * 1000).toISOString().slice(0, 10);

    // 待办小事（今日 2 条 + 明日 1 条）
    const tasks = [
      {
        recordId: rid('TSK'),
        title: '给妈妈打电话',
        description: '周末例行问候',
        dueDate: today,
        dueTime: '19:30',
        dueType: 'soft',
        estimateMinutes: 15,
        priority: 'P2',
        status: 'todo',
        tags: '["家庭"]',
        isDeleted: false,
      },
      {
        recordId: rid('TSK'),
        title: '整理房间衣柜换季',
        description: '把夏装收起来，秋冬装拿出来',
        dueDate: today,
        dueTime: '21:00',
        dueType: 'soft',
        estimateMinutes: 30,
        priority: 'P2',
        status: 'todo',
        tags: '["生活"]',
        isDeleted: false,
      },
      {
        recordId: rid('TSK'),
        title: '预约下周体检',
        description: '记得带身份证和医保卡',
        dueDate: tomorrow,
        dueTime: '10:00',
        dueType: 'soft',
        estimateMinutes: 60,
        priority: 'P1',
        status: 'todo',
        tags: '["健康"]',
        isDeleted: false,
      },
    ];

    // 今日日程
    const events = [
      {
        recordId: rid('EVT'),
        title: '下午茶小聚',
        description: '和闺蜜约的奶茶时间',
        startDatetime: new Date(`${today}T15:00:00+08:00`),
        endDatetime: new Date(`${today}T16:00:00+08:00`),
        isAllDay: false,
        durationMinutes: 60,
        eventType: 'personal',
        leadMinutes: 15,
        status: 'planned',
        timezone: 'Asia/Shanghai',
        isDeleted: false,
      },
      {
        recordId: rid('EVT'),
        title: '瑜伽晚课',
        description: '放松身心',
        startDatetime: new Date(`${today}T19:00:00+08:00`),
        endDatetime: new Date(`${today}T20:00:00+08:00`),
        isAllDay: false,
        durationMinutes: 60,
        eventType: 'course',
        leadMinutes: 15,
        status: 'planned',
        timezone: 'Asia/Shanghai',
        isDeleted: false,
      },
    ];

    // 习惯
    const habits = [
      {
        recordId: rid('HBT'),
        name: '每天喝水 8 杯',
        frequencyType: 'daily',
        frequencyValue: 1,
        timeSlot: 'any',
        suggestedTime: '09:00',
        durationMinutes: 5,
        startDate: today,
        status: 'active',
        reminderEnabled: true,
        isDeleted: false,
      },
      {
        recordId: rid('HBT'),
        name: '睡前读书 20 分钟',
        frequencyType: 'daily',
        frequencyValue: 1,
        timeSlot: 'evening',
        suggestedTime: '22:00',
        durationMinutes: 20,
        startDate: today,
        status: 'active',
        reminderEnabled: true,
        isDeleted: false,
      },
    ];

    await this.db.transaction(async (tx) => {
      await tx.insert(taskTable).values(tasks);
      await tx.insert(eventTable).values(events);
      await tx.insert(habitTable).values(habits);
    });

    this.logger.log('示例数据已插入: tasks=3, events=2, habits=2');
    return {
      seeded: true,
      inserted: { tasks: tasks.length, events: events.length, habits: habits.length },
    };
  }
}
