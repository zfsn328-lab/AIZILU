import { Module } from '@nestjs/common';
import { DemoController } from './demo.controller';
import { SeedService } from './demo.service';

@Module({
  controllers: [DemoController],
  providers: [SeedService],
})
export class DemoModule {}
