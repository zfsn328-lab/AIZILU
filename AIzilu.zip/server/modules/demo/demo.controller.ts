import { Body, Controller, Post } from '@nestjs/common';
import { SeedService, type SeedResult } from './demo.service';

@Controller('api/demo')
export class DemoController {
  constructor(private readonly seedService: SeedService) {}

  @Post('seed')
  async seed(@Body() body: { force?: boolean }): Promise<SeedResult> {
    return this.seedService.seedDemoData(body?.force === true);
  }
}
