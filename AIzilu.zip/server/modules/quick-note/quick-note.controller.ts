import { Body, Controller, Delete, Get, Param, Post } from '@nestjs/common';
import { QuickNoteService } from './quick-note.service';
import type { QuickNoteItem, QuickNoteType } from '@shared/api.interface';

interface CreateQuickNoteDto {
  content: string;
  remindAt?: string | null;
  type?: QuickNoteType;
  periodDays?: number | null;
}

@Controller('api/quick-note')
export class QuickNoteController {
  constructor(private readonly quickNoteService: QuickNoteService) {}

  @Get()
  async getList(): Promise<{ items: QuickNoteItem[] }> {
    const items = await this.quickNoteService.getList();
    return { items };
  }

  @Post()
  async create(
    @Body() body: CreateQuickNoteDto,
  ): Promise<{ item: QuickNoteItem; remindPast: boolean }> {
    return this.quickNoteService.create(body.content, body.remindAt, body.type, body.periodDays);
  }

  @Post(':id/toggle')
  async toggleDone(@Param('id') id: string): Promise<{ isDone: boolean }> {
    return this.quickNoteService.toggleDone(id);
  }

  @Delete(':id')
  async delete(@Param('id') id: string): Promise<{ success: boolean }> {
    await this.quickNoteService.softDelete(id);
    return { success: true };
  }
}
