import { Inject, Injectable, Logger, BadRequestException } from '@nestjs/common';
import { eq, desc, and } from 'drizzle-orm';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';

import { quickNote, taskTable, eventTable, habitTable, goalTable } from '@server/database/schema';
import type { QuickNoteItem, QuickNoteType } from '@shared/api.interface';

const MAX_CONTENT_LENGTH = 500;
const VALID_TYPES: QuickNoteType[] = ['note', 'task', 'event', 'habit', 'goal'];

@Injectable()
export class QuickNoteService {
  private readonly logger = new Logger(QuickNoteService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async getList(limit = 50): Promise<QuickNoteItem[]> {
    const rows = await this.db
      .select()
      .from(quickNote)
      .where(eq(quickNote.isDeleted, false))
      .orderBy(desc(quickNote.createdAt))
      .limit(limit);

    return rows.map((row) => ({
      recordId: row.recordId,
      content: row.content,
      noteDate: String(row.noteDate),
      noteTime: row.noteTime,
      remindAt: row.remindAt ? row.remindAt.toISOString() : null,
      createdAt: row.createdAt.toISOString(),
      isDone: row.isDone,
    }));
  }

  /**
   * 勾选/取消勾选完成（随手记软完成态）
   */
  async toggleDone(recordId: string): Promise<{ isDone: boolean }> {
    const rows = await this.db
      .select({ isDone: quickNote.isDone })
      .from(quickNote)
      .where(
        and(eq(quickNote.recordId, recordId), eq(quickNote.isDeleted, false)),
      )
      .limit(1);
    if (rows.length === 0) {
      throw new BadRequestException('记录不存在或已删除');
    }
    const next = !rows[0].isDone;
    await this.db
      .update(quickNote)
      .set({ isDone: next, updatedAt: new Date() })
      .where(eq(quickNote.recordId, recordId));
    this.logger.log(`随手记勾选完成 ${recordId} -> ${next}`);
    return { isDone: next };
  }

  async create(
    content: string,
    remindAt?: string | null,
    type: QuickNoteType = 'note',
    periodDays?: number | null,
  ): Promise<{ item: QuickNoteItem; remindPast: boolean }> {
    const trimmed = content.trim();
    if (!trimmed) {
      throw new BadRequestException('内容不能为空');
    }
    if (trimmed.length > MAX_CONTENT_LENGTH) {
      throw new BadRequestException(
        `内容不能超过 ${MAX_CONTENT_LENGTH} 字`,
      );
    }
    if (!VALID_TYPES.includes(type)) {
      throw new BadRequestException('类型不正确，可选 note/task/event/habit');
    }

    let remindAtDate: Date | null = null;
    let remindPast = false;
    if (remindAt && remindAt.trim()) {
      const parsed = new Date(remindAt);
      if (isNaN(parsed.getTime())) {
        throw new BadRequestException('提醒时间格式不正确');
      }
      remindAtDate = parsed;
      if (parsed.getTime() < Date.now()) {
        remindPast = true;
      }
    }

    const now = new Date();
    const dateStr = this.formatDate(now);
    const timeStr = this.formatTime(now);

    // 非 note 类型：写入对应业务表，便于月历/时间轴/打卡展示
    if (type === 'task') {
      const recordId = `TSK_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      const dueDate = remindAtDate
        ? new Date(remindAtDate.getTime() + 8 * 3600 * 1000).toISOString().slice(0, 10)
        : dateStr;
      const dueTime = remindAtDate
        ? `${String(remindAtDate.getHours()).padStart(2, '0')}:${String(remindAtDate.getMinutes()).padStart(2, '0')}`
        : null;
      await this.db.insert(taskTable).values({
        recordId,
        title: trimmed,
        dueDate,
        dueTime,
        dueType: 'soft',
        estimateMinutes: 30,
        priority: 'P2',
        status: 'todo',
        tags: '[]',
        isDeleted: false,
      });
      this.logger.log(`随手记→待办: ${recordId}`);
      return {
        item: {
          recordId,
          content: trimmed,
          noteDate: dueDate,
          noteTime: dueTime,
          remindAt: remindAtDate ? remindAtDate.toISOString() : null,
          createdAt: now.toISOString(),
          type,
        },
        remindPast,
      };
    }

    if (type === 'event') {
      const recordId = `EVT_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      const startDatetime = remindAtDate ?? new Date(`${dateStr}T09:00:00+08:00`);
      await this.db.insert(eventTable).values({
        recordId,
        title: trimmed,
        startDatetime,
        endDatetime: new Date(startDatetime.getTime() + 60 * 60 * 1000),
        isAllDay: false,
        durationMinutes: 60,
        eventType: 'other',
        leadMinutes: 15,
        status: 'planned',
        timezone: 'Asia/Shanghai',
        isDeleted: false,
      });
      this.logger.log(`随手记→日程: ${recordId}`);
      return {
        item: {
          recordId,
          content: trimmed,
          noteDate: new Date(startDatetime.getTime() + 8 * 3600 * 1000).toISOString().slice(0, 10),
          noteTime: `${String(startDatetime.getHours()).padStart(2, '0')}:${String(startDatetime.getMinutes()).padStart(2, '0')}`,
          remindAt: startDatetime.toISOString(),
          createdAt: now.toISOString(),
          type,
        },
        remindPast,
      };
    }

    if (type === 'habit') {
      const recordId = `HBT_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      await this.db.insert(habitTable).values({
        recordId,
        name: trimmed,
        frequencyType: 'daily',
        frequencyValue: 1,
        timeSlot: 'any',
        suggestedTime: remindAtDate
          ? `${String(remindAtDate.getHours()).padStart(2, '0')}:${String(remindAtDate.getMinutes()).padStart(2, '0')}`
          : null,
        durationMinutes: 10,
        startDate: dateStr,
        periodDays: periodDays && periodDays > 0 ? periodDays : null,
        status: 'active',
        reminderEnabled: false,
        isDeleted: false,
      });
      this.logger.log(`随手记→习惯: ${recordId}`);
      return {
        item: {
          recordId,
          content: trimmed,
          noteDate: dateStr,
          noteTime: null,
          remindAt: remindAtDate ? remindAtDate.toISOString() : null,
          createdAt: now.toISOString(),
          type,
        },
        remindPast,
      };
    }

    if (type === 'goal') {
      const recordId = `GL_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      const startDate = remindAtDate
        ? new Date(remindAtDate.getTime() + 8 * 3600 * 1000).toISOString().slice(0, 10)
        : dateStr;
      const targetDate = remindAtDate
        ? new Date(remindAtDate.getTime() + 8 * 3600 * 1000).toISOString().slice(0, 10)
        : new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString().slice(0, 10);
      await this.db.insert(goalTable).values({
        recordId,
        title: trimmed,
        category: 'other',
        metricType: 'count',
        targetValue: '1',
        currentValue: '0',
        unit: '次',
        progressSource: 'manual',
        startDate,
        targetDate,
        periodDays: periodDays && periodDays > 0 ? periodDays : null,
        status: 'active',
        isDeleted: false,
      });
      this.logger.log(`随手记→目标: ${recordId}`);
      return {
        item: {
          recordId,
          content: trimmed,
          noteDate: startDate,
          noteTime: null,
          remindAt: remindAtDate ? remindAtDate.toISOString() : null,
          createdAt: now.toISOString(),
          type,
        },
        remindPast,
      };
    }

    // 默认 note
    const recordId = `QNT_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

    const [row] = await this.db
      .insert(quickNote)
      .values({
        recordId,
        content: trimmed,
        noteDate: dateStr,
        noteTime: timeStr,
        remindAt: remindAtDate,
      })
      .returning();

    this.logger.log(`创建随手记: ${recordId}`);
    return {
      item: {
        recordId: row.recordId,
        content: row.content,
        noteDate: String(row.noteDate),
        noteTime: row.noteTime,
        remindAt: row.remindAt ? row.remindAt.toISOString() : null,
        createdAt: row.createdAt.toISOString(),
      },
      remindPast,
    };
  }

  async softDelete(recordId: string): Promise<void> {
    const result = await this.db
      .update(quickNote)
      .set({ isDeleted: true, updatedAt: new Date() })
      .where(
        and(eq(quickNote.recordId, recordId), eq(quickNote.isDeleted, false)),
      )
      .returning({ id: quickNote.recordId });

    if (result.length === 0) {
      throw new BadRequestException('记录不存在或已删除');
    }

    this.logger.log(`删除随手记: ${recordId}`);
  }

  private formatDate(date: Date): string {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  private formatTime(date: Date): string {
    const h = String(date.getHours()).padStart(2, '0');
    const m = String(date.getMinutes()).padStart(2, '0');
    return `${h}:${m}`;
  }
}
