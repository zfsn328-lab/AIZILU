import { Module } from '@nestjs/common';
import { QuickNoteController } from './quick-note.controller';
import { QuickNoteService } from './quick-note.service';

@Module({
  controllers: [QuickNoteController],
  providers: [QuickNoteService],
})
export class QuickNoteModule {}
