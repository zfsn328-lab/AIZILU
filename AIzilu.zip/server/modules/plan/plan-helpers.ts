import type {
  habitTable,
  goalTable,
} from '@server/database/schema';
import type { HabitItem, GoalItem } from '@shared/api.interface';

export function safeJsonParse<T>(str: string | null, fallback: T): T {
  if (!str) return fallback;
  try {
    return JSON.parse(str) as T;
  } catch {
    return fallback;
  }
}

export function isHabitDueOnDay(
  habit: { frequencyType: string; targetWeekdays: string },
  weekday: number,
): boolean {
  const freq = habit.frequencyType;
  if (freq === 'daily') return true;
  if (freq === 'weekly') {
    try {
      const weekdays: string[] = JSON.parse(habit.targetWeekdays || '[]');
      return weekdays.includes(String(weekday));
    } catch {
      return false;
    }
  }
  return true;
}

export function getTimeSlot(timeStr: string): 'morning' | 'afternoon' | 'evening' {
  if (!timeStr) return 'morning';
  const hour = parseInt(timeStr.slice(0, 2), 10);
  if (hour < 12) return 'morning';
  if (hour < 18) return 'afternoon';
  return 'evening';
}

export function defaultTimeForSlot(slot: string): string {
  switch (slot) {
    case 'morning':
      return '09:00';
    case 'afternoon':
      return '14:00';
    case 'evening':
      return '20:00';
    default:
      return '09:00';
  }
}

export function formatTime(date: Date): string {
  const h = String(date.getHours()).padStart(2, '0');
  const m = String(date.getMinutes()).padStart(2, '0');
  return `${h}:${m}`;
}

export function dateStr(d: string | Date): string {
  return typeof d === 'string' ? d : d.toISOString().slice(0, 10);
}

export function mapHabitItem(row: typeof habitTable.$inferSelect): HabitItem {
  return {
    recordId: row.recordId,
    name: row.name,
    frequencyType: row.frequencyType,
    frequencyValue: row.frequencyValue,
    targetWeekdays: safeJsonParse<string[]>(row.targetWeekdays, []),
    catchUpWindow: row.catchUpWindow,
    timeSlot: row.timeSlot,
    suggestedTime: row.suggestedTime,
    durationMinutes: row.durationMinutes,
    cue: row.cue,
    goalId: row.goalId,
    startDate: dateStr(row.startDate),
    endDate: row.endDate ? dateStr(row.endDate) : null,
    periodDays: row.periodDays ?? null,
    periodDoneDays: 0,
    periodTotalDays: null,
    periodProgressPercent: 0,
    status: row.status as any,
    currentStreak: row.currentStreak,
    bestStreak: row.bestStreak,
    completionRate30d: Number(row.completionRate30d),
    reminderEnabled: row.reminderEnabled,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export function mapGoalItem(row: typeof goalTable.$inferSelect): GoalItem {
  return {
    recordId: row.recordId,
    title: row.title,
    description: row.description,
    category: row.category,
    metricType: row.metricType,
    targetValue: row.targetValue !== null ? Number(row.targetValue) : null,
    currentValue: Number(row.currentValue),
    unit: row.unit,
    progressSource: row.progressSource,
    startDate: dateStr(row.startDate),
    targetDate: dateStr(row.targetDate),
    periodDays: row.periodDays ?? null,
    periodDoneDays: 0,
    periodRemain: 0,
    status: row.status as any,
    progressPercent: Number(row.progressPercent),
    achievedAt: row.achievedAt ? row.achievedAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}
