import { Inject, Injectable, Logger } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, gte, lt, isNull, isNotNull, or, asc } from 'drizzle-orm';
import { taskTable, eventTable, quickNoteTable } from '@server/database/schema';
import type { CalendarExportItem } from '@shared/api.interface';

@Injectable()
export class CalendarService {
  private readonly logger = new Logger(CalendarService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  /**
   * 导出未来 days 天内的所有安排（日程 + 未完成任务 + 带提醒的随手记）
   */
  async exportCalendar(days: number): Promise<{ items: CalendarExportItem[] }> {
    const horizonDays = Math.min(Math.max(days || 90, 1), 365);
    const now = new Date(Date.now() + 8 * 3600 * 1000);
    const startStr = now.toISOString().slice(0, 10); // 北京今天
    const startDate = new Date(`${startStr}T00:00:00+08:00`); // 北京今天零点
    const endDate = new Date(startDate.getTime() + horizonDays * 24 * 3600 * 1000);

    const items: CalendarExportItem[] = [];

    // 1) 日程事件
    const events = await this.db
      .select()
      .from(eventTable)
      .where(
        and(
          gte(eventTable.startDatetime, startDate),
          lt(eventTable.startDatetime, endDate),
          eq(eventTable.isDeleted, false),
          eq(eventTable.status, 'planned'),
        ),
      )
      .orderBy(asc(eventTable.startDatetime));

    for (const ev of events) {
      items.push({
        type: 'event',
        title: ev.title,
        description: ev.description ?? undefined,
        start: ev.startDatetime.toISOString(),
        end: ev.endDatetime ? ev.endDatetime.toISOString() : undefined,
        isAllDay: ev.isAllDay ?? false,
        reminderMinutes: ev.leadMinutes ?? 15,
        location: ev.location ?? undefined,
      });
    }

    // 2) 未完成任务（有截止日期，含今天之前未完成的顺延任务也导出）
    const tasks = await this.db
      .select()
      .from(taskTable)
      .where(
        and(
          isNotNull(taskTable.dueDate),
          or(eq(taskTable.status, 'todo'), eq(taskTable.status, 'doing')),
          eq(taskTable.isDeleted, false),
        ),
      )
      .orderBy(asc(taskTable.dueDate));

    for (const t of tasks) {
      if (!t.dueDate) continue;
      const dueStr = typeof t.dueDate === 'string' ? t.dueDate.slice(0, 10) : '';
      if (!dueStr) continue;
      if (dueStr > endDate.toISOString().slice(0, 10)) continue;
      items.push({
        type: 'task',
        title: t.title,
        start: t.dueTime ? `${dueStr}T${t.dueTime}` : dueStr,
        isAllDay: !t.dueTime,
        reminderMinutes: 30,
      });
    }

    // 3) 带提醒时间的随手记
    const notes = await this.db
      .select()
      .from(quickNoteTable)
      .where(
        and(
          eq(quickNoteTable.isDeleted, false),
          gte(quickNoteTable.remindAt, startDate),
          lt(quickNoteTable.remindAt, endDate),
        ),
      )
      .orderBy(asc(quickNoteTable.remindAt));

    for (const n of notes) {
      if (!n.remindAt) continue;
      items.push({
        type: 'note',
        title: n.content.length > 40 ? `${n.content.slice(0, 40)}…` : n.content,
        start: n.remindAt.toISOString(),
        reminderMinutes: 0,
      });
    }

    items.sort((a, b) => a.start.localeCompare(b.start));
    return { items };
  }
}
