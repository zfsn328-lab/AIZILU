import { Controller, Get, Query } from '@nestjs/common';
import { CalendarService } from './calendar.service';
import type { CalendarExportItem } from '@shared/api.interface';

@Controller('api/calendar')
export class CalendarController {
  constructor(private readonly calendarService: CalendarService) {}

  @Get('export')
  async export(
    @Query('days') days?: string,
  ): Promise<{ items: CalendarExportItem[]; exportedAt: string; horizonDays: number }> {
    const parsed = days ? parseInt(days, 10) : 90;
    const { items } = await this.calendarService.exportCalendar(Number.isNaN(parsed) ? 90 : parsed);
    return {
      items,
      exportedAt: new Date().toISOString(),
      horizonDays: Number.isNaN(parsed) ? 90 : parsed,
    };
  }
}
