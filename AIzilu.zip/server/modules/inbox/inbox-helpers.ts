import type { PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import {
  taskTable,
  eventTable,
  habitTable,
  goalTable,
  inboxTable,
} from '@server/database/schema';

export function genId(prefix: string): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

export function safeJsonParse<T>(str: string | null, fallback: T): T {
  if (!str) return fallback;
  try {
    return JSON.parse(str) as T;
  } catch {
    return fallback;
  }
}

export async function createTargetFromInbox(
  db: PostgresJsDatabase,
  targetType: string,
  item: typeof inboxTable.$inferSelect,
  payload?: any,
): Promise<string> {
  const draft = item.draftPayload ? JSON.parse(item.draftPayload) : {};
  const finalPayload = payload ?? draft;

  switch (targetType) {
    case 'task': {
      const id = genId('TSK');
      await db.insert(taskTable).values({
        recordId: id,
        title: finalPayload.title ?? item.rawInput.slice(0, 50),
        description: finalPayload.description ?? null,
        dueDate: finalPayload.dueDate ?? null,
        dueTime: finalPayload.dueTime ?? null,
        dueType: finalPayload.dueType ?? 'soft',
        estimateMinutes: finalPayload.estimateMinutes ?? 45,
        priority: finalPayload.priority ?? 'P2',
        status: 'todo',
        goalId: finalPayload.goalId ?? null,
        tags: JSON.stringify(finalPayload.tags ?? []),
        context: finalPayload.context ?? null,
        scheduledSlot: finalPayload.scheduledSlot ?? null,
        isPinned: false,
        sourceText: item.rawInput,
        isDeleted: false,
      });
      return id;
    }
    case 'event': {
      const id = genId('EVT');
      const now = new Date();
      await db.insert(eventTable).values({
        recordId: id,
        title: finalPayload.title ?? item.rawInput.slice(0, 50),
        description: finalPayload.description ?? null,
        startDatetime: finalPayload.startDatetime
          ? new Date(finalPayload.startDatetime)
          : now,
        endDatetime: finalPayload.endDatetime
          ? new Date(finalPayload.endDatetime)
          : null,
        isAllDay: finalPayload.isAllDay ?? false,
        durationMinutes: finalPayload.durationMinutes ?? 60,
        location: finalPayload.location ?? null,
        participants: finalPayload.participants ?? null,
        eventType: finalPayload.eventType ?? 'other',
        leadMinutes: finalPayload.leadMinutes ?? 15,
        status: 'planned',
        sourceTaskId: finalPayload.sourceTaskId ?? null,
        timezone: 'Asia/Shanghai',
        sourceText: item.rawInput,
        isDeleted: false,
      });
      return id;
    }
    case 'habit': {
      const id = genId('HBT');
      const today = new Date().toISOString().slice(0, 10);
      await db.insert(habitTable).values({
        recordId: id,
        name: finalPayload.name ?? item.rawInput.slice(0, 30),
        frequencyType: finalPayload.frequencyType ?? 'daily',
        frequencyValue: finalPayload.frequencyValue ?? 1,
        targetWeekdays: JSON.stringify(finalPayload.targetWeekdays ?? []),
        catchUpWindow: finalPayload.catchUpWindow ?? 0,
        timeSlot: finalPayload.timeSlot ?? 'any',
        suggestedTime: finalPayload.suggestedTime ?? null,
        durationMinutes: finalPayload.durationMinutes ?? 30,
        cue: finalPayload.cue ?? null,
        goalId: finalPayload.goalId ?? null,
        startDate: finalPayload.startDate ?? today,
        endDate: finalPayload.endDate ?? null,
        status: 'active',
        currentStreak: 0,
        bestStreak: 0,
        completionRate30d: '0',
        reminderEnabled: true,
        isDeleted: false,
      });
      return id;
    }
    case 'goal': {
      const id = genId('GOL');
      const today = new Date().toISOString().slice(0, 10);
      const targetDate = new Date();
      targetDate.setMonth(targetDate.getMonth() + 1);
      await db.insert(goalTable).values({
        recordId: id,
        title: finalPayload.title ?? item.rawInput.slice(0, 30),
        description: finalPayload.description ?? null,
        category: finalPayload.category ?? 'other',
        metricType: finalPayload.metricType ?? 'count',
        targetValue: finalPayload.targetValue ?? null,
        currentValue: '0',
        unit: finalPayload.unit ?? '次',
        progressSource: finalPayload.progressSource ?? 'manual',
        startDate: finalPayload.startDate ?? today,
        targetDate:
          finalPayload.targetDate ?? targetDate.toISOString().slice(0, 10),
        status: 'active',
        progressPercent: '0',
        isDeleted: false,
      });
      return id;
    }
    default:
      throw new Error(`不支持的目标类型: ${targetType}`);
  }
}
