import {
  Controller,
  Get,
  Post,
  Param,
  Body,
  Query,
  ParseIntPipe,
  BadRequestException,
} from '@nestjs/common';
import { InboxService } from './inbox.service';
import type {
  InboxItem,
  InboxBatchItem,
  PagedResponse,
} from '@shared/api.interface';

interface PendingResult {
  items: InboxItem[];
  batches: InboxBatchItem[];
}

interface ConfirmResult {
  success: boolean;
  targetId: string;
}

interface IgnoreResult {
  success: boolean;
}

interface BatchConfirmResult {
  success: boolean;
  count: number;
}

@Controller('api/inbox')
export class InboxController {
  constructor(private readonly inboxService: InboxService) {}

  @Get('pending')
  async getPending(): Promise<PendingResult> {
    return this.inboxService.getPending();
  }

  @Get('history')
  async getHistory(
    @Query('status') status: 'ignored' | 'expired',
    @Query('page', ParseIntPipe) page: number,
    @Query('pageSize', ParseIntPipe) pageSize: number,
  ): Promise<PagedResponse<InboxItem>> {
    if (!['ignored', 'expired'].includes(status)) {
      throw new BadRequestException('status must be ignored or expired');
    }
    return this.inboxService.getHistory(status, page, pageSize);
  }

  @Post(':id/confirm')
  async confirm(
    @Param('id') id: string,
    @Body() body: { targetType: string; payload?: any },
  ): Promise<ConfirmResult> {
    const targetId = await this.inboxService.confirm(id, body.targetType, body.payload);
    return { success: true, targetId };
  }

  @Post(':id/ignore')
  async ignore(@Param('id') id: string): Promise<IgnoreResult> {
    await this.inboxService.ignore(id);
    return { success: true };
  }

  @Post('batch/:batchId/confirm')
  async batchConfirm(
    @Param('batchId') batchId: string,
    @Body() body: { targetType?: string; payload?: any },
  ): Promise<BatchConfirmResult> {
    const count = await this.inboxService.batchConfirm(
      batchId,
      body.targetType,
      body.payload,
    );
    return { success: true, count };
  }

  @Post('batch/:batchId/ignore')
  async batchIgnore(
    @Param('batchId') batchId: string,
  ): Promise<BatchConfirmResult> {
    const count = await this.inboxService.batchIgnore(batchId);
    return { success: true, count };
  }
}
