import { Inject, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, isNull, count, desc, asc } from 'drizzle-orm';
import {
  inboxTable,
  activityLogTable,
} from '@server/database/schema';
import type {
  InboxItem,
  InboxBatchItem,
  PagedResponse,
} from '@shared/api.interface';
import { createTargetFromInbox, genId, safeJsonParse } from './inbox-helpers';

@Injectable()
export class InboxService {
  private readonly logger = new Logger(InboxService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  async getPending(): Promise<{ items: InboxItem[]; batches: InboxBatchItem[] }> {
    const allPending = await this.db
      .select()
      .from(inboxTable)
      .where(
        and(
          eq(inboxTable.status, 'pending'),
          eq(inboxTable.isDeleted, false),
        ),
      )
      .orderBy(desc(inboxTable.createdAt));

    const singleItems = allPending.filter((it) => !it.batchId);
    const batchedItems = allPending.filter((it) => it.batchId);

    // Group by batchId
    const batchMap = new Map<string, typeof batchedItems>();
    for (const item of batchedItems) {
      const list = batchMap.get(item.batchId!) ?? [];
      list.push(item);
      batchMap.set(item.batchId!, list);
    }

    const batches: InboxBatchItem[] = [];
    for (const [batchId, items] of batchMap) {
      batches.push({
        batchId,
        items: items
          .sort((a, b) => (a.batchIndex ?? 0) - (b.batchIndex ?? 0))
          .map((it) => this.mapInboxItem(it)),
        totalCount: items.length,
      });
    }

    return {
      items: singleItems.map((it) => this.mapInboxItem(it)),
      batches,
    };
  }

  async getHistory(
    status: 'ignored' | 'expired',
    page: number,
    pageSize: number,
  ): Promise<PagedResponse<InboxItem>> {
    const offset = (page - 1) * pageSize;

    const [countResult, items] = await Promise.all([
      this.db
        .select({ count: count() })
        .from(inboxTable)
        .where(
          and(eq(inboxTable.status, status), eq(inboxTable.isDeleted, false)),
        ),
      this.db
        .select()
        .from(inboxTable)
        .where(
          and(eq(inboxTable.status, status), eq(inboxTable.isDeleted, false)),
        )
        .orderBy(desc(inboxTable.updatedAt))
        .limit(pageSize)
        .offset(offset),
    ]);

    const total = Number(countResult[0]?.count ?? 0);

    return {
      items: items.map((it) => this.mapInboxItem(it)),
      total,
      page,
      pageSize,
    };
  }

  async confirm(id: string, targetType: string, payload?: any): Promise<string> {
    const items = await this.db
      .select()
      .from(inboxTable)
      .where(
        and(eq(inboxTable.recordId, id), eq(inboxTable.isDeleted, false)),
      );
    if (items.length === 0) {
      throw new NotFoundException('收件箱条目不存在');
    }
    const item = items[0];

    const targetId = await createTargetFromInbox(this.db, targetType, item, payload);

    await this.db
      .update(inboxTable)
      .set({
        status: 'confirmed',
        resolvedTargetType: targetType,
        resolvedTargetId: targetId,
        updatedAt: new Date(),
      })
      .where(eq(inboxTable.recordId, id));

    await this.logActivity('confirm', targetType, targetId, item);

    return targetId;
  }

  async ignore(id: string): Promise<void> {
    const updated = await this.db
      .update(inboxTable)
      .set({
        status: 'ignored',
        updatedAt: new Date(),
      })
      .where(
        and(eq(inboxTable.recordId, id), eq(inboxTable.isDeleted, false)),
      )
      .returning({ id: inboxTable.recordId });
    if (updated.length === 0) {
      throw new NotFoundException('收件箱条目不存在');
    }
  }

  async batchConfirm(
    batchId: string,
    targetType?: string,
    payload?: any,
  ): Promise<number> {
    const items = await this.db
      .select()
      .from(inboxTable)
      .where(
        and(
          eq(inboxTable.batchId, batchId),
          eq(inboxTable.status, 'pending'),
          eq(inboxTable.isDeleted, false),
        ),
      )
      .orderBy(asc(inboxTable.batchIndex));

    if (items.length === 0) return 0;

    let count = 0;
    for (const item of items) {
      const type = targetType ?? item.suggestedType ?? 'task';
      try {
        const targetId = await createTargetFromInbox(this.db, type, item, payload);
        await this.db
          .update(inboxTable)
          .set({
            status: 'confirmed',
            resolvedTargetType: type,
            resolvedTargetId: targetId,
            updatedAt: new Date(),
          })
          .where(eq(inboxTable.recordId, item.recordId));
        await this.logActivity('batch_confirm', type, targetId, item, batchId);
        count += 1;
      } catch (error) {
        this.logger.error(`批量确认失败: ${item.recordId}`, error);
      }
    }
    return count;
  }

  async batchIgnore(batchId: string): Promise<number> {
    const updated = await this.db
      .update(inboxTable)
      .set({
        status: 'ignored',
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(inboxTable.batchId, batchId),
          eq(inboxTable.status, 'pending'),
          eq(inboxTable.isDeleted, false),
        ),
      )
      .returning({ id: inboxTable.recordId });
    return updated.length;
  }

  private async logActivity(
    action: string,
    targetType: string,
    targetId: string,
    item: typeof inboxTable.$inferSelect,
    batchId?: string,
  ): Promise<void> {
    const id = genId('ACT');
    try {
      await this.db.insert(activityLogTable).values({
        recordId: id,
        action,
        targetType,
        targetId,
        beforeJson: JSON.stringify({
          inboxId: item.recordId,
          rawInput: item.rawInput,
        }),
        afterJson: null,
        changedFields: '[]',
        sessionId: 'anon',
        triggerSource: 'user',
        confidence: item.confidence,
        batchId: batchId ?? item.batchId ?? null,
        isUndone: false,
        idempotencyKey: `${action}_${item.recordId}_${Date.now()}`,
      });
    } catch (error) {
      this.logger.error('写入 activity_log 失败', error);
    }
  }

  private mapInboxItem(row: typeof inboxTable.$inferSelect): InboxItem {
    return {
      recordId: row.recordId,
      rawInput: row.rawInput,
      inputType: row.inputType,
      sourceImageUrl: row.sourceImageUrl,
      parsedJson: row.parsedJson,
      suggestedType: row.suggestedType,
      draftPayload: row.draftPayload,
      confidence:
        row.confidence !== null ? Number(row.confidence) : null,
      confidenceDetail: row.confidenceDetail,
      ambiguityReason: safeJsonParse<string[]>(row.ambiguityReason, []),
      questionText: row.questionText,
      questionOptions: row.questionOptions
        ? safeJsonParse<string[] | null>(row.questionOptions, null)
        : null,
      batchId: row.batchId,
      batchIndex: row.batchIndex,
      status: row.status as any,
      resolvedTargetType: row.resolvedTargetType,
      resolvedTargetId: row.resolvedTargetId,
      nudgeCount: row.nudgeCount,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
      expireAt: row.expireAt.toISOString(),
    };
  }
}
