import { Injectable, Logger, BadRequestException } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { Inject } from '@nestjs/common';
import { eq, and, desc } from 'drizzle-orm';
import { breakdownTable, taskTable } from '@server/database/schema';
import type { BreakdownItem, BreakdownStep, BreakdownStatus, UpdateBreakdownStepInput } from '@shared/api.interface';

const STEP_TEMPLATES: Array<{
  keywords: string[];
  steps: Array<{ text: string; dueOffset: number; dueTime: string }>;
}> = [
  {
    keywords: ['瘦', '减', '肥', '健身', '运动', '体重'],
    steps: [
      { text: '设定每日饮食计划（计算基础代谢和热量缺口）', dueOffset: 0, dueTime: '20:00' },
      { text: '制定每周运动方案（安排有氧和无氧训练）', dueOffset: 1, dueTime: '12:00' },
      { text: '记录每日体重和饮食（建立打卡追踪习惯）', dueOffset: 2, dueTime: '09:00' },
      { text: '评估进展调整计划（根据第一周效果优化）', dueOffset: 5, dueTime: '20:00' },
    ],
  },
  {
    keywords: ['读', '书', '学习', '考', '证', '英语', '单词'],
    steps: [
      { text: '制定学习计划（明确每天的学习时长和内容）', dueOffset: 0, dueTime: '20:00' },
      { text: '准备学习资料（整理教材、课程或笔记）', dueOffset: 1, dueTime: '12:00' },
      { text: '建立每日打卡（记录每天完成的学习进度）', dueOffset: 2, dueTime: '09:00' },
      { text: '阶段性小测与复盘（检验效果并调整节奏）', dueOffset: 5, dueTime: '20:00' },
    ],
  },
  {
    keywords: ['存', '钱', '攒', '理财', '储蓄'],
    steps: [
      { text: '盘点收支现状（记录每月的收入和固定支出）', dueOffset: 0, dueTime: '20:00' },
      { text: '设定储蓄目标（明确每月要存下的金额）', dueOffset: 1, dueTime: '12:00' },
      { text: '建立记账习惯（每天记录消费，控制预算）', dueOffset: 2, dueTime: '09:00' },
      { text: '复盘消费与储蓄（根据账单调整开销）', dueOffset: 5, dueTime: '20:00' },
    ],
  },
  {
    keywords: [],
    steps: [
      { text: '明确目标与现状（盘点起点，定义可衡量的小目标）', dueOffset: 0, dueTime: '20:00' },
      { text: '制定分步执行计划（把大目标拆成每周/每日动作）', dueOffset: 1, dueTime: '12:00' },
      { text: '建立每日记录与打卡（追踪进度，保持节奏）', dueOffset: 2, dueTime: '09:00' },
      { text: '阶段性复盘与调整（根据进展优化下一步）', dueOffset: 5, dueTime: '20:00' },
    ],
  },
];

@Injectable()
export class BreakdownService {
  private readonly logger = new Logger(BreakdownService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  private todayStr(): string {
    return new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 10);
  }

  private shiftDate(dateStr: string, days: number): string {
    const t =
      Date.parse(`${dateStr}T00:00:00+08:00`) + days * 86400000 + 8 * 3600 * 1000;
    return new Date(t).toISOString().slice(0, 10);
  }

  private dueLabel(offset: number, time: string): string {
    if (offset === 0) return `今天${time}前`;
    if (offset === 1) return `明天${time}前`;
    if (offset === 2) return `后天${time}前`;
    return `${offset}天后${time}前`;
  }

  private buildSteps(title: string): BreakdownStep[] {
    const t = title.toLowerCase();
    const tpl =
      STEP_TEMPLATES.find((x) => x.keywords.some((k) => t.includes(k))) ??
      STEP_TEMPLATES[STEP_TEMPLATES.length - 1];
    const today = this.todayStr();
    return tpl.steps.map((s, i) => ({
      id: `BS_${Date.now()}_${i}`,
      text: s.text,
      dueDate: this.shiftDate(today, s.dueOffset),
      dueLabel: this.dueLabel(s.dueOffset, s.dueTime),
      done: false,
    }));
  }

  /**
   * 拆解一个大目标：生成 4 步任务方案（pending 状态，等待用户确认）。
   */
  async create(title: string): Promise<BreakdownItem> {
    const trimmed = title.trim();
    if (!trimmed) throw new BadRequestException('请输入要拆解的目标');
    const recordId = `BD_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const steps = this.buildSteps(trimmed);
    await this.db.insert(breakdownTable).values({
      recordId,
      title: trimmed,
      steps: JSON.stringify(steps),
      status: 'pending',
      isDeleted: false,
    });
    this.logger.log(`目标拆解: ${recordId} ${trimmed}`);
    return {
      recordId,
      title: trimmed,
      steps,
      status: 'pending',
      confirmedAt: null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  }

  /**
   * 确认拆解：把每一步写入待办任务（task 表），拆解状态变为 confirmed。
   */
  async confirm(recordId: string): Promise<BreakdownItem> {
    const rows = await this.db
      .select()
      .from(breakdownTable)
      .where(
        and(eq(breakdownTable.recordId, recordId), eq(breakdownTable.isDeleted, false)),
      )
      .limit(1);
    if (rows.length === 0) throw new BadRequestException('拆解方案不存在');
    const row = rows[0];
    if (row.status === 'pending') {
      const steps: BreakdownStep[] = JSON.parse(row.steps);
      for (const s of steps) {
        await this.db.insert(taskTable).values({
          recordId: `TSK_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
          title: s.text,
          dueDate: s.dueDate,
          dueType: 'soft',
          estimateMinutes: 30,
          priority: 'P2',
          status: 'todo',
          goalId: recordId,
          tags: '[]',
          isDeleted: false,
        });
      }
      await this.db
        .update(breakdownTable)
        .set({ status: 'confirmed', confirmedAt: new Date(), updatedAt: new Date() })
        .where(eq(breakdownTable.recordId, recordId));
      this.logger.log(`确认拆解: ${recordId}`);
    }
    return this.getOne(recordId);
  }

  async getOne(recordId: string): Promise<BreakdownItem> {
    const rows = await this.db
      .select()
      .from(breakdownTable)
      .where(
        and(eq(breakdownTable.recordId, recordId), eq(breakdownTable.isDeleted, false)),
      )
      .limit(1);
    if (rows.length === 0) throw new BadRequestException('拆解方案不存在');
    return this.mapItem(rows[0]);
  }

  async list(): Promise<BreakdownItem[]> {
    const rows = await this.db
      .select()
      .from(breakdownTable)
      .where(eq(breakdownTable.isDeleted, false))
      .orderBy(desc(breakdownTable.createdAt));
    return rows.map((r) => this.mapItem(r));
  }

  async updateTitle(recordId: string, title: string): Promise<BreakdownItem> {
    const updated = await this.db
      .update(breakdownTable)
      .set({ title, updatedAt: new Date() })
      .where(
        and(eq(breakdownTable.recordId, recordId), eq(breakdownTable.isDeleted, false)),
      )
      .returning({ recordId: breakdownTable.recordId });
    if (updated.length === 0) throw new BadRequestException('拆解方案不存在');
    return this.getOne(recordId);
  }

  async update(recordId: string, payload: { title: string; steps?: UpdateBreakdownStepInput[] }): Promise<BreakdownItem> {
    const rows = await this.db
      .select()
      .from(breakdownTable)
      .where(
        and(eq(breakdownTable.recordId, recordId), eq(breakdownTable.isDeleted, false)),
      )
      .limit(1);
    if (rows.length === 0) throw new BadRequestException('拆解方案不存在');
    const row = rows[0];

    let stepsJson = row.steps;
    if (payload.steps && payload.steps.length > 0) {
      let currentSteps: BreakdownStep[] = [];
      try {
        const parsed = JSON.parse(row.steps);
        if (Array.isArray(parsed)) currentSteps = parsed;
      } catch {
        currentSteps = [];
      }
      const existingById = new Map<string, BreakdownStep>();
      for (const s of currentSteps) existingById.set(s.id, s);

      const today = this.todayStr();
      const nextSteps: BreakdownStep[] = [];
      for (const input of payload.steps) {
        const trimmed = input.text?.trim();
        if (!trimmed) continue;
        if (input.id && existingById.has(input.id)) {
          const existing = existingById.get(input.id)!;
          nextSteps.push({ ...existing, text: trimmed });
        } else {
          const newStep: BreakdownStep = {
            id: `BS_${Date.now()}_${nextSteps.length}`,
            text: trimmed,
            dueDate: today,
            dueLabel: '未设置时间',
            done: false,
          };
          nextSteps.push(newStep);
        }
      }
      if (nextSteps.length === 0) {
        throw new BadRequestException('至少保留一个步骤');
      }
      stepsJson = JSON.stringify(nextSteps);
    }

    await this.db
      .update(breakdownTable)
      .set({ title: payload.title, steps: stepsJson, updatedAt: new Date() })
      .where(eq(breakdownTable.recordId, recordId));
    return this.getOne(recordId);
  }

  async toggleDone(recordId: string): Promise<BreakdownItem> {
    const rows = await this.db
      .select()
      .from(breakdownTable)
      .where(
        and(eq(breakdownTable.recordId, recordId), eq(breakdownTable.isDeleted, false)),
      )
      .limit(1);
    if (rows.length === 0) throw new BadRequestException('拆解方案不存在');
    const current = rows[0];
    const nextStatus: BreakdownStatus = current.status === 'done' ? 'confirmed' : 'done';
    await this.db
      .update(breakdownTable)
      .set({ status: nextStatus, updatedAt: new Date() })
      .where(eq(breakdownTable.recordId, recordId));
    return this.getOne(recordId);
  }

  async softDelete(recordId: string): Promise<void> {
    const updated = await this.db
      .update(breakdownTable)
      .set({ isDeleted: true, updatedAt: new Date() })
      .where(
        and(eq(breakdownTable.recordId, recordId), eq(breakdownTable.isDeleted, false)),
      )
      .returning({ recordId: breakdownTable.recordId });
    if (updated.length === 0) throw new BadRequestException('拆解方案不存在');
    await this.db
      .update(taskTable)
      .set({ isDeleted: true, updatedAt: new Date() })
      .where(
        and(eq(taskTable.goalId, recordId), eq(taskTable.isDeleted, false)),
      );
  }

  private mapItem(row: typeof breakdownTable.$inferSelect): BreakdownItem {
    let steps: BreakdownStep[] = [];
    try {
      const parsed = JSON.parse(row.steps);
      if (Array.isArray(parsed)) steps = parsed;
    } catch {
      // ignore
    }
    const status = (row.status === 'pending' || row.status === 'confirmed' || row.status === 'done')
      ? (row.status as BreakdownStatus)
      : 'pending' as BreakdownStatus;
    return {
      recordId: row.recordId,
      title: row.title,
      steps,
      status,
      confirmedAt: row.confirmedAt ? row.confirmedAt.toISOString() : null,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    };
  }
}
