import { Controller, Get, Post, Patch, Delete, Param, Body, BadRequestException } from '@nestjs/common';
import { BreakdownService } from './breakdown.service';
import type { BreakdownItem, UpdateBreakdownTitleRequest, UpdateBreakdownRequest } from '@shared/api.interface';

@Controller('api/breakdown')
export class BreakdownController {
  constructor(private readonly breakdownService: BreakdownService) {}

  @Post()
  async create(@Body() body: { title?: string }): Promise<BreakdownItem> {
    if (!body?.title) throw new BadRequestException('title is required');
    return this.breakdownService.create(body.title);
  }

  @Get()
  async list(): Promise<BreakdownItem[]> {
    return this.breakdownService.list();
  }

  @Post(':id/confirm')
  async confirm(@Param('id') id: string): Promise<BreakdownItem> {
    return this.breakdownService.confirm(id);
  }

  @Patch(':id/title')
  async updateTitle(
    @Param('id') id: string,
    @Body() body: UpdateBreakdownTitleRequest,
  ): Promise<BreakdownItem> {
    if (!body?.title?.trim()) throw new BadRequestException('title is required');
    return this.breakdownService.updateTitle(id, body.title.trim());
  }

  @Patch(':id')
  async update(
    @Param('id') id: string,
    @Body() body: UpdateBreakdownRequest,
  ): Promise<BreakdownItem> {
    if (!body?.title?.trim()) throw new BadRequestException('title is required');
    return this.breakdownService.update(id, {
      title: body.title.trim(),
      steps: body.steps,
    });
  }

  @Post(':id/toggle-done')
  async toggleDone(@Param('id') id: string): Promise<BreakdownItem> {
    return this.breakdownService.toggleDone(id);
  }

  @Delete(':id')
  async remove(@Param('id') id: string): Promise<{ success: true }> {
    await this.breakdownService.softDelete(id);
    return { success: true };
  }
}
