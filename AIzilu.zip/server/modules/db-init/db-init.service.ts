import { Inject, Injectable, OnModuleInit, Logger } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { existsSync, readFileSync } from 'fs';
import { join } from 'path';
import { sql } from 'drizzle-orm';

const TABLES = [
  'app_profile',
  'task',
  'event',
  'habit',
  'habit_log',
  'goal',
  'inbox',
  'review',
  'activity_log',
  'daily_metric',
] as const;

@Injectable()
export class DbInitService implements OnModuleInit {
  private readonly logger = new Logger(DbInitService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async onModuleInit(): Promise<void> {
    try {
      this.logger.log('Checking database schema...');
      // 幂等补列：为已有表补充新增列（不阻塞启动）
      try {
        await this.db.execute(sql.raw(`
          CREATE TABLE IF NOT EXISTS quick_note (
            record_id text PRIMARY KEY,
            content text NOT NULL,
            note_date date NOT NULL,
            note_time text,
            is_done boolean NOT NULL DEFAULT false,
            is_deleted boolean NOT NULL DEFAULT false,
            created_at timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
            remind_at timestamptz(6)
          );
          ALTER TABLE quick_note ADD COLUMN IF NOT EXISTS is_done boolean NOT NULL DEFAULT false;
        `));
        this.logger.log('quick_note schema ensured (is_done column present).');
      } catch (columnError) {
        this.logger.warn(
          'quick_note column ensure skipped (table may not exist yet): ' +
            String(columnError),
        );
      }

      const existing = await this.checkExistingTables();

      if (existing.allPresent) {
        this.logger.log(
          `All ${TABLES.length} tables present. Schema verified.`,
        );
        return;
      }

      const missing = TABLES.filter((t) => !existing.tables.has(t));
      this.logger.warn(
        `Missing tables (${missing.length}): ${missing.join(', ')}. ` +
          'Attempting auto-create...',
      );

      try {
        const sqlPath = this.resolveSqlPath();
        const schemaSql = readFileSync(sqlPath, 'utf-8');
        await this.db.execute(sql.raw(schemaSql));
        this.logger.log(
          'Database schema auto-created successfully (10 tables).',
        );
      } catch (createError) {
        const code =
          (createError as { cause?: { code?: string } }).cause?.code ??
          (createError as { code?: string }).code;
        if (code === '42501') {
          this.logger.error(
            'Auto-create failed: insufficient DDL privileges. ' +
              'Please run the schema init SQL via miaoda db sql before starting the app. ' +
              'SQL file: server/assets/sql/schema_init.sql',
          );
          throw new Error(
            'Database schema not initialized. Missing tables: ' +
              missing.join(', '),
          );
        }
        throw createError;
      }
    } catch (error) {
      if (
        error instanceof Error &&
        error.message.startsWith('Database schema not initialized')
      ) {
        throw error;
      }
      this.logger.error('Schema initialization failed', error as Error);
      throw error;
    }
  }

  private async checkExistingTables(): Promise<{
    tables: Set<string>;
    allPresent: boolean;
  }> {
    const result = await this.db.execute<{ table_name: string }>(sql`
      SELECT tablename AS table_name
      FROM pg_tables
      WHERE schemaname = current_schema()
        AND tablename IN (${sql.join(
          TABLES.map((t) => sql`${t}`),
          sql`, `,
        )})
    `);
    const tableNames = result.map((row) => row.table_name);
    const tables = new Set(tableNames);
    return { tables, allPresent: tables.size === TABLES.length };
  }

  private resolveSqlPath(): string {
    const candidates = [
      join(__dirname, '../../assets/sql/schema_init.sql'),
      join(process.cwd(), 'server/assets/sql/schema_init.sql'),
    ];
    for (const p of candidates) {
      if (existsSync(p)) return p;
    }
    throw new Error(
      `schema_init.sql not found in any candidate path: ${candidates.join(', ')}`,
    );
  }
}
