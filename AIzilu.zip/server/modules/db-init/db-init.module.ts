import { Module } from '@nestjs/common';
import { DbInitService } from './db-init.service';

@Module({
  providers: [DbInitService],
})
export class DbInitModule {}
