import { Controller, Get, Param, Post } from '@nestjs/common';
import { ReminderService, type ReminderItem } from './reminder.service';

@Controller('api/reminders')
export class ReminderController {
  constructor(private readonly reminderService: ReminderService) {}

  /** 未读提醒（前端轮询） */
  @Get('pending')
  getPending(): Promise<ReminderItem[]> {
    return this.reminderService.getPending();
  }

  /** 历史提醒 */
  @Get('history')
  getHistory(): Promise<ReminderItem[]> {
    return this.reminderService.getHistory();
  }

  /** 标记已读 */
  @Post(':id/read')
  async markRead(@Param('id') id: string): Promise<{ success: boolean }> {
    const ok = await this.reminderService.markRead(id);
    return { success: ok };
  }
}
