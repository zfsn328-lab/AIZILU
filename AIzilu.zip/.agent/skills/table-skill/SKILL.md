---
name: table-skill
description: '@lark-apaas/client-toolkit/antd-table 表格开发规范：列类型用 TableColumnsType，含后端分页、固定列、加载状态等最佳实践'
available-agents:
  - Code
  - Worker
  - Reviewer
---

# Table Skill

@lark-apaas/client-toolkit/antd-table 表格开发，API 同 antd Table。

## Guidelines

- 列定义类型用 `TableColumnsType<T>`，由 `@lark-apaas/client-toolkit/antd-table` 直接 re-export
- 后端数据必须后端分页，禁止前端分页
- 必须开启固定表头 `scroll={% raw %}{{ y: 500 }}{% endraw %}`
- 列多时固定左侧重要列和右侧操作列
- 数据量大时（500+ 行）开启虚拟滚动 `virtual`

---

## Example

{% raw %}
```tsx
import { Table, TableProps } from "@lark-apaas/client-toolkit/antd-table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface User {
  id: string; name: string; email: string; status: "active" | "inactive";
}

const columns: TableProps<User>["columns"] = [
  { title: "姓名", dataIndex: "name", fixed: "left", width: 120 },
  { title: "邮箱", dataIndex: "email", width: 200 },
  { title: "状态", dataIndex: "status", width: 100,
    render: (s) => <Badge variant={s === "active" ? "default" : "secondary"}>{s === "active" ? "启用" : "禁用"}</Badge>
  },
  { title: "操作", key: "action", fixed: "right", width: 150,
    render: () => <div className="flex gap-2">
      <Button variant="ghost" size="sm">编辑</Button>
      <Button variant="ghost" size="sm">删除</Button>
    </div>
  },
];

export function UserTable({ data, loading, pagination, onPageChange }) {
  return (
    <Table
      columns={columns} dataSource={data} loading={loading} rowKey="id"
      scroll={{ x: 1000, y: 500 }}
      pagination={{ current: pagination.page, pageSize: pagination.pageSize, total: pagination.total, onChange: onPageChange }}
    />
  );
}
```
{% endraw %}

---

## Patterns

{% raw %}
```tsx
// 导入（列类型 TableColumnsType<T> 与 TableProps<T>["columns"] 等价）
import { Table, TableProps, TableColumnsType } from "@lark-apaas/client-toolkit/antd-table";

// 后端分页
<Table pagination={{ current: page, pageSize: 20, total, onChange: fetchData }} />

// 固定列
{ title: "姓名", fixed: "left", width: 120 }
{ title: "操作", fixed: "right", width: 100 }

// 行选择
<Table rowSelection={{ selectedRowKeys, onChange: setSelectedRowKeys }} />

// 虚拟滚动（数据量 500+ 行时开启，必须设 scroll.y）
<Table virtual scroll={{ x: 1000, y: 500 }} columns={columns} dataSource={largeData} />
```
{% endraw %}
