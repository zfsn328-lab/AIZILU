---
name: lark-apps-file
description: "Use when 在妙搭沙箱里用 `lark-cli apps +file-*` 管理【当前这个已存在的】妙搭应用的文件存储：一次性上传、下载、列出、删除、清理或查看文件，获取文件下载链接、临时分享链接，或查存储用量。触发词：文件上传, 文件下载, 文件列表, 文件删除, 文件清理, 文件查看, 文件元数据, 下载链接, 临时分享链接, 应用文件存储, 文件存储用量, +file-, file-upload, file-download, file-sign."
metadata:
  requires:
    bins: ["lark-cli"]
  cliHelp: "lark-cli apps --help; lark-cli apps +file-list --help（各 +file-* 子命令同理）"
control-by-feature-ab: true
# AppInit 只做需求理解与概要设计，不上传/下载应用文件；且「文件下载」这类触发词
# 会和「读取飞书云文档 / 云空间资源」的意图混淆。
unavailable-agents:
  - AppInit
---

# lark-apps-file

使用 `lark-cli apps +file-*` 处理应用存储里的文件型一次性操作，如上传、下载、查看元数据或生成临时分享链接。

## 沙箱约定（先读）

- **命令名**：一律 `lark-cli apps +file-*`；命令/flag 细节以 `--help` 为准。
- **应用已存在、app_id 走环境变量**：应用 id 在环境变量 `app_id` 里，命令需要 `--app-id` 时用 `--app-id "$app_id"`，不需要自行获取、解析或选择。
- **鉴权自动**：apps 域请求由运行环境自动打到 innerAPI 并注入鉴权头。**不要** `auth login` / `config init` / `--as`。
- **失败处理**：命令失败时把 `error.hint` 转述给用户，别原样甩 envelope JSON。

### 高风险写操作审批（exit 10）

`+file-delete` 是 `risk: high-risk-write`：不带 `--yes` 会 **exit 10** 并返回 `confirmation_required`。处理：

1. 识别 exit code=10 且 `error.type=="confirmation_required"`；
2. 把 `error.risk.action` + 关键参数给用户，明确"高风险/不可逆"，等显式同意；
3. 同意 → 原始 argv 末尾加 `--yes` 重试；拒绝 → 终止；
4. 想先看请求 → `--dry-run`（不触发门禁、不需 `--yes`）。

**绝不**看到 exit 10 就默认补 `--yes` 静默重试。

## 何时使用

### 匹配场景

- 用户要对应用存储里的文件做一次性操作：列出、查找、上传、下载、删除、查看元数据
- 用户要拿文件链接：应用内可用的下载地址，或对外分享、可过期的临时下载链接
- 用户要在 CI、脚本、一次性运维里处理测试文件、初始化测试数据或清理文件
- 用户要查应用的文件存储用量

### 不匹配场景

- 目标是实现前端页面里的文件上传/删除/取链接能力：用 `client-builtins-file-storage-service`
- 目标是实现 NestJS controller / service 里的文件处理能力：用 `server-builtins-file-storage-service`
- 输入来自当前会话附件，且还没确认真实本地路径：先用 `attachment`
- 目标是浏览器里的在线预览体验：用 `file-preview`
- 用户要操作工作区或代码仓库里的本地文件（如源代码、构建产物、`.env`），不是应用存储里的文件
- 数据库里的表数据：用 `lark-apps-db` 的 `+db-*`

## 按目标选择工具

| 目标 | 用什么 | 原因 |
|---|---|---|
| 当前会话附件继续上传到应用存储 | 先用 `attachment` 找真实本地路径，再 `+file-upload` | `+file-upload` 只接收本地路径，不直接处理附件引用 |
| 实现前端页面里的上传/删除/取链接能力 | `client-builtins-file-storage-service` | 这是前端页面功能开发，产出物是 `.tsx` / 页面逻辑，不是一次性 CLI 操作 |
| 实现服务端 controller / service 里的文件处理能力 | `server-builtins-file-storage-service` | 这是 NestJS 代码开发，不是一次性 CLI 调试 |
| 做 PDF / Word / Excel / PPT 在线预览 | `file-preview` | 目标是预览体验，不是文件运维 |

## 关键概念

### 文档中的路径写法

- 本文把应用存储里的对象统一写成以 `/` 开头的远端路径，例如 `/1858537546760216.png`
- 本地文件统一写成 `./logo.png` 这类**工作目录内的相对路径**；路径在别处时先 `cd` 过去或改成相对路径
- 如果命令行为与本文示例不一致，以 `lark-cli apps +file-list --help` 或对应子命令的 `--help` 为准

### 远端寻址：`--path` 精确匹配

远端文件统一用 `--path` 精确寻址（带前导 `/`）。规则：

- 只知道文件名时，先 `+file-list --name <名>` 定位拿到 `path`，再做后续操作；多个同名文件让用户确认
- `+file-list --path` 是精确匹配，不是目录前缀匹配
- 后续要稳定引用具体文件时，优先保留 `path`

### 上传的路径与文件名规则

- 上传只接收本地 `--file`：文件名沿用本地文件名，远端路径由平台分配、全局唯一（无需也无法手填）
- 特殊字符做 URL 编码透传；以 `.` 开头的隐藏文件名会加 `_` 前缀，避免下载回本地时覆盖隐藏文件

### 应用内下载地址 vs 临时分享链接 `signed_url`

| 类型 | 公网可直接访问 | 有效期 | 适用场景 | 推荐获取方式 |
|---|---|---|---|---|
| 下载地址 | 否 | 不过期 | 应用内使用文件、写入业务字段、前端或后端后续消费 | 上传响应的 JSON 输出；文件已在应用存储里就用 `+file-get` 的 JSON 输出（如有） |
| `signed_url` | 是 | 会过期，`--expires-in` 秒数，默认 1 天，最长 30 天 | 对外分享、浏览器直接打开、需要过期时间 | `+file-sign` |

规则：

- 不要依赖 `+file-list` 的 pretty 表格获取下载地址；上传者、下载地址（如有）仅在 JSON 输出里，单文件详情用 `+file-get`
- 只是应用内使用文件时，不要无故生成 `signed_url`
- `+file-sign` 的 pretty 模式只输出链接本身，便于复制 / 管道；要把到期时间一并告诉用户时用默认 JSON 输出

### file 域无环境概念

file 域不区分环境，没有 `--environment` / `--env`。

## 命令速查

这里只列高频、默认安全路径；完整参数以 `--help` 为准。

| 场景 | 命令 |
|---|---|
| 先看总帮助 | `lark-cli apps --help` |
| 某个子命令用法不确定 | `lark-cli apps +file-list --help`（各子命令同理） |
| 列出文件 | `lark-cli apps +file-list --app-id "$app_id"` |
| 按文件名精确查找 | `lark-cli apps +file-list --app-id "$app_id" --name logo.png` |
| 按 path / 文件名 / MIME / 大小 / 上传时间过滤 | `lark-cli apps +file-list --app-id "$app_id" --path/--name/--type/--size-gt/--uploaded-since ...` |
| 查看单文件元数据 | `lark-cli apps +file-get --app-id "$app_id" --path /1858537546760216.png` |
| 上传本地文件到应用存储 | `lark-cli apps +file-upload --app-id "$app_id" --file ./local.png` |
| 下载远程文件到本地 | `lark-cli apps +file-download --app-id "$app_id" --path /1858537546760216.png --output ./logo.png` |
| 删除前确认单文件范围 | `lark-cli apps +file-get --app-id "$app_id" --path <path>` |
| 删除前确认批量范围 | `lark-cli apps +file-list --app-id "$app_id" <过滤器>` |
| 执行删除（已确认影响范围后） | `lark-cli apps +file-delete --app-id "$app_id" --path <path1> --path <path2> --yes` |
| 生成临时分享链接 | `lark-cli apps +file-sign --app-id "$app_id" --path <path> --expires-in 604800` |
| 查文件存储用量 | `lark-cli apps +file-quota-get --app-id "$app_id"` |

`+file-list` 分页：`--page-size`（默认 20）/ `--page-token`；pretty 表格每项给名称、路径、大小、类型、上传时间 5 列。

## 多步工作流

### 1. 当前会话附件上传到应用存储

- 先用 `attachment` 确认当前会话附件的真实本地路径
- 再把该本地路径作为 `--file` 上传到应用存储

```bash
lark-cli apps +file-upload --app-id "$app_id" --file ./logo.png
```

### 2. 上传后立即拿下载地址

```bash
lark-cli apps +file-upload --app-id "$app_id" --file ./logo.png
```

- 从返回结果里读取平台分配的远端 `path` 和应用内下载地址
- 需要把文件链接写入业务字段、后续代码或测试数据时，优先直接用这次上传响应，不要再额外跑一次 `+file-list`

### 3. 已知文件名，先查 `path` 再下载

```bash
# 先查 path
lark-cli apps +file-list --app-id "$app_id" --name logo.png
# 再下载
lark-cli apps +file-download --app-id "$app_id" --path /1858537546760216.png --output ./logo.png
```

### 4. 批量清理文件

```bash
# 先用过滤器看命中（分页翻完）
lark-cli apps +file-list --app-id "$app_id" --uploaded-until 2026-03-01 --page-size 100
```

可替换的范围过滤器：

- `--type image/png`
- `--size-gt <字节>` / `--size-lt <字节>`
- `--uploaded-since 2026-04-01`
- `--uploaded-until 2026-03-01`

- 先把命中总数、样本文件、过滤条件展示给用户，并明确说明这是不可逆删除
- 在拿到明确授权前，不要继续执行 `+file-delete`

获得明确授权后，再分批删除（`--path` 可重复传多个）：

```bash
lark-cli apps +file-delete --app-id "$app_id" --path /a.png --path /b.png --yes
```

用法不确定或命令报错时，先看 `lark-cli apps --help` 或对应子命令的 `--help`。

## 时间格式（`--uploaded-since` / `--uploaded-until`）

按用户口语自然传入即可，支持：

- 相对时间 `7d` / `2h` / `30s`（从现在往前推）
- 日期 `2026-04-15`
- 日期时间 `2026-04-15T10:00:00`
- 带时区的 ISO 8601 `2026-04-15T10:00:00Z` / `2026-04-15T10:00:00+08:00`

> **时区**：不带时区的日期 / 日期时间按**运行机器的本地时区**解析（再归一化到 UTC 发给服务端）。CI（UTC）与本地（如 UTC+8）跑同一条命令，过滤边界会差几小时；要精确到某时区时显式写 ISO 8601 带偏移（如 `...+08:00` / `...Z`）。

## 安全规则

### 删除前必须确认影响范围

`+file-delete` 是不可逆操作。对来源不明或可能是生产数据的文件，先展示影响范围，再删除。

建议流程：

1. 先用 `+file-list` 或 `+file-get` 拿到待删清单、总数、总大小
2. 向用户展示影响范围，并暂停等待明确授权；没有授权前不要继续执行 `+file-delete`
3. 如果当前 agent 提供 `ask_user_question` 一类确认工具，优先用工具；没有时直接在对话中确认
4. 授权后再带 `--yes` 执行删除

### 批量删除要先报数

`--type`、`--size-gt`、`--uploaded-since` 一类范围过滤器容易扩大命中范围。删除前至少先跑一次 `+file-list` 确认命中数量；命中为 `0` 时不要继续执行删除。

### `+file-delete` 是逐项 best-effort

- 逐项返回结果：部分文件删除失败（如某个路径不存在）不影响其余文件，整体仍算成功
- 失败项在结果里单独标出原因，按逐项结果向用户说明哪些成功、哪些没删掉及原因

## 关键限制

- 单文件上传上限：`100 MB`
- `+file-sign --expires-in` 上限：30 天（默认 1 天）
- `+file-delete` 不带 `--yes` 会被确认关卡拦下（exit 10）
- 本地文件 / 输出路径限工作目录内相对路径
