# lark-apps 本地开发

适用：当前妙搭应用（full_stack 全栈或 frontend 纯前端）的源码已在工作区，用本地 code agent/IDE 开发、调试数据库（仅全栈应用有数据库），再部署上线。

## 改完代码后部署上线

改完代码，用户说"推上去""部署""上线""发布到云端"时，按此序列。

> `+release-create` 部署的是远端 `sprint/default` 上**已 push** 的代码，不是你本地工作区——未 commit / 未 push 的改动不会进入这次发布。所以发布前务必先把本次改动提交并推送。

1. `git status` 看本次改动；`git add <本次相关文件>` 暂存后 `git commit` 提交。只提交本次任务相关的改动即可，无关的零散文件不必强求清空——发布门禁是「**本次相关改动已提交并推送**」，不是「工作区绝对干净」。
2. `git push origin sprint/default` 把工作分支推到云端（遇非 fast-forward：先 `git pull --rebase origin sprint/default` 解决冲突再推，绝不 force-push）。
3. `lark-cli apps +release-create --app-id "$app_id"` 发起部署上线，记下返回的 `release_id`。
4. `lark-cli apps +release-get --app-id "$app_id" --release-id <release_id>` 轮询：`publishing` 继续轮询；`finished` 成功时该命令输出已含 `online_url`，直接读取它返回给用户（这是本轮发布完成后的可分享链接）；`failed` 时该命令输出已含 `error_logs`，直接据此给出失败原因。

## 领域规则

- 代码读写走原生 `git`；CLI 负责发布和数据库调试。不存在 `apps +pull` / `apps +push` / `apps code +read` 这类代码读写 shortcut，不要臆造。
- `sprint/default` 是工作分支；`main` 是发布态快照，由 `+release-create` 成功后服务端 fast-forward 推进；服务端护栏禁直推 `main`、拒 force-push、要求 `sprint/default` fast-forward。
- pull/push/diff/log 都用原生 git；云端 `sprint/default` 比本地新时，先 `git pull --rebase origin sprint/default`，解决冲突后再 push 和 publish。
- 环境变量由脚手架在本地启动时处理。
- frontend（纯前端，vite-react）应用的开发与部署流程和全栈一致，只是没有数据库、跳过一切 `+db-*` 步骤。后续要加数据库/后端能力时，本地链路不提供类型升级：引导用户到妙搭 web 的云端会话里用自然语言提出（如「给这个应用加登录和数据存储」）即可触发升级，无需特殊指令，也不要替用户拼站点地址。
- DB 调试用 `+db-table-list` / `+db-table-get` / `+db-execute`（见 lark-apps-db skill）；不要裸连数据库或自行拼连接串。
- DB 分 `dev` / `online`；日常调试优先 `--environment dev`。dev 的库结构变更要上线时，仍按应用发布链路走 `+release-create`，不要另造“数据库发布”步骤。
- 存量单库应用需要 dev/online 多环境时，用 `+db-env-create --environment dev`。这是不可逆 high-risk 操作。
- 本地刚推送的代码是否已部署，必须以本轮 `+release-get finished` 为准。
