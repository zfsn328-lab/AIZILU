# contact (v1)

## 选哪个命令

所有命令以当前用户身份运行（`--as user`，默认值，无需显式指定）;能否读到某个人取决于当前用户的可见范围。按意图选命令:

| 想做什么 | 命令 |
|---|---|
| 按姓名 / 邮箱搜员工拿 open_id | [`+search-user`](references/lark-contact-search-user.md) |
| 已知 open_id 取他人资料（姓名 / 部门 / 邮箱 / 是否激活等） | [`+search-user --user-ids <id>`](references/lark-contact-search-user.md) |
| 查看自己 | [`+get-user`](references/lark-contact-get-user.md) 或 `+search-user --user-ids me` |

已知 open_id 只是想查对方日程 / 忙闲,不必经过 contact —— 直接 [`lark-calendar`](../lark-calendar/README.md)（只读查询）。发消息、新建日程 / 邀请会议在当前沙箱不可用(lark-im 域仅开放群相关的只读查询,lark-calendar 域无写能力),不要用其它域命令替代。

## 典型场景

找张三给他发消息:先搜,确认 open_id:

```bash
lark-cli contact +search-user --query "张三" --has-chatted --as user
```

发消息能力在当前沙箱不可用(lark-im 域仅开放群相关的只读查询,不含发消息能力),拿到 open_id 后请告知用户该限制,不要用其它域命令替代。

搜索命中多条且后续操作有副作用(发消息、邀请会议等),把候选列给用户挑;不要擅自选第一条。

## 注意事项

- **41050 / Permission denied** 受当前用户可见范围限制(两条命令都可能遇到)。若确需扩大可见范围,让管理员调整。
- **跨租户用户**(`is_cross_tenant=true`)多数业务字段为空字符串,这是飞书可见性规则,下游做空值兜底。
- **ID 类型**:默认 `open_id`。`+get-user` 可改 `--user-id-type union_id|user_id`;`+search-user` 只接受 `open_id`。

## 边界

- 部门树 / 按部门列员工 / 组织架构不在 contact 域的白名单命令里，走原生 OpenAPI 查找接口。
