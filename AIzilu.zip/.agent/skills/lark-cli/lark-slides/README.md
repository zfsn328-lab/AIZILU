# slides

## 身份

- slides 相关的读取操作默认以 `--as user`（用户身份）执行，下文示例统一显式带 `--as user`。

## 能力边界

本 skill 在沙箱内是**只读**的：用于读取和检查已有演示文稿，不生成、不修改幻灯片内容。

- 读取整份演示文稿的完整 XML（`slides xml_presentations get`）。
- 按 `slide_id` 读取单页 XML，可指定历史版本（`slides xml_presentation.slide get`）。
- 列出历史版本、查询回滚任务状态（`slides +history-list` / `+history-revert-status`）。

## 核心概念

### URL 格式与 Token

| URL 格式 | 示例 | Token 类型 | 处理方式 |
|----------|------|-----------|----------|
| `/slides/` | `https://example.larkoffice.com/slides/xxxxxxxxxxxxx` | `xml_presentation_id` | URL 路径中的 token 直接作为 `xml_presentation_id` 使用 |
| `/wiki/` | `https://example.larkoffice.com/wiki/wikcnxxxxxxxxx` | `wiki_token` | ⚠️ **不能直接使用**，需要先查询获取真实的 `obj_token` |

### Wiki 链接特殊处理（关键！）

知识库链接（`/wiki/TOKEN`）不能直接当 `xml_presentation_id`。调用 slides 原生 API 前，先查询
wiki 节点，确认 `node.obj_type == "slides"`，再用 `node.obj_token` 作为真实 presentation ID。

```bash
lark-cli wiki spaces get_node --as user --params '{"token":"wiki_token"}'
```

例外：`slides +history-list` / `+history-revert-status` 的 `--presentation` 可以直接接收
wiki URL（自动解析，要求该节点是幻灯片），不需要先手动查询节点。

### 资源关系

```text
Wiki Space (知识空间)
└── Wiki Node (知识库节点, obj_type: slides)
    └── obj_token → xml_presentation_id

Slides (演示文稿)
├── xml_presentation_id (演示文稿唯一标识)
├── revision_id (版本号)
└── Slide (幻灯片页面)
    └── slide_id (页面唯一标识)
```

## References

- 读取整份 XML：[`lark-slides-xml-presentations-get.md`](references/lark-slides-xml-presentations-get.md)
- 读取单页 XML：[`lark-slides-xml-presentation-slide-get.md`](references/lark-slides-xml-presentation-slide-get.md)
- 历史版本与回滚状态：[`lark-slides-history.md`](references/lark-slides-history.md)

## 快捷命令（沙箱内仅以下两个可用，均只读）

- `+history-list` — 分页列出历史版本，返回 `entries[]`（含 `history_version_id`、`revision_id`、`edit_time`）
- `+history-revert-status` — 按 `task_id` 查询回滚任务状态（`status`、`failed_block_tokens`）

`--presentation` 接收 `xml_presentation_id`、`/slides/` URL 或可解析为幻灯片的 `/wiki/` URL。

```bash
lark-cli slides +history-list --as user --presentation "<slides_url_or_token>" --page-size 20
lark-cli slides +history-revert-status --as user --presentation "<slides_url_or_token>" --task-id "<task_id>"
```

## API（沙箱内仅以下原生 API 调用可用）

本沙箱内**仅**以下原生 `<service> <resource> <method>` 组合可用（全部只读），不要再自行拼其它
service/api 组合去试。调用前先用 `lark-cli schema slides.<resource>.<method>` 查看最新参数结构。

### xml_presentations

- `get` — 读取演示文稿的完整 XML 内容（返回 `data.xml_presentation.content`）

```bash
lark-cli slides xml_presentations get --as user --params '{"xml_presentation_id":"<id>","revision_id":-1}'
```

### xml_presentation.slide

- `get` — 按 `slide_id` 读取单页 XML，可指定历史版本

```bash
lark-cli slides xml_presentation.slide get --as user --params '{"xml_presentation_id":"<id>","slide_id":"<slide_id>","revision_id":-1}'
```
