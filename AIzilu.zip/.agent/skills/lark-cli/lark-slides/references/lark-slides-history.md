# slides history（历史版本与回滚任务状态）

用于查看 Slides XML presentation 的历史版本列表，以及查询回滚任务的执行状态。这两个都是
**只读**快捷命令：

- `slides +history-list` — 分页列出历史版本。
- `slides +history-revert-status` — 按 `task_id` 查询回滚任务状态。

> 发起回滚本身（`+history-revert`）是高风险写操作，不在本沙箱的只读推荐入口
> 内。用户临时要求回滚而撞到 exit 10 时，按上层 lark-cli SKILL.md 的高风险写审批协议处理。
> `+history-revert-status` 只负责查询一个已存在的回滚任务的执行进度。

`entries[].edit_time` 是 UTC RFC3339 时间字符串（例如 `2026-06-22T12:24:45Z`）。按时间匹配时先将
其解析为时间值，再比较先后关系或时间差。

## 命令形态

```bash
# 列出历史版本
lark-cli slides +history-list --as user --presentation "<slides_url_or_token>" --page-size 20

# 翻页
lark-cli slides +history-list --as user --presentation "<slides_url_or_token>" --page-size 20 --page-token "<page_token>"

# 查询回滚任务状态
lark-cli slides +history-revert-status --as user --presentation "<slides_url_or_token>" --task-id "<task_id>"
```

## 参数

| 命令 | 参数 | 必填 | 说明 |
|-|-|-|-|
| `+history-list` | `--presentation` | 是 | `xml_presentation_id`、Slides URL，或可解析为 Slides 的 wiki URL |
| `+history-list` | `--page-size` | 否 | 返回条数，范围 `1-20`，默认 `20` |
| `+history-list` | `--page-token` | 否 | 上一页返回的 `page_token` |
| `+history-revert-status` | `--presentation` | 是 | 同一个演示文稿 |
| `+history-revert-status` | `--task-id` | 是 | 发起回滚时返回的 `task_id` |

> `+history-list` 支持分页：无 `--page-token` 取第一页，`has_more=true` 时用上一页返回的
> `page_token` 继续翻页。`--presentation` 收到 wiki URL 时自动解析出真实演示文稿 ID，
> 无需先手动查询 wiki 节点。

## 按 revision_id 或时间点定位版本

当用户说"看看昨天下午 3 点的版本""revision_id=42 是哪一条"这类需求时，用 `+history-list` 定位：

1. 执行 `slides +history-list --presentation <presentation>` 获取第一页历史记录；只有
   `has_more=true` 且还需要更多候选时才继续传 `--page-token` 翻页。
2. 如果用户给出 `revision_id`：先筛选当前页中 `entries[].revision_id == 用户给出的 revision_id`。
   如果未命中且 `has_more=true`，继续拉下一页；如果已经命中候选，最多额外再拉一页，补齐同一个
   `revision_id` 可能跨页出现的相邻 `history_version_id`。若用户同时给出目标时间，在候选里选择
   `edit_time` 与目标时间最接近的一条；若未给目标时间但候选只有一条，可直接使用；若多个候选无法
   可靠区分，不要自行取第一条，向用户展示候选并确认。
3. 如果用户只给出时间：用 `entries[].edit_time` 匹配，选择目标时刻之前最近的一条；如果用户表达
   的是"最接近某时刻"，则选择绝对时间差最小的一条。
4. 从最终匹配条目读取 `history_version_id`。`history_version_id` 对应服务端 `minor_history.version`。

候选确认时使用类似格式：

```text
同一个 revision_id 命中多个历史版本，请确认是哪一条：
- history_version_id=11 revision_id=42 edit_time=2026-06-22T12:24:45Z name=...
- history_version_id=12 revision_id=42 edit_time=2026-06-22T12:25:14Z name=...
```

## 回滚任务状态轮询

已发起的回滚任务返回 `task_id` 与 `status` 后：

1. 如果 `status` 不是 `running`，不再调用状态接口。
2. 如果 `status` 是 `running`，等待响应中的 `poll_after_ms` 后调用 `+history-revert-status`；
   `poll_after_ms` 缺失、为 `0` 或非法时，默认等待 10 秒。
3. 状态查询返回 `running` 时继续轮询；返回 `done`、`partial_failed` 或 `failed` 时停止。
4. 默认最多轮询 5 分钟。达到上限后停止轮询，向用户说明任务仍在运行并返回 `task_id`，不得将其
   描述为回滚失败。
5. 状态查询出现临时错误时，按相同间隔最多连续重试 3 次；只重试 `+history-revert-status`。
6. `partial_failed` 或 `failed` 时展示 `failed_block_tokens`。

## 返回值要点

`+history-list` 返回：

```json
{
  "entries": [
    {
      "revision_id": 42,
      "history_version_id": "11",
      "edit_time": "2026-06-22T12:24:45Z",
      "type": 1,
      "name": "版本名",
      "description": "版本说明",
      "editor_ids": ["ou_xxx"]
    }
  ],
  "has_more": true,
  "page_token": "page_token"
}
```

`+history-revert-status` 返回：

```json
{
  "status": "partial_failed",
  "history_version_id": "11",
  "failed_block_tokens": ["blk_xxx"]
}
```

`status` 可能是 `running`、`done`、`partial_failed`、`failed`。当状态是 `partial_failed` 或
`failed` 时，优先检查 `failed_block_tokens`。

## 相关命令

- [xml_presentations get](lark-slides-xml-presentations-get.md) — 读取整份演示文稿 XML
- [xml_presentation.slide get](lark-slides-xml-presentation-slide-get.md) — 按 `slide_id` 读取单页 XML
