# lark-slides xml_presentations get

## 用途

读取飞书幻灯片（PPT）演示文稿的完整 XML 内容信息。

## 命令形态

```bash
lark-cli slides xml_presentations get --as user --params '<json_params>'
```

### 参数说明

| 参数 | 类型 | 必需 | 说明 |
|------|------|------|------|
| `--params` | JSON string | 是 | 路径参数与查询参数，结构以 schema 为准 |

### params JSON 结构

```json
{
  "xml_presentation_id": "slides_example_presentation_id",
  "revision_id": -1
}
```

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| `xml_presentation_id` | string | 是 | 演示文稿的唯一标识符 |
| `revision_id` | integer | 否 | 版本号，`-1` 表示最新版本 |

### 返回值

成功时返回演示文稿的完整信息：

```json
{
  "ok": true,
  "identity": "user",
  "data": {
    "xml_presentation": {
      "presentation_id": "slides_example_presentation_id",
      "revision_id": 1,
      "content": "<presentation xmlns=\"https://www.larkoffice.com/sml/2.0\" height=\"540\" width=\"960\">...</presentation>"
    }
  }
}
```

### 返回字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| `data.xml_presentation.presentation_id` | string | 演示文稿唯一标识 |
| `data.xml_presentation.revision_id` | integer | 版本号 |
| `data.xml_presentation.content` | string | XML 格式的完整内容 |

### 常见错误

| 错误码 | 含义 |
|--------|------|
| 404 | 演示文稿不存在，检查 `xml_presentation_id` 是否正确 |
| 403 | 对该演示文稿无访问权限 |
| 400 | 参数格式错误，确保 `--params` 是合法的 JSON 字符串 |

### 注意事项

1. 直接调用前，使用 `lark-cli schema slides.xml_presentations.get` 查看最新的参数结构
2. 返回的 XML 在 `data.xml_presentation.content` 字段中
3. 如果只需要部分信息，可以使用 `jq` 等工具过滤返回结果
4. 完整 XML 可能很长，用 `jq` 提取到本地文件而不是直接打到终端，避免输出被截断

## 相关命令

- [xml_presentation.slide get](lark-slides-xml-presentation-slide-get.md) — 按 `slide_id` 读取单页 XML
- [slides history](lark-slides-history.md) — 历史版本列表与回滚任务状态查询
