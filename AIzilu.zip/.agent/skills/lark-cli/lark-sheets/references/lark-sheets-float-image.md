# Lark Sheet Float Image

## 使用场景

查看飞书表格中已有**浮动图片**对象的配置（悬浮在单元格上方的图片，不属于单元格内容；与随行走的单元格内嵌图片不同）。本 reference 覆盖 1 个只读 shortcut：

| 操作需求 | 使用工具 | 说明 |
|---------|---------|------|
| 查看已有浮动图片 | `+float-image-list` | 获取浮动图片的位置、大小和层级配置 |

## Shortcuts

| Shortcut | Risk | 分组 |
| --- | --- | --- |
| `+float-image-list` | read | 对象 |

## Flags

### `+float-image-list`

_公共四件套 · 系统：`--dry-run`_

| Flag | Type | 必填 | 说明 |
| --- | --- | --- | --- |
| `--float-image-id` | string | optional | 按 id 过滤；省略时列工作表全部 |

## Examples

公共四件套：所有 shortcut 顶部排列 `--url` / `--spreadsheet-token` / `--sheet-id` / `--sheet-name`（XOR）。浮动图片是 sheet 级对象。

### `+float-image-list`

```bash
lark-cli sheets +float-image-list --url "..." --sheet-id "$SID"
```

返回每张浮动图片的 `image_token` / `position` / `size` / `z-index` 等。

### Validate / DryRun / Execute 约束

- `Validate`：XOR 公共四件套。
- `DryRun`：输出请求模板，零网络副作用。
- `Execute`：发起浮动图片列表查询。
