# Lark Sheet Formula Verify（+formula-verify）

> **本文定位**：飞书表格"公式是否真的零错误"的**只读**自检入口。`+formula-verify` 对指定子表（或整本工作簿）扫描公式与单元格值，一次调用聚合全表错误清单 + 编译失败清单 + 每类错误的定位与样本，让你快速核对一张表的公式健康度。它**不改动表格**。

## 为什么需要自检

飞书在线表格已经实时算好结果，但"算出来"和"算对了"是两件事。常见缺口：

- 公式编译失败 → 单元格落成文本（写入类操作留下的 `formula_errors[]` 是**编译失败**信号）。
- 公式编译成功但**运行时错误**：`#REF!` / `#DIV/0!` / `#VALUE!` / `#NAME?` / `#NULL!` / `#NUM!` / `#N/A`——这一类只看 `formula_errors[]` 看不到，必须扫单元格值。

`+formula-verify` 把两路信号合并成一份统一 JSON：一次调用聚合全表错误清单 + 编译失败清单 + 每类错误的定位与样本，AI 一眼就能定位问题。

## 调用契约

最小调用形态：

| 入参 | 含义 |
|---|---|
| `--url` / `--spreadsheet-token` | 表格定位（XOR 二选一，必填） |
| `--sheet-id` / `--sheet-name` | 限定子表（mutually exclusive；省略则扫全部可见子表） |
| `--range` | 限定 A1 范围；省略则用各 sheet 的 `current_region` |
| `--max-locations` | 每类错误样本上限，默认 20 |
| `--ai-only` | 只校验 AI 公式（`=AI(prompt, [range])`），跳过普通公式的 7 类 Excel 错误扫描。AI 公式是异步计算的：把这个 flag 配 `--range` 当写后的**第一次抽样检查**，不要用 `+cells-get` 轮询；抽样里没有明确的 failed / unsupported 状态时，可以在告知用户「计算仍在后台进行」的前提下继续交付，不必卡着等 pending 公式算完 |
| `--exit-on-error` | `status='errors_found'` 时返回非 0 退出码（CI 网关用） |

返回核心字段：

- `status` ∈ `success` / `errors_found` / `partial`——**唯一可机读的健康度判据**。
- `total_errors` / `total_formulas` / `scanned_cells`——本次扫描规模指标。
- `has_more`——为 true 表示扫描被内部上限截断（详见后文「截断与续读」），未覆盖完整范围。
- `error_summary[<错误类型>]`——每类错误的 `count` / `locations[]` / `samples[].{address,formula,depends_on}`。
- `compile_errors[]`——合并最近一次写入留下的编译失败清单，与运行时错误并存时同时出现。
- `warning_message`——仅在 `has_more=true` 时出现，告知调用方需要缩小 `--range` / 拆 `--sheet-id` 续读。

## 结果判读规则

- `status='success'` → 该扫描范围内公式零错误。
- `status='partial'` → 扫描被内部上限截断，只覆盖了一部分。先缩小 `--range` 或拆 `--sheet-id` 续扫，**不允许**把 `partial` 当作 `success`。
- `status='errors_found'` 且 `compile_errors[]` 非空 → 存在编译失败（这些单元格此刻是文本、不是公式）；按 `compile_errors[].reason` 定位是哪类语法问题（飞书函数名 / 范围语法 / 引用样式）。
- `status='errors_found'` 且只剩运行时错误 → 按 `error_summary` 的 `samples[].formula` + `depends_on` 排查根因（零除？空值参与运算？引用越界？日期差写法？数组语义？）。

注意：

- "编译失败但运行时无报错"不算 zero-error（编译失败的单元格此刻是文本不是公式，源数据一变就再也算不出值）。
- 靠肉眼读首末 5 行确认是不可靠的——表中段、隐藏行、合并区里的错误这样根本看不到。
- 修复公式属于写操作，不在本只读命令的范围内；把 `+formula-verify` 报出的错误定位转述给用户即可。

## 截断与续读

后端有一个内部硬上限对总扫描单元格数做截断（不暴露给调用方），超过后立即返回 `has_more=true` + `warning_message`，`error_summary` / `compile_errors` 仅覆盖已扫描部分。处理路径：

- 把工作簿按 `--sheet-id` / `--sheet-name` 拆成多次调用。
- 同 sheet 内按 `--range` 切片（如先 `A1:Z200` 再 `AA1:AZ200`），逐块自检。
- 每块都跑到 `has_more=false` 且 `status='success'` 才算这块通过。

## 常见陷阱

| 坑 | 应对 |
|---|---|
| 错误字符串本地化 | 后端按内部 `error_kind` / `compute_status` 字段识别错误类别，不走字符串匹配；调用方拿到的 7 类英文错误代码由后端统一规范输出，与 locale 无关。 |
| `formatted_value` 可能隐藏错误 | 某些条件格式 / 自定义数字格式会把 `#DIV/0!` 显示成空白。后端直接读 cell `error_kind`，不依赖 `formatted_value`，绕开此类被遮蔽。 |
| 把 `partial` 当 `success` | `partial` 仅表示**已扫描部分**无错误，剩余区域未知。必须续扫直到 `has_more=false` 且 `status='success'` 才能算通过。 |
| 编译失败 vs 运行时错误 | 同一份报告里 `compile_errors[]` 与 `error_summary` 并存。先看 `compile_errors[]`（编译失败）、再看运行时错误。 |
