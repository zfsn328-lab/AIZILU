# base 域命令参考

命令事实以 `lark-cli base +<cmd> --help` 为准。本文只补 `--help` 没说清的部分。

## 通用

- 所有命令默认 `--as user`。
- 除 `+url-resolve` 外，其余命令都必须传 `--base-token`。
- `--table-id` / `--view-id` 接 ID 或名称；ID 形态是 `tbl...` / `vew...`。

## `+url-resolve`

```bash
lark-cli base +url-resolve --url "<Base/Wiki/记录分享 URL>" --as user
```

返回 `base_token`，以及所选块的类型 `block_type` 与对应 ID。这是所有后续调用的入口。

**URL 里的 `table=` 不是 `table_id`。** 它表示当前选中的 Base **顶层块**，可能是数据表、仪表盘、workflow、文件夹或文档。判读返回值：

- `base_token` → 直接用。
- **仅当 `block_type` 为 `table` 时**，才把返回的 `table_id` 当数据表 ID 用。
- `block_type` 是其他类型（或返回的是 `dashboard_id` / `workflow_id`、只有中性 `block_id`）时，说明用户当前选中的**不是数据表**：改用 `+table-list --base-token <t>` 列出真实数据表，再按用户点名的表名选定 `--table-id`。
- `selection_source=url_query` 只说明「URL 当前选中了该块」，**不代表**它覆盖用户明确点名的目标。用户点名的目标与返回的 `block_name` 不一致时，以用户为准，走 `+table-list` 重新定位。

绝不要从 URL 字符串里自行截取 `table=` 的值当 `--table-id`。

## `+base-get` / `+table-list`

```bash
lark-cli base +base-get   --base-token <t> --as user
lark-cli base +table-list --base-token <t> --limit 50 --as user
```

`+table-list` 的 `--limit` 范围 1-100，默认 50。

## `+field-list` / `+view-list`

```bash
lark-cli base +field-list --base-token <t> --table-id <tbl> --as user
lark-cli base +view-list  --base-token <t> --table-id <tbl> --as user
```

`--limit` 范围 1-200，默认 100。写记录级查询前先用 `+field-list` 确认字段名与类型，
不要凭用户口述猜字段名。

## 7 个 `+view-get*`

```bash
lark-cli base +view-get                  --base-token <t> --table-id <tbl> --view-id <v> --as user
lark-cli base +view-get-filter           --base-token <t> --table-id <tbl> --view-id <v> --as user
lark-cli base +view-get-sort             --base-token <t> --table-id <tbl> --view-id <v> --as user
lark-cli base +view-get-group            --base-token <t> --table-id <tbl> --view-id <v> --as user
lark-cli base +view-get-card             --base-token <t> --table-id <tbl> --view-id <v> --as user
lark-cli base +view-get-timebar          --base-token <t> --table-id <tbl> --view-id <v> --as user
lark-cli base +view-get-visible-fields   --base-token <t> --table-id <tbl> --view-id <v> --as user
```

共 7 个，按需取对应配置；`+view-get` 是视图本体元信息。

## `+record-list`

```bash
lark-cli base +record-list --base-token <t> --table-id <tbl> --as user
lark-cli base +record-list --base-token <t> --table-id <tbl> --view-id "<视图名>" --as user
lark-cli base +record-list --base-token <t> --table-id <tbl> --field-id "标题" --field-id "状态" --as user
```

- 省略 `--view-id` 读全表；传 `--view-id` 读该视图筛选后的记录
- `--filter-json` 是筛选 JSON 对象（结构见下方「filter 条件结构」，与 `+view-get-filter` 读到的同一套），**会覆盖 `--view-id` 的筛选**
- `--sort-json` 是排序数组，如 `[{"field":"Updated","desc":true}]`
- `--field-id` 可重复，用于只投影需要的字段，减少返回体
- `--limit` 范围 1-200，默认 100

## `+record-search`

```bash
lark-cli base +record-search --base-token <t> --table-id <tbl> --keyword "<关键词>" --as user
```

`--keyword` 必填（除非用 `--json` 直传请求体）。`--limit` 默认 10，范围 1-200。
`--view-id` / `--filter-json` / `--sort-json` / `--field-id` 同 `+record-list`。

## filter 条件结构

`+view-get-filter` 返回的视图筛选、以及 `+record-list` / `+record-search` 的 `--filter-json`，共用同一套 tuple 结构：

```json
{
  "logic": "and",
  "conditions": [
    ["状态", "intersects", ["Doing"]],
    ["负责人", "intersects", [{ "id": "ou_xxx" }]],
    ["截止时间", "empty"]
  ]
}
```

- 顶层是 `{logic?, conditions?}`；`logic` 取 `and`（默认）或 `or`；`conditions` 默认空数组。
- 每条条件是 tuple `[field, operator, value?]`；`empty` / `non_empty` 写 2 项即可（`["截止时间","empty"]`）。
- 清空筛选写 `{"conditions": []}`。
- value 写法随字段类型而变：文本用字符串数组，单/多选用选项名数组，人员类（`user`/`created_by`/`updated_by`）用 `[{"id":"ou_xxx"}]`，checkbox 用布尔，日期类有专门的相对/绝对写法。构造前先用 `+field-list` 确认字段类型与选项名。

> 这套 tuple 结构**不适用于聚合查询**。本沙箱未开放 `+data-query`，遇到"分组统计/聚合"类需求时不要臆造它的 `filters` 对象 DSL。

## 选路

按条件取原始记录用 `+record-list`；只有「模糊找含某关键词的记录」才用 `+record-search`。
