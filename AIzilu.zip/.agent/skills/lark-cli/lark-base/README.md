# base (v3)

> [!IMPORTANT]
> - 运行 `lark-cli --version`，确认可用，无需询问用户。

## 身份

base 域命令默认使用 `--as user`。

## Shortcuts

| Shortcut | 说明 |
|----------|------|
| [`+url-resolve`](references/lark-base-commands.md) | 把 Base / Wiki / 记录分享 URL 解析成 `base_token` + 所选块的 `block_type` 与对应 ID |
| [`+base-get`](references/lark-base-commands.md) | 读 Base 本体元信息 |
| [`+table-list`](references/lark-base-commands.md) | 列数据表 |
| [`+field-list`](references/lark-base-commands.md) | 列字段（含类型与选项） |
| [`+view-list`](references/lark-base-commands.md) | 列视图，按视图名取 `view_id` |
| [`+view-get`](references/lark-base-commands.md) 及 `+view-get-card` / `+view-get-filter` / `+view-get-group` / `+view-get-sort` / `+view-get-timebar` / `+view-get-visible-fields` | 读视图配置（共 7 个） |
| [`+record-list`](references/lark-base-commands.md) | 读记录，可按视图 / filter-json / sort-json 取 |
| [`+record-search`](references/lark-base-commands.md) | 按关键词搜记录（`--keyword`） |

- 使用 Shortcut 前，必须先读 [references/lark-base-commands.md](references/lark-base-commands.md)。

## 先拿 base_token —— 定位规则

**不要把 Base / Wiki URL、wiki token 或孤立 raw token 直接当 `--base-token`。**

| 用户给了什么 | 怎么做 |
|---|---|
| Base / Wiki / 记录分享 URL | `lark-cli base +url-resolve --url "<URL>" --as user`，取 `base_token`；**`table_id` 只在返回的 `block_type` 为 `table` 时才可用**（URL 里的 `table=` 是顶层块，可能是仪表盘/workflow/文档，不是数据表 ID）。不是 `table` 就走 `+table-list` 按表名定位。详见 [commands](references/lark-base-commands.md) |
| 文档里的 `<bitable token="..." table-id="...">` 标签 | 直接把 `token` 当 `base_token`、`table-id` 当 `--table-id`，不用再 `+url-resolve` |
| 只有 Base 名称或关键词 | 本域没有按名称搜 Base 的能力；改用 [lark-drive](../lark-drive/README.md) 的 `+search --doc-types bitable` 先定位到 URL，再 `+url-resolve` |

`--table-id` / `--view-id` 既接 ID（`tbl...` / `vew...`）也接名称。

## 意图路由

| 用户需求 | 命令 |
|---|---|
| 这个 Base 里有哪些表 | `+table-list --base-token <t>` |
| 这张表有哪些字段、字段类型/选项是什么 | `+field-list --base-token <t> --table-id <tbl>` |
| 读表里的记录 | `+record-list --base-token <t> --table-id <tbl>` |
| 只读某个视图筛选后的记录 | `+record-list ... --view-id "<视图名或 vew...>"` |
| 按关键词搜记录 | `+record-search ... --keyword "<关键词>"` |
| 只要某几个字段 | 追加 `--field-id <字段名>`（可重复） |
| 这个视图的筛选/排序/分组/可见字段怎么配的 | `+view-get-filter` / `+view-get-sort` / `+view-get-group` / `+view-get-visible-fields` |
| Base 叫什么、归谁 | `+base-get --base-token <t>` |

## 分页

`+table-list` 的 `--limit` 范围 1-100（默认 50）；`+field-list` / `+view-list` / `+record-list`
的 `--limit` 范围 1-200（默认 100）；`+record-search` 的 `--limit` 默认 10。都配 `--offset` 翻页。

结果被 `--limit` 截断时，不要拿这一页的内容回答「一共有多少」「最大的是哪个」这类全局问题，
先翻完或收窄条件。
