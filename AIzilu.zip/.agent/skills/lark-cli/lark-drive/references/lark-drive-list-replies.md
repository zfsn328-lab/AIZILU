# drive +list-replies

分页获取某条评论下的回复。`drive file.comments list` 返回的评论卡片自带 `reply_list.replies`，但当卡片 `item.has_more=true` 时回复没有拉全——这时（或需要按 `comment_id` 独立分页看全部回复时）用本命令。

## 命令

```bash
# 推荐：完整 URL + 评论 ID
lark-cli drive +list-replies --url "https://example.larksuite.com/docx/<DOCX_TOKEN>" --comment-id '<id>'
```

## 参数

| 参数 | 必填 | 说明 |
|---|---|---|
| `--url` | 与 `--token` 二选一 | 推荐入口。支持 doc/docx/sheet/file/slides/base/bitable/apps/wiki URL；apps 妙搭 URL 使用 `/page/<token>`；wiki URL 会自动解析到真实文档。 |
| `--token` | 与 `--url` 二选一 | 裸 token 或 URL。裸 token 必须搭配 `--type`；wiki token 使用 `--type wiki`。 |
| `--type` | 裸 token 时必填 | 传 token 对应类型：`doc`、`docx`、`sheet`、`file`、`slides`、`bitable`、`base`、`apps`、`wiki`。wiki token 使用 `wiki`；传 `base` 时，CLI 会按 `bitable` 类型处理。 |
| `--comment-id` | 是 | 评论 ID；来自 `drive file.comments list` 返回的 `items[].comment_id` |
| `--page-size` | 否 | 1-100，默认 50 |
| `--page-token` | 否 | 上次输出的 `page_token`；`has_more=true` 时用它续拉 |
| `--need-reaction` | 否 | 在回复上返回 reaction 数据 |

## 行为说明

- 根回复承载评论正文本身，是回复列表中创建最早的一条：**仅第一页（未传 `--page-token`）的 `items[0]` 是根回复**；翻页后（传了 `--page-token`）返回的 `items[0]` 只是普通回复，不要按位置当作根回复。
- 输出字段：`items[].reply_id` / `user_id` / `create_time` / `update_time` / `content.elements`；`items[].user_id` 是 open_id，可与当前身份比对判断回复归属。
- 输出的 `items` 始终是 JSON 数组（服务端省略时归一化为 `[]`）。

## 输出

```json
{
  "file_token": "docx_token",
  "file_type": "docx",
  "comment_id": "<comment_id>",
  "items": [],
  "has_more": false,
  "page_token": "",
  "count": 0
}
```

`items` 是回复数组；是否继续翻页以 `has_more` 为准，`has_more=true` 时用返回的 `page_token` 续拉。

## 参考

- [`../README.md`](../README.md) file.comments 节 —— 评论卡片模型与统计口径（`comment_id` 的来源）
- [`lark-drive-batch-query-comments.md`](lark-drive-batch-query-comments.md) —— 按评论 ID 批量获取评论卡片
