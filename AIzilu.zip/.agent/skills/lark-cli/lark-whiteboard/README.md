# whiteboard (v1)

> [!IMPORTANT]
> - 运行 `lark-cli --version`，确认可用，无需询问用户。

## 身份

画板导出默认使用 `--as user`。

## Shortcuts

| Shortcut | 说明 |
|----------|------|
| [`+export`](references/lark-whiteboard-export.md) | 导出画板为预览图片、SVG 矢量图、代码或原始节点结构。 |

- 使用 Shortcut 前，必须先读其对应 reference 文档。

## 意图路由

| 用户需求 | 命令 |
|---|---|
| 查看画板内容 / 导出图片 | [`+export --output-type preview`](references/lark-whiteboard-export.md) |
| 导出 SVG 矢量图 | [`+export --output-type svg`](references/lark-whiteboard-export.md) |
| 提取画板的 Mermaid/PlantUML 源码 | [`+export --output-type source`](references/lark-whiteboard-export.md) |
| 导出画板原始节点结构（OpenAPI 原生格式） | [`+export --output-type raw`](references/lark-whiteboard-export.md) |

## 获取画板 token

导出需要画板 token（形如 `wbcnXXX`）：

| 用户给了什么 | 怎么获取 |
|---|---|
| 直接给了 whiteboard token（`wbcnXXX`）| 直接使用 |
| 文档 URL 或 doc_id，文档中已有画板 | `lark-cli docs +fetch --doc <URL> --as user`，从返回的 `<whiteboard token="xxx"/>` 提取（参数详见 [lark-doc](../lark-doc/README.md)）|
