
# calendar +meeting

通过日程 ID（`event_id`） 获取关联的视频会议信息（`meeting_id`、`meeting_note`）。只读。

## 命令

```bash
# 单个 / 批量（逗号分隔，最多 50 个）
lark-cli calendar +meeting --event-ids <event_id1>,<event_id2>

# 默认使用主日历，需要时显式传 --calendar-id
lark-cli calendar +meeting --event-ids <event_id> --calendar-id <calendar_id>
```

## 输出字段

| 字段 | 说明 |
|------|------|
| `event_id` | 日程 ID |
| `meeting_id` | 关联的视频会议 ID |
| `meeting_note` | 用户主动绑定到日程的纪要文档 Token（`MeetingNotes`，由用户在日程页手动添加）。**与会中产生的 AI 智能纪要 `note_doc_token` 是两份不同文档。** |

## 获取绑定的纪要文档

`meeting_note` 是用户在日程页手动绑定的纪要文档 Token，可直接取其正文：

```bash
lark-cli docs +fetch --api-version v2 --doc <meeting_note> --doc-format markdown
```
