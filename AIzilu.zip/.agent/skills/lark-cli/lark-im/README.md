# im (v1)

## Core Concepts

- **Chat**: A group chat or P2P conversation, identified by `chat_id` (oc_xxx).
- **Message**: A single message in a chat, identified by `message_id` (om_xxx).
- **Reaction**: An emoji reaction on a message.
- **Member**: An entry in a chat's member list — a user account or a bot (returned in separate `users[]` / `bots[]` buckets).

所有命令以当前用户身份运行（`--as user`，默认值，无需显式指定）；能否读到某个群 / 成员 / 消息取决于该用户对目标资源的可见性。

## Resource Relationships

```
Chat (oc_xxx)
├── Message (om_xxx)
│   └── Reaction (emoji)
└── Member (user / bot)
```

## Shortcuts（推荐优先使用）

Shortcut 是对常用操作的高级封装（`lark-cli im +<verb> [flags]`）。有 Shortcut 的操作优先使用。本沙箱只透出以下 3 个只读快捷命令：

| Shortcut | 说明 |
|----------|------|
| [`+chat-list`](references/lark-im-chat-list.md) | List chats the current user is a member of; defaults to groups; pass --types=p2p,group to include p2p single chats; supports sorting, auto-pagination (--page-all), --exclude-muted |
| [`+chat-members-list`](references/lark-im-chat-members-list.md) | List members of a chat; returns separate users[] / bots[] buckets; --member-types filters which kinds to return; --page-all pagination; surfaces truncations[] when the server caps a bucket |
| [`+chat-search`](references/lark-im-chat-search.md) | Search visible group chats by --query keyword and/or --member-ids; e.g. look up chat_id by group name; supports type filters, sorting, auto-pagination (--page-all), and --exclude-muted |

## API Resources

```bash
lark-cli schema im.<resource>.<method>   # 调用 API 前必须先查看参数结构
lark-cli im <resource> <method> [flags]  # 调用 API
```

> **重要**：使用原生 API 时，必须先运行 `schema` 查看 `--data` / `--params` 参数结构，不要猜测字段格式。

本沙箱只透出以下只读 API 命令（均为 read-only）；**不要**尝试列表之外的 `im <service>/<api>` 组合。

### chats

  - `get` — 获取群信息。调用方需在目标群内才能拿到完整信息；内部群还需与群属于同一租户。

### chat.members

  - `bots` — 读取群内机器人成员信息。上游 skill 未提供 typed-flag 文档，调用前先 `lark-cli schema im.chat.members.bots` 查看参数与返回结构。
  - `get` — 读取群成员信息。上游 skill 未提供 typed-flag 文档，调用前先 `lark-cli schema im.chat.members.get` 查看参数与返回结构。

### pins

  - `list` — 获取群内 Pin 消息。

### reactions

  - `batch_query` — 批量获取多条消息的表情回复。[Must-read](references/lark-im-reactions.md)
  - `list` — 获取单条消息的表情回复记录。[Must-read](references/lark-im-reactions.md)

## 权限表

| 方法 | 所需 scope |
|------|-----------|
| `chats.get` | `im:chat:read` |
| `+chat-list` / `+chat-search` | `im:chat:read` |
| `chat.members.get` | `im:chat.members:read` |
| `+chat-members-list` | `im:chat.members:read` |
| `reactions.batch_query` | `im:message.reactions:read` |
| `reactions.list` | `im:message.reactions:read` |
| `pins.list` | `im:message.pins:read` |
