# docs +history-list（历史版本列表）

用于查看 Docx 的历史版本列表（分页），读取每个版本的 `revision_id`、`history_version_id`、
`edit_time`、版本名等信息。本沙箱只开放只读的 `+history-list`，不提供回滚（写操作）能力。

`entries[].edit_time` 是 RFC3339 时间字符串（例如 `2026-06-22T12:24:45Z`）。按时间匹配时先把它
解析为时间值，再比较先后关系或时间差——**不要**把它当 Unix 秒数直接比大小。

## 用法

`+history-list` 是分页接口：先拉第一页，只有 `has_more=true` 且还需要更多候选时才继续传
`--page-token` 翻页。

- 按 `revision_id` 定位版本：逐页筛选 `entries[].revision_id` 相同的记录。未命中时必须继续翻页
  至 `has_more=false`；命中位于页尾时，继续读取下一页以收集相邻的同 `revision_id` 候选。多条
  记录时结合 `edit_time` 选择；无法区分时请用户确认。
- 按时间点定位版本：用 `entries[].edit_time` 匹配，选择不晚于目标时间的最近一条；用户明确要求
  「最接近」时，选择时间差最小的一条。
- `history_version_id` 对应服务端 `minor_history.version`。

## 命令

```bash
# 列出历史版本
lark-cli docs +history-list --doc "<docx_url_or_token>" --page-size 20

# 翻页
lark-cli docs +history-list --doc "<docx_url_or_token>" --page-size 20 --page-token "<page_token>"
```

## 参数

| 命令 | 参数 | 必填 | 说明 |
|-|-|-|-|
| `+history-list` | `--doc` | 是 | Docx URL/token，或可解析为 Docx 的 wiki URL |
| `+history-list` | `--page-size` | 否 | 返回条数，范围 `1-20`，默认 `20` |
| `+history-list` | `--page-token` | 否 | 上一页返回的 `page_token` |

## 返回值要点

`+history-list` 返回：

```json
{
  "entries": [
    {
      "revision_id": 42,
      "history_version_id": "11",
      "edit_time": "2026-06-22T12:24:45Z",
      "type": 1,
      "name": "版本名",
      "description": "版本说明",
      "editor_ids": ["ou_xxx"]
    }
  ],
  "has_more": true,
  "page_token": "page_token"
}
```

是否还有下一页以返回里的 `has_more` 为准；`page_token` 只作为 `has_more=true` 时续跑下一页的游标。
