# docs

## 能力范围（本沙箱仅开放以下只读命令）

本沙箱环境下，docs 域仅提供三个只读的快捷命令，文档读取默认使用 `--as user`：

```bash
# 读取文档内容（默认 XML，simple；若 URL 存在 #share-... 锚点，优先按锚点局部读取，不要全文拉取）
lark-cli docs +fetch --doc "文档URL或token"

# 列出文档历史版本
lark-cli docs +history-list --doc "文档URL或token" --page-size 20

# 按关键词搜云文档
lark-cli docs +search --query "<关键词>"
```

其余 docs 能力（创建 / 编辑 / 追加正文、图片与附件的插入·预览·下载、封面资源、思维笔记、
画板更新、字数统计、历史回滚等写 / 管理操作）在本沙箱**不作为可用入口**，不要尝试拼这些命令。

## 前置条件 — 执行操作前必读

**执行对应操作前，MUST 先用 Read 工具读取以下文件：**

1. **读取文档（`docs +fetch`）** → 必读 [`lark-doc-fetch.md`](references/lark-doc-fetch.md)（`--scope` / `--detail` 选择、局部读取策略、`<fragment>` / `<excerpt>` 输出结构）
2. **查看历史版本（`docs +history-list`）** → 必读 [`lark-doc-history.md`](references/lark-doc-history.md)（分页与返回字段）

**未读完对应文件就执行相应操作会导致参数选择错误。**

## 快速决策

- 找文档 / 导入导出走 [`lark-drive`](../lark-drive/README.md)；只读 / 摘要用 `docs +fetch` 默认 `simple`；只需要 block 直达链接或按范围精读时，用 `docs +fetch --detail with-ids` 局部读取
- block 直达链接格式：`文档基础 URL#block_id`；没有 block_id 时局部 fetch `with-ids`
- 用户想查看文档的历史版本列表（`revision_id` / `edit_time` / 版本名）→ 用 `docs +history-list`，先读 [`lark-doc-history.md`](references/lark-doc-history.md)
- 拿到 spreadsheet URL/token 后 → 切到 `lark-sheets` 做对象内部操作
- 文档内容中出现嵌入的 `<sheet>` / `<bitable>` / `<cite file-type="sheets|bitable">` 标签时 → **必须主动提取 token 并切到对应域下钻读取内部数据**，不能只呈现标签本身：`<sheet>` 走 `lark-sheets`，`<bitable>`（多维表格 / Base）走 `lark-base`

| 标签 / 属性 | 提取字段 | 切到技能 |
|-|-|-|
| `<sheet token="..." sheet-id="...">` | `token` -> spreadsheet_token, `sheet-id` | [`lark-sheets`](../lark-sheets/README.md) |
| `<bitable token="..." table-id="...">` | `token` -> base_token, `table-id` | [`lark-base`](../lark-base/README.md) |
| `<cite type="doc" file-type="sheets" token="..." sheet-id="...">` | 同 `<sheet>` | [`lark-sheets`](../lark-sheets/README.md) |
| `<cite type="doc" file-type="bitable" token="..." table-id="...">` | 同 `<bitable>` | [`lark-base`](../lark-base/README.md) |
| `<synced_reference src-token="..." src-block-id="...">` | `src-token` -> doc_token, `src-block-id` -> block_id | 用 `docs +fetch` 读取 src-token 文档，定位 block |

## Shortcuts（推荐优先使用）

Shortcut 是对常用操作的高级封装（`lark-cli docs +<verb> [flags]`）。有 Shortcut 的操作优先使用。

| Shortcut | 说明 |
|----------|------|
| [`+fetch`](references/lark-doc-fetch.md) | Fetch Lark document content (XML / Markdown / im-markdown; `im-markdown` only after fetch for `lark-im`) |
| `+search` | 按关键词搜云文档（默认匹配标题与正文）；见下方「`+search`」节 |
| [`+history-list`](references/lark-doc-history.md) | List document history versions (`revision_id` / `edit_time` / version name) |

## `+search` —— 按关键词搜云文档

```bash
lark-cli docs +search --query "<关键词>" --as user
lark-cli docs +search --query "<关键词>" --page-size 20 --as user
```

- `--query` 是搜索关键词
- `--page-size` 默认 15、最大 20；配 `--page-token` 翻页
- `--filter` 接 JSON 对象做条件过滤
- 与 [lark-drive](../lark-drive/README.md) 的 `+search` 共用同一后端搜索接口；要按文件类型 /
  归属 / 时间窗过滤时用 drive 那个，它的过滤器更全
