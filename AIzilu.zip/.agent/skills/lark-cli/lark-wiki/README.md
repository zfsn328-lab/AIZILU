# wiki (v2)

## 身份说明

知识空间和节点是用户的个人资源，本 skill 的所有命令统一显式带 `--as user`。`--as` 的默认值是
`auto`，不显式指定时可能不按用户身份解析，导致列出的是应用可见的空间而非用户自己的；所以下面
的每条命令与示例都带 `--as user`（`my_library` 个人文档库更是只在 `--as user` 下才有效）。

## 快速决策

- 用户要**按特定主题 / 关键词 / 内容线索查找资料并收集到知识库节点或新建知识库节点下**：先用 Drive 全量搜索召回，再按 Wiki 目标解析、确认和移动；不要只用 Wiki 节点列表做局部遍历。
- 用户要**整理 / 盘点 / 归类 / 重构知识库、个人文档库、文档库目录或 Wiki 节点结构**，或要生成整理方案、目标目录树、移动计划时，不要只使用 Wiki 节点 API；应先完成 Drive / Wiki / 个人文档库的统一入口解析、资源盘点、分类计划、写前确认和结果验证。
- 用户给的是知识库 URL（`.../wiki/<token>`）且要查节点详情：用 `lark-cli wiki +node-get --node-token '<url>' --as user --format json` 解析出 `node_token` / `obj_token` / `space_id`。**获取或解析 Wiki 节点统一优先用 `+node-get`**，包括只为拿到 `space_id`、`node_token`、`obj_token`、`obj_type` 的中间步骤——从返回的 `data.space_id` 读空间 ID。只有当任务确实需要 `+node-get` 未输出的原始响应字段时，才回退到 `wiki spaces get_node`（读 `data.node.space_id`），且回退前先跑 `lark-cli schema wiki.spaces.get_node`。节点解析与后续操作必须使用同一身份。
- 截断的 wiki node token 会被直接拒绝：不要把肉眼截短、复制不全的 token 拼进 `--node-token` 试探，先要回完整 URL 或 token。
- 用户要列出 Wiki 节点：先用 `lark-cli wiki +space-list --as user` 拿数字 `space_id`，再用 `lark-cli wiki +node-list --space-id <space_id> --as user`。不要把 wiki URL、node token、doc token、名称直接当 `--space-id`。钻子节点时 `--parent-node-token` 必须是 wiki node token；如果用户给的是 docx/sheet/base URL，先用 `lark-cli wiki +node-get --node-token <url> --as user` 解析出 `node_token`。
- `wiki +node-list` 命中 `invalid_parameters`、`not_found`、`permission_denied` 时，不要重复调用同一参数；按 hint 修 `space_id` / `parent_node_token` / 权限。只有 `rate_limit` 才做退避重试。
- 用户要**查看 / 列出空间成员**：先拿到数字 `space_id`（见上，用 `+space-list` 或 `+node-get` 解析），再调用 `wiki members list`（先 `lark-cli schema wiki.members.list` 查参数结构，再 `lark-cli wiki members list ... --as user`）；多成员场景按返回的 `page_token` 翻页。这是只读查询，不涉及成员的增删。

## Shortcuts（推荐优先使用）

Shortcut 是对常用只读查询的高级封装（`lark-cli wiki +<verb> [flags]`）。有 Shortcut 的操作优先使用。

| Shortcut | 说明 |
|----------|------|
| [`+space-list`](references/lark-wiki-space-list.md) | List all wiki spaces accessible to the caller |
| [`+node-list`](references/lark-wiki-node-list.md) | List wiki nodes in a space or under a parent node (supports pagination) |
| [`+node-get`](references/lark-wiki-node-get.md) | Get a wiki node's details by node_token / obj_token / Lark URL |

## API Resources

```bash
lark-cli schema wiki.<resource>.<method>   # 调用原生 API 前必须先查看 --data / --params 参数结构，不要猜测字段格式
lark-cli wiki <resource> <method> [flags]  # 调用 API
```

沙箱里 wiki 域**仅以下只读 API 可用**，不要臆造其它 service/resource/method 组合：

### spaces

- `get` — 获取知识空间信息
- `get_node` — 获取知识空间节点信息
- `list` — 获取知识空间列表

### members

- `list` — 获取知识空间成员列表

### nodes

- `list` — 获取知识空间子节点列表
