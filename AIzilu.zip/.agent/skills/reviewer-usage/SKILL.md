---
name: reviewer-usage
description: "Reviewer SubAgent dispatch & post-return protocol — required reading BEFORE invoking Reviewer. Covers when you MUST escalate to Reviewer after repeated self-fix failures, how many Reviewers to dispatch, how to split scopes, what the prompt must contain, and how to act on the per-issue policy tags Reviewer returns. 触发词：派 Reviewer、code review、审查、排查、review and fix、反复失败、修不好、repeated-fix"
available-agents:
  - Code
---

# Reviewer Usage Guide

This skill is the operational manual for dispatching the Reviewer SubAgent and handling its returned report. Reviewer's own `description` only states what Reviewer is for; everything about *how* to use it lives here. **Load this skill before every Reviewer dispatch.**

## When NOT to dispatch Reviewer

- Pure code-location questions ("where is X implemented", "which file handles Y") → use Explore.
- Missing-feature requests ("help me implement X", "X is not implemented yet", 帮我实现 / 还没实现) → handle as regular implementation.

## When you MUST escalate (repeated-fix)

Inline self-fixing has a hard ceiling. The moment ANY of the following is true, **STOP self-fixing and dispatch a Reviewer via `task` instead** — do not attempt a 3rd inline patch of the same problem:

- **同一问题失败 ≥2 轮**: you have already attempted to fix the *same* symptom twice (edit → check → still broken → edit again → still broken) and it persists. The 3rd attempt MUST be a Reviewer dispatch, not another inline guess. Two failed self-fixes is direct evidence your hypothesis is wrong — an independent Reviewer with no anchoring bias is more likely to find the true root cause than a 3rd same-direction patch.
- **用户二次否定**: the user has rejected your fix twice ("还是不对" / "没生效" / "还是这个问题" on the same issue). The second rejection is a mandatory escalation trigger — do not keep iterating inline.

Why this is a hard rule, not a suggestion: thrash (repeatedly editing the same code in the same wrong direction) burns tokens and time while convergence probability stays near zero. Escalating to a Reviewer breaks the loop with fresh, unbiased root-cause analysis. When you escalate, follow the normal dispatch protocol below (still pass `<user-original-message>` verbatim; still pass only `scope` + `dimensions`).

## Review dimensions

Performance, correctness, security, maintainability. Default to **performance + correctness**; include security only if explicitly requested or clearly relevant. User-specified dimensions override the default.

## Dispatch count — trade-offs

More is NOT always better:

- **Single Reviewer overloaded** → on a large project the attention budget gets diluted and critical bugs are missed.
- **Too many Reviewers** → cross-scope gaps (issues spanning multiple Reviewers' scopes go unreported), and the same files get re-read by multiple Reviewers (token + latency doubled).

### Heuristics (not hard rules — judge by the actual situation)

- Use `glob` to roughly estimate file count before dispatching.
- Small / single-module change (< 50 files): **1 Reviewer**.
- Mid-size full project (50–150 files): **2 Reviewers**, split by scope.
- Large full project (> 150 files): **3–4 Reviewers**, split by scope.
- User explicitly limits the scope or asks for a single dimension on a small change: **1 Reviewer** suffices.

## Hard constraints when splitting

- **Mutually exclusive scopes**: a typical project splits into `server/` (incl. `server/database/`), `client/`, and `shared/`; each scope is owned by exactly ONE Reviewer. Two Reviewers MUST NOT review the same directory (duplicated Read is the most common form of waste).
- **Each Reviewer covers all requested dimensions within its own scope** (default: performance + correctness). Do NOT make a single Reviewer the sole owner of "shared / cross-boundary consistency" — that locks its attention onto type contracts and lets performance bugs inside its scope slip through. Cross-boundary consistency is a shared check between two adjacent Reviewers (e.g. the server Reviewer audits "do shared types match what the server actually returns", the client Reviewer audits "do shared interfaces match what the frontend actually calls").
- **Change-type reviews (not full-project audits)**: a Reviewer MUST read every scope the change actually touches. If a commit modifies `server/`, you MUST dispatch a Reviewer for `server/` — you cannot get away with only a `client/` Reviewer.
- **Multiple Reviewers MUST be dispatched in parallel** (multiple tool calls in a single message). Never serially.
- **Each Reviewer's prompt** must spell out `scope = <specific directories or file list>` and `dimensions = <performance/correctness/...>`, and explicitly say "do not read code outside this scope". Do not broadcast the full task to every Reviewer.

## Other rules for the dispatch

- **Wait synchronously** for all Reviewer reports before fixing. No background dispatch.
- **Do not pre-read code**; pass scope only (git range, directory paths, or file list). Each Reviewer discovers and reads within its scope.
- **REQUIRED — Reviewer prompt MUST start with** `<user-original-message>{用户原话}</user-original-message>`. Reviewer uses this verbatim text to classify fix-intent vs review-only mode for its mandatory ACTION block; without it Reviewer guesses wrong and the recommended AskUser option is wrong. ❌ FORBIDDEN: paraphrase, summarize, translate, or omit the user's message — pass it character-for-character.

## Caller anti-pattern checklist (read before dispatching Reviewer)

### ❌ Anti-pattern 1: scope is narrower than where the true root cause may live

The caller does not know where the true root cause is — a "suspicious directory" guessed from surface clues (a filename in the stack trace, a module the user named) often excludes the directory the true root cause actually lives in. Phase 1 Discovery is designed for Reviewer to narrow down via glob/grep on its own; when the caller does that work prematurely, it loses the true root cause.

**Hard rule**: for bug-investigation tasks, `scope` MUST stay at a directory-tree top-level boundary (`client/` / `server/` / `shared/`). **Drilling down into a subdirectory or a single file is forbidden.**

The only exception is a small refactor PR static review where the commit touches a single subdirectory only AND the total file count exceeds 150 requiring 3–4 Reviewers running in parallel (per the Heuristics earlier in this skill).

### ❌ Anti-pattern 2: adding "key observations / focus on / suspected files" sections outside `<user-original-message>`

If the caller forms its own shallow hypothesis before dispatching Reviewer and injects that as a "clue" into Reviewer's prompt, it violates the core principle of reviewer-usage: Reviewer is an independent sub-agent whose value comes from judging without caller bias. Injecting observations anchors Reviewer to the caller's (usually wrong) direction → the true root cause is never found.

**Hard rule**: outside the `<user-original-message>` block, **only `scope = ...` and `dimensions = ...` are allowed**. Any "focus on / key files / suspected paths / investigation direction / key observations" sections must be removed.

Exception: if the user's own message already contains these phrasings (e.g. the user said "please focus on X"), keep them inside `<user-original-message>` verbatim — that is the user's real intent, not caller pollution.


## Protocol after Reviewer returns

Reviewer pre-tags each issue with a `policy` field (`auto-fix` or `AskUser`) and prints an ACTION header. Code agent acts on the tags directly — it does NOT re-classify.

### Step 1 — Read the ACTION header

It tells you: (a) how many issues are tagged `auto-fix`, (b) how many are tagged `AskUser`, (c) the exact `options` and `recommended` label for the `ask_user_question` call.

### Step 2 — Fix every `policy: auto-fix` issue immediately

No AskUser, no confirmation, no asking the user.

### Step 3 — Handle `policy: AskUser` issues (only if at least one exists)

- **STEP 3a (echo)**: emit a short user-facing summary listing the `policy: AskUser` issues, grouped by 🔴 Critical / 🟠 Bug / 🟡 Suggestion, with file:line. ≤25 lines (collapse the rest as `... (其余 N 项见下方表单)`). The user cannot see Reviewer's report directly — without this echo they cannot decide.
- **STEP 3b (call ask_user_question)**: in the same turn, immediately call `ask_user_question` — `header`: `Review 确认`; `description`: paste the same list as STEP 3a; ONE Radio `question`: "Reviewer 另发现以下超出本次任务范围的问题，是否一并处理？"; use the exact `options` and `recommended` label that the ACTION header specified.
- No FINAL reply between 3a and 3b.

### Step 4 — Act on the user's choice

Strip any trailing `（推荐）` from the returned label before matching:

- `修复严重问题` → fix the 🔴+🟠 subset of `policy: AskUser` issues, then report.
- `修复所有问题` → fix every `policy: AskUser` issue, then report.
- `修复建议项` → fix every `policy: AskUser` 🟡 issue, then report.
- `不修复` → report with: `policy: auto-fix` fixes done + `policy: AskUser` issues left untouched (preserve original Reviewer `file:line — desc` entries verbatim).

## Recursion and edge cases

- If fixes trigger a new Reviewer dispatch, recurse through the same protocol, but cap AskUser follow-ups **per original Reviewer batch** at 2. On the 3rd would-be AskUser, fold remaining `policy: AskUser` items into the final report instead. A brand-new Reviewer dispatch resets the counter.
- `policy: auto-fix` fix failure does NOT skip AskUser — mark failed items as `未处理` inside the AskUser description so the user sees the real state.
- `Verdict: Looks good` (zero issues) → no AskUser; report directly.
- Reviewer report missing `policy` tags or unparseable into 🔴/🟠/🟡 → treat all parseable issues as `policy: AskUser` and route through Step 3 so the user decides.
- Multiple Reviewers dispatched in parallel: each report runs this protocol independently (no cross-report aggregation); the recursion cap applies per batch.
