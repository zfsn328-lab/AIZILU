---
name: correctness-review
description: "Correctness and maintainability audit checklist for the Reviewer agent. Covers exception handling, concurrency, resource leaks, error handling, type safety, fault tolerance, frontend-backend contract. 触发词：正确性审查, 代码质量, correctness review"
hook: SessionStart
available-agents:
  - Reviewer
---

# Correctness Review Checklist

## S0 · Drizzle ORM Custom Types (CRITICAL — frequently missed)

**Must check in every review that uses Drizzle ORM with custom column types:**

- `customTimestamptz` / any custom type with `fromDriver`: the `fromDriver(value)` function **must handle null/undefined input**. `new Date(null)` silently returns `1970-01-01T00:00:00.000Z` (epoch) instead of null — this corrupts timestamp display and comparisons. Fix: add `if (value == null) return null;` at the top of `fromDriver`.
- `userProfile` / `fileAttachment` custom types: same null-guard requirement in `fromDriver`.
- Check `schema.ts` for ALL `customType<...>({ fromDriver(value) { ... } })` definitions and verify null handling.

## S1 · Exception Handling Completeness

**Core issue**: Unhandled Promise rejections, empty catch blocks, async errors silently swallowed — causes process crash in production.

```typescript
// BAD: forEach does not await async, exceptions cannot propagate
req.body.items.forEach(async (item) => {
  await db.inventory.decrement(item.id, item.qty);
});

// GOOD: for...of correctly propagates exceptions
for (const item of req.body.items) {
  await db.inventory.decrement(item.id, item.qty);
}
```

**Checklist**:
- Async functions must have try/catch or asyncHandler wrapper
- Catch blocks must not be empty — at least log the error
- Promise chains must end with .catch()
- Do not use async/await inside forEach
- Must have `unhandledRejection` / `uncaughtException` handlers as safety net

| Scenario | Severity |
|----------|----------|
| Async handler without try/catch | CRITICAL |
| Promise without .catch() / empty catch | HIGH |
| Catch without logging | MEDIUM |

## S2 · Concurrency Race Conditions

**Core issue**: Module-level mutable variables shared across concurrent requests; read-modify-write (TOCTOU) without lock protection.

```typescript
// BAD: findOne then save — two requests both read stock=1 → oversell
const item = await Item.findOne({ id });
if (item.stock > 0) { item.stock -= 1; await item.save(); }

// GOOD: atomic DB operation
await db.query('UPDATE items SET stock = stock - 1 WHERE id = $1 AND stock > 0', [id]);
```

**Checklist**:
- No module-level let/var read-written by request handlers
- Read-modify-write operations must have transaction or lock protection
- No TOCTOU patterns

| Scenario | Severity |
|----------|----------|
| Module-level variable shared across concurrent requests | CRITICAL |
| Read-modify-write without lock | HIGH |

## S3 · Resource Leaks

**Core issue**: DB connections not released in finally, setInterval without cleanup, Streams not closed.

```typescript
// BAD: connection never released if query throws
const conn = await pool.getConnection();
const users = await conn.query('SELECT * FROM users');
conn.release();

// GOOD: finally ensures release
const conn = await pool.getConnection();
try { return await conn.query('SELECT * FROM users'); } finally { conn.release(); }
```

**Checklist**:
- Manually acquired DB connections must be released in finally
- setInterval must have corresponding clearInterval
- EventListeners must be removed at lifecycle end
- File handles and Streams must be properly closed

| Scenario | Severity |
|----------|----------|
| DB connection not released in finally | CRITICAL |
| Stream not closed | HIGH |
| setInterval without cleanup | MEDIUM |

## S5 · Fault Tolerance & Degradation

**Core issue**: External calls without timeout causing connection exhaustion; non-critical dependency failure bringing down the main flow.

```typescript
// BAD: no timeout — hangs forever if downstream is stuck
await axios.get(`https://user-service/users/${userId}`);
// GOOD: timeout + degradation
await axios.get(url, { timeout: 3000 });
```

**Checklist**:
- All external HTTP calls must have timeout configured
- Critical external calls should have retry with exponential backoff
- Downstream service unavailability must have a degradation plan

| Scenario | Severity |
|----------|----------|
| External call without timeout / no degradation causing single point of failure | HIGH |
| No retry mechanism | MEDIUM |

## S6 · Infinite Loops & Recursion

**Core issue**: while/for loops missing termination conditions, recursion without base case, retries without limit.

```typescript
// BAD: retry without limit
while (true) { try { return await fetch(url); } catch { await sleep(1000); } }
// GOOD: with limit + backoff
for (let i = 0; i < 3; i++) {
  try { return await fetch(url); } catch (e) { if (i === 2) throw e; await sleep(1000 * 2**i); }
}
```

**Checklist**:
- while(true) / for(;;) must have reachable break and the condition variable must be modified inside the loop body
- Recursive functions must have reachable base case + depth guard
- Retries must have maxRetries limit
- Event-driven implicit loops must have counter protection

| Scenario | Severity |
|----------|----------|
| while(true) without reachable break / recursion without base case | CRITICAL |
| Retries without limit / implicit event loops | HIGH |

## S7 · React Render Infinite Loops

**Trigger signal** — stack trace contains any of the following → must run S7:

- `Maximum update depth exceeded`
- `setRef` calling `dispatchSetState` / `dispatchSetStateInternal`
- Stack contains `Array.map` + `setRef` (`composeRefs` / `Slot` chain)
- `setState` called inside `componentWillUpdate` / `componentDidUpdate`
- `useEffect`-triggered re-render loop

**Required reading** — before drafting any S7 finding, locate and read the steering skill at `**/nestjs-react-fullstack/react-hook-best-practices/SKILL.md` via `Glob`. That file's `Critical Anti-Patterns` table plus the "死循环根因模式" callout is the single source of truth for both the catalogue of root causes and the "trace upstream to the ref provider" diagnostic rule. Reviewer's S7 conclusions must map back to one of those documented anti-patterns; do not invent diagnoses outside that catalogue.

For any other React-flavored correctness finding (hook deps, derived state, redundant `useEffect`, async cleanup, safe destructuring), read the same skill first — it owns React correctness rules in this codebase.

**Phase 1 globs (mandatory)** — in addition to the scope's top-level directories, glob `**/use-*.{ts,tsx}` + `**/hooks/**` + `**/*-provider.{ts,tsx}` so the Phase 2 read list covers the ref-provider side. Without those reads Reviewer cannot land an S7 finding.

## Self-Built Data Authorization Correctness (single-domain decidable)

**Core issue**: The platform's RBAC/PBAC is role-based and only fits feature-level authorization; apps that need per-user data authorization usually build their own (custom permission tables + application-layer allowlist filtering). Two defect classes surface directly as user-visible wrong behavior (blank screen / data over-exposure), so they are correctness issues. **Each item is decidable from a single Reviewer's own scope — no cross-Reviewer join needed.**

**⚠️ Severity is mandatory**: every item below, once matched, is 🔴 CRITICAL or 🟠 BUG — **never downgrade to 🟡 SUGGESTION**. They are user-visible functional/data defects (no-permission blank screen = feature unusable; data over-exposure = security incident), not style preferences. Phrasings like "permission failure silently swallowed / no feedback" or "no-permission notice" MUST be reported as 🔴/🟠, not SUGGESTION.

- **Missing permission-denied fallback page** (client scope; decidable from app.tsx / route guard / page component alone): the route guard's "no permission" branch only does `<Navigate to={...} replace />` (or returns `null`), with no 403 / no-permission UI anywhere in the app → users without permission get a silent redirect / blank screen, **🔴 CRITICAL**. A data page that renders an empty table as "no data" when the permission set is empty (`allowedXxx.length === 0`), or silently catches a permission-fetch failure with no feedback and no explicit no-permission notice → **🟠 BUG**. Judge from the component's own code only; do not depend on the service-layer empty-set behavior.
- **Application layer is the only authorization point** (server scope; decidable from schema.ts + service alone): `schema.ts` `pgPolicy` RLS has degenerated to permissive-all → row-level security is effectively void and the app-layer `.includes()` filter becomes the only control, **🔴 CRITICAL**. **"Permissive-all" has two forms — check both, both are defects**: (1) `using` written as always-true (e.g. `sql\`true\``); (2) **`pgPolicy(...)` omitting the `using`/`withCheck` clause entirely** — in drizzle/PG a policy with no `using` defaults to allowing all rows; this is the most subtle form: a `pgPolicy("...", { as: "permissive", for: "select"|"all", to: [...] })` with no `using` is exactly it. Check every `pgPolicy`: whenever `for` is `select`/`all` and `using` is missing or always-true → report this defect. Also: any data read/write path (including OpenAPI / export / cron jobs) that bypasses the app-layer filter and returns rows via a direct `db.select` → data over-exposure.
- **Self-built authorization fail-open** (server scope): `getUserPermissions` etc. returning full permissions (admin) instead of denying when `userId` is missing / errors → privilege escalation, **🔴 CRITICAL**.

> Trigger: a `*_permission` table / `permission_type` column in `schema.ts`, or an `allowedXxx.includes(...)` filter in the service layer, indicates a self-built data-authorization app — this section is mandatory. Skip if none of these signals are present.

| Scenario | Severity |
|----------|----------|
| Route guard's no-permission branch only silently redirects, no 403 / no-permission page | 🔴 CRITICAL |
| Empty permission set renders empty table as "no data" / permission failure silently swallowed / no explicit no-permission notice | 🟠 BUG |
| RLS/pgPolicy permissive-all, app-layer filter is the only authorization point with bypass paths | 🔴 CRITICAL |
| Self-built authorization fail-opens to full permissions when userId is missing | 🔴 CRITICAL |

## Business Logic Correctness

**Core issue**: Aggregation formulas include wrong population (e.g. average includes abstentions), incremental score accumulation drifts from source of truth, boundary conditions produce wrong results.

**Checklist**:
- Aggregation queries (AVG, SUM, COUNT): verify the WHERE clause excludes records that should not participate (e.g. abstained votes excluded from average rating)
- Scores/totals stored as incremental deltas: verify they are periodically reconciled against the source of truth, or use source-of-truth recalculation instead of delta accumulation
- Division operations: check for divide-by-zero when the denominator can be 0
- Sorting/ranking: verify the sort field matches what the user sees (e.g. UI shows "投票分" but backend sorts by "AI分")

| Scenario | Severity |
|----------|----------|
| Aggregation includes wrong population → wrong business metric | HIGH |
| Incremental accumulation drifts from source of truth over time | HIGH |
| Sort field mismatch between UI display and backend query | MEDIUM |
| Divide-by-zero unhandled | MEDIUM |

## Error Handling

| Check | Focus |
|-------|-------|
| Error path coverage | All possible failure branches handled |
| Swallowed errors | Empty catch, catch-and-log-only, default values masking problems |
| Error propagation | Errors that should bubble up being intercepted |
| Error messages | User-facing error messages clear and actionable |

## TypeScript Type Safety

| Check | Focus |
|-------|-------|
| `any` abuse | Using `any` to bypass type checking — use concrete types or `unknown` |
| Promise handling | Missing `await`, unhandled rejections |
| Closure traps | Closures in loops capturing mutating variables |

## Frontend-Backend Contract

- Same endpoint returning different structures with different params — format must be consistent
- Frontend missing defensive handling of API responses (response?.data?.items || [])
- **Custom column types (e.g. customTimestamptz) must handle null input in fromDriver — `new Date(null)` returns epoch (1970-01-01), not null**
- **Shared type definitions (shared/api.interface.ts) must match actual API response types — check Date vs string, number vs string mismatches**

## On-demand References

For observability (Q2), testability (Q3), dependency security (Q4), and separation of concerns (A1) checks, see `references/examples.md` (Q3, A1 sections).
