# Shared Report Template — review / fix 统一报告模板

> 本文件定义 `stability-review-skill` 与 `stability-fix-skill` 共用的报告骨架。
> 目标：让 review 阶段和 fix 阶段的输出结构一致，便于人读、便于后续工具消费，也便于多轮迭代更新。

---

## 设计原则

统一报告模板应满足：

1. **一个报告可持续更新**：review 后可追加 fix 结果
2. **字段稳定**：同一 finding 在不同阶段保持同一 ID
3. **状态清晰**：未修复、已修复、人工介入可直接区分
4. **边界明确**：报告要写清本轮做了什么、没做什么

---

## 推荐顶层结构

```markdown
# 📋 Stability Report

## 基本信息
## 本轮执行范围
## 业务概况
## Findings Summary
## Detailed Findings
## Fix Records
## Remaining Risks
## Next Actions
```

说明：
- review-only 时，`Fix Records` 可为空或写“本轮未执行修复”
- fix-only 时，`业务概况` 可复用上一轮内容，不必重新展开

---

## Section 1：基本信息

```markdown
## 基本信息

| 项目 | 值 |
|------|----|
| Report ID | stability-{YYYYMMDD}-{HHmmss} |
| Repo Path | {repoPath} |
| Stage | {review / fix / review+fix} |
| Generated At | {ISO 8601} |
| Skill | {stability-review-skill / stability-fix-skill} |
| Source Report | {上游报告 ID，没有则写 N/A} |
```
```

---

## Section 2：本轮执行范围

```markdown
## 本轮执行范围

- **已处理内容**:
  - {本轮实际审查或修复的目录 / 模块 / finding 集合}
- **未处理内容**:
  - {未覆盖区域，若无则写 N/A}
- **执行边界说明**:
  - {例如：review-only / 仅修复 AUTO findings / 未运行全量测试}
```
```

---

## Section 3：业务概况

review 阶段建议完整输出；fix 阶段可简写或引用上一轮。

```markdown
## 业务概况

- **业务类型**: {电商 / 支付 / 抽奖 / CMS / 未知}
- **技术栈**: {Node.js, TypeScript, Express, Prisma ...}
- **关键特性**: {支付, 库存, 用户认证 ...}
- **业务检查点**:
  - [ ] {BIZ-...}
```
```

---

## Section 4：Findings Summary

```markdown
## Findings Summary

| 指标 | 数量 |
|------|------|
| Total Findings | {N} |
| ✅ Resolved | {N} |
| ❌ Unresolved | {N} |
| ⚠️ Manual | {N} |

### By Severity

| Severity | Count |
|----------|-------|
| CRITICAL | {N} |
| HIGH | {N} |
| MEDIUM | {N} |
| LOW | {N} |
| INFO | {N} |
```
```

---

## Section 5：Detailed Findings

每个 finding 使用统一 block，字段与 `fix-handoff.md` 保持一致。

```markdown
## Detailed Findings

### ❌ [S1-001] — async forEach 导致异常无法冒泡
- **Rule**: S1
- **Severity**: HIGH
- **File**: `src/order.ts:42`
- **Status**: ❌ 未解决（未尝试修复）
- **Confidence**: HIGH
- **Fixability**: AUTO

**Summary**:
...

**Evidence**:
```typescript
...
```

**FixHint**:
...
```
```

要求：
- review skill 输出完整 finding block
- fix skill 更新 `Status`，必要时追加 `FixResult`
- 同一 ID 不要重复新建多个 finding

---

## Section 6：Fix Records

```markdown
## Fix Records

| Finding ID | Fix Round | Touched Files | Validation | Result |
|-----------|-----------|---------------|------------|--------|
| S1-001 | 1/2 | `src/order.ts` | 静态复查 + 单测 | ✅ 已解决 |
```
```

规则：
- review-only 时，写：`本轮未执行修复`
- fix skill 必须填写实际尝试过的记录
- 未尝试修复的问题不要伪造修复记录

---

## Section 7：Remaining Risks

```markdown
## Remaining Risks

- {仍未解决的 CRITICAL / HIGH}
- {需要人工介入的问题}
- {由于验证不足而保守保留的问题}
```
```

这个 section 很重要，因为它体现“当前仓库仍剩下什么风险”。

---

## Section 8：Next Actions

```markdown
## Next Actions

- {建议的后续动作 1}
- {建议的后续动作 2}
- {是否建议调用 fix skill / 是否建议人工介入 / 是否建议补测试}
```
```

建议：
- review skill 在这里写“是否建议进入 fix 阶段”
- fix skill 在这里写“是否还需要人工继续处理”

---

## 最小兼容要求

即使上下文紧张，也至少保留以下 section：

- `基本信息`
- `本轮执行范围`
- `Findings Summary`
- `Detailed Findings`
- `Next Actions`

---

## 最佳实践

- review skill 和 fix skill 使用同一份 report ID 或 source report ID 串联上下游
- finding ID 不能在修复阶段改名
- fix skill 尽量在原 finding 下追加 `FixResult`，而不是另起一套描述
- 如果本轮没有修复，明确写 `本轮未执行修复`
