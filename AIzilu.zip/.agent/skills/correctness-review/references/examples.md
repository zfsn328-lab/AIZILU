# Correctness Review Examples

> Extracted from stability-check-examples.md. Covers S1, S2, S3, S5, S6, Q3, A1 rules.

---

## S1 · Exception Handling Completeness

**BAD — Empty catch block**:
```typescript
async function createUser(data) {
  try {
    const user = await db.users.create(data);
    return user;
  } catch (err) {
    // does nothing → caller never gets the error
  }
}
```

**GOOD — Complete error handling chain**:
```typescript
async function createUser(data) {
  try {
    const user = await db.users.create(data);
    return user;
  } catch (err) {
    logger.error('createUser failed', { userId: data.id, error: err });
    throw new AppError('USER_CREATE_FAILED', err);
  }
}
```

**BAD — async inside forEach**:
```typescript
app.post('/order', async (req, res) => {
  req.body.items.forEach(async (item) => {
    await db.inventory.decrement(item.id, item.qty);
  });
  res.json({ ok: true }); // forEach does not await, exceptions cannot bubble
});
```

**GOOD — for...of**:
```typescript
app.post('/order', async (req, res) => {
  try {
    for (const item of req.body.items) {
      await db.inventory.decrement(item.id, item.qty);
    }
    res.json({ ok: true });
  } catch (err) {
    logger.error('order processing failed', err);
    res.status(500).json({ error: 'Order failed' });
  }
});
```

---

## S2 · Concurrency Race Conditions

**BAD — Module-level mutable variable shared across requests**:
```typescript
let requestCount = 0;
app.get('/api/data', (req, res) => {
  requestCount++; // all concurrent requests share this, data race
  res.json(processData(requestCount));
});
```

**GOOD — Request-scoped isolation**:
```typescript
import { AsyncLocalStorage } from 'async_hooks';
const requestContext = new AsyncLocalStorage<{ count: number }>();
app.get('/api/data', (req, res) => {
  requestContext.run({ count: 0 }, () => {
    const ctx = requestContext.getStore()!;
    ctx.count++;
    res.json(processData(ctx.count));
  });
});
```

**BAD — TOCTOU (read then write without lock)**:
```typescript
// Two requests both findOne → both read stock=1 → both write stock=0 → oversell
async function purchaseItem(itemId: string) {
  const item = await Item.findOne({ id: itemId });
  if (item.stock > 0) {
    item.stock -= 1;
    await item.save();
  }
}
```

**GOOD — Atomic operation**:
```typescript
async function purchaseItem(itemId: string) {
  const result = await db.query(
    'UPDATE items SET stock = stock - 1 WHERE id = $1 AND stock > 0 RETURNING *',
    [itemId]
  );
  if (result.rowCount === 0) throw new Error('Out of stock');
}
```

---

## S3 · Resource Leaks

**BAD — setInterval without cleanup**:
```typescript
app.get('/monitor', (req, res) => {
  setInterval(() => checkHealth(), 5000); // created per request, never cleaned → memory leak
  res.json({ status: 'monitoring' });
});
```

**GOOD — Lifecycle management**:
```typescript
const intervals: NodeJS.Timeout[] = [];
function startMonitor() {
  intervals.push(setInterval(() => checkHealth(), 5000));
}
process.on('SIGTERM', () => intervals.forEach(clearInterval));
```

---

## S5 · Fault Tolerance & Degradation

**BAD — Non-critical dependency bringing down the main flow**:
```typescript
app.post('/register', async (req, res) => {
  const user = await User.create(req.body);
  await emailService.sendWelcome(user.email); // fails → entire registration 500
  res.json(user);
});
```

**GOOD — Non-critical operations made async**:
```typescript
app.post('/register', async (req, res) => {
  const user = await User.create(req.body);
  emailQueue.add('welcome', { email: user.email }).catch(err => {
    logger.error('Failed to queue welcome email', { userId: user.id, err });
  });
  res.json(user);
});
```

---

## S6 · Infinite Loops & Recursion

**BAD — while condition variable not modified**:
```typescript
let found = false;
while (!found) {
  const item = queue.peek(); // peek does not consume → found stays false → infinite loop
  if (item.ready) found = true;
}
```

**GOOD — Consume + iteration limit**:
```typescript
const MAX = 1000;
let found = false, i = 0;
while (!found && i < MAX) {
  i++;
  const item = queue.dequeue();
  if (item?.ready) found = true;
}
if (!found) throw new Error('Max iterations reached');
```

**BAD — Recursion without depth protection**:
```typescript
function flatten(arr: any[]): any[] {
  return arr.reduce((acc, val) =>
    Array.isArray(val) ? acc.concat(flatten(val)) : acc.concat(val), []);
}
```

**GOOD — Depth protection**:
```typescript
function flatten(arr: any[], maxDepth = 10): any[] {
  if (maxDepth <= 0) return arr;
  return arr.reduce((acc, val) =>
    Array.isArray(val) ? acc.concat(flatten(val, maxDepth - 1)) : acc.concat(val), []);
}
```

**BAD — Event-driven implicit infinite loop**:
```typescript
emitter.on('error', (err) => { emitter.emit('retry'); });
emitter.on('retry', () => { doSomethingThatMightFail(); }); // failure emits error again → infinite
```

**GOOD — Counter protection**:
```typescript
let retryCount = 0;
emitter.on('error', (err) => {
  if (retryCount++ < 3) emitter.emit('retry');
  else logger.error('Max retries exceeded', err);
});
```

---

## Q3 · Testability

**BAD — Hardcoded external dependency**:
```typescript
export async function chargeUser(userId: string, amount: number) {
  const stripe = new Stripe(process.env.STRIPE_KEY!);
  return stripe.charges.create({ amount, currency: 'usd', source: (await User.findById(userId)).stripeId });
}
```

**GOOD — Dependency injection**:
```typescript
export async function chargeUser(userId: string, amount: number, deps: { stripe: Stripe; userRepo: UserRepository }) {
  const user = await deps.userRepo.findById(userId);
  return deps.stripe.charges.create({ amount, currency: 'usd', source: user.stripeId });
}
```

---

## A1 · Separation of Concerns

**BAD — Route layer writing SQL directly**:
```typescript
app.get('/users/:id', async (req, res) => {
  const result = await db.query(`SELECT u.*, COUNT(o.id) FROM users u LEFT JOIN orders o ON u.id = o.user_id WHERE u.id = $1 GROUP BY u.id`, [req.params.id]);
  res.json(result.rows[0]);
});
```

**GOOD — Layered architecture**:
```typescript
// routes → service → repository
app.get('/users/:id', async (req, res) => { res.json(await userService.getUserWithStats(req.params.id)); });
```
