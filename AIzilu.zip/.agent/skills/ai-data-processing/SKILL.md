---
name: ai-data-processing
description: 当妙搭应用需要对业务表数据进行 AI 数据加工、自动分类打标、摘要生成、结构化字段抽取、优先级判断或历史数据回填时使用。适用于工单、反馈、评论、文档、商品等记录在新增、更新或批量处理后生成或更新业务字段的场景；方案基于妙搭 PG，通过 rds_ai.ai_query 对单行记录执行模型推理，并结合业务字段、加工函数、ai_job 队列、增量/存量入队、异步执行和结果验证完成数据写回。
control-by-feature-ab: true
---

# AI 数据加工

本 skill 用于实现 AI 分类、打标、摘要、结构化抽取、判优先级和字段回填等数据加工效果。底层使用 `rds_ai.ai_query`，适合「单行数据 → 一次模型推理 → 写回本行字段」的业务加工。

⚠️ **`CREATE EXTENSION rds_ai` 必须单独分批提交，成功后再执行后续 SQL（见步骤 2）。**

## 何时使用

✅ **匹配场景**
- 工单、反馈、评论自动分类 / 打标 / 判优先级
- 文档、帖子、商品自动生成摘要 / 关键词
- 从文本中抽取结构化字段，例如城市、金额、投诉原因
- 对已有历史数据做一次性 AI 回填
- 新增或更新业务记录后，持续触发同一套 AI 加工逻辑

❌ **不匹配场景**
- 语义检索、相似召回、向量搜索 → 用 `rds_ai.ai_embed`
- 多轮对话、RAG 问答、工具调用、多步 Agent 流程 → 用 AI 插件或应用代码
- 结构化抽取发生在应用层代码而非库内 SQL 流程 → 用 `ai-text-to-json` 插件（见 plugin-guide）
- 跨多张表复杂推理、跨外部数据源加工 → 用应用代码承载

## 函数用法

默认使用平台模型 `doubao-seed-2.0-lite`（`reasoning_effort = minimal`，小规格，平衡效率与质量），绝大多数数据加工场景不传 `model_name` 直接用默认。

```sql
rds_ai.ai_query(question text)
```

只有用户明确要求模型，或默认模型不适合当前任务时，才传第二个参数：

```sql
rds_ai.ai_query(question text, '{{model_name}}')
```

**需要换模型时，先查当前可用列表**：

```sql
SELECT * FROM rds_ai.list_model();
```

按业务需求选定模型，取其 `model_name` 作为第二个参数。

⚠️ **模型可用性由租户管理后台管控。** `list_model()` 返回的是平台预置清单；管理员下架或停用其中某个模型后，平台自动在其余可用预置模型中选择，业务 SQL 无需改动。因此除非用户明确要求锁定模型，否则不传 `model_name`；锁定的模型被停用时，加工结果可能出现风格波动。预置模型全部不可用时调用直接失败，处置见「关键注意事项」。

## 实现步骤

以下 SQL 使用 `tickets` / `priority` 作为示例。Agent 生成实际方案时，必须替换成用户应用里的真实表名、字段名、主键和 `task_kind`。

### 1. 确认输入和输出

生成 SQL 前先确认：
- 源表和源字段，例如 `tickets.content`
- 源表稳定主键，例如 `tickets.id`
- 结果字段和类型，例如 `priority text`
- 输出格式，例如只允许 `P0 / P1 / P2 / P3`
- `task_kind` 名称，例如 `label_ticket_priority`，同一 workspace 内必须唯一
- 只处理存量，还是新数据也要持续处理

如果用户没说明输出格式，默认用短文本枚举，并在 prompt 里写明「只返回结果值，不要解释」。

### 2. 启用必要插件

`ai_query` 是 `rds_ai` 插件中的方法。**⚠️ 这一句必须单独提交执行，与后续 SQL 分批：**

```sql
CREATE EXTENSION IF NOT EXISTS rds_ai CASCADE;
```

`rds_ai` 启用过程包含一次性的初始化工作，**该语句返回成功后** `rds_ai.*` 函数才可用。一旦与后续依赖 `rds_ai.*` 的 SQL（小样本验证 prompt、加工函数等）合并到同一批次提交，后续语句可能在初始化尚未就绪时执行而失败。

**等本步骤返回成功后，再继续执行后面的步骤。** `CASCADE` 会自动带 `pgcrypto` 等基础依赖，不需要单独再写 `CREATE EXTENSION pgcrypto`。

不要在 skill 里配置 API key、模型网关、额度、调用日志等平台能力；这些由平台预置。

### 3. 小样本验证 prompt

先用少量记录预览结果，不要直接批量写表。

```sql
SELECT
  id,
  content,
  rds_ai.ai_query(
    '判断以下工单优先级，只返回 P0 / P1 / P2 / P3 之一，不要解释：' || content
  ) AS priority_preview
FROM tickets
WHERE content IS NOT NULL
ORDER BY id DESC
LIMIT 5;
```

### 4. 新增业务结果字段

```sql
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS priority text;

COMMENT ON COLUMN tickets.priority IS
  'AI 生成：根据 content 判断工单优先级，结果为 P0 / P1 / P2 / P3';
```

### 5. 封装业务加工函数

函数只处理一条业务记录：取源字段、调用 `rds_ai.ai_query`、写回结果字段。

```sql
CREATE OR REPLACE FUNCTION fn_ai_label_ticket_priority(p_id bigint)
RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  v_content text;
  v_result  text;
BEGIN
  SELECT content INTO v_content
  FROM tickets
  WHERE id = p_id;

  IF v_content IS NULL OR length(trim(v_content)) = 0 THEN
    UPDATE tickets SET priority = NULL WHERE id = p_id;
    RETURN;
  END IF;

  v_result := trim(rds_ai.ai_query(
    '判断以下工单优先级，只返回 P0 / P1 / P2 / P3 之一，不要解释：' || v_content
  ));

  IF v_result NOT IN ('P0', 'P1', 'P2', 'P3') THEN
    RAISE EXCEPTION 'invalid priority result: %', v_result;
  END IF;

  UPDATE tickets
  SET priority = v_result
  WHERE id = p_id;
END;
$$;
```

枚举类结果必须在写回前校验，不符合预期就 `RAISE EXCEPTION`，交给队列重试 / 标记失败。

结构化抽取写入 `jsonb` 时，prompt 必须要求只返回 JSON：

```sql
v_result := rds_ai.ai_query(
  '从文本中抽取投诉原因和城市，只返回 JSON，格式：{"reason":"","city":""}。文本：' || v_content
);

UPDATE tickets
SET ai_extract = v_result::jsonb
WHERE id = p_id;
```

### 6. 创建 AI 任务队列和执行函数

`rds_ai.ai_query` 单次调用可能较慢，新增 / 更新触发时不要直接在业务写入事务里调用模型。Agent 需要为当前 workspace 创建 `ai_job` 队列表和 `ai_run_pending_jobs()` 执行函数；它们不是平台预置对象。如果这些对象已存在，先检查结构并复用，新增任务时只追加新的 `task_kind` 分支，不要覆盖已有任务逻辑。

如果不确定对象是否已存在，先检查：

```sql
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'ai_job'
ORDER BY ordinal_position;

SELECT to_regprocedure('ai_run_pending_jobs(integer)') AS existing_function;
-- 如果 existing_function 非空，再查看函数定义：
-- SELECT pg_get_functiondef('ai_run_pending_jobs(integer)'::regprocedure);
```

新建时使用以下模板：

```sql
CREATE TABLE IF NOT EXISTS ai_job (
  id            bigserial PRIMARY KEY,
  ref_table     text        NOT NULL,
  ref_id        text        NOT NULL,
  task_kind     text        NOT NULL,
  payload       jsonb       NOT NULL DEFAULT '{}',
  status        text        NOT NULL DEFAULT 'pending',
  retry_count   int         NOT NULL DEFAULT 0,
  max_retry     int         NOT NULL DEFAULT 5,
  next_retry_at timestamptz NOT NULL DEFAULT now(),
  error_message text,
  started_at    timestamptz,
  finished_at   timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT chk_ai_job_status CHECK (status IN ('pending', 'running', 'success', 'failed'))
);

CREATE UNIQUE INDEX IF NOT EXISTS uniq_ai_job_active
ON ai_job (ref_table, ref_id, task_kind)
WHERE status IN ('pending', 'running');

CREATE INDEX IF NOT EXISTS idx_ai_job_runnable
ON ai_job (next_retry_at, id)
WHERE status = 'pending';
```

执行函数按 `task_kind` 分发到对应业务函数。后续新增其他 AI 加工任务时，必须保留已有 `CASE` 分支，只追加新分支。

```sql
CREATE OR REPLACE FUNCTION ai_run_pending_jobs(p_batch_size int DEFAULT 5)
RETURNS TABLE(processed int, succeeded int, failed int)
LANGUAGE plpgsql
AS $$
DECLARE
  r_job       record;
  v_processed int := 0;
  v_succeeded int := 0;
  v_failed    int := 0;
BEGIN
  FOR r_job IN
    SELECT id, ref_table, ref_id, task_kind, retry_count, max_retry
    FROM ai_job
    WHERE status = 'pending'
      AND next_retry_at <= now()
    ORDER BY id
    LIMIT p_batch_size
    FOR UPDATE SKIP LOCKED
  LOOP
    v_processed := v_processed + 1;

    UPDATE ai_job
    SET status = 'running', started_at = now(), error_message = NULL
    WHERE id = r_job.id;

    BEGIN
      CASE r_job.task_kind
        WHEN 'label_ticket_priority' THEN
          PERFORM fn_ai_label_ticket_priority(r_job.ref_id::bigint);
        ELSE
          RAISE EXCEPTION 'unknown ai_job task_kind: %', r_job.task_kind;
      END CASE;

      UPDATE ai_job
      SET status = 'success', finished_at = now()
      WHERE id = r_job.id;

      v_succeeded := v_succeeded + 1;
    EXCEPTION WHEN OTHERS THEN
      UPDATE ai_job
      SET status = CASE
            WHEN r_job.retry_count + 1 >= r_job.max_retry THEN 'failed'
            ELSE 'pending'
          END,
          retry_count = r_job.retry_count + 1,
          error_message = SQLERRM,
          next_retry_at = now() + (interval '1 minute' * power(2, r_job.retry_count)),
          finished_at = CASE
            WHEN r_job.retry_count + 1 >= r_job.max_retry THEN now()
            ELSE NULL
          END
      WHERE id = r_job.id;

      v_failed := v_failed + 1;
    END;
  END LOOP;

  RETURN QUERY SELECT v_processed, v_succeeded, v_failed;
END;
$$;
```

### 7. 新数据自动入队

业务 trigger 只负责插入待处理任务，不直接调用 `rds_ai.ai_query`。

```sql
CREATE OR REPLACE FUNCTION fn_enqueue_ticket_priority()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND NEW.content IS NOT DISTINCT FROM OLD.content THEN
    RETURN NEW;
  END IF;

  INSERT INTO ai_job (ref_table, ref_id, task_kind, payload)
  VALUES (
    'tickets',
    NEW.id::text,
    'label_ticket_priority',
    jsonb_build_object('source_column', 'content', 'target_column', 'priority')
  )
  ON CONFLICT DO NOTHING;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS tg_enqueue_ticket_priority ON tickets;

CREATE TRIGGER tg_enqueue_ticket_priority
AFTER INSERT OR UPDATE OF content ON tickets
FOR EACH ROW EXECUTE FUNCTION fn_enqueue_ticket_priority();
```

### 8. 存量数据批量入队

先查待处理规模，让用户确认范围。

```sql
SELECT count(*) AS rows_to_process
FROM tickets
WHERE priority IS NULL
  AND content IS NOT NULL;
```

确认后入队：

```sql
INSERT INTO ai_job (ref_table, ref_id, task_kind, payload)
SELECT
  'tickets',
  id::text,
  'label_ticket_priority',
  jsonb_build_object('source_column', 'content', 'target_column', 'priority')
FROM tickets
WHERE priority IS NULL
  AND content IS NOT NULL
ON CONFLICT DO NOTHING;
```

### 9. 执行待处理任务

Agent 需要把下面这条 SQL 接到应用自动化任务、定时任务或手动运维入口里周期性执行；只创建 `ai_job` 不会自动消费任务。默认建议每 1 分钟执行一次，`p_batch_size` 先用 `5`；大量回填时再按实际耗时调大。如果当前环境不能创建自动化任务，必须把这条 SQL 作为后续手动操作明确交付给用户。

```sql
SELECT * FROM ai_run_pending_jobs(5);
```

建议先手动执行一次，确认能处理成功：

```sql
SELECT * FROM ai_run_pending_jobs(1);
```

### 10. 验证结果

```sql
SELECT status, count(*)
FROM ai_job
WHERE task_kind = 'label_ticket_priority'
GROUP BY status;

SELECT priority, count(*)
FROM tickets
GROUP BY priority
ORDER BY count(*) DESC;

SELECT id, content, priority
FROM tickets
WHERE priority IS NOT NULL
ORDER BY id DESC
LIMIT 20;
```

调用明细和 token 消耗由平台日志记录，不在业务 SQL 里手写日志。

## 常见 prompt 模板

均按 `rds_ai.ai_query('<prompt>' || 源字段)` 调用；工单优先级见步骤 3 / 5。

| 场景 | prompt 模板（与源字段拼接） |
| --- | --- |
| 情感分类 | `判断以下评论情感，只返回 positive / neutral / negative 之一，不要解释：` |
| 摘要 | `为以下内容生成 50 字以内摘要，只返回摘要正文：` |
| 结构化抽取 | `从以下文本抽取字段，只返回 JSON：{"category":"","amount":"","city":""}。文本：` |

## 关键注意事项

| 禁止 / 要求 | 原因 | 正确做法 |
| --- | --- | --- |
| ❌ 业务事务路径（同步 trigger / 大批量 UPDATE）里直接调 `rds_ai.ai_query` | HTTP 调用会因网络抖动、限流、超时、模型异常抛错，阻塞业务写入、占锁并产生大额模型调用 | trigger 只入队，模型调用统一由 `ai_run_pending_jobs()` 的 EXCEPTION 块兜住；批量场景先小样本验证，再经 `ai_job` 分批处理 |
| ❌ 422 / `quota_exceeded` 报错后继续重试 | 当前应用 AI 调用额度已用完，重试只会继续报错 | 任务直接置 `failed`、停止入队，续费后批量重跑；提示用户「AI 调用额度已耗尽，请联系应用 Owner 在控制台续费或升级套餐后再试」 |
| ❌ 429 / `rate_limit_exceeded` 报错后原速重跑 | 调用过于密集触发限流 | 保持重试 + 指数退避；调小 `ai_run_pending_jobs` 单次批量、放慢 worker 节奏；提示用户「AI 调用过于频繁触发了限流，已自动放慢节奏，稍后会继续跑完」 |
| ❌ 500 / `model_unavailable` 报错后继续重试或继续入队 | 租户预置模型已被全部下架或停用，平台无模型可选，重试不会恢复 | 任务置 `failed` 并停止入队；提示用户「当前租户无可用 AI 模型，请联系租户管理员恢复后再试」；模型恢复后重跑失败任务即可 |
| ❌ prompt 不约束输出格式 | 解释性文本会作为脏值写回业务表 | 分类任务写清枚举值并在 SQL 函数里校验结果；JSON 抽取写清 JSON schema |
| ❌ trigger 只靠 `UPDATE OF <col>` 判断变化 | 无关更新会重复入队、重复消耗 | 函数里再用 `IS NOT DISTINCT FROM` 判断源字段变化 |

`rds_ai.ai_query` 抛错时，PG 错误信息通常带 HTTP 状态码（422 / 429 / 500）或 `quota_exceeded` / `rate_limit_exceeded` / `model_unavailable` 关键字；失败任务停在 `ai_job` 表，错误码可从 `error_message` 字段读出供 UI 展示和告警归类。

**禁止**的写法（会阻塞业务写入事务）：

```sql
-- ❌ 同步 trigger 里直接调 ai_query
CREATE TRIGGER tg_xxx BEFORE INSERT ON tickets
FOR EACH ROW EXECUTE FUNCTION (NEW.priority := rds_ai.ai_query(...));

-- ❌ 大批量 UPDATE 直接调 ai_query
UPDATE tickets SET priority = rds_ai.ai_query('...' || content) WHERE ...;
```

如果业务确实需要同步打标（不可接受异步队列），trigger 函数里调用 `rds_ai.ai_query` **必须**显式包 EXCEPTION：

```sql
BEGIN
  v_result := rds_ai.ai_query(...);
  -- 校验 + 写回
EXCEPTION WHEN OTHERS THEN
  NEW.priority := NULL;   -- 失败置 NULL 不阻塞业务
END;
```
