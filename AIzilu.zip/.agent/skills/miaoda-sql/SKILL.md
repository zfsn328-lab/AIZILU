---
name: miaoda-sql
description: Use when creating or modifying Miaoda PostgreSQL tables, writing or troubleshooting RLS policies, running `miaoda db` SQL/schema/data commands, seeding mock data, or handling audit/changelog/migration/recovery. 触发词：miaoda db, SQL, 建表, 改表, 数据库, mock 数据, 示例数据, 数据审计, 变更历史, 数据恢复, PITR, 多环境发布, RLS, policy, pgPolicy, 行级权限, SQLSTATE 42501 (permission denied)
control-by-feature-ab: true
gate-tools:
  - tool: bash
    when-contains:
      command: "miaoda db"
---

# miaoda-sql

妙搭应用数据库操作速查：优先用 `miaoda db` 专用子命令，只有 DDL / DML / SELECT 才手写 SQL。完整命令细节、错误码、示例见 [full-reference.md](references/full-reference.md)。跨域文件、应用发布、应用元数据、线上观测请加载 `miaoda-cli`。

`miaoda` 是妙搭沙箱已预装的 Code Agent 命令行工具，直接调用，不要使用 `npx`。

## Quick Reference

| 场景 | 首选命令 | 关键规则 |
|---|---|---|
| 列表 / 查表结构 | `miaoda db schema list` / `schema get <table>` | 禁止用 `information_schema` / `pg_indexes` 模拟常规结构查询 |
| 执行 DDL / DML / SELECT | `miaoda db sql "<query>"` | SQL 唯一执行通道 |
| 批量导入 CSV / JSON | `miaoda db data import <file> [--table <table>]` | 目标表已存在；表头 / key 与列名完全一致；无 upsert |
| 批量导出 | `miaoda db data export <table> [--format csv\|json\|sql]` | 单次 1 MB 上限；已存在文件需 `--force` 或换路径 |
| 表结构变更历史 | `miaoda db changelog` | DDL 维度：CREATE / ALTER / DROP / INDEX；禁止直查 `pg_audit` 模拟 |
| 表数据变更历史 | `miaoda db audit enable/status/list/disable` | DML 维度：INSERT / UPDATE / DELETE；需按表启用；禁止直查 `pg_audit` 模拟 |
| 多环境 DDL 发布 | `miaoda db migration init/diff/apply` | 仅专家模式；apply 不可逆，默认引导走 web 控制台 |
| PITR 恢复 | `miaoda db recovery diff/apply <timestamp>` | 仅专家模式 + migration init；apply 不可逆覆盖 |
| DB 用量 | `miaoda db quota` | 查容量、行数、实例规格 |

**changelog vs audit**：结构变化用 `changelog`；行数据变化用 `audit list <table>`。更多 flags 与输出契约见 reference。

**何时打开 reference**：完整 flags / JSON 输出结构 / 错误码、import-export 边界（大表分批、路径覆盖、非 ASCII 标识符）、audit/changelog/migration/recovery/quota 具体参数、系统表白名单、user_profile 唯一表达式、pg function、JSONB 复杂注释等长尾限制 → 见 [full-reference.md](references/full-reference.md)。

## Hard Rules

| 规则 | 要求 |
|---|---|
| SQL 执行通道 | 只用 `miaoda db sql`，不要调用其它 SQL 工具 |
| 写 SQL 前确认结构 | 先 `schema list/get` 或只读查看 `server/database/schema.ts`；`schema.ts` 是生成产物，禁止手改——DB 结构不对就改 DDL 后重跑 codegen；DB 正确但 schema.ts 渲染错误时同样不手改，向用户说明是 codegen bug |
| DDL 原子性 | CREATE TABLE + RLS + policy + COMMENT + INDEX 放在一次 SQL 调用；需要全回滚时显式 `BEGIN; ... COMMIT;` |
| 高风险授权 | DDL、DELETE/TRUNCATE、`migration init/apply`、`recovery apply` 执行前必须向用户展示影响范围并取得明确授权 |
| `--yes` 边界 | 只跳过 CLI 二次确认，不能代替用户授权 |
| 线上发布 / 恢复 | `migration apply` / `recovery apply` 默认引导用户走 web 控制台；除非用户明确要求 CLI |
| 已有数据安全 | 已有表 / 已有数据禁止直接 DROP / DELETE；优先 ALTER / UPDATE；不确定先问用户 |
| 平台保留对象 | 禁止创建或修改 `auth`、`users` 等平台保留表；禁止 DROP 平台审计列 |
| 业务人员字段 | 业务需要“创建人 / 负责人”字段时命名为 `creator` / `owner` / `author`，避免与审计列混淆 |
| 非交互命令 | 非 TTY 场景需要确认的命令必须显式 `--yes`，但仍要先拿用户授权 |

## CREATE TABLE Template

新建业务表必须包含 4 个审计列、启用 RLS、创建 4 条默认 policy。

```sql
CREATE TABLE IF NOT EXISTS <table> (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  -- ... business columns ...
  name varchar(100) NOT NULL,
  _created_at TIMESTAMP(3) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  _created_by user_profile DEFAULT (
    CASE
      WHEN current_setting('app.user_id', TRUE) = '' THEN NULL
      ELSE concat('(', current_setting('app.user_id', TRUE), ')')::user_profile
    END
  ),
  _updated_at TIMESTAMP(3) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  _updated_by user_profile DEFAULT (
    CASE
      WHEN current_setting('app.user_id', TRUE) = '' THEN NULL
      ELSE concat('(', current_setting('app.user_id', TRUE), ')')::user_profile
    END
  )
);

ALTER TABLE <table> ENABLE ROW LEVEL SECURITY;

CREATE POLICY service_role_bypass_policy ON <table>
  TO service_role USING (true);

CREATE POLICY "修改全部数据" ON <table>
  AS PERMISSIVE FOR ALL TO authenticated USING (true);

CREATE POLICY "查看全部数据" ON <table>
  AS PERMISSIVE FOR SELECT TO authenticated, anon USING (true);

CREATE POLICY "修改本人数据" ON <table>
  AS PERMISSIVE FOR ALL TO authenticated USING (
    (current_setting('app.user_id'::text) = ANY (ARRAY[]::text[]))
    AND (current_setting('app.user_id'::text) = ((_created_by).user_id)::text)
  );
```

> ⚠️ **每条 policy 必带表达式**：`INSERT` → `WITH CHECK`，`SELECT/UPDATE/DELETE/ALL` → `USING`，二选一别两边都写。漏写则 `with_check`/`using` 落库为 `NULL`、该规则不生效（查询静默 0 行或写入报 `42501`）。raw `CREATE POLICY` 与 Drizzle `pgPolicy()` 同约束：
>
> ```ts
> pgPolicy("查看", { for: "select", to: [authenticatedRole], using: sql`true` }),     // ✅ select/update/delete/all → using
> pgPolicy("插入", { for: "insert", to: [authenticatedRole], withCheck: sql`true` }), // ✅ insert → withCheck
> pgPolicy("插入", { for: "insert", to: [authenticatedRole] }),                       // ❌ 漏 withCheck → 不生效
> ```
>
> **公开匿名写入**：默认模板只含 `anon` SELECT。仅当业务允许未登录访客提交时，才给目标 RLS 表补匿名插入，并用未登录 HTTP POST 2xx 验证：
>
> ```sql
> CREATE POLICY "允许匿名插入" ON <table>
>   AS PERMISSIVE FOR INSERT TO anon WITH CHECK (true);
> ```
>
> Drizzle 等价规则：`pgPolicy(..., { for: "insert", to: [anonRole], withCheck: sql`true` })`。反例：`FOR SELECT TO anon` 只读，`FOR INSERT TO authenticated` 只登录态写；个人数据、后台管理、公开只读页仍走登录/权限控制。
>
> **查询空 / 42501 排查序**：① policy 表达式是否为 `NULL`（`miaoda db schema get <table>` 看 `using`/`with_check`）→ ② 连接角色是否在 `TO` 列表（`authenticated`/`anon`）→ ③ 依赖 `app.user_id` 的策略是否 `SET LOCAL app.user_id`。

建表流程：`schema list/get` 确认不存在或需变更 -> 生成 DDL -> 用户授权 -> `miaoda db sql` 执行 -> 插入 mock -> 必要时重跑 codegen 刷新 `schema.ts`。

## DDL Rules

### DDL Workflow

1. 先 `miaoda db schema list` 判断表是否存在；已有表再 `miaoda db schema get <table>` 看 DDL / columns / indexes / comments。
2. 生成 DDL 时只写裸表名，不写 `public.` 或 workspace schema。
3. CREATE TABLE 必须带审计列、RLS、4 条默认 policy；JSONB 字段必须在同一次调用里写 `COMMENT ON COLUMN ... IS '@type { ... }'`。
4. CREATE TABLE / CREATE INDEX / ALTER TABLE ADD COLUMN 必须带 `IF NOT EXISTS`，避免重复执行失败。
5. 执行前向用户展示目标对象和变更内容；DROP / DROP COLUMN 还要说明数据丢失风险并取得明确授权。
6. 执行：`miaoda db sql "<ddl>"`。多条 DDL 是一个逻辑单元时放在一次调用；需要全回滚则显式包事务。

### DDL Do / Don't

| 场景 | 做法 |
|---|---|
| 新建表 | 用本 skill CREATE TABLE Template，一次包含 RLS、policy、COMMENT、INDEX |
| 修改表 | `ALTER TABLE <table> ADD COLUMN IF NOT EXISTS ...`，相关 COMMENT 同次执行 |
| 加索引 | `CREATE INDEX IF NOT EXISTS idx_<table>_<cols> ON <table>(...)` |
| JSONB 类型 | `COMMENT ON COLUMN t.payload IS '@type { key: string }'`（会据此生成 ORM 代码中的 ts 类型） |
| 删除表 / 列 | 已有业务数据默认禁止；用户明确授权后才执行 |

## SQL Pitfalls

| 陷阱 | 正确做法 |
|---|---|
| 表名带 schema 前缀 | 业务表一律裸表名：`SELECT ... FROM user_profile`，不要写 `public.t` |
| 保留字作标识符 | 避免 `user`、`order`、`desc`、`offset`、`references` 等 |
| `IF NOT EXISTS` 滥用 | 支持：CREATE TABLE / INDEX / EXTENSION、ALTER TABLE ADD COLUMN；不支持：CREATE TYPE / POLICY / ADD CONSTRAINT |
| 审计列写错 | 列名是 `_created_at` / `_updated_at` / `_created_by` / `_updated_by`，查询不要写 `created_at` |
| user_profile 未解引用 | 查询 / 过滤用 `(field).user_id`；raw SQL 不直接返回复合类型给前端 |
| user_profile 表达式索引 / 唯一性 | 索引用三重括号：`CREATE INDEX ... ON t (((owner).user_id))`；表达式唯一性用 `CREATE UNIQUE INDEX`，不要用 `ALTER TABLE ADD CONSTRAINT UNIQUE` |
| UUID 手写 | 主键用 `DEFAULT gen_random_uuid()`；INSERT 不手写 UUID，外键用子查询取父表 id |
| MySQL 方言 | 不用 `SHOW TABLES` / `DESCRIBE` / 内联 `COMMENT`；改用 schema 命令和 `COMMENT ON` |
| 日期列当字符串用 | 按月 / 按天筛选写范围比较 `col >= '2026-08-01' AND col < '2026-09-01'`；date / timestamptz 上 `LIKE '2026-08%'` 报 42883 |
| 空数组类型不明 | 写 `ARRAY[]::text[]` 或 `'{}'::text[]` |
| 标量子查询多行 | `VALUES((SELECT ...))` / `SET col=(SELECT ...)` 必须唯一或 `ORDER BY ... LIMIT 1` |
| 系统表查询 | 常规结构查询用 schema 命令；系统表仅限 reference 中列出的白名单 |
| 多语句事务误判 | `A; B; C` 不自动包事务，B 失败时 A 不回滚；需要原子性用 `BEGIN/COMMIT` |

## Data Types and Design

| 项目 | 规则 |
|---|---|
| 主键 | 默认 `id UUID PRIMARY KEY DEFAULT gen_random_uuid()`；人员实体表可用 `user_profile PRIMARY KEY` |
| 命名 | 单数、全小写、snake_case、无冗余后缀 |
| 短文本 | 分类 / 状态 / 枚举用 `varchar(255)`，值用小写英文 + 下划线 |
| JSONB | 必须 `COMMENT ON COLUMN ... IS '@type { ... }'` 声明 TypeScript 类型；复杂格式见 reference |
| 强约束 | UNIQUE / FOREIGN KEY / NOT NULL 默认谨慎，不确定时不用；加 NOT NULL 列必须带 `DEFAULT` 让存量行自动填默认值：`ALTER TABLE <table> ADD COLUMN <col> <type> NOT NULL DEFAULT <默认值>` |
| 附件 / 图片 | URL 用 `TEXT`，命名 `xxx_url`；图片 mock 遵循下方 generate_image 规则 |

## Mock Data Rules

| 规则 | 要求 |
|---|---|
| 数量 | 新建表默认插 3-6 条（除非用户明确不要）；现有表仅用户要求时造数据；要求更多时单表最多 20 条，再多走 `data import` |
| 字段一致性 | 页面 / 业务会读的同表字段必须都在 SQL mock 中提供，禁止一半 DB 一半代码拼 |
| user_id 来源 | 上下文明确 user_id > `env.userId` / `env.user.id` > 测试用户列表；禁止编造 |
| 图片 URL | 写入数据库的任何图片字段，包括 JSONB 内嵌图片，都按“用户上传图 -> 历史语义匹配图 -> `generate_image`”顺序处理；只有工具失败才用带 seed 的 Picsum 兜底 |
| 关联 | 外键 / 子查询引用的数据必须已存在；UUID 字段不用手写 |
| 审计列 | `_created_at` / `_updated_at` 可省略；需要归属时显式写 `_created_by` / `_updated_by` |

测试用户（**只用于数据库 `user_profile` 列**）：`1847292357012580` 张伟、`1847292986161210` 李明、`1838411738368010` 刘洋、`1847292458018820` 赵丽、`1847286122258458` 孙强、`1846114399229988` John Smith、`1847298549409911` Emma Johnson、`1847291727560708` Michael Brown、`1848568929333380` Robert Wilson、`1847751107397639` Maria Garcia。

> ⚠️ 这些是妙搭数字 user_id，**不是飞书 open_id**。需要 open_id（`ou_` 开头）的场景一律另行解析，禁止直接复用这些数字 ID。

### `user_id` / `user_profile`

- `user_id` 是高频写入规则，不是长尾 reference：只能来自上下文明确给定、`env.userId` / `env.user.id`，或上方测试用户列表，禁止编造。
- 写入 `user_profile` 字段用 `ROW('<user_id>')::user_profile`；更新复合类型时替换整个字段。
- 查询、过滤、索引 `user_profile` 时只使用 `(field).user_id`；不要依赖 `name` / `email` / `avatar` / `status`。

## SELECT Rules

常规查询直接用 `miaoda db sql "SELECT ..."`；查结构仍优先 `schema list/get`。

| 规则 | 要求 |
|---|---|
| 字段 | 禁止 `SELECT *`；只返回页面 / 逻辑需要的列 |
| 行数 | SELECT 返回 1000 行硬上限；必须显式 `LIMIT` 或聚合 |
| 分页 | 大表优先游标分页：`WHERE id > <last_id> ORDER BY id LIMIT n`，避免大 OFFSET |
| 统计 | 总数用 `count(*)`；分组用 `GROUP BY`；避免拉全量到 agent 侧统计 |
| 慢查询 | 用 `EXPLAIN (ANALYZE, BUFFERS)`；大表 Seq Scan 时考虑加索引 |
| PostgreSQL 函数 | `ROUND` 用 `ROUND(num::numeric, n)` 或 `ROUND(num::double precision)` |

## DML Rules

| 操作 | 规则 |
|---|---|
| INSERT | NOT NULL 且无默认值的列必须提供，批量 INSERT 每行列数一致；需要幂等用 `ON CONFLICT ... DO NOTHING` / `DO UPDATE`（mock 数量、UUID / user_id 来源、审计列写法见 Mock Data Rules） |
| UPDATE | 必须有明确 WHERE，禁止无条件 UPDATE；用户说"修改 / 更新 / 改一下"数据时用 UPDATE，禁止 DELETE + INSERT；修改业务字段时同步 `_updated_at = CURRENT_TIMESTAMP` 和 `_updated_by`；影响范围不明先 `SELECT count(*)` 给用户确认 |
| DELETE / TRUNCATE | 当前会话中 Agent 自己插入的 mock 可删；已有表 / 已有数据默认禁止，必须先 `SELECT count(*)` 展示命中行数并取得用户明确授权；`TRUNCATE` 影响整表，视同高风险删除 |

```sql
INSERT INTO task (title, status, assignee, _created_by, _updated_by)
VALUES
  ('梳理需求', 'open', ROW('1847292357012580')::user_profile, ROW('1847292357012580')::user_profile, ROW('1847292357012580')::user_profile),
  ('完成设计', 'doing', ROW('1847292986161210')::user_profile, ROW('1847292357012580')::user_profile, ROW('1847292357012580')::user_profile)
ON CONFLICT (title) DO NOTHING;
```

## Import / Export Checklist

| 场景 | 检查项 |
|---|---|
| import | 先 `schema get` 对齐列；目标表已存在；CSV 表头 / JSON key 完全匹配；扩展名只支持 `.csv` / `.json` |
| import 值类型 | JSON 空值用 `null`；INTEGER / BIGINT 写字符串或改 CSV，避免裸数字 / 科学计数被当浮点拒收；CSV 列数对齐，含逗号 / 换行字段用双引号 |
| import 冲突 | 主键 / 唯一键冲突会整批回滚；先 SELECT 查重，或改用 SQL `ON CONFLICT` |
| export | 默认不覆盖已有文件；大表按主键区间分批；非 ASCII 表名 / 列名先 rename 或 SELECT alias，避免直接 export 静默 0 行 |
| SQL 回放 | Excel 先转 CSV；`--format sql` 导出的文件用 `miaoda db sql < file.sql`，不要走 `data import` |
