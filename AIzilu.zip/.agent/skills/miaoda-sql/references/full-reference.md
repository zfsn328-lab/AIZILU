# miaoda-sql Reference

本 reference 只承接 [`../SKILL.md`](../SKILL.md) 未展开的细节：完整 CLI flags、错误码、输出契约、运维子命令、少见 PostgreSQL 限制、import/export 边界。DDL / SELECT / DML 的常用规则以 [`../SKILL.md`](../SKILL.md) 为准。

## CLI Command Details

### `miaoda db sql <query>`

执行 SELECT / INSERT / UPDATE / DELETE / DDL。多条语句可用分号分隔或 stdin 传入。

```bash
miaoda db sql "SELECT id, name FROM user_profile LIMIT 10"
miaoda db sql "ALTER TABLE product ADD COLUMN IF NOT EXISTS cover_url text"
miaoda db sql < migration.sql
miaoda db sql "SELECT id, name FROM user_profile LIMIT 5" --json
```

`miaoda db sql` 完全透传 SQL：平台不会自动补审计列、RLS、policy、COMMENT 或 trigger。

### `miaoda db schema list / get`

```bash
miaoda db schema list
miaoda db schema list --json
miaoda db schema get product
miaoda db schema get product --json
```

`schema get` 用于确认建表语句、字段类型、索引、注释；常规结构查询禁止用 `information_schema.columns` / `pg_indexes` 手写模拟。

### `miaoda db data import / export`

```bash
miaoda db data import users.csv
miaoda db data import data.csv --table user_profile
miaoda db data export user_profile
miaoda db data export user_profile --format json
miaoda db data export user_profile --format sql
miaoda db data export user_profile -f ~/Desktop/backup.csv
miaoda db data export user_profile --force
```

导入前置：目标表已存在；CSV 表头 / JSON 顶层 key 与表字段名完全一致；扩展名只支持 `.csv` / `.json`；任何错误都会整批回滚。导出默认不覆盖已有文件，使用 `--force` 或 `-f` 换路径。

导入值类型：JSON 空值用 `null`；CSV 空值留空单元格；`INTEGER` / `BIGINT` 在 JSON 中建议写字符串或改 CSV，避免 JSON 裸数字 / 科学计数被当浮点拒收；CSV 每行列数必须与表头一致，含逗号 / 换行 / 引号的字段用双引号包裹。来源是 Excel 或其它格式时，先转 CSV 再导。

导出边界：单次 1 MB 上限，大表按主键区间或游标分页分批；表名 / 列名非纯 ASCII 时，直接 `data export` 可能静默 0 行，先 rename 成 ASCII 或用 `SELECT col AS ascii_alias ...` 导出。

SQL 格式回放：`data export --format sql` 产物用 `miaoda db sql < file.sql`，不要走 `data import`。

## Global Flags and Exit Codes

| Flag | 说明 |
|---|---|
| `--json [fields]` | JSON 结构化输出，可选字段过滤，如 `--json id,name` |
| `--output <pretty\|json>` | 输出格式，默认 `pretty` |
| `--timeout <seconds>` | 客户端超时，默认 30s |
| `--env <name>` | 指定 `dev` / `online`；仅专家模式 + migration init 后可用 |
| `--verbose` | debug 日志到 stderr，含 inner-api 请求 / 响应 / logid |
| `-h, --help` | 帮助 |

退出码：`0` 成功；`1` 运行时错误；`2` 用法错误。

## Output Contracts

### SQL limits

| 约束 | 说明 |
|---|---|
| SELECT 1000 行硬上限 | 超过报 `RESULT_SET_TOO_LARGE`，无隐式截断 |
| 单语句 5000 行 / 1 MB 上限 | 超过需用 LIMIT、聚合或游标分页 |
| 多语句不自动包事务 | `A; B; C` 中 B 失败时 A 已提交；需要原子性显式 `BEGIN/COMMIT` |
| 多语句错误定位 | 错误信封带 `statement_index`，从 0 开始 |
| NULL 表达 | JSON 输出为原生 `null`；pretty / 管道输出为字面字符串 `NULL` |

### `--json` data shape

所有成功响应都是顶层 `data` 信封；不要只按内层数据解析。

| 调用 | 完整成功响应形态 |
|---|---|
| 单语句 SELECT | `{"data": [{...row1}, {...row2}]}` |
| 单语句 INSERT / UPDATE / DELETE | `{"data": {"affected_rows": N}}` |
| 单语句 DDL | `{"data": {}}` |
| 多语句 | `{"data": [<statement 0 data>, <statement 1 data>]}` |

### Error envelope and codes

错误统一为：`{"error":{"code":"...","message":"...","hint":"...","statement_index":0}}`。`hint` 优先级高，先按 hint 修复再重试。

| 错误码 | 触发场景 |
|---|---|
| `SYNTAX_ERROR` | SQL 语法错误 |
| `TABLE_NOT_FOUND` | 表不存在 |
| `COLUMN_NOT_FOUND` | 列不存在 |
| `RESULT_SET_TOO_LARGE` | SELECT 超过 1000 行 |
| `STATEMENT_TIMEOUT` | 服务端 30s 强制中断 |
| `TIMEOUT` | CLI 客户端超时 |
| `SQL_OPERATION_FORBIDDEN` | 命中平台禁用 SQL |
| `EXTENSION_NOT_WHITELISTED` | `CREATE EXTENSION` 不在白名单 |
| `UNKNOWN_ENV_VALUE` | `--env` 不存在或未 init |
| `FILE_ALREADY_EXISTS` | 导出目标文件已存在 |
| `IMPORT_TABLE_NOT_FOUND` | 导入目标表不存在 |
| `IMPORT_COLUMN_MISMATCH` | CSV 表头 / JSON key 与表字段不匹配 |
| `IMPORT_PK_CONFLICT` | 导入主键冲突，已回滚 |
| `IMPORT_TYPE_MISMATCH` | 导入类型不匹配，已回滚 |
| `IMPORT_FORMAT_UNSUPPORTED` | 文件扩展名非 `.csv` / `.json` |
| `IMPORT_FILE_NOT_FOUND` | 本地导入文件不存在 |
| `AUDIT_ALREADY_ENABLED` | 重复启用同一表 audit |
| `AUDIT_NOT_ENABLED` | 未启用 audit 却 disable / list |
| `INVALID_TIMESTAMP` | recovery 时间格式不合法 |

## Authorization Details

以下操作前必须向用户展示影响范围并取得明确授权：

| 场景 | 触发条件 | 展示内容 |
|---|---|---|
| 表结构变更 | CREATE / ALTER / DROP TABLE / INDEX / COLUMN | 目标对象、变更内容；DROP 说明数据风险 |
| 数据删除 | DELETE / TRUNCATE | 目标表、WHERE 条件、`SELECT count(*)` 命中行数 |
| 多环境初始化 | `db migration init` | 不可逆、会创建 dev 分支，可选复制数据 |
| dev -> online 发布 | `db migration apply` | 先展示 `migration diff` 输出，说明影响 online |
| PITR 恢复 | `db recovery apply` | 先展示 `recovery diff`，说明恢复点之后变更会丢失 |

`--yes` 只跳过 CLI TTY 二次确认，不代替授权。`migration apply` / `recovery apply` 默认引导用户走 web 控制台，只有用户明确要求 CLI 时才执行。

## Changelog and Audit

### `miaoda db changelog`

查表结构变更历史：CREATE / ALTER / DROP TABLE、CREATE / DROP INDEX 等。全应用默认开启，无需启用。
禁止直接查询或模拟 `pg_audit`。

```bash
miaoda db changelog
miaoda db changelog --json --limit 200
miaoda db changelog --table user_profile --since 7d --type ALTER_TABLE
miaoda db changelog --change-id chg_xxxxxx
miaoda db changelog --cursor <next_cursor> --limit 50
```

`operator` 在 JSON 下是 `{id, name}`，pretty 模式展示 name。

### `miaoda db audit`

查行级数据变更历史：INSERT / UPDATE / DELETE。需要先按表启用。
禁止直接查询或模拟 `pg_audit`。

```bash
miaoda db audit enable user_profile --retention 30d
miaoda db audit status
miaoda db audit status user_profile --json
miaoda db audit list user_profile --since 1h --limit 20
miaoda db audit list user_profile order product --since 24h --json
miaoda db audit disable user_profile
```

`audit list --json` 关键字段：`event_id` / `event_time` / `target_table` / `type` / `operator` / `summary` / `before` / `after`。多表查询中部分表不可用时归入 `skipped`，不整体失败。

## Migration, Recovery, Quota

### `miaoda db migration`

仅专家模式可用。拆成 `dev` + `online` 两个独立 DB 分支，在 dev 改 DDL，再 diff / apply 到 online。

```bash
miaoda db migration init
miaoda db migration init --sync-data
miaoda db sql "ALTER TABLE product ADD COLUMN IF NOT EXISTS cover_url text" --env dev
miaoda db migration diff
miaoda db migration apply --yes
```

限制：不可逆；只支持 dev -> online；只发布 DDL；数据变更需自行同步；非 TTY apply 必须 `--yes`。

### `miaoda db recovery`

PITR 恢复到过去时间点。仅专家模式 + migration init 后可用，默认窗口 7 天。

```bash
miaoda db recovery diff 30m
miaoda db recovery diff 2026-04-15T10:00:00Z
miaoda db recovery diff 2026-04-15T18:00:00+08:00
miaoda db recovery apply 30m --yes
```

`recovery diff` action：`restore_table`、`drop_table`、`alter_table`、`data`。apply 若目标时间点与当前一致会直接退出。

### `miaoda db quota`

```bash
miaoda db quota
miaoda db quota --json
miaoda db quota --env dev
```

返回字段：`size_bytes_used` / `size_bytes_limit` / `tables` / `total_rows` / `instance_class`。

## Platform Forbidden SQL

命中会被 CLI 拒绝并返回 `SQL_OPERATION_FORBIDDEN` 或 `EXTENSION_NOT_WHITELISTED`。

| 类别 | 禁止 SQL |
|---|---|
| 数据库级 | `CREATE / DROP / ALTER DATABASE` |
| Schema 级 | `CREATE / DROP SCHEMA` |
| 用户级 | `CREATE / DROP USER` |
| 角色级 | `CREATE / DROP / ALTER ROLE` |
| Owner 切换 | `REASSIGN OWNED` / `DROP OWNED` |
| Extension | 仅白名单内允许，如 `pg_trgm`、`pgcrypto` |

业务红线：禁止操作平台保留表如 `auth`、`users`；禁止 DROP 平台审计列；业务创建人 / 负责人字段命名为 `creator` / `owner` / `author`，避免混淆审计列。

## PostgreSQL Edge Cases

| 场景 | 规则 |
|---|---|
| 系统表白名单 | 只允许 `information_schema.tables/columns/table_constraints/key_column_usage/views/sequences/schemata`、`pg_indexes`、`pg_description` |
| 系统表禁用 | 禁止 `pg_tables`、`pg_policies`、`pg_type`、`pg_class`、`pg_attribute`、`pg_catalog.*` |
| DISTINCT + window functions | 分两层查询，先 DISTINCT 再窗口函数 |
| 日期相减 | 两个 DATE 相减直接返回天数整数 |
| 内联 COMMENT | 禁止 `column TEXT COMMENT 'xx'`，使用独立 `COMMENT ON` |
| CREATE TYPE | 不支持 `IF NOT EXISTS` |
| CREATE POLICY | 不支持 `IF NOT EXISTS` |
| ALTER TABLE ADD CONSTRAINT | 不支持 `IF NOT EXISTS` |

### JSONB comments

JSONB 字段必须用 `COMMENT ON COLUMN ... IS '@type { ... }'` 声明 TypeScript 类型；CREATE TABLE 和 COMMENT 应放在同一次 DDL 调用中。

```sql
COMMENT ON COLUMN orders.items IS '@type { items: Array<{ sku: string }> }';
COMMENT ON COLUMN orders.metadata IS '@type { source: string } @description 订单来源';
COMMENT ON COLUMN product.payload IS '@type { key: string }';
```

当 `@type` 里含图片语义字段（`image` / `cover_url` / `avatar` / `gallery` / `images` / `photos`）时，mock 写入规则同普通图片列：先找语义匹配图片，再调用 `generate_image`，不能直接写 Picsum。

### `user_profile` compound type

平台内置：`(user_id varchar, name varchar, email varchar, avatar text, status integer)`，无需创建。仅允许业务 SQL 访问 `(field).user_id`；不要依赖 name / email / avatar / status。

```sql
INSERT INTO teacher (teacher_profile, class_id)
VALUES (ROW('1847292986161210')::user_profile, gen_random_uuid());

SELECT (teacher_profile).user_id AS teacher_profile, class_id
FROM teacher;

UPDATE teacher
SET teacher_profile = ROW('1847292357012580')::user_profile
WHERE (teacher_profile).user_id = '1847292986161210';

CREATE INDEX idx_teacher_user_id ON teacher (((teacher_profile).user_id));
CREATE UNIQUE INDEX uk_teacher_user_id ON teacher (((teacher_profile).user_id));
```

表达式唯一性必须用 `CREATE UNIQUE INDEX`；`ALTER TABLE ... ADD CONSTRAINT ... UNIQUE` 不支持 `(field).user_id` 这类表达式列。

### pg function constraints

创建函数时：函数体内禁止 DDL；`RETURNS trigger` 必须 `LANGUAGE plpgsql`。

```sql
CREATE OR REPLACE FUNCTION fn_set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.title := trim(NEW.title);
  RETURN NEW;
END;
$$;
```

## Mock Data Details

| 中文用户 user_id | name | 英文用户 user_id | name |
|---|---|---|---|
| 1847292357012580 | 张伟 | 1846114399229988 | John Smith |
| 1847292986161210 | 李明 | 1847298549409911 | Emma Johnson |
| 1838411738368010 | 刘洋 | 1847291727560708 | Michael Brown |
| 1847292458018820 | 赵丽 | 1848568929333380 | Robert Wilson |
| 1847286122258458 | 孙强 | 1847751107397639 | Maria Garcia |

图片 URL 决策：优先用户上传的语义匹配图片；其次历史消息中语义匹配图片；否则调用 `generate_image`。prompt 必须与数据语义匹配；禁止使用品牌名、角色名、真实人物等版权内容。只有生成失败才用 Picsum，且必须带 seed：`https://picsum.photos/seed/${seed}/400/300`；不能先写 Picsum 再声称已经生成图片。

JSONB 图片字段同样适用：只要 `@type` 中包含 `image` / `cover_url` / `avatar` / `gallery` / `images` / `photos` 等图片地址语义，就不能跳过 `generate_image`。

## `schema.ts` Codegen Split

`server/database/schema.ts` 是 DB 元数据生成产物，只能只读辅助确认结构，禁止手改。

| 现象 | 处理 |
|---|---|
| DB 结构、默认值、类型或约束不对 | 改 DDL 后重跑 codegen，让 `schema.ts` 跟随真源刷新 |
| DB 正确但 `schema.ts` 展示错误 | 视为 codegen 渲染 bug；不要手改产物，说明平台侧需修复 |
