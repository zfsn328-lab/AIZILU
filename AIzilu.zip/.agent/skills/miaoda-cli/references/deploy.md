---
name: miaoda-deploy
description: 当需要触发妙搭应用发布、查询发布单 / 历史 / 错误日志时使用。本 skill 操作的是构建发布流水线，不涉及代码编辑、数据库、文件存储。
---

# miaoda deploy

妙搭应用发布管理的 CLI 操作集，覆盖：

- `deploy`（无子命令）：触发一次发布
- `deploy get <deploy-id>`：查看指定发布单详情
- `deploy history`：查询发布历史
- `deploy error-log <deploy-id>`：查询失败发布的错误日志

> 完整 flag / 默认值 / 取值以 `miaoda deploy [<sub>] --help` 为准。本文只补充 `--help` 没说的判断与协作知识。

## 何时使用

✅ **匹配场景**

- 用户要求"上线" / "trigger 发布"
- 用户要求查看历史发布（哪些成功 / 失败）
- 发布失败后排查具体错误（"上次发布为啥挂了"）
- 等发布跑完再做下一步操作（用 `--wait`）

❌ **不匹配场景**

- 写代码、改配置 → 用代码编辑工具
- 配置发布策略 / 流水线 → 走平台 UI（CLI 不支持）
- 查看运行时日志 / 监控指标 → 用 `miaoda observability`

## deploy 前置检查（Agent 必须执行）

`miaoda deploy` 跑的是当前 git 分支的 **远端 HEAD**——本地未提交 / 未推送的代码不会进发布产物。
所以在调用 `miaoda deploy` 之前，Agent 必须先检查工作区状态，避免"发了个旧版本却以为发了新版"：

1. **跑 `git status --porcelain=v2 --branch`**，从同一份输出里判断两件事：
   - **uncommitted changes**：存在任意非 `#` 开头的行（staged、unstaged、untracked 任一种），即工作区脏。
   - **未推送 commit**：`# branch.ab +N -M` 这一行的 `+N`，N>0 表示本地领先远端 N 个 commit。
   - 备注：早期写法 `git rev-list --count @{u}..HEAD` 会触发某些安全工具对 `..` 的拦截；如必须分开跑，等价命令是 `git rev-list --count HEAD --not @{u}`。
2. **两者都没有**：直接 `miaoda deploy`。
3. **有但能从上下文判断意图**：
   - 用户刚说"改完了，上线一下"且本会话内修过相关代码 → 自行 commit 并 push 后再 deploy
   - 修改是无关的旁路（比如随手改了 CLAUDE.md / 调试用的 console.log）→ 提醒用户但不擅自带入发布
4. **从上下文不能确定**：用 AskUser 问清楚——是否要"先 commit + push 再 deploy" / "不带这些改动直接 deploy" / "先暂停确认"。**不要默默替用户决定**。

提交时遵守仓库 commit 规范（解释"为什么"、不绕过 hook 等）；commit 后必须 `git push` 到远端，否则 deploy 仍然拿不到新代码。

## deploy 失败处理（Agent 必须执行）

只要 `miaoda deploy --wait` 返回的 `data.detail.status !== "success"`（或 `deploy get` 显示 failed），**Agent 必须主动排查并修复，直到发布成功**——不要把失败原样甩回给用户、然后停下来等指令。

1. **取错误**：立即 `miaoda deploy error-log <pipelineTaskID> --json | jq '.data'` 拿完整 errorMsg（pretty 也已不截断，但 JSON 更稳）。多 job 时优先看 `componentName: "miaodaContainerDeploy"` 等业务组件的报错。
2. **定位根因**：把 errorMsg 当成普通报错 → 读栈、定位文件 / 函数 / 配置项；如果是依赖 / 编译 / 启动期问题，配合 `miaoda observability log --since <发布时间窗>` 看运行时日志补完上下文。
3. **修复 → 重发**：改完代码 → commit → push → 重新 `miaoda deploy --wait`。**每轮失败都要重新走 1-2 步**，避免按上一轮的猜测重复改。
4. **退出循环的条件**（满足任一即可停手）：
   - 发布成功（`data.detail.status === "success"`）。
   - 连续 3 轮"修复 + 重发"仍同类报错 → 停下来向用户陈述：已尝试的方案、当轮 errorMsg、怀疑的原因，请用户介入。
   - 错误明显超出代码可解决范围（账号 / 配额 / 平台侧 5xx / 资源不存在等）→ 直接告诉用户具体是哪一类，附 `error-log` 原文，不要硬试。
5. **不能做的事**：
   - 不要为了"让 deploy 通过"绕过测试 / lint / commit hook（违反 CLAUDE.md）。
   - 不要在没看 `error-log` 的情况下凭直觉改代码再发；每一次重发都必须有具体根因假设。
   - 不要把上一轮的发布产物当成成功（同一 pipelineTaskID 看的还是旧错），重发后用新返回的 ID 查 `error-log`。

## deploy 状态确认（Agent 必须执行）

优先用 `miaoda deploy --wait`，因为 CLI 会内置每 2s 轮询并在 `data.detail.status` 给出终态。但这条兜底规则不只针对不传 `--wait`：**无论是否传了 `--wait`，只要 deploy 调用后没有看到明确的 `success` / `failed` / `canceled` 终态，Agent 都必须继续确认发布状态**。

不要用异步模式或后台模式调用 deploy（例如 `&`、`nohup`、后台 task、detached run，或任何会让命令提前返回的包装方式），否则调用可能提前结束，Agent 会误判发布已经完成。

如果 deploy 输出没有明确终态（接口可能异步提前返回，甚至可能没有可用输出），Agent **必须**自行每 2s 轮询当前发布状态，直到看到终态：

```bash
miaoda deploy
```

如果拿到了 `pipelineTaskID`：执行一次 `miaoda deploy get <pipelineTaskID> --json`，读取 `.data.status`；若不是 `success` / `failed` / `canceled`，等待 2s 后再执行下一次 `deploy get`。每次都要重新判断状态，不要写无限循环脚本。

如果没有拿到 `pipelineTaskID`，或输出为空 / 被截断 / 无法解析，则先查发布历史找到对应的发布记录，从 `data[0].ID` 取得 `pipelineTaskID`，然后回到 `deploy get` 做 2s 状态轮询：

```bash
miaoda deploy history --limit 1 --json
# 读取 .data[0].ID 作为 pipelineTaskID
```

轮询期间不要把“已触发发布”当作“发布成功”。如果 `deploy get` 临时查不到同一个 ID，等待 2s 后继续重试；只有看到终态后才进入成功汇报或失败排查。

## 关键行为

`deploy` 自身就是发布动作，**不存在 `deploy create` 子命令**。

**`<deploy-id>` 即 pipelineTaskID**：发布单不再有独立的 `releaseID`，唯一标识就是 pipeline 实例 ID（i64 数字字符串）。

- `miaoda deploy` 的 JSON 输出是 `{"data": {"pipelineTaskID": "..."}}`，这个值就是后续 `get` / `error-log` 的 `<deploy-id>`；带 `--wait` 时，`data.detail.status` 是可读字符串，`data.detail.status_code` 保留 BAM 原始数字枚举，stage/job/step 内的 status 同样翻译。
- `miaoda deploy history` 返回的 `SimpleInstance` 主键叫 `ID`（同一个东西）。
- `miaoda deploy get/history --json` 为 Agent 消费做了状态翻译：`data.status` / `data[].status` 是可读字符串（如 `success` / `failed`），对应 `status_code` 保留 BAM 原始数字枚举。
- 状态枚举走 `NodeStatus`（todo / running / success / failed / canceled / hold_on），不再有 publishing / finished / rollback。

**`--branch` 沙箱注入**：参数被 hideHelp 隐藏，运行时从 `LOCAL_MOCK_MIAODA_DEPLOY_BRANCH` env 读取（沙箱内由平台注入实际值）；CLI 显式传 `--branch` 会被拒（`ARGS_INVALID`）。`--app-id` 同理。

**`--wait` 退出语义**：

- 流水线 SUCCESS / FAILED / CANCELED 都让 CLI 以退出码 0 正常退出。**业务成败由 `data.detail.status` 表达**：`success` 表示成功，其他为 `failed` / `canceled`。
- pretty 模式分别打印 `✓ 发布成功` / `✗ 发布失败` / `• 发布已取消`；失败时 stderr 附 `miaoda deploy error-log <deploy-id>` hint。
- TTY 下用 ora spinner 实时显示当前 stage 名称 + 客户端估算的"已耗时 X.Xs"，stage 转终态时把 `✓ stage(12.3s)` 落到 spinner 上方。JSON / 非 TTY 模式静默。
- 超时退出码 1，错误码 `DEPLOY_TIMEOUT`。

**`deploy get <deploy-id>` 实现细节**：BAM 没有 by-ID 的发布单查询接口；CLI 内部用 `listPipelineInstances({limit:500})` 拉最近 500 条再客户端按 `ID` 命中。命中失败抛 `DEPLOY_NOT_FOUND`，提示用户走 `deploy history` 看窗口。

## 协作链路

**触发并等结果**（最常见的 Agent 链路）：

```bash
miaoda deploy --wait
# 读 data.detail.status；非 success 时立即 miaoda deploy error-log <pipelineTaskID>
```

**deploy 后已有 pipelineTaskID 但没看到终态**：

```bash
miaoda deploy get <pipelineTaskID> --json
# 如果 .data.status 不是 success / failed / canceled，等待 2s 后再执行一次单次查询
```

**deploy 后没有拿到 ID**：

```bash
miaoda deploy history --limit 1 --json
# 从 .data[0].ID 拿 pipelineTaskID，然后每 2s 执行 miaoda deploy get <pipelineTaskID> --json
```

**最近一次失败原因**：

```bash
miaoda deploy history --status failed --limit 1
# 拿到 ID 后
miaoda deploy error-log <ID>
```

`error-log` 输出 `[{"jobID", "componentName", "errorMsg"}]`，`errorMsg` 直接给用户即可，不必再加工。
