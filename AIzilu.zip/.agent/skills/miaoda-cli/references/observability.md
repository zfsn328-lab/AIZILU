---
name: miaoda-observability
description: 当需要查询妙搭应用的线上日志、链路追踪、监控指标（请求量 / 延迟 / CPU / 内存）或运营指标（活跃用户 / 页面访问量）时使用。本 skill 全部为只读查询，不会改动应用状态。不涉及构建发布、代码、数据库写入。
---

# miaoda observability

妙搭应用线上可观测数据的 CLI 操作集，全部只读，覆盖：

- `log`：线上运行日志（按时间倒序，分页）
- `trace list`：链路追踪列表
- `trace get <trace-id>`：单条链路详情
- `source-stack`：根据前端报错信息、错误日志 ID 或包含前端错误的 trace ID，反解源码位置
- `metric <metric-name>`：监控指标（`requests` / `latency` / `cpu` / `memory`）
- `analytics <analytics-name>`：运营指标（`users` / `page-view`）

> 完整 flag / 默认值 / 取值以 `miaoda observability <sub> --help` 为准。本文只补充 `--help` 没说的判断与协作知识。

## 何时使用

✅ **匹配场景**

- 用户排查"应用挂了"、"接口报错"、"用户反馈打不开页面" → 查 `log` / `trace`
- 用户问"线上慢不慢"、"CPU 占用多少"、"昨天有多少请求" → 查 `metric`
- 用户问"DAU / 新增用户 / 页面 PV" → 查 `analytics`
- 拿到 `traceID` 后追下游调用链 → `trace get`
- 关联日志与链路：日志带 `traceID` → `trace get` 看完整链路
- 拿到单条日志 ID 后复查原始日志 → `log --log-id <log-id>`
- 拿到多条日志 ID / trace ID 后批量复查 → 重复传 `--log-id` / `--trace-id`
- 前端报错需要定位源码行列 → `source-stack --log-id <log-id>` / `source-stack --trace-id <trace-id>`

❌ **不匹配场景**

- 改告警规则 / 配置看板 → 走平台 UI（CLI 不支持）
- 查发布失败原因 → 用 `miaoda deploy error-log`（流水线日志，不是运行时日志）
- 离线分析 / 指标聚合 → 拉数据后自己处理

## 查询作用域

所有命令都隐式作用在沙箱注入的 `MIAODA_APP_ID` 上，查询当前应用的 **线上 runtime 环境** 数据。`--app-id` 参数被 hideHelp 隐藏且 CLI 显式传会被拒（`ARGS_INVALID`）。`--help` 里 `log` / `trace` 提到的 `--env` 实际并未注册，无需也不能传。

## 关键约束

**`metric` / `analytics` 的 `<series>` 取值与指标名绑定**——传错会被服务端拒。

| 指标                    | `--series` 取值                                                                  |
| ----------------------- | -------------------------------------------------------------------------------- |
| `metric requests`       | `total` / `error`                                                                |
| `metric latency`        | `p50` / `p99`                                                                    |
| `metric cpu` / `memory` | 不支持 `--series`（指标只有一条线）                                              |
| `analytics users`       | `active` / `new` / `total`（兼容 `active-users` / `new-users` / `total-users`）  |
| `analytics page-view`   | `all` / `desktop` / `mobile`（兼容 `all-view` / `desktop-view` / `mobile-view`） |

不传 `--series` 默认返回该指标所有相关线。

**`metric` 的 `--page` / `--api` 仅对 `requests` / `latency` 生效**，对 `cpu` / `memory` 传了不报错但无效。

**`analytics` 的 `--page`** 仅对 `page-view` 生效，对 `users` 无效。

**`trace get <trace-id>`**：链路超过保留时长后会以 500 + `hint: 检查 trace-id 是否正确，或链路已超出保留时长` 失败，退出码 1。

**`--log-id` / `--trace-id` 支持重复传入**：保持单数 flag 名，不提供复数 alias。单条继续使用 `miaoda observability log --log-id <id>`；多条用重复 flag，例如 `--log-id <id1> --log-id <id2>` 或 `--trace-id <trace1> --trace-id <trace2>`。

**`source-stack` 的数据依赖**：命令会先按 log ID / trace ID 拉取线上日志，再从日志中读取 `release_commit_id`（或 `commit_id`）和 generated stack frame。CLI 会按 BAM v1.0.127 传 `sourceMapFilePrefix: "client/assets/"` 与全量 frames；后端根据每个 frame 的 `fileName` 匹配不同 sourcemap，因此同一日志里多个不同 bundle 文件名也可以一次解析。JSON 结果中的 `error_message_stack` 是传统多行字符串堆栈（如 `Error: boom\n  at src/App.tsx:42:7`），不是 frame 数组，也不再拆出单独的错误信息字段。若日志缺少 commit 或可解析堆栈，JSON 结果会返回 `status: "unresolved"` 和 `reason`，Agent 应改用 `log` / `trace` 详情继续定位或提示日志字段缺失。

## 响应形态（v1.0.123 起合并响应）

`metric` / `analytics` 返回的 JSON 信封 `data` 是一组按时间合并的点位，多指标拼在同一时间点的 `values` 里：

```json
{
  "data": [
    {
      "timestamp": 1778126400, // metric 是秒；analytics 用 timestampNs 是纳秒
      "dimensions": {},
      "values": {
        "client_api_request_latency_p50": 676.08,
        "client_api_request_latency_p99": 718.33
      }
    }
  ],
  "next_cursor": null,
  "has_more": false
}
```

**`metric requests` 的 null → 0 兜底**：BAM 在该时间点无数据时会传 `null`。CLI 仅对 `requests` 把请求过的 `client_api_request_count` / `client_api_request_error_count` 兜底为 0，因为"没有请求"在业务上等价于 0；`latency` / `cpu` / `memory` 不做这个兜底（p50 没数据 ≠ 延迟为 0）。pretty 模式表头会按 `--series` label（p50/p99/total/error 等）展示。

## `--down-sample` 边界丢点风险

出于查询性能，日志平台**会按 `--down-sample` 的桶大小把请求时间区间向下取整**——`--since` 落在桶中间会被往前对齐到桶起点，`--until` 同理被往前对齐到上一个桶起点。这意味着 `--down-sample 1h` 时，**最近 1 小时内 / 起点附近最多 1 小时的数据可能直接被服务端丢弃**。

经验法则：

- 默认尽量用 `--down-sample 1m`，把丢弃范围压到 1 分钟以内（性能仍可接受）
- 仅在大跨度回看（≥ 7d 趋势图）时才提到 `1h` / `1d`，并接受边界数据缺失
- 如果查询结果末尾比预期"少了一段"，先把 `--down-sample` 调小再查，多半就回来了

```bash
# 排查"最近怎么没数据" → 优先用 1m
miaoda observability metric requests --since 1h --down-sample 1m
```

## 协作链路

**接口慢 → 定位环节**（最常见的排障路径）：

```bash
# 1. 找最近的慢请求
miaoda observability log --api /api/orders --min-duration 500 --since 1h
# 2. 从日志取 trace_id，看完整链路
miaoda observability trace get <traceID>
```

**线上报错 → 取错误样本**：

```bash
miaoda observability log --since 1h --level ERROR --grep "<keyword>"
```

**按日志 ID 精确复查**：

```bash
miaoda observability log --log-id <log-id> --json
```

**按多条日志 / 链路批量复查**：

```bash
miaoda observability log --log-id <log-id-1> --log-id <log-id-2> --json
miaoda observability log --trace-id <trace-id-1> --trace-id <trace-id-2> --json
miaoda observability trace list --trace-id <trace-id-1> --trace-id <trace-id-2> --json
```

**反解前端源码位置**：

```bash
# 已有一个或多个错误日志 ID
miaoda observability source-stack --log-id <log-id-1> --log-id <log-id-2> --json

# 已有一个或多个包含前端错误日志的 trace ID
miaoda observability source-stack --trace-id <trace-id-1> --trace-id <trace-id-2> --json
```

**指标趋势**（粒度按时间窗调，避免点位过密）：

```bash
# 最近 1 天 P99，1 小时一个点
miaoda observability metric latency --series p99 --since 1d --down-sample 1h

# 最近 1 周新增用户，按天
miaoda observability analytics users --series new --since 7d --granularity day
```
