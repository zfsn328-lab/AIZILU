---
name: miaoda-cli
description: 妙搭沙箱预装的 Code Agent 命令行工具 `miaoda`，**直接调用**用于应用元数据、发布与线上可观测性原子能力。当任务涉及应用元数据查看/修改（app get/update）、触发发布与查询发布状态/历史/错误日志（deploy / deploy get / deploy history / deploy error-log）、线上日志/链路/监控/运营指标（observability log/trace/metric/analytics）时使用。触发词：miaoda app / miaoda deploy / miaoda observability / 妙搭发布 / 妙搭上线 / 妙搭线上日志 / 妙搭监控 / 妙搭链路 / 妙搭 DAU / 妙搭 PV。
control-by-feature-ab: true
---

# miaoda-cli

`miaoda` 是妙搭沙箱已预装的 Code Agent 命令行工具，直接调用。每条命令对应一个平台原子操作，跨域编排交给 Agent 侧组合。

## 调用范式

```bash
miaoda <domain> <action> [args] [flags]
```

- **两层为主**：`miaoda app get`
- **域内命令多时可二级资源分组**：`miaoda <domain> <resource> <action>`
- **核心操作目标用位置参数**（如 `app_demo_xxx`），**修饰符用 flag**（如 `--summary`、`--id cap_xxx`）
- **默认 `pretty` 同时服务人类与 Agent**：只有需要严格字段契约的脚本场景才加 `--json`，可用 `--json id,name` 做字段级选择

## 全局 flag

| Flag | 说明 |
|---|---|
| `--json [fields]` | JSON 结构化输出，可选字段级选择 |
| `--output <pretty\|json>` | 输出格式，默认 `pretty` |
| `--verbose` | debug 日志到 stderr |
| `-h, --help` | 帮助 |
| `-v, --version` | 版本号（仅根命令） |

## 输出契约

- pretty（默认）：紧凑对齐，人类与 Agent 共用
- JSON 模式：业务字段在 `data` key 下（`{"data": ...}`），列表分页时带 `next_cursor` / `has_more`；不再额外包 `ok` / `request_id` 等命令级 wrapper
- 错误始终写 stderr：
  - pretty：`Error: message\n  hint: ...`
  - JSON：`{"error": {"code": "...", "message": "...", "hint": "..."}}`
- 退出码：`0` 成功；`1` 运行时错误（按 `error.code` 决策重试）；`2` 用法错误（修正参数后重试）

## 调试：`--verbose`

输出更多 debug 信息到 stderr（例如 inner-api 的请求/响应、logid 等），用于排查异常或贴 logid 求助平台。

## 域与子命令

按"域"作为第一级命名空间。本 skill 当前覆盖 `app`、`deploy` 与 `observability` 三个域：

| 域 | 用途 | 参考 |
|---|---|---|
| `miaoda app ...` | 应用元数据：查看 / 修改名称与描述 | [references/app.md](./references/app.md) |
| `miaoda deploy ...` | 触发发布、查询发布单 / 历史 / 错误日志 | [references/deploy.md](./references/deploy.md) |
| `miaoda observability ...` | 可观测性：仅用于线上日志、链路、监控指标、运营指标 | [references/observability.md](./references/observability.md) |
