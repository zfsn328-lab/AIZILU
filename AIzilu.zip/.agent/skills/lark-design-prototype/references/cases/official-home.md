# Official Site / Solution Center Case Inspiration

case_id: official-home-001
reference_weight: low

Applies to: official home pages, solution centers, product introduction pages, and marketing-oriented product home pages.

## Borrowable

- The first screen directly expresses the brand, product, or solution theme.
- Keep one primary CTA and a clear cue for the next content.
- Media prefers product UI images, solution graphics, real business thumbnails, or light illustrations.
- Lower sections can use solution categories, feature cards, customer trust, and product capability sections.
- Expression can be more relaxed than in-product pages, while still staying clean, trustworthy, and Feishu-like.

## Risk Reminders

- Purely decorative hero with no product signal;
- Multiple CTAs competing for the center;
- Strong tech look, dark cyber feel, high-saturation large color blocks, or page UI gradients;
- Cards lack concrete product visuals or business graphics;
- Font size, illustration, and whitespace are all enlarged, causing an empty feel.

## Free To Change

First-screen structure, product media form, section count, CTA copy, customer trust, and feature-card form are decided by the current task.
