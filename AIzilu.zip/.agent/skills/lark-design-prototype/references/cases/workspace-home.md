# Workspace / Portal Case Inspiration

case_id: workspace-home-001
reference_weight: low

Applies to: office home pages, workspaces, collaboration entries, portal aggregation pages, CRM tool home pages.

## Borrowable

- Organize content around a vertical main spine, with left-right columns only carrying clear auxiliary information.
- Side navigation, top tools, welcome area, quick entries, recommended content, and recent visits may appear only when needed.
- Large workspaces keep white or very light surfaces, use few dividers, and separate modules through whitespace and section titles.
- Use about 40px breathing space between content groups and a clean 16–24px rhythm inside groups.
- Quick entries, app entries, and recommendation entries default to left alignment.
- When recommendations, welcome areas, empty states, or product entries need visual anchors, prefer the illustration library, UD illustrations, or product assets.
- Quick entries use equal height within the same row, with row height determined by the tallest card in that row. Icon containers may use low-opacity blue light fill. When recommended content only has title and description, prefer adding a responsible thumbnail, light illustration, or product image.
- Recent visits, tasks, customers, and approvals prefer lists or tables, keep only necessary fields, and avoid information stacking.

## Risk Reminders

- Full-page wall of cards;
- Heavy gray background;
- Shadows on ordinary cards;
- Every module has a full frame;
- Missing module titles, or titles wrapped inside bordered containers;
- Quick entries use outline Buttons or are centered as a whole;
- Quick entries in the same row have uneven heights or are stretched by fixed large heights;
- Recommended content lacks a visual anchor and becomes pure text plus outlined icons;
- Mixed icon styles;
- Modules added only because the case has them, although the current task does not need them.

## Free To Change

Module order, module count, whether a right rail exists, whether a welcome area exists, illustration form, entry count, list fields, and business names are all decided by the current task.
