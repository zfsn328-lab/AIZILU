# Data Table / Directory Case Inspiration

case_id: data-table-001
reference_weight: low

Applies to: Base, data directories, table views, file directories, and data workspaces.

## Borrowable

- The primary path is carried by a table, list, directory grid, or view switch.
- The title area contains clear object identity, search, filters, view switch, and primary action.
- Data content stays scannable. Table headers, rows, status tags, avatars, and row actions align, and field count stays restrained.
- Table body cells stay one-line and 400 weight. Long text uses ellipsis or detail handling, not stacked primary / secondary lines.
- Directory cards can use thumbnails, file-type icons, recent modification, and permission / status metadata to feel real.
- Complex filters can collapse into a dropdown, drawer, or filter panel.

## Risk Reminders

- Replacing the table primary path with large dashboard cards;
- Heavy table lines, making it feel like a traditional admin system;
- Table section title wrapped inside the table frame;
- Bold table body, or customer name, amount, owner, and similar fields using 500 / 600 in bulk;
- Two-line information stacked in cells, raising row height and reducing scan efficiency;
- Directory cards only have titles and no metadata;
- Filter tools compress titles, making long text display character by character;
- Recognizable table, filters, tabs, and pagination are hand-written as static blocks.

## Free To Change

Table columns, view type, directory card density, whether a right detail panel exists, toolbar button count, and empty-state content are decided by the current task.
