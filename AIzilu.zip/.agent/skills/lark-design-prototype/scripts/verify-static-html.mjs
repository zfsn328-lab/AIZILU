#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

function usage() {
  return `Usage:
  node verify-static-html.mjs <file.html> [--sidebar]

Runs token-light pre-browser checks for Lark-style static HTML deliverables.
Use --sidebar only when the page contains a navigation sidebar. Shadow declarations are reported for contextual review.`;
}

const htmlPath = process.argv[2];
if (!htmlPath) {
  console.error(usage());
  process.exit(2);
}

const absoluteHtmlPath = path.resolve(htmlPath);
const html = await fs.readFile(absoluteHtmlPath, 'utf8');

const hardFailures = [];
const warnings = [];
const passed = [];

function pass(name, ok, failMessage, warn = false) {
  if (ok) {
    passed.push(name);
  } else if (warn) {
    warnings.push(failMessage);
  } else {
    hardFailures.push(failMessage);
  }
}

pass(
  'no gradients',
  !/(linear-gradient|radial-gradient|conic-gradient)/i.test(html),
  'Page UI contains gradients.',
);
const shadows = [...html.matchAll(/box-shadow\s*:\s*([^;}"'<>]+)/gi)]
  .map((match) => match[1].trim())
  .filter((value) => !/^none(?:\s*!important)?$/i.test(value));
pass(
  'no shadows requiring contextual review',
  shadows.length === 0,
  'Shadow declarations found; verify they belong to permitted floating layers, not ordinary cards.',
  true,
);
if (process.argv.includes('--sidebar')) {
  pass(
    'fixed sidebar background',
    html.includes('#f9f9f9'),
    'Sidebar background #f9f9f9 is missing.',
  );
  pass(
    'fixed selected sidebar state',
    html.includes('#1f23290d'),
    'Selected sidebar state #1f23290d is missing.',
  );
}
pass('has table', /<table[\s>]/i.test(html), 'No table found.', true);
pass('has search input', /type=["']search["']/i.test(html), 'No search input found.', true);
pass(
  'has local responsive CSS',
  /@media\s*\(/i.test(html),
  'No responsive media query found.',
  true,
);

const imageRefs = [...html.matchAll(/<img\b[^>]*\bsrc=["']([^"']+)["']/gi)].map(
  (match) => match[1],
);
const localImageRefs = imageRefs.filter(
  (src) => !/^(https?:)?\/\//.test(src) && !src.startsWith('data:'),
);
const missingImages = [];
for (const src of localImageRefs) {
  try {
    await fs.access(new URL(src, pathToFileURL(absoluteHtmlPath)));
  } catch {
    missingImages.push(src);
  }
}

pass(
  'all local images exist',
  missingImages.length === 0,
  `Missing local image assets: ${missingImages.join(', ')}`,
);

const tableHeaders = [...html.matchAll(/<th\b[^>]*>([\s\S]*?)<\/th>/gi)]
  .map((match) => match[1].replace(/<[^>]+>/g, '').trim())
  .filter(Boolean);

console.log(
  JSON.stringify(
    {
      file: absoluteHtmlPath,
      passed,
      warnings,
      hardFailures,
      stats: {
        images: imageRefs.length,
        localImages: localImageRefs.length,
        tableHeaders,
      },
    },
    null,
    2,
  ),
);

if (hardFailures.length > 0) {
  process.exit(1);
}
