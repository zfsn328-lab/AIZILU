# Theme: Split Pastel

**Vibe:** Playful, modern, friendly, creative

**Best For:** Consumer apps, product overviews, lifestyle brands

**Typography:**
- Display: `Outfit` (700/800) — rounded geometric sans
- Body: `Outfit` (400/500)

**字体加载（加到 `client/src/tailwind-theme.css`）：**
```css
@import url('https://miaoda.feishu.cn/fonts/css2?family=Outfit:wght@400;500;700;800&display=swap');

:root {
  --font-display: 'Outfit', sans-serif;
  --font-sans: 'Outfit', sans-serif;
}
@theme inline {
  --font-display: var(--font-display);
  --font-sans: var(--font-sans);
}
```
_单字体多字重；标题 `font-display` + `font-bold`，正文不加字体类。_

**Theme CSS:**
```css
[data-ppt-theme="split-pastel"] {
  --ppt-bg-peach: #f5e6dc;
  --ppt-bg-lavender: #e4dff0;
  --ppt-text-dark: #1a1a1a;
  --ppt-badge-mint: #c8f0d8;
  --ppt-badge-yellow: #f0f0c8;
  --ppt-badge-pink: #f0d4e0;
}
```

**Key Tailwind Classes:**
```tsx
// Two-color vertical split
className="min-h-full grid grid-cols-2"
// left: bg-[var(--ppt-bg-peach)]  right: bg-[var(--ppt-bg-lavender)]

// Playful badge pill
className="inline-flex items-center gap-1.5 bg-[var(--ppt-badge-mint)] text-[var(--ppt-text-dark)] rounded-full px-3 py-1 text-sm font-medium"

// Grid pattern overlay (right panel)
className="absolute inset-0 bg-[linear-gradient(rgba(0,0,0,0.04)_1px,transparent_1px),linear-gradient(90deg,rgba(0,0,0,0.04)_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none"

// Rounded CTA
className="rounded-full bg-[var(--ppt-text-dark)] text-white px-6 py-3 font-display font-bold"
```

**Signature Elements:**
- Split background colors (peach + lavender)
- Playful pill badges with icons
- Soft grid pattern on one panel
- Fully rounded CTA buttons
- Warm, approachable pastels
