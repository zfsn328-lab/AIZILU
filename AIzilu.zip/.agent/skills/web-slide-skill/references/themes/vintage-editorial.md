# Theme: Vintage Editorial

**Vibe:** Witty, confident, editorial, personality-driven

**Best For:** Storytelling, lifestyle editorial, magazine-style decks

**Typography:**
- Display: `Fraunces` (700/900) — distinctive serif with personality
- Body: `Work Sans` (400/500) — clean humanist sans

**字体加载（加到 `client/src/tailwind-theme.css`）：**
```css
@import url('https://miaoda.feishu.cn/fonts/css2?family=Fraunces:wght@700;900&family=Work+Sans:wght@400;500&display=swap');

:root {
  --font-display: 'Fraunces', Georgia, serif;
  --font-sans: 'Work Sans', system-ui, sans-serif;
}
@theme inline {
  --font-display: var(--font-display);
  --font-sans: var(--font-sans);
}
```
_标题用 `className="font-display"`，正文不加字体类。_

**Theme CSS:**
```css
[data-ppt-theme="vintage-editorial"] {
  --ppt-bg-cream: #f5f3ee;
  --ppt-text: #1a1a1a;
  --ppt-text-secondary: #555555;
  --ppt-accent-warm: #e8d4c0;
  --ppt-rule: #1a1a1a;
}
```

**Key Tailwind Classes:**
```tsx
// Cream background
className="bg-[var(--ppt-bg-cream)] text-[var(--ppt-text)]"

// Display headline (italic variant)
className="font-display text-[clamp(2.5rem,7vw,6rem)] font-black italic leading-[0.95] tracking-tight"

// Bold bordered CTA box
className="border-2 border-[var(--ppt-text)] px-6 py-3 font-display text-lg"

// Abstract geometric accents (circle outline + line + dot)
className="absolute top-8 right-8 w-24 h-24 rounded-full border-2 border-[var(--ppt-text)]"
className="absolute w-1 h-16 bg-[var(--ppt-text)]"
className="absolute w-3 h-3 rounded-full bg-[var(--ppt-text)]"
```

**Signature Elements:**
- Abstract geometric shapes (circle outline + line + dot) — no illustrations
- Bold bordered CTA boxes
- Witty, conversational copy tone
- Italic display type as hero
- Warm cream background with high-contrast black text
