# Theme: Pastel Geometry

**Vibe:** Friendly, approachable, modern, playful

**Best For:** Product overviews, onboarding, consumer apps

**Typography:**
- Display: `Plus Jakarta Sans` (700/800) — rounded friendly sans
- Body: `Plus Jakarta Sans` (400/500)

**字体加载（加到 `client/src/tailwind-theme.css`）：**
```css
@import url('https://miaoda.feishu.cn/fonts/css2?family=Plus+Jakarta+Sans:wght@400;500;700;800&display=swap');

:root {
  --font-display: 'Plus Jakarta Sans', sans-serif;
  --font-sans: 'Plus Jakarta Sans', sans-serif;
}
@theme inline {
  --font-display: var(--font-display);
  --font-sans: var(--font-sans);
}
```
_单字体多字重；标题用 `font-display` + `font-bold`，正文不加字体类。_

**Theme CSS:**
```css
[data-ppt-theme="pastel-geometry"] {
  --ppt-bg: #fef6e4;
  --ppt-bg-secondary: #ffffff;
  --ppt-text: #001858;
  --ppt-text-secondary: #172c66;
  --ppt-accent-coral: #f582ae;
  --ppt-accent-mint: #8bd3dd;
  --ppt-accent-lavender: #b8c1ec;
}
```

**Key Tailwind Classes:**
```tsx
// Soft background
className="bg-[var(--ppt-bg)]"

// 标题（Plus Jakarta Sans 700/800，与正文同字体，靠字重拉层级）
className="font-display text-[clamp(1.75rem,5vw,3.5rem)] font-extrabold leading-tight text-[var(--ppt-text)]"

// Pill/tag badges
className="bg-[var(--ppt-accent-coral)]/20 text-[var(--ppt-accent-coral)] rounded-full px-4 py-1.5 text-sm font-medium"

// Decorative circles
className="absolute w-32 h-32 rounded-full bg-[var(--ppt-accent-mint)]/30"
```

**Signature Elements:**
- Soft pastel backgrounds (cream, mint, lavender)
- Pill-shaped decorative elements
- Rounded corners everywhere
- Playful geometry
