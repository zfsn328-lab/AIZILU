# Theme: Dark Botanical

**Vibe:** Elegant, sophisticated, warm luxury

**Best For:** Premium brands, luxury products, lifestyle

**Typography:**
- Display: `Cormorant` (400/600) — elegant serif
- Body: `IBM Plex Sans` (300/400) — clean, readable sans

**字体加载（加到 `client/src/tailwind-theme.css`）：**
```css
@import url('https://miaoda.feishu.cn/fonts/css2?family=Cormorant:wght@400;600&family=IBM+Plex+Sans:wght@300;400;500&display=swap');

:root {
  --font-display: 'Cormorant', Georgia, serif;
  --font-sans: 'IBM Plex Sans', system-ui, sans-serif;
}
@theme inline {
  --font-display: var(--font-display);
  --font-sans: var(--font-sans);
}
```
_标题用 `className="font-display"`，正文不加字体类。_

**Theme CSS:**
```css
[data-ppt-theme="dark-botanical"] {
  --ppt-bg: #0f0f0f;
  --ppt-bg-secondary: #1a1a1a;
  --ppt-text: #e8e4df;
  --ppt-text-secondary: #9a9590;
  --ppt-accent-warm: #d4a574;
  --ppt-accent-pink: #e8b4b8;
  --ppt-accent-sage: #8b9a7d;
}
```

**Key Tailwind Classes:**
```tsx
// Background with abstract shapes
className="bg-[var(--ppt-bg)] relative"

// Decorative blob (position absolute)
className="absolute w-64 h-64 rounded-full bg-[var(--ppt-accent-warm)]/20 blur-3xl"

// Elegant heading
className="font-display text-[var(--ppt-text)] tracking-wide"
```

**Signature Elements:**
- Soft abstract blob shapes (warm coral, sage, pink)
- Elegant serif headings
- Generous whitespace
- Subtle blur effects on decorative elements
