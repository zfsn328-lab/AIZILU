# Implementation Guide

Code templates for generating web slide presentations. Read this after completing the two-step style reference in SKILL.md.

---

## Output Directory Structure

```
.
├── client/
│   ├── src/
│   │   ├── app.tsx             # 应用入口（路由配置）
│   │   ├── tailwind-theme.css  # Tailwind 全局主题定制
│   │   ├── pages/              # 页面组件（与路由对应）
│   │   │   ├── [PresentationName]
│   │   │   │   ├── slides/                      # Slide components
│   │   │   │   │  ├── Slide01Title.tsx
│   │   │   │   │  ├── Slide02Problem.tsx
│   │   │   │   │  ├── Slide03Solution.tsx
│   │   │   │   │  └── ...
│   │   │   │   ├── components/                # Shared presentation components
│   │   │   │   │  ├── Slide.tsx               # Base slide container
│   │   │   │   │  ├── Reveal.tsx              # Animation wrapper
│   │   │   │   │  └── Navigation.tsx          # Navigation component (style varies by theme)
│   │   │   │   ├── hooks/                     # Presentation hooks
│   │   │   │   │  ├── useSlideNavigation.ts
│   │   │   │   │  └── useKeyboardNav.ts
│   │   │   │   ├── theme.css                   # PPT Specific Theme CSS variables
│   │   │   │   └── [PresentationName].tsx
├── shared/           # 前后端共享的目录
│   ├── static/       # 静态资源（含图片、json等）
```

---

## Main Presentation Component

Encodes invariants #2, #3, #4 from SKILL.md. Copy verbatim.

```tsx
// [PresentationName].tsx
import { useRef, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { useSlideNavigation } from './hooks/useSlideNavigation';
import { useKeyboardNav } from './hooks/useKeyboardNav';
import { ProgressBar } from './components/ProgressBar';
import { Navigation } from './components/Navigation'; // Style varies by theme

// Import slides — MUST use default import (项目 steering 规范)
import Slide01Title from './slides/Slide01Title';
import Slide02Problem from './slides/Slide02Problem';
// ... more slides

import './theme.css';

const slides = [
  Slide01Title,
  Slide02Problem,
  // ... more slides
];

export function PresentationName() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { currentSlide, goToSlide, nextSlide, prevSlide } = useSlideNavigation(
    slides.length
  );

  useKeyboardNav({ nextSlide, prevSlide });

  // Wheel state (desktop) — MUST use refs (closure `let` resets on re-render)
  const streamActiveRef = useRef(false);
  const streamEndTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastTriggerTimeRef = useRef(0);
  const lastAbsDeltaYRef = useRef(0);
  const lastInnerScrollRef = useRef(0);
  // Touch state (mobile)
  const touchStartYRef = useRef(0);
  const touchStartXRef = useRef(0);
  const touchInScrollableRef = useRef(false);
  const nextSlideRef = useRef(nextSlide);
  const prevSlideRef = useRef(prevSlide);
  nextSlideRef.current = nextSlide;
  prevSlideRef.current = prevSlide;

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Wheel: one swipe = one page flip. Three signals target TRACKPAD behavior
    // (continuous stream: ramp-up 5→10→20→50, then monotonically decaying
    // inertia tail over 1-2s). Mouse wheel (discrete clicks) works trivially
    // under this handler.
    //
    //   (1) streamActive + stream-end timer — every event refreshes the timer;
    //       flag only drops after STREAM_END_MS of silence. Per-event gap
    //       checks leak (inertia gaps can grow to 100-150ms mid-stream).
    //   (2) Post-trigger cooldown — absorbs the ramp-up phase where deltaY
    //       grows 1.5×/event and would falsely trip spike detection.
    //   (3) |deltaY| spike — lets users re-swipe DURING inertia tail. Inertia
    //       decays monotonically, so a jump above the decaying value is
    //       unambiguously fresh user input.
    const STREAM_END_MS = 140;
    const COOLDOWN_MS = 500;
    const SPIKE_RATIO = 1.5;
    const SPIKE_MIN_DELTA = 15;
    const INERTIA_MS = 400; // inner-scroll tail
    const SWIPE_MIN_DY = 40; // mobile swipe threshold

    const handleWheel = (e: WheelEvent) => {
      // Escape hatch: event originated inside an opt-in scrollable region
      // (long tables, code blocks). Only paginate when the inner region is at
      // its boundary in the wheel direction.
      const target = e.target as HTMLElement | null;
      const scrollable = target?.closest?.<HTMLElement>('[data-slide-scrollable]');
      if (scrollable) {
        const atTop = scrollable.scrollTop <= 0;
        const atBottom =
          scrollable.scrollTop + scrollable.clientHeight >= scrollable.scrollHeight - 1;
        const goingDown = e.deltaY > 0;
        const goingUp = e.deltaY < 0;
        if ((goingDown && !atBottom) || (goingUp && !atTop)) {
          lastInnerScrollRef.current = Date.now();
          return;
        }
        // At boundary in wheel direction. Trackpad inertia from the inner
        // scroll keeps firing events for 1-2s even after scrollTop stops moving.
        // Refresh the timestamp on each absorbed event so the full inertia
        // tail is swallowed — otherwise tail events past INERTIA_MS leak
        // through and paginate unexpectedly.
        if (Date.now() - lastInnerScrollRef.current < INERTIA_MS) {
          lastInnerScrollRef.current = Date.now();
          return;
        }
      }

      e.preventDefault();

      if (streamEndTimerRef.current !== null) clearTimeout(streamEndTimerRef.current);
      streamEndTimerRef.current = setTimeout(() => {
        streamActiveRef.current = false;
        streamEndTimerRef.current = null;
      }, STREAM_END_MS);

      const absDelta = Math.abs(e.deltaY);
      const prevAbsDelta = lastAbsDeltaYRef.current;
      lastAbsDeltaYRef.current = absDelta;

      const isSpike =
        absDelta >= SPIKE_MIN_DELTA && absDelta > prevAbsDelta * SPIKE_RATIO;
      const now = Date.now();
      const inCooldown = now - lastTriggerTimeRef.current < COOLDOWN_MS;

      if (streamActiveRef.current && !isSpike) return;
      if (inCooldown) return;

      streamActiveRef.current = true;
      lastTriggerTimeRef.current = now;

      if (e.deltaY > 0) nextSlideRef.current();
      else if (e.deltaY < 0) prevSlideRef.current();
    };

    // Touch: block native scroll (container is `touch-none`, but we also
    // preventDefault touchmove to short-circuit any remaining inertia).
    // Decide direction on `touchend` from total dy — don't paginate mid-drag,
    // that causes multi-flip from continued finger travel or browser inertia.
    const onTouchStart = (e: TouchEvent) => {
      const t = e.touches[0];
      touchStartYRef.current = t.clientY;
      touchStartXRef.current = t.clientX;
      const target = e.target as HTMLElement | null;
      touchInScrollableRef.current = !!target?.closest?.('[data-slide-scrollable]');
    };
    const onTouchMove = (e: TouchEvent) => {
      if (touchInScrollableRef.current) return; // inner scroll handles it
      e.preventDefault();
    };
    const onTouchEnd = (e: TouchEvent) => {
      if (touchInScrollableRef.current) return;
      const t = e.changedTouches[0];
      const dy = touchStartYRef.current - t.clientY;
      const dx = touchStartXRef.current - t.clientX;
      if (Math.abs(dx) > Math.abs(dy)) return; // horizontal → ignore
      if (Math.abs(dy) < SWIPE_MIN_DY) return; // too small
      if (dy > 0) nextSlideRef.current();
      else prevSlideRef.current();
    };

    container.addEventListener('wheel', handleWheel, { passive: false });
    container.addEventListener('touchstart', onTouchStart, { passive: true });
    container.addEventListener('touchmove', onTouchMove, { passive: false });
    container.addEventListener('touchend', onTouchEnd, { passive: true });
    return () => {
      container.removeEventListener('wheel', handleWheel);
      container.removeEventListener('touchstart', onTouchStart);
      container.removeEventListener('touchmove', onTouchMove);
      container.removeEventListener('touchend', onTouchEnd);
      if (streamEndTimerRef.current !== null) clearTimeout(streamEndTimerRef.current);
    };
  }, []); // Empty deps — refs keep handlers fresh

  return (
    <div
      ref={containerRef}
      data-ppt-theme="[theme-name]"
      className={cn(
        // Invariant #2: lock viewport, zero native scroll (desktop + mobile).
        "fixed inset-0 overflow-hidden overscroll-none touch-none",
        "bg-[var(--ppt-bg)] text-[var(--ppt-text)]"
      )}
    >
      <ProgressBar current={currentSlide} total={slides.length} />

      {/* Navigation component - style varies by theme (see navigation-styles.md) */}
      <Navigation
        total={slides.length}
        current={currentSlide}
        onDotClick={goToSlide}
        onPrev={prevSlide}
        onNext={nextSlide}
      />

      {/* Invariant #2: transform-track. Each slide is one `h-full` slot;
          translating the track by -N*100% reveals slide N. CSS transition
          drives the animation — no JS rAF, no scroll, no snap. */}
      <div
        className="w-full h-full flex flex-col will-change-transform"
        style={{
          transform: `translate3d(0, -${currentSlide * 100}%, 0)`,
          transition: 'transform 500ms cubic-bezier(0.4, 0, 0.2, 1)',
        }}
      >
        {slides.map((SlideComponent, index) => (
          <SlideComponent key={index} isActive={currentSlide === index} />
        ))}
      </div>
    </div>
  );
}
```

---

## Base Slide Component

```tsx
// components/Slide.tsx
import { forwardRef } from 'react';
import { cn } from '@/lib/utils';

interface SlideProps extends React.HTMLAttributes<HTMLElement> {
  variant?: 'default' | 'centered' | 'split';
}

export const Slide = forwardRef<HTMLElement, SlideProps>(
  ({ variant = 'default', className, children, ...props }, ref) => {
    const variantClasses = {
      default: 'justify-center',
      centered: 'justify-center items-center text-center',
      split: 'flex-row',
    };

    return (
      <section
        ref={ref}
        data-slide  // ⛔ REQUIRED — invariant #1; keeps debugging/styling selectors consistent
        className={cn(
          // Invariant #3: fill the track slot (`w-full h-full shrink-0`), do NOT
          // self-size with viewport units. Padding vars shrink on short screens.
          "w-full h-full shrink-0 overflow-hidden flex flex-col relative",
          "px-[var(--ppt-pad-x)] pt-[var(--ppt-pad-top)] pb-[var(--ppt-pad-bottom)]",
          variantClasses[variant],
          className
        )}
        {...props}
      >
        <div className="flex-1 flex flex-col justify-center max-h-full overflow-hidden">
          {children}
        </div>
      </section>
    );
  }
);

Slide.displayName = 'Slide';
```

---

## Reveal Animation Component

```tsx
// components/Reveal.tsx
import { motion, type Variants } from 'framer-motion';
import { cn } from '@/lib/utils';

interface RevealProps {
  children: React.ReactNode;
  delay?: number;
  direction?: 'up' | 'down' | 'left' | 'right' | 'scale' | 'blur';
  className?: string;
}

const variants: Record<string, Variants> = {
  up: { hidden: { opacity: 0, y: 30 }, visible: { opacity: 1, y: 0 } },
  down: { hidden: { opacity: 0, y: -30 }, visible: { opacity: 1, y: 0 } },
  left: { hidden: { opacity: 0, x: -50 }, visible: { opacity: 1, x: 0 } },
  right: { hidden: { opacity: 0, x: 50 }, visible: { opacity: 1, x: 0 } },
  scale: { hidden: { opacity: 0, scale: 0.9 }, visible: { opacity: 1, scale: 1 } },
  blur: { hidden: { opacity: 0, filter: 'blur(10px)' }, visible: { opacity: 1, filter: 'blur(0px)' } },
};

export function Reveal({ children, delay = 0, direction = 'up', className }: RevealProps) {
  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, amount: 0.3 }}
      variants={variants[direction]}
      transition={{ duration: 0.6, delay, ease: [0.16, 1, 0.3, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}
```

---

## Theme CSS File

**⛔ DO NOT copy placeholder values. Read `references/style-presets.md` and the selected theme file for accurate values.**

**字体相关变量写在 `client/src/tailwind-theme.css`，不写在这里。** 本文件只管 ppt 专属的颜色、间距、动效。字体走全局 `--font-display` / `--font-sans`（见 style-presets.md 的「字体加载 + Tailwind 布线」），禁止在此声明 `--ppt-font-display` / `--ppt-font-body` 这类页面级变量——和 Tailwind token 脱节必挂。

```css
/* theme.css */

[data-ppt-theme="<theme-name>"] {
  /* GET ALL VALUES FROM references/themes/{theme-name}.md */
  --ppt-bg: ;
  --ppt-bg-secondary: ;
  --ppt-text: ;
  --ppt-text-secondary: ;
  --ppt-accent: ;
  --ppt-accent-foreground: ;
  /* ⛔ 禁止在此声明 --ppt-font-*；字体通过全局 --font-display / --font-sans +
     className="font-display" 使用，配置见 tailwind-theme.css */

  /* Slide padding — consumed by Slide.tsx. DO NOT rename.
     Bottom is larger than top to reserve nav safe-area. */
  --ppt-pad-x: clamp(1rem, 4vw, 4rem);
  --ppt-pad-top: clamp(1rem, 4vw, 4rem);
  --ppt-pad-bottom: clamp(5rem, 8vh, 7rem);

  /* Animation - standard values */
  --ppt-ease: cubic-bezier(0.16, 1, 0.3, 1);
  --ppt-duration: 0.6s;
}

/* Short-height breakpoints — laptop windows, split-screen, browser zoom.
   Shrink padding so content actually fits the track slot. */
@media (max-height: 800px) {
  [data-ppt-theme] {
    --ppt-pad-x: clamp(0.75rem, 3vw, 2.5rem);
    --ppt-pad-top: clamp(0.75rem, 2vh, 2rem);
    --ppt-pad-bottom: clamp(4rem, 7vh, 5.5rem);
  }
}
@media (max-height: 600px) {
  [data-ppt-theme] {
    --ppt-pad-x: clamp(0.5rem, 2vw, 1.5rem);
    --ppt-pad-top: clamp(0.5rem, 1.5vh, 1rem);
    --ppt-pad-bottom: clamp(3rem, 6vh, 4rem);
  }
}
@media (prefers-reduced-motion: reduce) {
  [data-ppt-theme] { --ppt-duration: 0.2s; }
}
```

---

## useSlideNavigation Hook

Transform-track navigation is just an index — no DOM queries, no scroll animation, no IntersectionObserver, no reverse-sync. The CSS transition on the track's `translateY` drives the animation (invariant #2), so the hook's only job is to move the index.

Why this is simple-by-design: the previous scroll-based implementation fought three browser quirks (iOS Safari cancelling smooth-scroll on touch, viewport-unit drift as the mobile URL bar animates, manual scroll drifting `currentSlide` out of sync with visual position). Transforming the track sidesteps all three.

```tsx
// hooks/useSlideNavigation.ts
import { useState, useCallback } from 'react';

export function useSlideNavigation(totalSlides: number) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const goToSlide = useCallback(
    (index: number) => {
      if (index < 0 || index >= totalSlides) return;
      setCurrentSlide(index);
    },
    [totalSlides]
  );

  const nextSlide = useCallback(() => {
    setCurrentSlide((s) => (s < totalSlides - 1 ? s + 1 : s));
  }, [totalSlides]);

  const prevSlide = useCallback(() => {
    setCurrentSlide((s) => (s > 0 ? s - 1 : s));
  }, []);

  return { currentSlide, goToSlide, nextSlide, prevSlide };
}
```

---

## useKeyboardNav Hook

```tsx
// hooks/useKeyboardNav.ts
import { useEffect } from 'react';

interface UseKeyboardNavProps {
  nextSlide: () => void;
  prevSlide: () => void;
}

export function useKeyboardNav({ nextSlide, prevSlide }: UseKeyboardNavProps) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowRight':
        case 'ArrowDown':
        case ' ':
        case 'PageDown':
          e.preventDefault();
          nextSlide();
          break;
        case 'ArrowLeft':
        case 'ArrowUp':
        case 'PageUp':
          e.preventDefault();
          prevSlide();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [nextSlide, prevSlide]);
}
```

---

## Scrollable Content Within a Slide (Escape Hatch)

**Default answer: split the slide.** A 30-row table or a 50-line code block should become two or three slides. Only use this escape hatch when the content genuinely has to live on one slide (reference tables users scan, a log dump, etc.).

To opt a region into internal scrolling without fighting the global wheel handler, add `data-slide-scrollable` to the element that owns the scrollbar:

```tsx
<Slide>
  <h2 className="text-[clamp(1.25rem,min(3.5vw,6vh),2.5rem)] mb-4">
    自然疗愈 · 2 天 1 夜行程表
  </h2>

  {/* ⬇️ data-slide-scrollable + explicit height cap + overflow-y-auto */}
  <div
    data-slide-scrollable
    className="flex-1 min-h-0 overflow-y-auto overscroll-contain pr-2"
  >
    <table className="w-full">{/* long table rows */}</table>
  </div>
</Slide>
```

**Requirements for the scrollable element:**

- `data-slide-scrollable` attribute (the wheel handler looks for this via `closest()`)
- `overflow-y-auto` (or `overflow-y-scroll`)
- Bounded height — use `flex-1 min-h-0` inside a flex column, OR `max-h-[50vh]` directly. Without a height cap, the element grows beyond the slide's track slot and the overflow never kicks in.
- `overscroll-contain` (recommended) — prevents browser's default scroll-chaining onto the outer container, which would trigger pagination.

**Behavior:**

- Wheel events inside the region scroll it natively while it has room; once at the boundary, the next wheel gesture paginates — after a 400ms quiet window so trackpad inertia doesn't leak into pagination.
- Touch on mobile: the container is `touch-none`, but the handler checks `closest('[data-slide-scrollable]')` on `touchstart` and lets those gestures flow natively. The user must lift and re-swipe outside the scrollable region to paginate (or tap a nav dot / arrow).
- At most one scrollable region per slide.

---

## Example Title Slide

**⛔ Export 规范（铁律）：** 每个 slide 文件**必须** `export default function XxxSlide()`，父页面用 `import XxxSlide from './XxxSlide'`（default import）。**禁止** named export / named import —— 项目 steering 规范要求所有 Section/Slide 统一 default 形式，混用会导致"模块没有默认导出"编译错误。

```tsx
// slides/Slide01Title.tsx
import { Slide } from '../components/Slide';
import { Reveal } from '../components/Reveal';

interface Props {
  isActive: boolean;
}

// ✅ 正确：default export
export default function Slide01Title({ isActive }: Props) {
  return (
    <Slide variant="centered">
      <div className="max-w-4xl mx-auto">
        <Reveal>
          <span className="inline-block px-4 py-1.5 mb-6 text-sm font-medium rounded-full bg-[var(--ppt-accent)] text-[var(--ppt-accent-foreground)]">
            NEW PRODUCT
          </span>
        </Reveal>

        <Reveal delay={0.1}>
          <h1 className="font-display text-[clamp(2rem,6vw,5rem)] font-bold leading-tight mb-4">
            Your Presentation Title
          </h1>
        </Reveal>

        <Reveal delay={0.2}>
          <p className="text-[clamp(1rem,2vw,1.5rem)] text-[var(--ppt-text-secondary)]">
            A compelling subtitle that captures attention
          </p>
        </Reveal>
      </div>
    </Slide>
  );
}
```

**❌ 禁止写法：**

```tsx
// ❌ 错误：named export
export function Slide01Title({ isActive }: Props) { ... }

// ❌ 错误：在文件底部再加一行 export default（双导出会误导 LLM，部分 slide 漏加导致整页编译失败）
export function Slide01Title({ isActive }: Props) { ... }
export default Slide01Title;

// ❌ 父页面错误 import
import { Slide01Title } from './slides/Slide01Title';
```
