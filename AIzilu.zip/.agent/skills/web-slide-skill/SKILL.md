---
name: web-slide-skill
description: Create stunning, animation-rich web presentations using React + Tailwind CSS. Supports creating from scratch or converting PowerPoint files. AI auto-selects the best theme based on content. 触发词：幻灯片, 演示文稿, 演示, slide, slides, presentation, PPT, PPTX, pitch deck, 网页幻灯片, 做PPT, 制作PPT, 转换PPT, 导入PPT, web slide, 全屏展示, 主题演讲
---

{% raw %}
# Web Slide Skill

Create beautiful, animation-rich web presentations using React + Tailwind CSS. AI automatically selects the best theme based on content; users can override anytime.

---

## ⚠️ REQUIRED: Two-Step Style Reference

**Before generating any presentation, follow these two steps in order:**

**Step 1 — Read the index (always):**
```
references/style-presets.md
```
Contains: viewport fitting requirements, theme selection guide, font quick reference, animation presets, effect→feeling mapping.

**Step 2 — Read the selected theme file:**
```
references/themes/{theme-name}.md
```
Contains: CSS variables, Tailwind classes, signature elements for the chosen theme.

Available theme files: `bold-signal` · `dark-botanical` · `neon-cyber` · `terminal-green` · `notebook-tabs` · `pastel-geometry` · `swiss-modern` · `paper-ink`

**⛔ Do NOT generate theme CSS without completing both steps.**
**⛔ Hard block:** If you have not read both `references/style-presets.md` and the selected `references/themes/{theme-name}.md`, you MUST NOT output any code, components, or file structure. Stop and read them first.

---

## Core Philosophy

1. **React + Tailwind** — Generate React components with Tailwind CSS styling.
2. **AI-Driven Selection** — Automatically select the best theme based on content. Users can override anytime.
3. **Distinctive Design** — Avoid generic "AI slop" aesthetics. Every presentation should feel custom-crafted.
4. **Production Quality** — Well-commented, accessible, and performant code.
5. **Viewport Fitting (CRITICAL)** — Every slide fits one viewport. Overflow → split, don't compress.

---

## Tech Stack

| Technology | Usage |
|------------|-------|
| Tailwind CSS 4 | Styling with CSS variables |
| Framer Motion | Animations |
| Lucide React | Icons |
| Shiki | Code syntax highlighting |

---

## CRITICAL: Viewport Fitting

Each slide fills one transform-track slot (`w-full h-full` inside `fixed inset-0`). Overflow → split into the next slide. Never shrink fonts or compress layout to squeeze content in.

**Per-slide self-check before output:**
1. Target the **short viewport** (laptop / split-screen, ~720–800px tall). Body area = viewport height − `--ppt-pad-top` − `--ppt-pad-bottom`. Fit there?
2. Tables / lists / grids — rough rows × line-height at base body font: over budget?
3. Uncertain → split.
4. Trim order: **delete filler → bullet-ify → split page**. Never shrink fonts.

See `references/style-presets.md` for base classes, density limits, and fit checklist.

---

## Phase 0: Detect Mode

| Mode | Trigger | Next Step |
|------|---------|-----------|
| **Mode A: New** | Create slides from scratch | Phase 1 below |
| **Mode B: PPT Conversion** | User has .ppt/.pptx to convert | ⬇️ Mode B Fast Path |
| **Mode C: Enhancement** | Improve existing presentation | Read file, then enhance |

| Mode | Interaction Strategy |
|------|----------|
| **Mode A** | No questions. Infer from input, make assumptions, proceed directly. |
| **Mode B** | Present extracted content for user confirmation before styling. |
| **Mode C** | Confirm intended changes only if scope is ambiguous. |

---

## ⚡ Mode B Fast Path: PPT Conversion

**If Mode B was detected above — handle here and skip Phase 1–3.**

Read `references/ppt-conversion.md` for the full extraction script and step-by-step workflow. After extraction and theme selection → go to Phase 4: Delivery.

---

## Phase 1: Content Analysis (Mode A / C only)

**For Mode A: Do not ask questions — infer from what the user provides.**

### Extract Information

| Information | How to Infer |
|-------------|--------------|
| **Purpose** | Keywords like "pitch", "teach", "present to team", "conference" |
| **Topic/Industry** | Subject matter: tech, finance, education, creative, etc. |
| **Audience** | Investors, developers, students, executives, general public |
| **Tone** | Formal vs casual, serious vs playful |
| **Content** | Bullet points, outlines, or raw text provided |

### Handle Missing Information

| User Provides | Action |
|---------------|--------|
| Full content | Proceed directly to theme selection |
| Topic only | Generate a reasonable slide outline (5-8 slides) |
| Vague request | Create a generic pitch deck structure, inform user they can refine |

**Never block on missing information.** Make reasonable assumptions and proceed.

---

## Phase 2: Theme Auto-Selection (AI-Driven)

**AI automatically selects the best theme. No user interaction required.**

### Theme Matching Rules (Priority Order)

#### 1. User Explicit Override (Highest Priority)
- "用 Neon Cyber 主题" → Neon Cyber
- "简约专业风格" → Swiss Modern
- "暗色科技风" → Neon Cyber

#### 2. Content Keywords

| Keywords | → Theme |
|----------|---------|
| 投资, pitch, 融资, startup, 商业计划 | → **Bold Signal** |
| AI, ML, 算法, API, 技术架构, 未来, 科技 | → **Neon Cyber** |
| 代码, 开发者, CLI, SDK, 终端, GitHub | → **Terminal Green** |
| 品牌, 奢侈品, 高端, 设计, 美学 | → **Dark Botanical** |
| 数据, 报告, 分析, KPI, 季度, 企业 | → **Swiss Modern** |
| 教程, 入门, 学习, 指南, 教育 | → **Pastel Geometry** |
| 故事, 旅程, 经历, 感悟, 文化, 叙事 | → **Paper & Ink** |
| 评测, 对比, 清单, 总结, 笔记 | → **Notebook Tabs** |

**冲突解决**：同时匹配多个主题时，选择表格中排序靠前的主题。

#### 3. Audience Inference

| Audience | → Theme |
|----------|---------|
| 投资人/VC | → Bold Signal |
| 开发者/工程师 | → Terminal Green 或 Neon Cyber |
| 企业高管 | → Swiss Modern |
| 设计师/创意人员 | → Dark Botanical |
| 学生/初学者 | → Pastel Geometry |
| 通用/混合 | → Bold Signal (default) |

#### 4. Default Fallback
No clear signals → **Bold Signal** (versatile, professional, works for most cases)

### Announce Selection

```
Based on your content about [topic], I'll use the **[Theme Name]** theme ([brief description]).
If you'd prefer a different style, let me know and I can regenerate.
```

---

## Phase 2.5: Navigation Style (AI-Driven)

AI auto-selects navigation based on theme. See `references/navigation-styles.md` for all 6 styles and theme-navigation defaults. Users can override anytime.

---

## Phase 3: Generate Presentation

Read `references/implementation-guide.md` for all code templates (components, hooks, theme CSS).

### Output Structure

```
client/src/pages/[PresentationName]/
├── slides/           # Slide01Title.tsx, Slide02Problem.tsx, ...
├── components/       # Slide.tsx, Reveal.tsx, Navigation.tsx
├── hooks/            # useSlideNavigation.ts, useKeyboardNav.ts
└── theme.css         # Theme CSS variables (from references/themes/{theme}.md)
```

### ⛔ Pagination Invariants — DO NOT VIOLATE

Copy `references/implementation-guide.md` templates verbatim. Each invariant guards a distinct failure mode.

1. **`data-slide` on every slide root.** Use the shared `<Slide>` component; if hand-rolling `<section>`, add the attribute.
2. **Transform-track, not native scroll.** Container: `fixed inset-0 overflow-hidden overscroll-none touch-none`. Inner track: `translate3d(0, -${currentSlide * 100}%, 0)` with CSS transition. No `scroll-snap`, no `scrollIntoView`, no rAF scroll animation — iOS Safari cancels smooth-scroll on any touch, and viewport units drift as the mobile URL bar shows/hides. Scroll-free transform eliminates the whole "stuck mid-slide" bug class.
3. **Slides fill the track slot, not the viewport.** `w-full h-full shrink-0` inside a `flex-col` track. Do NOT use `h-dvh`/`h-svh`/`h-lvh`/`h-screen` on slide roots — viewport-unit drift leaks adjacent slides through.
4. **Gesture input via `useRef` + effect deps `[]`.** Wheel: 3-signal stream debounce (stream-end timer + cooldown + spike detection). Touch: `touchmove` preventDefault + `touchend` swipe check (`|dy| ≥ 40 && |dy| > |dx|`). Capture `nextSlide`/`prevSlide` through refs — closure `let` resets every render, causing multi-page jumps.
5. **Asymmetric padding via `--ppt-pad-*` CSS vars.** Bottom var is larger (reserves nav safe-area). Symmetric `p-[...]` makes the nav overlap content.
6. **Design for short viewports, not tall desktops.** Typography uses `clamp(min, min(Xvw, Yvh), max)`. Max 2 stacked content blocks per slide. Split hero+flow+grid+callout compositions.
7. **Cross-slide header consistency.** Before writing any slide code, lock a shared header spec (chapter number format like `01`, kicker label, accent bar) and apply it identically to every content slide. Title slide and pure-quote slides are the only exceptions.
8. **Fit or split.** Every slide fits its viewport. Overflow → split across slides; never shrink fonts or compress layout. Target the short viewport (laptop / split-screen). **Split by meaning (each sub-slide gets its own sub-title), not by mechanical 1/3-2/3-3/3 slicing.** Uncertain → split.

---

## Phase 4: Delivery

```
Your presentation is ready!

📁 Location: /client/src/pages/[PresentationName]/
🎨 Style: [Theme Name]
📊 Slides: [count]

Navigation:
- Arrow keys (← → ↑ ↓) or Space to navigate
- Trackpad/wheel and mobile swipe also work
- Click the navigation dots to jump to any slide

To customize:
- Colors: Edit theme.css variables
- Animations: Modify Reveal component delays
- Layout: Adjust Slide variant prop

Would you like me to make any adjustments?
```

---

## Troubleshooting

See `references/troubleshooting.md` for symptom→fix diagnoses (pagination bugs, truncation on short screens, nav overlap, internal scroll).

---

## Example Session Flow

1. User: "帮我做一个 AI startup 的融资 pitch deck，包含问题、方案、市场、团队、融资需求"
2. Skill 分析内容，自动选择主题 → Bold Signal（融资 pitch 场景）
3. Skill 告知用户："基于您的融资 pitch 内容，我将使用 **Bold Signal** 主题。如需其他风格可随时告知。"
4. Skill 生成完整 presentation 到 `/client/src/pages/AIPitchDeck/`
5. Skill 路由配置
6. User: "第三页的图表能换成柱状图吗？"
7. Skill 修改指定 slide
8. 最终交付

{% endraw %}
