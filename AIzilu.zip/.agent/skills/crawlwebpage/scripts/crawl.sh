#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Install playwright if not installed
npm i playwright --registry=https://registry.npmmirror.com --prefix "$SCRIPT_DIR" --silent

# Run crawl.js
"$SCRIPT_DIR/crawl.js" "$@"
