#!/usr/bin/env node
import { chromium } from 'playwright';
import { writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { join } from 'node:path';

// HTML 输出目录：保存到当前工作目录的 tmp/html 下
const HTML_DIR = join(process.cwd(), 'tmp', 'html');
if (!existsSync(HTML_DIR)) {
  mkdirSync(HTML_DIR, { recursive: true });
}

async function crawl(url) {
  const browser = await chromium.launch({
    executablePath: '/etc/alternatives/chromium-browser',
    headless: true,
    args: [
      '--disable-gpu',
      '--no-sandbox',
      '--disable-software-rasterizer',
      '--disable-dev-shm-usage',
      '--disable-features=UseDBus,GlobalShortcuts',
    ],
  });

  const page = await browser.newPage();

  let html = '';
  let title = '';
  let status = 'ok'; // ok | partial | failed
  let httpStatus = 0;

  try {
    const response = await page.goto(url, {
      waitUntil: 'domcontentloaded',
      timeout: 15_000,
    });

    httpStatus = response ? response.status() : 0;

    // 等 network idle 最多 3 秒
    try {
      await page.waitForLoadState('networkidle', { timeout: 3_000 });
    } catch {
      status = 'partial';
    }

    // 拿 title
    try {
      title = await page.title();
    } catch {
      title = '';
    }
  } catch {
    status = 'failed';
    httpStatus = 0;
  } finally {
    // 拿 HTML
    try {
      html = await page.content();
    } catch {
      html = '';
    }
    await browser.close();
  }

  return { status, title, html, httpStatus };
}

// CLI 主函数
(async () => {
  const url = process.argv[2];
  if (!url) {
    console.error('Usage: node crawl.js <url>');
    process.exit(1);
  }

  const result = await crawl(url);

  // HTML 文件名：时间戳 + host
  const safeHost = new URL(url).hostname.replace(/[^a-zA-Z0-9]/g, '_');
  const filename = `crawl_${safeHost}_${Date.now()}.html`;
  const filePath = join(HTML_DIR, filename);

  try {
    writeFileSync(filePath, result.html, 'utf-8');
  } catch (err) {
    console.error('Failed to write HTML file:', err);
    process.exit(1);
  }

  // 输出信息
  console.log(`URL: ${url}`);
  console.log(`Title: ${result.title}`);
  console.log(`HTML Saved To: ${filePath}`);

  // 退出码：非 200 或抓取失败就 1
  if (result.httpStatus !== 200) {
    process.exit(1);
  } else {
    process.exit(0);
  }
})();
