---
name: crawlwebpage
description: "Crawl a webpage and save its HTML content using Playwright headless browser. Use this instead of web_fetch when the page requires JavaScript rendering (SPA, dynamic content, client-side routing). 触发词：爬取网页, 抓取页面, 爬虫, crawl, scrape, 获取网页内容, 动态页面"
---

# crawlwebpage

使用 Playwright 无头浏览器爬取网页，获取 JS 渲染后的完整 HTML。

---

## 方案选择决策树

```
用户需要获取网页内容
├─ 静态页面（博客、文档、API 返回 HTML）
│  └─ 使用 web_fetch —— 更快、更轻量
├─ 动态页面（SPA、CSR、需要 JS 渲染）
│  ├─ 只需要页面内容（文本、结构）
│  │  └─ 使用 crawl.sh ✅（本 skill）
│  └─ 需要交互操作（点击、填表、滚动加载更多）
│     └─ 使用浏览器 MCP 工具（claude-in-chrome）
└─ 不确定是否为动态页面
   └─ 先用 web_fetch 试一次
      ├─ 返回完整内容 → 用 web_fetch 即可
      └─ 返回空壳（只有 <div id="root"></div> 等） → 切换到 crawl.sh
```

**判断动态页面的信号：** URL 含 `#/`（hash 路由）、用户说"SPA/React/Vue/Angular"、web_fetch 返回内容过少或只有框架骨架。

---

## 使用方式

```bash
./scripts/crawl.sh <url>
```

**输出到 stdout：**
```
URL: https://example.com/products
Title: Products - Example
HTML Saved To: /path/to/tmp/html/crawl_example_com_1736956800000.html
```

**退出码：** `0` 成功（HTTP 200）| `1` 失败（非 200、网络错误、写入错误）

---

## 拿到 HTML 后的处理流程

爬取只是第一步。根据用户目标选择后续操作：

| 用户目标 | 后续操作 |
|----------|----------|
| 提取文本内容 | 用 Read 读取 HTML，提取 `<main>` / `<article>` 等语义标签内的文本 |
| 提取结构化数据 | 解析 HTML 中的列表/表格，输出 JSON 或 Markdown 表格 |
| 分析页面结构 | 读取 HTML，总结 DOM 层级、关键组件、数据加载方式 |
| 截图/视觉分析 | 改用浏览器 MCP，crawl.sh 只保存 HTML 不截图 |
| 监控页面变化 | 多次运行 crawl.sh，对比不同时间的 HTML 差异 |

处理 HTML 时优先关注语义化标签（`<main>`, `<article>`, `<section>`），忽略 `<script>`, `<style>`, `<nav>`, `<footer>` 等非内容标签。

---

## 故障排查

| 现象 | 原因 | 解决方案 |
|------|------|----------|
| HTML 只有空壳 `<div id="root"></div>` | 数据通过异步 API 加载，3s networkidle 超时不够 | 重试一次；如果持续失败，考虑直接拦截页面 API 请求获取 JSON 数据 |
| 退出码 1 + 网络错误 | URL 不可达或 DNS 失败 | 确认 URL 正确且网络可访问 |
| 退出码 1 + HTTP 403/401 | 页面需要登录或有反爬 | 需要 Cookie/Token 的场景超出 crawl.sh 能力，改用浏览器 MCP 手动登录后操作 |
| Playwright 安装失败 | 网络问题或缺少系统依赖 | 检查 npm registry 可达性；Linux 上可能需要安装 Chromium 系统依赖 |
| 内容不完整（缺少懒加载部分） | 页面需要滚动触发加载 | crawl.sh 不支持滚动，改用浏览器 MCP 模拟滚动操作 |

---

## 技术细节

- 使用 Chromium headless 模式
- 等待 `domcontentloaded`（15s 超时）+ `networkidle`（3s 超时，超时不算失败）
- HTML 保存到 `tmp/html/crawl_<hostname>_<timestamp>.html`
- 首次运行自动安装 Playwright（使用 npmmirror 源）
