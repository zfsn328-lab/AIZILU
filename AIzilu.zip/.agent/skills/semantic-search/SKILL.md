---
name: semantic-search
description: 当妙搭应用需要为业务数据实现向量检索、语义搜索、相似内容召回或相似记录推荐时使用。适用于商品、文档、FAQ、工单、评论、案例等文本数据的语义匹配场景；方案基于妙搭 PG，通过 rds_ai.ai_embed 生成文本 embedding，并结合 vector 插件完成向量存储、HNSW 索引和相似度查询。
---

# 语义检索与相似召回

本 skill 用于实现语义搜索、相似内容召回和推荐等检索效果。底层使用 `rds_ai.ai_embed` 生成文本向量，并结合 `vector` 插件完成向量存储、索引和相似度排序。本 skill 涵盖：
- 启用 `pgcrypto` / `rds_ai` / `vector` 插件
- 拼接语义文本
- 新增 `vector` 类型向量列
- 新增 / 更新时生成 embedding
- 存量数据回填 embedding
- 创建 HNSW 向量索引
- 编写语义查询 SQL

## 何时使用

✅ **匹配场景**
- 商品按自然语言描述搜索，例如「适合夏天穿的透气运动鞋」
- 知识库、文档、FAQ 按语义召回
- 找相似工单、相似评论、相似案例
- 根据一段文本推荐相似商品、文章或记录

❌ **不匹配场景**
- 分类、打标、摘要、抽取、判优先级 → 用 `rds_ai.ai_query`
- 需要生成一段回答文本 → 用 `rds_ai.ai_query` 或 AI 插件
- 多轮对话、RAG 编排、工具调用 → 用 AI 插件或应用代码

## 前置插件

`ai_embed` 是 `rds_ai` 插件中的方法；完整语义检索还需要 `vector` 插件提供向量类型、向量索引和距离计算。

```sql
CREATE EXTENSION IF NOT EXISTS rds_ai CASCADE;
CREATE EXTENSION IF NOT EXISTS vector;
```

`CASCADE` 会把 `rds_ai` 的依赖（`pgcrypto` 等）一起自动启用，不需要单独再写 `CREATE EXTENSION pgcrypto`。

⚠️ **实际部署时，`CREATE EXTENSION rds_ai` 必须单独提交执行（与其它 SQL 分批），等其返回成功再继续后续 SQL，详见步骤 2。**

不要在 skill 里配置 API key、模型网关、额度、调用日志等平台能力；这些由平台预置。

## 函数用法

本期固定使用平台 embedding 模型 `Doubao-embedding-vision`（默认 **1024 维**），**不支持指定其他模型**——更换模型会导致整列向量空间偏移、索引失效。

```sql
rds_ai.ai_embed(text_to_embed text)
```

返回值是 pgvector 兼容的字面量文本（形如 `[-0.019, 0.009, ...]`），可以直接 `::vector` 转换：

```sql
SELECT rds_ai.ai_embed('你好')::vector;
-- → vector(1024)
```

⚠️ **模型可用性由租户管理后台管控。** embedding 仅此一个模型、无备选，管理员将其下架或停用后 `rds_ai.ai_embed` 即不可用，调用报 `model_unavailable`（处置见「关键注意事项」）。

## 实现步骤

以下 SQL 使用 `products` / `embedding` 作为示例。Agent 生成实际方案时，必须替换成用户应用里的真实表名、字段名、主键、返回列和索引名。

### 1. 确认检索对象

生成 SQL 前先确认：
- 检索哪张表，例如 `products`
- 哪些字段组成语义文本，例如 `name + description + tags`
- 向量列名，默认 `embedding`
- 查询结果返回哪些列，默认 `top 10`
- 表是否有稳定主键，例如 `id`，用于存量数据分批回填

如果用户没指定字段，优先选择最能表达语义的文本列；不要把 ID、时间戳、状态位等弱语义字段拼进去。

### 2. 启用必要插件

**⚠️ 必须分两批单独提交：先 `rds_ai`、确认成功，再执行其余 SQL。**

第一批——只跑这一条，等其返回成功后再继续：

```sql
CREATE EXTENSION IF NOT EXISTS rds_ai CASCADE;
```

`rds_ai` 启用过程包含一次性的初始化工作，**该语句返回成功后** `rds_ai.*` 函数才可用。一旦与后续依赖 `rds_ai.*` 的 SQL 合并到同一批次提交，后续语句可能在初始化尚未就绪时执行而失败。

第二批——上一批成功后再执行其余插件与后续步骤 SQL：

```sql
CREATE EXTENSION IF NOT EXISTS vector;
```

`CASCADE` 会自动带 `pgcrypto` 等基础依赖，不需要单独再写。

### 3. 确认向量维度

创建 `vector(...)` 列前，先用一次测试调用确认当前模型返回维度，并把结果填入后续建列 SQL：

```sql
SELECT vector_dims(rds_ai.ai_embed('test')::vector) AS embedding_dim;
```

### 4. 拼接语义文本

多字段拼接优先用 `concat_ws`，避免某个字段为 `NULL` 导致整体结果为 `NULL`。再用 `nullif(trim(...), '')` 过滤空文本，避免对空字符串生成无意义向量。

```sql
nullif(trim(concat_ws(' ', name, description, tags)), '')
```

### 5. 新增向量列

维度跟当前 embedding 模型一致（`Doubao-embedding-vision` 平台默认输出 1024 维）：

```sql
ALTER TABLE products
  ADD COLUMN IF NOT EXISTS embedding vector(1024);

COMMENT ON COLUMN products.embedding IS
  'AI embedding：由 rds_ai.ai_embed 根据 name / description / tags 生成；模型 Doubao-embedding-vision，1024 维。';
```

### 6. 新增 / 更新时生成 embedding

```sql
CREATE OR REPLACE FUNCTION fn_products_refresh_embedding()
RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  v_text text;
BEGIN
  IF TG_OP = 'INSERT'
     OR NEW.name IS DISTINCT FROM OLD.name
     OR NEW.description IS DISTINCT FROM OLD.description
     OR NEW.tags IS DISTINCT FROM OLD.tags THEN
    v_text := nullif(trim(concat_ws(' ', NEW.name, NEW.description, NEW.tags)), '');

    IF v_text IS NULL THEN
      NEW.embedding := NULL;
    ELSE
      -- 必须兜底：rds_ai 抖动 / 超时时不能让业务 INSERT/UPDATE 回滚。
      -- 失败把 embedding 置 NULL，等存量回填补齐。
      BEGIN
        NEW.embedding := rds_ai.ai_embed(v_text)::vector;
      EXCEPTION WHEN OTHERS THEN
        NEW.embedding := NULL;
      END;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS tg_products_refresh_embedding ON products;

CREATE TRIGGER tg_products_refresh_embedding
BEFORE INSERT OR UPDATE OF name, description, tags ON products
FOR EACH ROW EXECUTE FUNCTION fn_products_refresh_embedding();
```

### 7. 存量数据回填

小表可以直接回填：

```sql
UPDATE products
SET embedding = rds_ai.ai_embed(nullif(trim(concat_ws(' ', name, description, tags)), ''))::vector
WHERE embedding IS NULL
  AND nullif(trim(concat_ws(' ', name, description, tags)), '') IS NOT NULL;
```

大表分批执行，避免长事务：

```sql
WITH batch AS (
  SELECT
    id,
    nullif(trim(concat_ws(' ', name, description, tags)), '') AS text_to_embed
  FROM products
  WHERE embedding IS NULL
    AND nullif(trim(concat_ws(' ', name, description, tags)), '') IS NOT NULL
  ORDER BY id
  LIMIT 500
  FOR UPDATE SKIP LOCKED
)
UPDATE products p
SET embedding = rds_ai.ai_embed(b.text_to_embed)::vector
FROM batch b
WHERE p.id = b.id;
```

重复执行直到剩余数为 `0`：

```sql
SELECT count(*) AS remaining
FROM products
WHERE embedding IS NULL
  AND nullif(trim(concat_ws(' ', name, description, tags)), '') IS NOT NULL;
```

### 8. 创建向量索引

默认使用 HNSW + cosine 距离。大表或线上表建索引时，优先使用 `CREATE INDEX CONCURRENTLY`，避免长时间阻塞写入。

```sql
CREATE INDEX IF NOT EXISTS idx_products_embedding
ON products USING hnsw (embedding vector_cosine_ops);
```

大表 / 线上表优先使用：

```sql
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_products_embedding
ON products USING hnsw (embedding vector_cosine_ops);
```

### 9. 编写语义查询

查询时对用户输入调用同一个 `rds_ai.ai_embed`，按向量距离排序，**并加距离阈值过滤掉相关性不够的结果**，避免无相关结果时强行凑数返回无关项。

```sql
WITH query_embedding AS MATERIALIZED (
  SELECT rds_ai.ai_embed($1)::vector AS embedding
)
SELECT
  p.id,
  p.name,
  p.description,
  p.embedding <=> q.embedding AS distance
FROM products p, query_embedding q
WHERE p.embedding IS NOT NULL
  AND p.embedding <=> q.embedding < $threshold
ORDER BY p.embedding <=> q.embedding
LIMIT 10;
```

**怎么定阈值**：先用代表性 query 跑一次（不带阈值），观察返回的 `distance` 列分布，找到「相关结果都 ≤ X，无关结果都 > X」的拐点作为阈值；上线后再按用户反馈调整（反馈"无关太多"就调小，反馈"应查到的查不出来"就调大）。


### 10. 验证链路

上线前至少做三类检查：非空文本是否都已有 embedding、查询是否能返回预期结果、查询计划是否使用向量索引。

```sql
SELECT count(*) AS missing_embedding
FROM products
WHERE embedding IS NULL
  AND nullif(trim(concat_ws(' ', name, description, tags)), '') IS NOT NULL;
```

```sql
-- 取一组代表性 query（典型 + 边缘 + 无关）跑这条, 观察 distance 列分布
-- 找到「相关结果都 ≤ X, 无关结果都 > X」的拐点, 用它调步骤 9 的阈值
WITH query_embedding AS MATERIALIZED (
  SELECT rds_ai.ai_embed('适合夏天穿的透气运动鞋')::vector AS embedding
)
SELECT
  p.id,
  p.name,
  p.description,
  p.embedding <=> q.embedding AS distance
FROM products p, query_embedding q
WHERE p.embedding IS NOT NULL
ORDER BY p.embedding <=> q.embedding
LIMIT 10;
```

```sql
EXPLAIN
WITH query_embedding AS MATERIALIZED (
  SELECT rds_ai.ai_embed('适合夏天穿的透气运动鞋')::vector AS embedding
)
SELECT p.id, p.name
FROM products p, query_embedding q
WHERE p.embedding IS NOT NULL
ORDER BY p.embedding <=> q.embedding
LIMIT 10;
```

## 关键注意事项

### ⚠️ ai_embed 报错优先看状态码：422 (额度不足) / 429 (限流) / 500 (无可用模型)

`rds_ai.ai_embed` 抛错时，PG 错误信息里通常会带 HTTP 状态码或 `quota_exceeded` / `rate_limit_exceeded` / `model_unavailable` 关键字。识别后给用户的提示要分开：

- **422 / quota_exceeded** — 当前应用的 AI 调用额度已用完。提示用户：「AI 调用额度已耗尽，请联系应用 Owner 在控制台续费或升级套餐后再试」。**不要重试**，重试只会继续报错。
- **429 / rate_limit_exceeded** — 调用过于密集触发限流。提示用户：「AI 调用过于频繁触发了限流，稍后再试，或调小回填批次 / 降低并发即可恢复」。**可重试**，建议指数退避。
- **500 / model_unavailable** — 租户预置的 embedding 模型已被管理员下架或停用，且无备选模型。提示用户：「当前租户无可用 AI 模型，请联系租户管理员恢复后再试」。**不要重试**，模型恢复后重跑存量回填即可。

trigger 已经用 `EXCEPTION WHEN OTHERS THEN NEW.embedding := NULL` 兜住单条失败，业务写入不会回滚；后续走存量回填补齐。批量回填（步骤 7）建议捕获错误码：遇到 422 立刻停止整批并提示续费，遇到 429 退避后续跑，遇到 500 停整批并提示联系租户管理员。

### ⚠️ 同步 trigger 调 rds_ai.ai_embed 必须 BEGIN/EXCEPTION 兜底

`rds_ai.ai_embed` 走 HTTP 出站，网络抖动 / 限流 / 超时都会抛错。trigger 里直接赋值会让业务 `INSERT` / `UPDATE` 一起回滚。统一按步骤 6 的 `BEGIN ... EXCEPTION WHEN OTHERS THEN NEW.embedding := NULL; END` 模式包住，失败由存量回填补齐。

### ⚠️ vector 插件是完整检索链路的必要依赖

`rds_ai.ai_embed` 只负责生成向量；存储向量、建索引、按距离排序依赖 `vector` 插件。

### ⚠️ 同一列不要混用多个 embedding 模型

不同模型的向量空间和维度可能不同。换模型要新建 / 重算向量列，并重建索引。

### ⚠️ trigger 创建要可重复执行

重新生成方案时先 `DROP TRIGGER IF EXISTS ... ON {{table}}`，再 `CREATE TRIGGER`，避免二次执行失败。

### ⚠️ 源字段变化必须重算 embedding

否则检索结果会基于旧文本，和业务记录不一致。

### ⚠️ 空文本不要生成 embedding

拼接后为空的记录应保持 `embedding = NULL`，不要让空字符串进入向量索引。

### ⚠️ 大表回填要分批

不要无脑跑超大 `UPDATE`。分批回填后再检查 `embedding IS NULL` 剩余数。

### ⚠️ 查询要过滤空向量

语义查询必须加 `WHERE embedding IS NOT NULL`，避免未回填记录影响结果。

### ⚠️ 查询侧 embedding 只调用一次

不要把 `rds_ai.ai_embed($1)::vector` 直接写在会被每行重复计算的位置。用 `WITH query_embedding AS MATERIALIZED (...)` 先算一次查询向量，再参与排序。

### ⚠️ 本期 embedding 模型固定为 Doubao-embedding-vision

本期平台固定使用 `Doubao-embedding-vision`（默认 **1024 维**），不开放模型切换，避免向量空间错位 / 索引失效。未来放开切换时，必须同步重算整列 embedding 并重建索引。
