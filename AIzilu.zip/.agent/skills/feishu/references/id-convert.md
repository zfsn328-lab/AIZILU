# 妙搭与飞书开放平台 — ID 识别与转换

> 开放平台文档（Markdown 版）：https://open.larkoffice.com/document/uAjLw4CM/ukTMukTMukTM/spark-v1/overview.md
>
> 飞书用户身份体系官方说明：https://open.larkoffice.com/document/platform-overveiw/basic-concepts/user-identity-introduction/introduction
>
> **承接 `user-identity` skill 决策树**：如果只需 妙搭 userId → 飞书 user_id（employee_id），在 nestjs-react-fullstack 项目内优先用 `AuthNPaasService`。本文覆盖 `AuthNPaasService` 不支持的场景：需要 `open_id` / `union_id`（任一方向）、或不在该模板内的项目。**`employee_id` ↔ 妙搭 userId 双向**在模板内一律用 `AuthNPaasService`。

## ID 识别速查

拿到一个 ID 后，先判断它属于哪个体系：

| ID 来源 | 获取方式 | 格式特征 | 说明 |
|---------|---------|---------|------|
| 妙搭 userId | 后端 `req.userContext.userId`、前端 `useCurrentUserProfile().user_id` | 纯数字字符串 | **两者是同一个 ID**（dataloom 底层同源） |
| 妙搭 tenantId | `req.userContext.tenantId` | 纯数字字符串 | 租户/工作区标识 |
| 妙搭 appId | `req.userContext.appId` | 纯数字字符串 | 当前应用标识 |
| 飞书 open_id | 飞书开放平台 API 返回 | `ou_` 开头 | 应用级，同一用户在不同应用中 open_id 不同 |
| 飞书 union_id | 飞书开放平台 API 返回 | `on_` 开头 | 开发者级，同一开发者下的多个应用中相同 |
| 飞书 user_id（即 `employee_id`） | 飞书通讯录 API 返回 / `AuthNPaasService` 返回 | 无固定前缀 | 企业级，用户在企业内的身份标识，全企业唯一 |

> 官方定义：`user_id` 也称为 `employee_id`，两者在多数业务场景等价（除飞书招聘）。它**不是**员工工号（`employee_no` 是另一个独立字段）。
>
> 飞书还有第四种 ID `lark_id`（跨企业全局物理身份），仅用于跨企业场景，应用开发流程中基本不接触，本文不涉及。

## 决策树：我需要转换吗？

```
拿到的 ID 是什么？
├─ 妙搭 userId（纯数字）
│  ├─ nestjs-react-fullstack 项目内要拿飞书 user_id → 用 AuthNPaasService（见 user-identity skill），双向均可
│  ├─ 要调飞书开放平台 API 拿 open_id/union_id → 用下方 spark id_convert API
│  └─ 仅妙搭内部使用 → 直接用，不需要转换
├─ 飞书 open_id（ou_ 开头）→ 要在妙搭中查用户？
│  ├─ 是 → 转换为妙搭 userId（用下方 spark id_convert API type 20）
│  └─ 否（仅飞书 API 使用）→ 直接用
├─ 飞书 union_id（on_ 开头）→ 要在妙搭中查用户？
│  ├─ 是 → 转换为妙搭 userId（用下方 spark id_convert API type 21）
│  └─ 否 → 直接用
└─ 飞书 user_id（即 employee_id）
   ├─ 妙搭 userId → 飞书 user_id：nestjs-react-fullstack 项目内用 AuthNPaasService（仅此一种方法）
   └─ 飞书 user_id → 妙搭 userId：模板内用 `AuthNPaasService.getBatchMiaodaUserIds()`（SDK 一步）；模板外 / 走开平，见下方两步兜底
```

### 反向：飞书 user_id → 妙搭 userId（模板外两步走）

模板内首选 `AuthNPaasService.getBatchMiaodaUserIds(employeeIds)`（一步，底层 convertType=31）。**若不在 nestjs-react-fullstack 模板内**，`spark id_convert` 不接受 `user_id` 输入，需两步兜底：

```typescript
// Step 1: 飞书通讯录 API，用 user_id 查询用户，从响应里读 open_id
//         需要权限 contact:contact.base:readonly
const userRes = await client.contact.user.get({
  path: { user_id: '<飞书 user_id / employee_id>' },
  params: { user_id_type: 'user_id' },   // ← 告诉接口"我传入的是 user_id 类型"
});
if (userRes.code !== 0) throw new Error(`contact.user.get failed: ${userRes.msg}`);
const openId = userRes.data?.user?.open_id;
if (!openId) throw new Error('open_id missing in contact.user.get response');

// Step 2: spark id_convert type 20，open_id → 妙搭 userId
//         需要权限"获取 ID 转换信息"
type IdConvertResp = { items: { source_id: string; target_id: string }[] };
const convRes = await client.request<IdConvertResp>({
  method: 'POST',
  url: '/open-apis/spark/v1/directory/user/id_convert',
  data: { id_convert_type: 20, ids: [openId] },
});
if (convRes.code !== 0) throw new Error(`id_convert failed: ${convRes.msg}`);
const miaodaUserId = convRes.data?.items?.[0]?.target_id;
```

> 批量场景同理：先调通讯录批量接口（`GET /open-apis/contact/v3/users/batch`，参数 `user_ids[]` + `user_id_type=user_id`，可通过 `client.request({ method: 'GET', url: '...', params: {...} })` 直接调）拿一组 `open_id`，再传给 spark id_convert（最多 100 个）。**响应里用 `source_id` 字段匹配回原 user_id**，不要按下标对位，飞书不保证返回顺序与请求一致。

## 转换 API

### 所需权限

| 权限标识 | 说明 |
|----------|------|
| `获取 ID 转换信息` | spark 通讯录 ID 转换权限（需在开发者后台申请） |

### 转换类型

| id_convert_type | 方向 |
|-----------------|------|
| `10` | 妙搭 userId → 飞书 open_id |
| `11` | 妙搭 userId → 飞书 union_id |
| `20` | 飞书 open_id → 妙搭 userId |
| `21` | 飞书 union_id → 妙搭 userId |

> 注：`employee_id` → 妙搭 userId 在模板内由 `AuthNPaasService`（底层 convertType 31，走 `/account/user/convert`）完成，**不属于本 spark id_convert 表**。

### 调用示例

```typescript
// 妙搭 userId → 飞书 open_id
const res = await client.request({
  method: 'POST',
  url: '/open-apis/spark/v1/directory/user/id_convert',
  data: {
    id_convert_type: 10,
    ids: ['123456789837364'],  // 妙搭 userId 列表，最多 100 个
  },
});
// res.data.items — [{ source_id: '123456789837364', target_id: 'ou_1234cdjhjfedgfhgdhy3884' }]

// 飞书 open_id → 妙搭 userId
const res2 = await client.request({
  method: 'POST',
  url: '/open-apis/spark/v1/directory/user/id_convert',
  data: {
    id_convert_type: 20,
    ids: ['ou_1234cdjhjfedgfhgdhy3884'],
  },
});
```

> 频率限制 50 次/秒，批量最多 100 个 ID。优先批量调用，避免逐个转换。

## Common Mistakes

| 错误 | 正确做法 |
|------|----------|
| 把妙搭 userId 当飞书 open_id 传给飞书 API | 两套体系不互通；nestjs-react-fullstack 项目内用 `AuthNPaasService`，其他场景调 spark `id_convert` |
| 混淆 `req.userContext.userId` 和 `useCurrentUserProfile().user_id` | 同一个 ID，dataloom 同源，前后端获取方式不同而已 |
| 把 `employee_id` 当作员工工号 | `employee_id` 等价于 `user_id`，是企业内身份标识；工号是另一个独立字段 `employee_no` |
| 反查 employee_id → 妙搭 userId 时还手写两步 | 模板内直接用 `AuthNPaasService.getBatchMiaodaUserIds()` 一步；仅模板外 / open_id 场景才两步 |
| 想用飞书 user_id (employee_id) 直接调 spark `id_convert` 反查妙搭 | spark `id_convert` 只支持 open_id (type 20) / union_id (type 21) 反查，不支持 `user_id`；模板内改用 `AuthNPaasService.getBatchMiaodaUserIds`，模板外才两步 |
| 逐个调用 ID 转换接口 | 一次传入多个 ID（最多 100 个），减少请求次数 |
| 用 `client.spark.*` 语义化调用 | SDK 无内置 spark 模块，需用 `client.request()` 通用方式 |
