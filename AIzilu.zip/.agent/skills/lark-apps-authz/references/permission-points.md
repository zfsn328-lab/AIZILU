# 权限点位表建表 DDL（PERM_CREATE_TABLE）

首次启用动态权限点位时执行。通过 `lark-cli apps +db-execute --app-id "$app_id" --sql "<ddl>" --yes` 下发；
SQL 执行通道、建表规范与高风险授权要求以 `lark-apps-db` skill 为准。

## 两张表

```sql
CREATE TABLE IF NOT EXISTS authz_permissions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  action VARCHAR(100) NOT NULL,
  subject VARCHAR(100) NOT NULL,
  description TEXT DEFAULT '',
  creator user_profile NOT NULL,
  _created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
  _created_by user_profile,
  _updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
  _updated_by user_profile,
  UNIQUE(action, subject)
);

CREATE TABLE IF NOT EXISTS authz_role_permissions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  role_key VARCHAR(100) NOT NULL,
  permission_id UUID NOT NULL REFERENCES authz_permissions(id) ON DELETE CASCADE,
  creator user_profile NOT NULL,
  _created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
  _created_by user_profile,
  _updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
  _updated_by user_profile,
  UNIQUE(role_key, permission_id)
);
```

## 两条必读约束

> **RLS 与默认 policy**：以上仅为业务列示意，实际建表必须按 `lark-apps-db` skill 的 CREATE TABLE Template 在**同一次 `+db-execute` 调用**中补齐 `ENABLE ROW LEVEL SECURITY` 和 4 条默认 policy（两张表都要），并在执行前取得用户授权。

> **`role_key` ↔ 角色 ID**：`authz_role_permissions.role_key` 存储的值必须等于角色的 role_id（`+role-create --role-id` 传入的值，或平台分配后从 `+role-list` 读到的值）。两者是同一个标识，INSERT 映射时 `role_key` 填 `'admin'`、`'editor'` 等角色 ID，运行时鉴权也用它匹配用户拥有的角色。
