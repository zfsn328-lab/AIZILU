---
name: authz-cli
description: "Use when AI Agent needs to run miaoda-auth-cli commands in sandbox to manage roles, or run `miaoda db sql` in sandbox to manage permission point tables (create, seed, add, update, delete). All commands are executed by the Agent in its sandbox terminal. NOT for writing permission control code — CanRole/@Can coding should use authz-guide skill instead. 触发词：miaoda-auth-cli, authz-cli, 查询角色列表, 模拟角色, 创建角色, 批量创建角色, 权限点位, 权限表, 新增点位, 更新点位, 删除点位, role mock, role list CLI"
control-by-feature-ab: true
---

# authz CLI — 权限管理工具

Agent 在沙箱内直接执行的权限管理工具集，包含两部分能力：

- **角色管理**：通过 `miaoda-auth-cli` 命令管理角色（查询、创建、更新、模拟）
- **权限点位管理**：通过 `miaoda db sql` 管理权限表和数据（建表、新增/更新/删除点位、管理映射）。SQL 执行通道与建表规范以 `miaoda-sql` skill 为准

## 工具边界

| 场景 | 正确做法 |
|------|----------|
| Agent 查询系统已有哪些角色 | `miaoda-auth-cli role list --output json` |
| Agent 创建/更新角色 | `miaoda-auth-cli role create/update` |
| Agent 模拟角色测试权限 | `miaoda-auth-cli role mock` |
| 创建 authz_permissions/authz_role_permissions 表 | `miaoda db sql` 执行 DDL |
| 开发阶段新增/更新/删除权限点位 | `miaoda db sql` 执行 INSERT/UPDATE/DELETE |
| 开发阶段初始化或调整角色-点位映射 | `miaoda db sql` 执行 INSERT/DELETE |
| 运行态调整角色-点位映射（勾选/取消） | 由应用管理页面处理，**不属于** Agent 职责 |
| **应用前端**需要权限控制 | 使用 `<CanRole>` 或 `<Can>` 组件（参考 `authz-guide` skill） |
| **应用后端**需要权限控制 | 使用 `@CanRole` 或 `@Can` 装饰器（参考 `authz-guide` skill） |

> **禁止**在生成的应用代码（前端/后端）中调用 `miaoda-auth-cli`。CLI 命令只在 Agent 对话终端中执行。

> 始终使用 `--output json` 获取结构化响应，便于解析和后续处理。

## Action 决策流程

### Action 类型与触发场景

| Action | 触发场景 | 对应操作 |
| ------ | -------- |---------|
| QUERY | 需要了解当前系统已有哪些角色 | `miaoda-auth-cli role list --output json` |
| CREATE | 查询后发现所需角色不存在，需按设计方案批量创建 | `miaoda-auth-cli role create --name "..." --biz-id "..." --output json` |
| UPDATE | 需要修改已有角色的名称或描述 | `miaoda-auth-cli role update --from-biz-id "..." --name "..." --output json` |
| MOCK | 用户需要测试特定角色的权限效果 | `miaoda-auth-cli role mock --user-id "..." --roles "..." --output json` |
| PERM_CREATE_TABLE | 首次启用动态权限：创建 authz_permissions/authz_role_permissions 表 | `miaoda db sql` 执行 DDL |
| PERM_SEED | 初始化权限点位和角色-点位映射数据 | `miaoda db sql` 执行 INSERT |
| PERM_ADD | 新增权限点位（新功能上线时） | `miaoda db sql` 执行 INSERT + 同步更新 `@Can`/`<Can>` 代码 |
| PERM_UPDATE | 修改权限点位的 action/subject/description | `miaoda db sql` 执行 UPDATE + 同步更新 `@Can`/`<Can>` 代码 |
| PERM_DELETE | 删除权限点位（功能下线时） | `miaoda db sql` 执行 DELETE（级联删除映射）+ 移除 `@Can`/`<Can>` 代码 |

### 决策流程图

```text
权限设计方案
    │
    ├─ 推荐模式：静态角色鉴权
    │   └─ 新建 ──→ 按角色清单逐个 CREATE ──→ 编写 CanRole 代码（authz-guide）
    │
    ├─ 推荐模式：动态权限点位鉴权
    │   ├─ 新建 ──→ CREATE 角色 → PERM_CREATE_TABLE → PERM_SEED → 编写 @Can 代码（authz-guide）
    │   └─ 升级（仅限历史 CanRole 代码迁移）──→ PERM_CREATE_TABLE → PERM_SEED → CanRole 升级为 Can（authz-guide）
    │
    ├─ "给某功能加权限控制" / "新建某个角色"
    │   └──→ QUERY（查询角色）
    │         ├─ 角色存在 ──→ 编写鉴权代码（authz-guide）
    │         └─ 角色不存在 ──→ CREATE ──→ 编写鉴权代码
    │
    ├─ "新功能上线，需要新增权限点位" ──→ PERM_ADD + 同步 @Can/<Can> 代码
    │
    ├─ "功能下线，删除权限点位" ──→ PERM_DELETE + 移除 @Can/<Can> 代码
    │
    ├─ "修改角色信息" ──→ UPDATE
    │
    └─ "测试某角色权限" ──→ MOCK
```

### 关键约束

**角色设计由权限设计方案承载**，本 skill 负责角色 CLI 操作和权限点位管理。

**日常权限开发流程**：QUERY → 判断是否 CREATE → 编写鉴权代码（参考 `authz-guide`）。

**动态权限点位初始化流程**：CREATE 角色 → PERM_CREATE_TABLE → PERM_SEED → 编写鉴权代码。

**权限点位变更**：PERM_ADD / PERM_UPDATE / PERM_DELETE **必须同步更新** `@Can`/`<Can>` 代码，确保数据库点位定义与代码中的鉴权声明一致。

---

## CLI 命令参考

### 创建角色

```bash
miaoda-auth-cli role create \
  --name "管理员" \
  --description "拥有全部管理权限" \
  --biz-id "admin" \
  --output json
```

**参数：**

- `--name`（必需）：角色名称
- `--biz-id`（必需）：角色业务 ID（snake_case）
- `--description`（可选）：角色描述
- `--output`（可选）：输出格式（json: JSON 格式）

### 更新角色

```bash
miaoda-auth-cli role update \
  --from-biz-id "admin" \
  --name "管理员（全局）" \
  --description "拥有全部管理权限，含组织维度配置" \
  --output json
```

**参数：**

- `--from-biz-id`（必需）：当前角色业务 ID
- `--name`（必需）：角色名称
- `--description`（可选）：角色描述
- `--biz-id`（可选）：新角色业务 ID
- `--output`（可选）：输出格式（json: JSON 格式）

### 查询角色列表

```bash
# JSON 输出（Agent 推荐）
miaoda-auth-cli role list --output json

# 仅输出角色 bizID 列表
miaoda-auth-cli role list --output biz-id
```

**参数：**

- `--output`（可选）：输出格式（json / biz-id）

### 模拟用户角色

```bash
# 为指定用户配置模拟角色集
miaoda-auth-cli role mock \
  --user-id "7100000000000000001" \
  --roles "admin,ops,viewer" \
  --output json

# 清空某个用户的所有模拟角色
miaoda-auth-cli role mock --user-id "7100000000000000001" --roles ""
```

**参数：**

- `--user-id`（必需）：用户 ID
- `--roles`（必需）：逗号分隔的角色 bizID 列表
- `--output`（可选）：输出格式（json: JSON 格式）

### 按设计方案批量创建

当权限设计方案已输出角色清单（含 name、bizId、description）时，按清单顺序逐个创建：

```bash
# 按角色清单顺序执行，每个角色一条命令
miaoda-auth-cli role create --name "读者" --biz-id "reader" --description "浏览图书与分类，发起借阅" --output json
miaoda-auth-cli role create --name "图书编辑" --biz-id "editor" --description "负责图书内容的创建与维护" --output json
miaoda-auth-cli role create --name "管理员" --biz-id "admin" --description "拥有所有业务管理权限" --output json
```

> 创建完所有角色后，按权限设计方案的功能权限映射表编写鉴权代码（参考 `authz-guide`）。

## 权限点位管理（`miaoda db sql`）

> **SQL 执行通道**：所有 DDL/DML 只用 `miaoda db sql "<query>"` 执行，不要调用其它 SQL 工具。建表规范（审计列、RLS、默认 policy、`IF NOT EXISTS`）、DML 规则与高风险授权要求**参阅 `miaoda-sql` skill**。

> **职责边界**：
> - **开发阶段（Agent）**：通过 `miaoda db sql` 对 `authz_permissions`（点位定义）和 `authz_role_permissions`（角色-点位映射）两张表做 CURD，含建表、预填、点位增删改、初始映射调整。
> - **运行态（管理页面）**：只提供受限能力——角色-点位映射的勾选/取消。**禁止**管理页面提供权限点位本身的新增/删除功能（点位增删属于代码变更范畴，必须回到开发阶段走 `miaoda db sql` + 同步 `@Can`/`<Can>`）。

> **⚠️ 双表原则**：权限点位涉及 `authz_permissions`（点位定义）和 `authz_role_permissions`（角色-点位映射）两张表，初始化和变更时**必须同时处理两张表**，禁止只操作其中一张。

### PERM_CREATE_TABLE — 建表

首次启用动态权限点位时执行：

```sql
CREATE TABLE IF NOT EXISTS authz_permissions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  action VARCHAR(100) NOT NULL,
  subject VARCHAR(100) NOT NULL,
  description TEXT DEFAULT '',
  creator user_profile NOT NULL,
  _created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
  _created_by user_profile,
  _updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
  _updated_by user_profile,
  UNIQUE(action, subject)
);

CREATE TABLE IF NOT EXISTS authz_role_permissions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  role_key VARCHAR(100) NOT NULL,
  permission_id UUID NOT NULL REFERENCES authz_permissions(id) ON DELETE CASCADE,
  creator user_profile NOT NULL,
  _created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
  _created_by user_profile,
  _updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
  _updated_by user_profile,
  UNIQUE(role_key, permission_id)
);
```

> **RLS 与默认 policy**：以上仅为业务列示意，实际建表必须按 `miaoda-sql` skill 的 CREATE TABLE Template 在**同一次 `miaoda db sql` 调用**中补齐 `ENABLE ROW LEVEL SECURITY` 和 4 条默认 policy（两张表都要），并在执行前取得用户授权。

> **`role_key` ↔ 角色 bizID**：`authz_role_permissions.role_key` 存储的值必须等于角色的业务 ID（即 `miaoda-auth-cli role create --biz-id` 传入的值）。两者是同一个标识，INSERT 映射时 `role_key` 填 `'admin'`、`'editor'` 等 bizID，运行时鉴权也用它匹配用户拥有的角色。

### PERM_SEED — 预填初始数据

按权限设计方案的「权限点位定义」和「角色-点位初始映射」表预填：

```sql
-- 按「权限点位定义」表
INSERT INTO authz_permissions (action, subject, description) VALUES
  ('read', 'Task', '查看任务'),
  ('create', 'Task', '创建任务'),
  ('update', 'Task', '编辑任务'),
  ('delete', 'Task', '删除任务');

-- 按「角色-点位初始映射」表
INSERT INTO authz_role_permissions (role_key, permission_id) VALUES
  ('admin', (SELECT id FROM authz_permissions WHERE action='read' AND subject='Task')),
  ('admin', (SELECT id FROM authz_permissions WHERE action='create' AND subject='Task')),
  ('member', (SELECT id FROM authz_permissions WHERE action='read' AND subject='Task'));
```

> 以上 SQL 仅为示例，实际数据根据权限设计方案生成。

### PERM_ADD — 新增权限点位

新功能上线时，新增点位 + 初始映射 + 同步鉴权代码：

```sql
-- 1. 新增点位定义（authz_permissions 表）
INSERT INTO authz_permissions (action, subject, description) VALUES
  ('export', 'Task', '导出任务');

-- 2. 为需要该权限的角色添加映射（authz_role_permissions 表）
INSERT INTO authz_role_permissions (role_key, permission_id) VALUES
  ('admin', (SELECT id FROM authz_permissions WHERE action='export' AND subject='Task'));
```

> **必须同步**：
> - 在后端对应的 Controller 方法上添加 `@Can('export', 'Task')`，前端添加 `<Can action="export" subject="Task">`
> - **禁止**只插入 authz_permissions 而不处理 authz_role_permissions，否则新点位无任何角色拥有

### PERM_UPDATE — 修改权限点位

修改已有点位的 action、subject 或 description：

```sql
-- 修改 authz_permissions 表（authz_role_permissions 通过外键 permission_id 关联，无需修改）
UPDATE authz_permissions SET description = '导出任务列表为 Excel' WHERE action = 'export' AND subject = 'Task';
```

> 如果修改了 action 或 subject，**必须同步更新**所有引用该点位的 `@Can`/`<Can>` 代码。authz_role_permissions 通过 `permission_id` 外键关联，不受 action/subject 变更影响。

### PERM_DELETE — 删除权限点位

功能下线时，删除点位 + 自动级联删除映射 + 移除鉴权代码：

```sql
-- 删除 authz_permissions 记录，authz_role_permissions 中关联的映射会被 ON DELETE CASCADE 自动删除
DELETE FROM authz_permissions WHERE action = 'export' AND subject = 'Task';
```

> **必须同步**：移除后端的 `@Can('export', 'Task')` 装饰器和前端的 `<Can action="export" subject="Task">` 组件。
> 虽然 authz_role_permissions 会自动级联删除，仍需**确认**不存在其他代码依赖被删除的点位。

---

## 退出码

| 退出码 | 说明 |
| ------ | ---- |
| 0 | 成功 |
| 非 0 | 失败，具体错误信息会在终端输出 |

## Common Mistakes

| 错误 | 正确做法 |
| ---- | -------- |
| 在应用代码中调用 `miaoda-auth-cli` | CLI 仅供 Agent 终端执行；应用代码用 CanRole 组件/装饰器（参考 `authz-guide`） |
| 更新角色时未指定 `--from-biz-id` | 必须通过 `--from-biz-id` 指定要更新的角色 |
| 模拟角色时未正确格式化 `--roles` 参数 | 使用逗号分隔的角色 bizID 列表，如 `admin,ops,viewer` |
| 期望 JSON 输出但未指定 `--output json` | Agent 应始终添加 `--output json` 参数 |
| 只创建角色不编写鉴权代码 | 创建角色后必须编写鉴权代码（参考 `authz-guide`） |
| 没有设计方案就大批量创建角色 | 先确认是否有权限设计方案输出的角色清单，再按清单逐个 CREATE |
| 动态权限点位场景只创建角色不建表预填 | 需要执行 PERM_CREATE_TABLE + PERM_SEED |
| 在管理页面提供权限点位的增删改 | 权限点位的增删改由 Agent 通过 PERM_ADD/UPDATE/DELETE 操作，管理页面只做角色-点位映射 |
| 新增/修改/删除权限点位后不同步代码 | PERM_ADD/UPDATE/DELETE 后**必须同步**更新对应的 `@Can`/`<Can>` 代码 |
| PERM_ADD 只插入 authz_permissions 不插入 authz_role_permissions | 新增点位后必须同时为相关角色添加映射，否则无角色拥有该权限 |
