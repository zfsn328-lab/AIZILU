---
name: user-management-best-practices
description: "Use when 决定是否创建用户表、选择用户唯一标识（user_id vs email/手机号）、设计 user_profile 字段与 UNIQUE 约束、处理防重复提交/upsert 去重，或涉及问卷、抽奖、报名、投票等用户提交场景的表结构设计。触发词：用户管理, 用户表设计, user_id, email, user_profile, 去重, 防重复提交, 批量导入用户, upsert, UNIQUE约束, UserSelect, UserDisplay, user management, deduplication"
steering: true
steering-topic: user_management_best_practices
match-template-name: nestjs-react-fullstack
---

# 用户管理最佳实践指南

## 概述

本指南适用于生成涉及用户管理、问卷、抽奖、报名、投票等用户提交场景的代码。

**核心问题：**

- 妙搭 Agent 无法获取企业的所有用户数据，需要构建应用维度的用户表
- 企业无法显式感知飞书的 user_id（不透明的数字字符串，如 "1847292357012580"），无法批量导入飞书用户到应用的用户表
- 推荐使用邮箱或者手机号作为业务层唯一标识（不是 user_id）
- UserSelect 返回的 IUserProfile 对象已包含 email 和 phone_number 字段，可直接使用

**本指南解决：**

- 何时使用 UserSelect 组件 vs 何时创建用户表
- 如何设计用户业务表（正确的唯一约束）
- 防止重复提交的正确实现方式

---

## 核心原则：禁止事项

| 禁止操作                              | 说明                                                   | 正确做法                                                                                     |
| ------------------------------------- | ------------------------------------------------------ | -------------------------------------------------------------------------------------------- |
| 不推荐实现批量导入用户的功能          | Agent 无法获取企业全量用户，批量 INSERT users 表行不通 | 推荐使用 UserSelect 组件动态选择用户                                                         |
| 不推荐用 user_id 作为去重逻辑         | 企业不感知飞书用户 id，无法感知是谁                    | 使用 email 或者手机号做唯一约束（UNIQUE(email)），不要使用姓名，可能会重复                   |
| 禁止编造 user_id                      | Mock 数据中不能随意编造 user_id 值                     | 必须使用 SQL skill 规定的测试用户列表                                                        |
| 禁止全量查询用户列表                  | 全量拉取数据会导致接口超时或 OOM                       | 使用后端分页查询（skip/take）                                                                |
| 禁止前端分页用户列表                  | 前端分页需要全量拉取数据，导致性能问题                 | 使用后端分页，前端仅控制页码                                                                 |
| 禁止只存 user_id 不存 email or 手机号 | 业务层无法用 user_id 做防重和查询                      | 存储 user_profile 字段（已包含 email/phone），并在表中单独添加 email 或 phone 列用于唯一约束 |

---

## 决策树示例：何时创建用户表 vs 何时使用 user_profile

```text
需要记录用户相关业务数据？
    │
    ├─ 仅需要识别"谁"执行操作（发帖人、评论者）
    │   └─ ✅ 直接使用 user_profile 类型字段
    │       示例：posts.author（user_profile）
    │
    └─ 需要存储业务特定的用户数据
        │
        ├─ 数据与具体业务资源强绑定（问卷提交、抽奖记录）
        │   └─ ✅ 创建业务表 + user_profile 字段 + email 唯一约束
        │       示例：questionnaire_responses (id, respondent, email, UNIQUE(questionnaire_id, email))
        │
        └─ 数据代表"用户在系统中的身份"（员工、学生、会员）
            └─ ✅ 创建人员实体表，user_profile 作为主键
                示例：employees (employee_profile PRIMARY KEY, department, position)
```

---

## 用户列表查询与性能注意事项

### UserSelect vs 分页列表的选择

根据场景选择正确的用户选择方式：

| 场景               | 使用组件         | 数据加载方式 | 典型数量 |
| ------------------ | ---------------- | ------------ | -------- |
| 表单选择用户       | UserSelect       | 搜索驱动     | 1-10     |
| 用户管理后台       | Table + 后端分页 | 分页加载     | 100+     |
| 问卷提交记录列表   | Table + 后端分页 | 分页加载     | 100+     |
| 抽奖参与者名单展示 | Table + 后端分页 | 分页加载     | 100+     |

- **UserSelect 组件**：搜索驱动，返回完整 IUserProfile 对象（含 email、phone_number）。详细用法参考 **client-builtins-user-service**
- **Table + 后端分页**：详细实现参考 **table-skill**

### 分页实现

用户列表必须使用后端分页，禁止前端全量拉取。具体实现参考 **table-skill**。

### 动态创建用户记录

**何时动态创建：**

1. **首次提交场景**：用户首次提交问卷/参与抽奖时，使用 `upsert` 方法
2. **首次登录场景**：用户首次登录系统时，创建用户记录

## 常见错误速查表

| 错误模式                | 问题                   | 正确做法                                                     | 影响        |
| ----------------------- | ---------------------- | ------------------------------------------------------------ | ----------- |
| 批量 INSERT users       | Agent 无法获取全量用户 | 使用 UserSelect 组件                                         | 🔴 CRITICAL |
| `UNIQUE(user_id)`       | 企业不认识 user_id     | `UNIQUE(email)`                                              | 🔴 CRITICAL |
| 编造 user_id            | Mock 数据无效          | 使用测试用户列表                                             | 🔴 CRITICAL |
| 全量查询用户列表        | 接口超时或 OOM         | 使用后端分页（skip/take）                                    | 🔴 CRITICAL |
| 前端分页（全量拉取）    | 首次加载超时           | 使用后端分页                                                 | 🔴 CRITICAL |
| 只存 user_id 不存 email | 无法做业务层防重       | 存储 user_profile（已含 email），并添加 email 列用于唯一约束 | 🟠 BUG      |
| 直接显示 user_id        | 用户体验差             | 使用 UserDisplay 组件                                        | 🟡 UX       |
| 创建 users 基础表       | 无法同步飞书数据       | 使用 user_profile 类型                                       | 🟠 DESIGN   |

## 相关技能参考

- **client-builtins-user-service**: UserSelect 详细用法、IUserProfile 类型定义、UserDisplay 组件、useCurrentUserProfile hook
- **sql**: user_profile 类型约束、JSONB 验证规则、测试用户列表
- **table-skill**: Table 组件使用、后端分页实现、前端分页最佳实践
- **authz-guide**: 结合基于角色的访问控制（如：只允许用户查看/编辑自己的提交）

## 自查清单

### 表设计

- [ ] 判断是否需要创建用户表（参考决策树）
- [ ] 人员实体表使用 `user_profile PRIMARY KEY`
- [ ] 业务表使用 `id UUID PRIMARY KEY` + `user_profile` 字段
- [ ] 业务表包含 `email VARCHAR(255)` or `phone VARCHAR(255)` 字段
- [ ] 设置了正确的唯一约束（使用 email or 手机号，如 `UNIQUE(resource_id, email)`）

### 前端实现

- [ ] 使用 UserSelect 组件而非手动输入
- [ ] 使用 UserDisplay 展示用户（不直接显示 user_id）
- [ ] 用户列表使用后端分页（不全量拉取）
- [ ] Table 组件的 onChange 触发后端请求

### 后端实现

- [ ] Entity 定义了正确的唯一约束（`@Unique(['resourceId', 'email'])` or `@Unique(['resourceId', 'phone'])`）
- [ ] 错误处理包含唯一约束冲突（409 Conflict）
- [ ] 存储 user_profile 字段（已包含 email/phone）
- [ ] 在表中单独添加 email 或 phone 列，用于唯一约束和索引查询
- [ ] 列表接口使用 skip/take 分页查询
- [ ] 返回 pagination 对象（page, pageSize, total）

### Mock 数据

- [ ] user_id 使用测试用户列表（不编造）
- [ ] user_profile 中的 email/phone 与 user_id 对应正确
- [ ] 测试了重复提交场景（唯一约束生效）
