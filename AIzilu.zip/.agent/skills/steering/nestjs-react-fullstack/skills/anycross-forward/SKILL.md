---
name: anycross-forward
description: "Use when generating client-side code that calls an internal / intranet HTTP API through the platform's built-in `/api/__platform__/http-forward` endpoint. 触发词：anycross, http-forward, http forwarder, 内网转发, 内网接口, 内网 API, 请求内网, 请求内网接口, 调用内网接口, 转发到内网, 请求内部接口"
steering: true
steering-topic: anycross_forward
steering-inclusion: manual
match-template-name: nestjs-react-fullstack
available-agents:
  - Code
  - Worker
  - DevOps
  - Reviewer
unavailable-agents:
  - AppInit
---

# anycross-forward 内网请求转发指南

通过平台内置 `/api/__platform__/http-forward` 端点，从前端把请求转发到客户内网地址。后端 SDK 通过 `PlatformModule.forRoot()` **自动装配**，业务零接入；前端用 `axiosForBackend` 调用即可。

> SDK 不感知代理 / 鉴权 / 隧道。实际通路由部署环境（沙箱 mihomo + iptables）处理，生成代码里**不要**拼 `proxy_group_id` / `jwtToken` / `anycross-host`。

## 一、决策树

```text
需要从前端发请求？
    │
    ├─ 目标是平台内置 capability / Dataloom？
    │   └─ 是 ──→ 用对应 SDK，不走 forwarder
    │
    ├─ 目标是公网公共 API（github.com 等）？
    │   └─ 是 ──→ 直接 fetch / axios（不走 forwarder）
    │
    ├─ 目标是客户内网 HTTP/HTTPS API？
    │   └─ 是 ──→ ✅ 用 forwarder：axiosForBackend + `/api/__platform__/http-forward`
    │
    └─ 目标是 ws:// / file:// / 二进制流 / FormData？
        └─ 是 ──→ ❌ 当前版本不支持，回退方案见"限制"小节
```

## 二、Quick reference

| 项           | 值                                                                           |
| ------------ | ---------------------------------------------------------------------------- |
| 端点路径     | `ALL /api/__platform__/http-forward`                                     |
| Query 参数   | `targetUrl` （必填，仅 `http://` / `https://`）                              |
| 前端 SDK     | `axiosForBackend` from `@lark-apaas/client-toolkit/utils/getAxiosForBackend` |
| HTTP method  | 透传：GET / POST / PUT / PATCH / DELETE / HEAD / OPTIONS                     |
| Body 形态    | string / JSON-able object（axios 自动序列化） / null                         |
| Headers      | 自动透传（剔除 hop-by-hop / accept-encoding / host / content-length）        |
| 响应         | 上游 `status` / `headers` / `data` 原样投射                                  |
| 默认超时     | 30000 ms（可在 `PlatformModule.forRoot({ httpForwarder })` 改）              |
| 默认响应上限 | 10485760 bytes (10 MB)                                                       |
| 鉴权         | SDK **不内置**；业务方在路由上加 `@NeedLogin()` 等 guard                     |

## 三、标准前端代码模板

```ts
// client/src/api/corp-api.ts
import { axiosForBackend } from "@lark-apaas/client-toolkit/utils/getAxiosForBackend";

const FORWARD = "/api/__platform__/http-forward";
const BASE = "http://api.corp.com/v1";

// GET — 拉用户列表
export async function fetchUsers() {
  const res = await axiosForBackend.get(FORWARD, {
    params: { targetUrl: `${BASE}/users` },
  });
  return res.data; // 上游真实响应 data
}

// POST — 创建订单，body 直接传对象
export async function createOrder(payload: { qty: number }) {
  const res = await axiosForBackend.post(FORWARD, payload, {
    params: { targetUrl: `${BASE}/orders` },
    headers: { "X-Tenant": "demo" }, // 自定义 headers 自动透传上游
  });
  return res.data;
}

// DELETE — 路径参数拼在 targetUrl 上
export async function deleteOrder(id: string) {
  await axiosForBackend.delete(FORWARD, {
    params: { targetUrl: `${BASE}/orders/${id}` },
  });
}
```

## 四、错误处理模板

> ⚠️ 模板的 `GlobalExceptionFilter`（`server/common/filters/exception.filter.ts`）会把 forwarder 抛的 `HttpException` 重新打包为 `{ error: { code: 'BAD_REQUEST' | 'BAD_GATEWAY' | ..., message, details } }`：顶层 `error.code` 是 HTTP 状态映射，**forwarder 自己的业务码（`INVALID_REQUEST` / `UPSTREAM_TIMEOUT` 等）被 `JSON.stringify` 进 `error.details`**，需要 `JSON.parse` 才能拿到。

```ts
import { axiosForBackend } from "@lark-apaas/client-toolkit/utils/getAxiosForBackend";
import type { AxiosError } from "axios";

type ForwarderInner = { code?: string; message?: string };
type ApiError = {
  error?: { code?: string; message?: string; details?: string };
};

function parseForwarder(err: unknown): ForwarderInner | undefined {
  const details = (err as AxiosError<ApiError>)?.response?.data?.error?.details;
  if (typeof details !== "string") return undefined;
  try {
    return JSON.parse(details) as ForwarderInner;
  } catch {
    return undefined;
  }
}

export async function safeForward(targetUrl: string) {
  try {
    const res = await axiosForBackend.get("/api/__platform__/http-forward", {
      params: { targetUrl },
    });
    // 上游 4xx/5xx 也走这里：res.status 是上游真实 status
    return { ok: true, status: res.status, data: res.data };
  } catch (err) {
    // 只有 forwarder 自身错才走 catch
    const inner = parseForwarder(err);
    switch (inner?.code) {
      case "INVALID_REQUEST":
      case "INVALID_TARGET_PROTOCOL":
        // targetUrl 缺失 / 格式非法 / 协议非 http(s)
        return { ok: false, reason: "targetUrl 配置错误" };
      case "UPSTREAM_TIMEOUT":
        return { ok: false, reason: "上游 30s 超时" };
      case "UPSTREAM_UNREACHABLE":
        // DNS 解析失败 / 连接拒绝 / 网络层不可达；
        // inner.message 形如 "upstream unreachable (ENOTFOUND)"，括号里是 cause code
        return { ok: false, reason: inner.message ?? "上游不可达" };
      case "RESPONSE_TOO_LARGE":
        return { ok: false, reason: "上游响应 > 10MB" };
      default:
        throw err;
    }
  }
}
```

## 五、生成代码必须遵守的 6 条

1. **路径恒为 `/api/__platform__/http-forward`**，HTTP method 来自调用方，service 透传给上游。
2. **`targetUrl` 永远放 `params`**，不要拼到 URL 字符串里、不要放 body、不要放 header。
3. **服务端零接入**——`PlatformModule.forRoot()` 已自动装配 `HttpForwarderModule`，**不要**在用户 `AppModule` 里再写 `HttpForwarderModule.forRoot()`。
4. **前端只用 `axiosForBackend`**，它已带 401 → `x-login-url` 自动跳转拦截器，**不要**再实现登录跳转。
5. **响应原样投射**：`res.status` / `res.headers` / `res.data` 都来自上游真实响应。forwarder 自身错被模板 `GlobalExceptionFilter` 包成 `error.response.data.error`，业务码需从 `error.details`（JSON 字符串）里 parse 出来，详见第四节。
6. **headers 直接走 `headers: {...}`**，无需手剔 `host` / `content-length` / hop-by-hop，service 端会处理。

## 六、Common Mistakes

| ❌ 错误                                                                               | ✅ 正确                                                                                                                        |
| ------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| `axiosForBackend.post('/api/__platform__/http-forward?targetUrl=...')` 手拼 query | `params: { targetUrl }`，让 axios 做 URL 编码                                                                                  |
| `axiosForBackend.post(targetUrl, body)` 把 targetUrl 当路径                           | 路径永远 `/api/__platform__/http-forward`，targetUrl 走 `params`                                                           |
| 用裸 `axios.get('/api/__platform__/http-forward', ...)`（直接 import 'axios'）    | 用 `axiosForBackend`（带 baseURL / 401 拦截器）                                                                                |
| body 传 `FormData` / `Blob` / 流                                                      | v0.1.0 仅支持 string / JSON-able；二进制走 base64 字符串                                                                       |
| 上游 4xx/5xx 被当作转发失败                                                           | 上游响应**原样投射**到 `res`；只有 forwarder 自身错才进 catch，业务码在 `error.response.data.error.details`（需 `JSON.parse`） |
| 用户 `AppModule` 手写 `HttpForwarderModule.forRoot()`                                 | 已被 `PlatformModule` 自动装配，重复注册冲突                                                                                   |
| 拼 `?targetUrl=...&proxy_group_id=xxx&jwt=yyy` 等自定义参数                           | 部署环境接管路由，SDK 不感知；唯一参数是 `targetUrl`                                                                           |
| `targetUrl: 'ws://...'` / `'file://...'`                                              | 仅 `http://` / `https://`，否则 `INVALID_TARGET_PROTOCOL`                                                                      |
| 在生成代码里手动加 `Authorization` 模拟 anycross                                      | 部署环境处理鉴权，业务代码只关心**业务**header                                                                                 |
| 假设响应可流式读取                                                                    | 当前版本响应统一 utf-8 string，不流式                                                                                          |

## 七、限制（v0.1.0）

- **Body**：仅 `string` / JSON-able object / `null`；不支持 binary / FormData / 流
- **响应**：统一 utf-8 string；不支持流式 / 二进制下载
- **不做请求重试**（透传语义，重试由业务方决定）
- **超时 / 响应上限可配**：业务方可在 `PlatformModule.forRoot({ httpForwarder: { requestTimeoutMs, maxResponseBytes } })` 处覆盖默认值
- **错误码 contract**：`INVALID_REQUEST` / `INVALID_TARGET_PROTOCOL` / `UPSTREAM_UNREACHABLE` / `UPSTREAM_TIMEOUT` / `RESPONSE_TOO_LARGE`

## 八、相关

- 后端 SDK 实现：`@lark-apaas/nestjs-http-forwarder`
- 前端 SDK：`axiosForBackend` from `@lark-apaas/client-toolkit/utils/getAxiosForBackend`
- 自动装配点：`@lark-apaas/nestjs-core` 的 `PlatformModule`
- 鉴权约束：参见 `user-identity`——forwarder 不内置鉴权，路由级 `@NeedLogin()` 仍生效
