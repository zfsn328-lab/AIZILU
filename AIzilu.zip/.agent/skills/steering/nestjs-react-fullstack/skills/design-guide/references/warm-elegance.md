---
version: alpha
name: warm-elegance
name_zh: 暖调精致
description: 暖调精致风——暖米/暖灰/暖黄三色渐变页面背景上叠放白色超圆角(32px)卡片,黄色(#FACC15)作为唯一强调色点缀 CTA/活跃态/装饰细节;深色反转区(#2D2D2D)与嵌入深色卡片(#1A1A1A)形成视觉对比层,纤细 pill 型 CSS 柱图/环形进度指示器(border trick)/线性进度条构成数据可视化语言,灰度高对比人物头像(仅内容涉及具体人物时)配渐变遮罩与磨砂玻璃标签点缀。温暖、安心、掌控感。
colors:
  bg: "linear-gradient(to bottom right, rgba(228,229,230,0.6), rgba(250,237,182,0.6), rgba(243,232,203,0.6))"
  surface: "#FFFFFF"
  surface-dark: "#2D2D2D"
  surface-embed: "#1A1A1A"
  text: "#1E293B"
  text-muted: "#9CA3AF"
  text-dim: "#64748B"
  text-body: "#6B7280"
  accent: "#FACC15"
  border: "#F3F4F6"
  positive: "rgb(90,173,112)"
  danger: "#EF4444"
  orange: "#F97316"
typography:
  body:
    fontFamily: 'Inter, "PingFang SC", "Microsoft YaHei", "Noto Sans SC", sans-serif'
    fontWeight: [300, 400, 500, 600, 700]
    usage: 全局唯一字体,覆盖所有文字层级
rounded:
  card: "2rem(32px)"
  embed: "1.5rem(24px)"
  icon-lg: "1rem(16px)"
  icon: "0.75rem(12px)"
  pill: 9999px
spacing:
  content-px: "1rem~2rem(p-4 md:p-8)"
  grid-gap: "1.5rem(24px)"
  section-gap: "2rem~2.5rem(mb-8/mb-10)"
  card-padding: "1.5rem(p-6)"
  goal-gap: "3rem(space-y-12)"
components:
  primary-card:
    background: "{colors.surface}"
    padding: "1.5rem(p-6)"
    borderRadius: "{rounded.card}"
    boxShadow: "shadow-sm,hover=>shadow-md"
    border: "1px solid {colors.border}"
  dark-sidebar:
    background: "{colors.surface-dark}"
    padding: "2rem(p-8)"
    borderRadius: "{rounded.card}"
    boxShadow: shadow-2xl
    decoration: "两处 blur 装饰光晕(左上 80px 白 5%透明/右下 60px 黄 10%透明)"
  embed-card:
    background: "{colors.surface-embed}"
    padding: "1.25rem(p-5)"
    borderRadius: "{rounded.embed}"
    boxShadow: shadow-lg
    hover: "-translate-y-1"
  avatar-card:
    usage: "仅当内容本身涉及具体人物(团队/专访/员工画像)时使用,禁止装饰性占位"
    image: "grayscale contrast-125,group-hover:scale-110 duration-1000"
    mask: "bg-gradient-to-t from-black/80 via-transparent to-transparent"
    status-tag: "磨砂玻璃 bg-white/10 backdrop-blur-md border-white/20,配 {colors.positive} 脉冲点"
    value-pill: "border-white/40 bg-white/5 backdrop-blur-xl rounded-2xl"
  progress-bar:
    light: "h-1 bg-slate-50 rounded-full,填充色 {colors.accent}/slate-800/slate-300"
    dark: "h-1.5 bg-white/10 rounded-full,填充色 {colors.accent}/white 40%透明/{colors.positive}/{colors.danger}(风险severity场景)"
  charts:
    palette: "{colors.accent} {colors.text} #94A3B8 {colors.positive} {colors.danger}"
    bar: "barWidth 12,pill 全圆角[6,6,6,6],默认 #E2E8F0,emphasis {colors.accent}+黄色光晕阴影 shadowBlur 15"
    pie: "环形 radius 60%~75%,padAngle 3,itemStyle 圆角 4,配色 accent/text/#CBD5E1"
    line: "线宽 2px,主序列 {colors.accent},辅助序列 {colors.text-muted}/{colors.text-dim},极简 symbol(直径4px)或无 symbol,区域填充可选 {colors.accent} 8%透明渐变"
    radar: "轴线 {colors.border} 细线,填充 {colors.accent}/{colors.positive} 半透明(opacity 0.15~0.2),圆点 symbol 4px,多序列取色顺序同 charts.palette"
    tooltip: "白底,1px {colors.border} 边框,圆角 16px,box-shadow 0 4px 6px -1px rgba(0,0,0,0.1)"
    axis: "隐藏轴线与刻度,标签 {colors.text-muted} 9px,网格线虚线 {colors.border} 或全隐藏——此克制原则适用于 bar/pie/line/radar 所有图表类型,禁止 ECharts 默认粗轴线/灰色网格"
    legend: "底部,{colors.text-muted} 11px,圆点 icon 8×8"
anchors:
  - id: warm-gradient-bg
    type: token
    desc: 三色暖调 linear-gradient 页面背景(见 colors.bg),奶油/暖灰/暖黄混合 0.6 透明度叠加
  - id: super-rounded-card
    type: token
    desc: 白色卡片一律超圆角(见 rounded.card),嵌入深色卡片圆角略小一档(见 rounded.embed)
  - id: accent-yellow-single
    type: token
    desc: 黄色(colors.accent)是全局唯一强调色,仅用于 CTA/活跃态/装饰细节,不作大面积底色
  - id: dark-inversion-zone
    type: component
    desc: 深色侧边栏(surface-dark)+嵌入深色卡片(surface-embed)在浅色主体旁形成反转对比层
  - id: pill-bar-progress
    type: pattern
    desc: 纤细 pill 型 CSS 柱图/线性进度条/环形指示器(border trick)构成数据可视化语言,非常规图表外观
  - id: grayscale-avatar
    type: component
    desc: 人物头像灰度高对比处理(grayscale contrast-125)配渐变遮罩与磨砂玻璃标签——仅当内容本身涉及具体人物(团队/专访/员工画像)时使用,禁止装饰性占位
gaps:
  - "无暗色模式(dark mode)整体主题切换定义,深色区域为固定局部反转区而非可切换主题"
  - "无表单控件(input/select/checkbox 等)规范"
exceptions:
  - 嵌入式深色卡片圆角用 rounded.embed(24px),不与主卡片 rounded.card(32px)统一
  - 图标容器/列表按钮圆角用 rounded-xl(12px)/rounded-2xl(16px),小于卡片超圆角档位
  - Logo/CTA 按钮/头像/环形指示器一律全圆(rounded.pill),不遵循超圆角档位
  - 内容量较大时可纵向分 section，每段列数与比例按内容关系确定，并保持卡片圆角、深色反转区和强调色语言
---

## Overview

暖调精致风,三色暖调渐变(奶油/暖灰/暖黄各 0.6 透明度)铺满页面背景,承托白色超圆角(32px)卡片构成主内容区,黄色(colors.accent)作为唯一强调色点亮 CTA、活跃态与装饰细节。深色反转区(colors.surface-dark)与嵌入式深色卡片(colors.surface-embed)在浅色主体旁形成层次对比,营造精致感。数据可视化采用纤细 pill 型 CSS 柱图、环形进度指示器(border trick)与线性进度条,替代传统图表语言;人物头像做灰度高对比处理配渐变遮罩,磨砂玻璃标签点缀细节。页面结构由内容决定。情绪基调:温暖、安心、掌控感。

## Colors

| 角色 | 值 | 用法 |
|-----|-----|-----|
| bg | {colors.bg} | 页面暖调渐变背景 |
| surface | {colors.surface} | 白色卡片底 |
| surface-dark | {colors.surface-dark} | 深色反转侧边栏 |
| surface-embed | {colors.surface-embed} | 嵌入式深色卡片 |
| text | {colors.text} | 主要文字 |
| text-muted | {colors.text-muted} | 次要文字、全大写标签 |
| text-dim | {colors.text-dim} | 辅助标签(如进度条数值说明) |
| text-body | {colors.text-body} | 正文默认颜色,比 text-dim 更浅 |
| accent | {colors.accent} | 黄色强调:CTA、活跃态、装饰、图表高亮 |
| border | {colors.border} | 白色卡片浅边框 |
| positive | {colors.positive} | 正向/安全状态、脉冲点、深色区进度填充 |
| danger | {colors.danger} | 紧急/告警标签、图表告警序列色、深色区风险进度填充 |
| orange | {colors.orange} | 数值高亮变体色(Tailwind orange-500 标准值) |

## Typography

全局样式首行原样写入(HARD REQUIREMENT,禁止替换):

```css
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
body { font-family: 'Inter', sans-serif; }
```

唯一字体:**Inter**(拉丁无衬线体,fontFamily 已追加 CJK 兜底 PingFang SC/Microsoft YaHei/Noto Sans SC,系统字体无需 @import)。

| 层级 | 样式(Tailwind) | 颜色 |
|-----|-----|-----|
| 页面大标题 | text-4xl font-semibold tracking-tight | text |
| 大数值 KPI | text-4xl font-light tracking-tight | text / positive / orange |
| 卡片标题 | font-bold tracking-tight | text |
| 卡片副标题 | text-xl font-bold | text |
| 全大写标签 | text-[10px] font-bold uppercase tracking-widest | text-muted |
| 斜体标签 | text-[10px] italic uppercase tracking-[0.2em] | text-muted |
| 正文 | text-sm | {colors.text-body} |
| 数据值 | text-sm font-mono font-bold tracking-tight | text |
| 小标签 | text-[9px]/text-[8px] font-bold uppercase | 按语境变化 |
| 深色区标题 | text-2xl font-bold italic tracking-tighter | surface(白) |
| 深色区进度 | text-3xl font-light font-mono opacity-50 | surface(白) |

## Layout

- 内容容器:p-4 md:p-8,全宽响应式(无 max-width)。
- 可选品牌标识区:左上 Logo pill(bg-black text-white px-5 py-2 rounded-full font-bold text-xl tracking-tighter + 黄色图标 + shadow-lg shadow-black/10);右上仅放报告元信息文字(日期/版本/来源),不放搜索/通知/用户头像等应用操作控件。
- 可用非对称卡片组合制造主次层级，列数、比例、顺序和深色反转区的位置均按内容关系确定。
- 内容量较大时纵向分 section，深色反转区可作为段内卡片、横向强调区或侧边区域，不要求贯穿全高。
- Section 间距 mb-8/mb-10(32~40px)。
- 响应式按内容优先级减少列数，窄屏避免深色区挤压主内容，内容容器从 p-8 收敛至 p-4。

## Elevation & Depth

| 元素 | 值 |
|-----|-----|
| 白色卡片 | shadow-sm,hover => shadow-md |
| 深色侧边区 | shadow-2xl |
| Logo | shadow-lg shadow-black/10 |
| 嵌入深色卡片 | shadow-lg,hover:-translate-y-1 |
| 活跃柱体黄色光晕 | shadow-[0_0_15px_rgba(250,204,21,0.4)] |
| 状态脉冲点绿色光晕 | shadow-[0_0_8px_rgba(90,173,112,0.8)] |

层次感 = 极轻阴影(浅色区)+ 深色实心反转(深色区)+ 局部发光阴影(强调态),不用硬偏移阴影。Hover 交互:白色卡片阴影增强;嵌入深色卡片上移;图片 group-hover:scale-110(1000ms);图标 group-hover 变黄底黑字(500ms);文字 group-hover 变黄;tracking 展开 group-hover:tracking-[0.25em];按钮 active:scale-95。

## Shapes

- 圆角档位:主卡片 {rounded.card}(32px)、嵌入卡片 {rounded.embed}(24px)、图标容器 {rounded.icon}(12px)/{rounded.icon-lg}(16px)、Logo/CTA/头像/环形指示器全圆 {rounded.pill}。
- 边框语言:白色卡片 1px {colors.border}(近乎不可见);深色区域 border-white/10 或 border-dashed border-white/20;列表分隔 border-dashed border-gray-200。
- 装饰元素:磨砂玻璃标签(backdrop-blur-md border border-white/20 bg-white/10);装饰光晕(blur-[80px] bg-white/5 左上 + blur-[60px] bg-accent/10 右下);灰度头像(grayscale contrast-125);渐变遮罩(bg-gradient-to-t from-black/80 via-transparent to-transparent);脉冲动画(animate-pulse 状态点)。
- 环形进度指示器用边框技巧实现:border-[10px] border-accent border-r-transparent rotate-45。

## Components

核心组件规格见 frontmatter components(primary-card / dark-sidebar / embed-card / avatar-card / progress-bar / charts)。补充细节:

- **品牌标识(可选)**:Logo pill(bg-black text-white px-5 py-2 rounded-full font-bold text-xl tracking-tighter + 黄色图标 + shadow-lg shadow-black/10);右上仅放报告元信息文字(日期/版本/来源),不放搜索/通知/用户头像等应用操作控件。
- **人物头像卡片(仅内容涉及具体人物时使用,禁装饰性占位)**:图片容器 rounded-2xl aspect-[4/5];状态标签左上(磨砂玻璃+{colors.positive} 脉冲点);底部信息 flex justify-between(白色名称 text-2xl + 标签 opacity-70 + 数值 pill 磨砂玻璃 rounded-2xl)。
- **列表卡片**:标题 italic underline decoration-accent;告警标签 bg-red-50 text-red-500 rounded-full;列表项图标 bg-slate-50 rounded-xl(group-hover:bg-yellow-50);分隔线 hr border-dashed;底部按钮 rounded-2xl border border-slate-100。
- **柱状图卡片(CSS)**:标题行圆点(w-2 h-2 bg-accent rounded-full)+ ArrowUpRight 图标;柱体区 flex items-end h-32;柱体 max-w-[12px] rounded-full,默认 bg-slate-100,活跃 bg-accent + 黄色光晕 + scale-x-110。
- **日历卡片**:星期头 grid-cols-7 text-slate-300;日期格 w-10 h-10 rounded-xl,活跃日 bg-black text-white ring-4 ring-black/5 scale-110;标记点 absolute -bottom-1(活跃=accent,默认=slate-300)。
- **深色侧边栏目标项**:图标 bg-white/10 rounded-xl(group-hover:bg-white/20);百分比 >50%=accent,<=50%=white/40,风险severity场景改用 danger 填充(如"高危"红色进度条);进度条填充 accent/white-40%/positive/danger;间距 space-y-12;底部 CTA 图标 group-hover:rotate-12,文字 group-hover:tracking-[0.25em]。
- **图表(ECharts)**:序列色按 charts.palette 顺序;bar 为纤细 pill 型(barWidth 12,全圆角);pie 为环形(60%~75%);line/radar 规格见 frontmatter components.charts,一律去除默认粗轴线与灰色网格,风格与 bar/pie 保持一致克制;tooltip/axis/legend 规格见 frontmatter components.charts。

## Do's and Don'ts

- 优先使用设计系统定义的配色变量({colors.accent}/{colors.surface-dark}/{colors.positive} 等),通过透明度与渐变产生层次,保持整体暖色调统一感。
- 数据可视化统一用 ECharts 配合 charts 主题配置,让图表在色彩与圆角上与卡片、进度条等 CSS 组件保持一致,包括 line/radar 等非 bar/pie 图表。
- 保持浅色暖底与深色反转区的对比节奏,用超圆角(32px/24px)与极轻阴影营造柔和、精致的卡片层次。
- 响应式断点内间距可微调;卡片内条目数量可增减;日历月份、进度条/百分比数值均可动态化。
- 不要让黄色强调色覆盖大面积底色,仅用于点状/线状/CTA 场景。

## Hard Rules

- 页面背景必须为三色暖调 linear-gradient({colors.bg}),禁止替换为纯色或其他色系渐变。
- 主卡片圆角必须为 {rounded.card}(32px),禁止使用常规 rounded-lg/rounded-xl 等更小圆角(Exceptions 列明的除外)。
- 强调色必须为 {colors.accent}(#FACC15),且为全局唯一强调色,不得引入第二强调色。
- 页面应保留至少一处深色反转区({colors.surface-dark})或嵌入深色卡片({colors.surface-embed})作为对比锚点；形态和位置按内容决定。
- 字体必须为 Inter,@import 必须原样写入全局样式首行,禁止替换或省略(HARD REQUIREMENT)。
- 任何图表(bar/pie/line/radar)必须遵循 charts 规格去除 ECharts 默认粗轴线与灰色网格,禁止使用未经处理的默认样式。

## Exceptions

- 嵌入式深色卡片圆角用 {rounded.embed}(24px),不与主卡片 {rounded.card}(32px)统一。
- 图标容器/列表按钮圆角用 {rounded.icon}(12px)/{rounded.icon-lg}(16px),小于卡片超圆角档位。
- Logo/CTA 按钮/头像/环形指示器一律全圆({rounded.pill}),不遵循超圆角档位。
- 透明胶带式磨砂玻璃标签自带 backdrop-blur,是允许的模糊效果(不属于阴影)。
- 长内容允许纵向分 section，每段内部按内容关系自适应排列，并保持卡片圆角、深色反转区和强调色语言。

