---
version: alpha
name: organic-minimalism
name_zh: 有机极简
description: 有机极简主义界面风——大面积留白配柔和自然绿调,超大圆角卡片(40-48px)+极简线性图标+无装饰主义排版;单一强调色石灰绿严格聚焦于激活态/CTA/关键结果,全局仅浅阴影(shadow-sm)。自然、轻盈、精确、值得信赖。
colors:
  bg: "#FFFFFF"
  surface: "#F6F7F2"
  header: "#1A1A1A"
  text: "#1A1A1A"
  text-muted: "#9CA3AF"
  accent-bg: "#D8EC9D"
  accent-text: "#B3D166"
  border: "rgba(243, 244, 246, 0.5)"
  hover-bg: "#F3F4F6"
  accent-soft: "rgba(179, 209, 102, 0.3)"
  select-target-hover: "#1F2937"
  select-target-bg: "#111827"
  selection-highlight: "#D1FAE5"
typography:
  base:
    fontFamily: '"Noto Sans SC", sans-serif'
    usage: 全局唯一字体族,标题/正文/数值统一继承(无字体切换);数值以 font-bold 呈现区分,非独立数字字体
  hero-title:
    fontSize: 48px
    fontWeight: 700
    lineHeight: leading-tight
    usage: 页面主标题(Tailwind text-5xl font-bold leading-tight)
  section-title:
    fontSize: 36px
    fontWeight: 700
    usage: 区块标题、转换器数值显示(Tailwind text-4xl font-bold)
  card-title:
    fontSize: 24px
    fontWeight: 700
    usage: 网格卡片标题(Tailwind text-2xl font-bold)
  body:
    fontSize: 18px
    fontWeight: 400
    lineHeight: leading-relaxed
    usage: 描述段落(Tailwind text-lg font-normal leading-relaxed)
  small-label:
    fontSize: 14px
    fontWeight: 500
    usage: 按钮文字、卡片副标题(Tailwind text-sm font-medium)
  breadcrumb:
    fontSize: 12px
    fontWeight: 500
    usage: 面包屑导航、底部版权(Tailwind text-[12px] font-medium)
  micro-label:
    fontSize: 11px
    fontWeight: 700
    letterSpacing: tracking-widest
    upper: true
    usage: 表单标签(uppercase+tracking-widest)、页脚关键词(Tailwind text-[11px] font-bold uppercase tracking-widest)
  pill-select:
    fontSize: 12px
    fontWeight: 700
    usage: 下拉选择器文字(Tailwind text-xs font-bold)
rounded:
  hero: 48px
  panel: 40px
  icon: 16px
  full: 9999px
spacing:
  page-top: 48px
  hero-margin-top: 64px
  hero-padding: "48px~64px"
  grid-margin-top: 96px
  grid-margin-bottom: 128px
  card-padding: 40px
  panel-padding: "32px~48px"
  grid-gap: 24px
  form-group-gap: 48px
  footer-padding: 48px
components:
  cta-button:
    container: flex items-center gap-3 group px-1
    text: "font-bold {colors.text}"
    circle: "w-10 h-10 rounded-full {colors.accent-bg} shadow-sm"
    icon: "w-5 h-5 {colors.text}"
    hover: group-hover:translate-x-1
  learn-more-button:
    container: flex items-center gap-2 group
    text: "text-sm font-medium {colors.text}"
    circle: "w-8 h-8 rounded-full {colors.hover-bg}"
    icon: "w-4 h-4 {colors.text}"
    hover: group-hover:rotate-45
  swap-button:
    container: "w-12 h-12 rounded-full {colors.bg} border border-gray-100 shadow-sm"
    icon: "w-4 h-4 {colors.text-muted}"
    hover: hover:bg-gray-50 hover:scale-110
  category-card:
    radius: "{rounded.panel}"
    padding: "{spacing.card-padding}"
    layout: "h-[320px] flex flex-col justify-between text-left"
    default: "bg={colors.surface},hover:bg-gray-100/50"
    active: "bg={colors.accent-bg}"
    icon-container:
      default: "w-12 h-12 {rounded.icon} bg-transparent {colors.text}"
      active: "w-12 h-12 {rounded.icon} bg-white {colors.text}"
      hover: group-hover:scale-110
    title: "见 {typography.card-title}"
    subtitle: "{colors.text-muted} text-sm mt-1"
    arrow-default: "w-10 h-10 rounded-full bg-white shadow-sm,icon={colors.text-muted}"
    arrow-active: "w-10 h-10 rounded-full bg-white,icon={colors.text}"
    transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
  number-input:
    style: "text-4xl font-bold {colors.text} bg-transparent focus:outline-none w-full"
    placeholder: "0"
    validation: "仅允许数字和小数点 /^-?\\d*\\.?\\d*$/"
    appearance: "-webkit-appearance: none(隐藏浏览器数字控件)"
  unit-select:
    source: "bg={colors.accent-soft},文字色 text-lime-800(源未提供 hex,见 gaps),text-xs font-bold px-4 py-2 rounded-full,hover:bg-lime-primary/50"
    target: "bg={colors.select-target-bg},color=white,text-xs font-bold px-4 py-2 rounded-full,hover:bg={colors.select-target-hover}"
  result-display:
    style: "text-4xl font-bold {colors.accent-text} truncate w-full"
anchors:
  - id: huge-rounded-cards
    type: token
    desc: 全站卡片/面板圆角均为超大有机圆角(见 rounded.hero 与 rounded.panel),取代常规小圆角体系
  - id: lime-accent-single
    type: token
    desc: 唯一强调色石灰绿(accent-bg/accent-text),仅用于激活态、CTA、数值结果,不做大面积铺色
  - id: category-card-active-state
    type: component
    desc: 分类网格卡片默认态暖灰底,激活态整卡切换为强调色底+图标容器反白,是全站唯一的状态切换视觉焦点
  - id: minimal-line-icon
    type: pattern
    desc: 全站图标为极简线性图标,无填充无装饰边框,仅描边呈现
  - id: whitespace-heavy-layout
    type: pattern
    desc: 区块间距远大于常规密度,留白本身是主要视觉语言而非装饰元素
  - id: soft-shadow-only
    type: token
    desc: 全局阴影统一为极轻的 shadow-sm 一档,无重投影、无模糊分级体系
  - id: no-decoration-typography
    type: pattern
    desc: 全站单一无衬线字体族,无手写体/衬线体混排,标题与正文靠字重字号区分而非装饰
gaps:
  - 下拉选择器(来源单位)文字色 class 为 text-lime-800,源未提供对应 hex 值
  - 源文件未提供字体 @import 语句(仅注明字体族名 'Noto Sans SC, sans-serif'),按规范补充标准 Google Fonts 引入,权重覆盖源文件实际使用的 400/500/700(补充项,请确认)
  - 无暗色模式定义
  - 无图表/数据看板组件规范(源为单位转换器工具页,不含图表场景)
  - 无表单校验错误态样式定义(仅数字输入框的格式校验规则,无错误提示视觉)
  - 未指定具体图标库,仅描述为"极简线性图标"(源无实现细节)
exceptions:
  - 互换按钮/圆形图标按钮/下拉选择器 Pill 使用 rounded.full(全圆),不遵循卡片类超大圆角(hero/panel)体系,圆形与卡片是两套独立圆角逻辑
  - 页脚边框(border-t border-gray-100)使用不透明 gray-100,而非 colors.border 的半透明 rgba 值,是全局唯一使用不透明边框色的位置
  - 下拉选择器(来源单位)文字色 text-lime-800 源未给出 hex,未纳入 colors 色板(见 gaps)
---

## Overview

有机极简主义界面风:超大留白 + 单一石灰绿强调色 + 极简线性图标构成自然、轻盈、精确、可信任的基调。整体节奏依赖宽松间距营造呼吸感，而非依赖装饰元素；模块类型和页面结构由任务决定。

## Colors

| 角色 | 值 | 用法 |
|-----|-----|-----|
| bg | {colors.bg} | 页面主背景 |
| surface | {colors.surface} | 卡片/区块底色,带微黄暖灰调(转换器面板/网格卡片默认态) |
| header | {colors.header} | 主标题文字 |
| text | {colors.text} | 正文主色、按钮文字、图标默认色 |
| text-muted | {colors.text-muted} | 辅助说明、副标题、标签文字、非激活箭头图标 |
| accent-bg | {colors.accent-bg} | 石灰绿背景 —— CTA 圆形按钮底色、分类卡片激活态底色 |
| accent-text | {colors.accent-text} | 石灰绿文字 —— 转换结果数值 |
| border | {colors.border} | 转换器面板极淡分割线 |
| hover-bg | {colors.hover-bg} | 悬停态底色、"了解更多"按钮圆形底 |
| accent-soft | {colors.accent-soft} | 下拉选择器(来源单位)背景,石灰绿低透明度 |
| select-target-hover | {colors.select-target-hover} | 下拉选择器(目标单位)悬停色 |
| select-target-bg | {colors.select-target-bg} | 下拉选择器(目标单位)默认背景,深色 |
| selection-highlight | {colors.selection-highlight} | 文本选中高亮(selection:bg) |

## Typography

全局样式首行原样写入(HARD REQUIREMENT,禁止替换;补充项——源文件仅注明字体族名 "Noto Sans SC, sans-serif",未提供 @import 语句,此处按 Google Fonts 标准补充,权重覆盖源文件实际使用的 400/500/700,请确认):

```css
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;700&display=swap');
```

全站单一字体族(见 frontmatter typography.base),无字体切换;数值继承同一字体,仅以 font-bold 呈现区分,非独立数字字体。

| 层级 | 大小 | 字重 | 行高 | 用途 |
|-----|-----|-----|-----|-----|
| Hero Title | 48px(text-5xl) | 700(font-bold) | leading-tight | 页面主标题 |
| Section Title | 36px(text-4xl) | 700(font-bold) | 默认 | 区块标题、转换器数值显示 |
| Card Title | 24px(text-2xl) | 700(font-bold) | 默认 | 网格卡片标题 |
| Body | 18px(text-lg) | 400(font-normal) | leading-relaxed | 描述段落 |
| Small Label | 14px(text-sm) | 500(font-medium) | 默认 | 按钮文字、卡片副标题 |
| Breadcrumb | 12px(text-[12px]) | 500(font-medium) | 默认 | 面包屑导航、底部版权 |
| Micro Label | 11px(text-[11px]) | 700(font-bold) | 默认 | 表单标签(uppercase+tracking-widest)、页脚关键词 |
| Pill / Select | 12px(text-xs) | 700(font-bold) | 默认 | 下拉选择器文字 |

## Layout

- 整体容器可参考 max-w-7xl(1280px) mx-auto px-6，并按内容密度调整。
- 用超大圆角表面承载主任务或重要内容；卡片数量、列数、主次比例和区块顺序不作预设。
- 间距系统:见 frontmatter spacing(page-top / hero-margin-top / hero-padding / grid-margin-top / grid-margin-bottom / card-padding / panel-padding / grid-gap / form-group-gap / footer-padding)。
- 响应式断点按可读性减少列数和内边距，窄屏将相关内容自然重排，不固定为 2/5+3/5 或三列。

## Elevation & Depth

全局保持极轻阴影(仅 shadow-sm),强化通透感,无重阴影/无模糊层级体系:

| 元素 | 阴影值 |
|-----|-----|
| 转换器白色面板 | shadow-sm |
| CTA 圆形按钮 | shadow-sm |
| 非激活卡片箭头按钮 | shadow-sm |
| 互换按钮 | shadow-sm |

无 hover 阴影升级,深度感完全依赖留白与超大圆角,不依赖阴影分级。

## Shapes

- 圆角体系:Hero 卡片 {rounded.hero},转换器面板/网格卡片 {rounded.panel},图标容器 {rounded.icon},圆形按钮/Pill {rounded.full}。全站无常规小圆角(4-8px)卡片,圆角只有"超大"与"全圆"两档。
- 边框:转换器面板 border {colors.border};输入/输出下划线 border-b border-gray-100;互换按钮 border border-gray-100;页脚顶部 border-t border-gray-100。全局边框极淡(gray-100 或 border token 半透明),不用深色描边。
- 图标:极简线性描边图标,无填充/无装饰边框(源未指定具体图标库,见 gaps)。
- 动效:卡片切换 transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);悬停微交互 scale-110 / translate-x-1 / rotate-45,幅度小、无弹跳。

## Components

详见 frontmatter components(cta-button / learn-more-button / swap-button / category-card / number-input / unit-select / result-display)。补充说明:

- CTA 按钮悬停 group-hover:translate-x-1,圆形箭头底色即 accent-bg。
- "了解更多"按钮悬停 group-hover:rotate-45,圆形底色为中性灰 hover-bg,与 CTA 的强调色圆形形成主/次按钮区分。
- Category Card 默认态与激活态是本风格唯一的强调色触发点:默认态用 surface 暖灰,激活态整卡切换为 accent-bg,图标容器同步由透明切换为白底。
- 下拉选择器(来源单位)用 accent-soft(石灰绿 30% 透明度)底,与(目标单位)深色 select-target-bg 底形成"来源=浅绿 / 目标=深灰"的语义区分。

## Do's and Don'ts

- 强调色(accent-bg / accent-text)只用于激活态、CTA、数值结果,不做大面积铺色。
- 卡片/面板圆角保持超大(40px 以上),避免与常规小圆角混用打破"有机"气质。
- 阴影统一用 shadow-sm 级别,不引入更重的投影分级。
- 页面留白节奏(mt-24 / mb-32 等大间距)是气质核心,不为塞入更多内容压缩间距。

## Hard Rules

- 全局唯一强调色为石灰绿(accent-bg / accent-text),不得引入第二种强调色。
- 卡片类圆角(Hero / 面板 / 网格卡片)必须使用 rounded.hero 或 rounded.panel(40px 以上),不得使用常规小圆角。
- 阴影统一 shadow-sm,禁止使用更重的投影或模糊阴影层级。
- 主字体族全局统一为 Noto Sans SC,不得混入手写体/衬线体等其他字体气质。
- @import 字体加载行必须原样保留在全局样式首行,禁止替换或省略(HARD REQUIREMENT)。

## Exceptions

- 互换按钮/圆形图标按钮/下拉选择器 Pill 使用 rounded.full(全圆),不遵循卡片类超大圆角(hero / panel)体系,圆形与卡片是两套独立圆角逻辑。
- 页脚边框(border-t border-gray-100)使用不透明 gray-100,而非 colors.border 的半透明 rgba 值,是全局唯一使用不透明边框色的位置。
- 下拉选择器(来源单位)文字色 text-lime-800 源未给出 hex,未纳入 colors 色板(见 gaps)。
