---
version: alpha
name: crimson-frosted-glass
name_zh: 暗黑毛玻璃
description: 毛玻璃暗色界面风——纯黑底 + 固定模糊背景图 + 三段渐变遮罩,浮层为半透明白毛玻璃卡片(细边框+24px 大圆角+无阴影),红色强调色(#FF4D4D)点缀主数据系列/图标/趋势标记;超大粗体标题(text-5xl~text-7xl,extrabold/black,tracking-tighter);内容采用杂志式层级与错落节奏。高端、沉浸、数据自信。
colors:
  bg: "#000000"
  surface: "rgba(255,255,255,0.05)"
  surface-hover: "rgba(255,255,255,0.10)"
  header-from: "rgba(0,0,0,0.60)"
  header-via: "rgba(0,0,0,0.80)"
  header-to: "#000000"
  text: "#FFFFFF"
  text-60: "rgba(255,255,255,0.60)"
  text-50: "rgba(255,255,255,0.50)"
  text-40: "rgba(255,255,255,0.40)"
  text-30: "rgba(255,255,255,0.30)"
  accent: "#FF4D4D"
  border: "rgba(255,255,255,0.10)"
  icon-bg: "rgba(255,255,255,0.05)"
  button-active-bg: "#FFFFFF"
  button-active-text: "#000000"
  accent-area-top: "rgba(255,77,77,0.30)"
  accent-area-bottom: "rgba(255,77,77,0)"
  inactive-bar: "rgba(255,255,255,0.10)"
  positive: "#4ADE80"
  positive-bg: "rgba(34,197,94,0.20)"
  negative: "#EF4444"
  icon-orange: "#FB923C"
  icon-blue: "#60A5FA"
typography:
  sans:
    fontFamily: 'Inter, sans-serif'
    fontWeight: 400
    usage: 全局唯一字体(Tailwind font-sans),标题字重上探至 800(extrabold)/900(black)
rounded:
  card: 24px
  button-group: 16px
  button: 12px
  icon: 12px
  nav-item: 16px
  trend-tag: 8px
  avatar: 9999px
  tooltip: 12px
  bar-end: "0px 10px 10px 0px"
spacing:
  content-padding-mobile: 16px
  content-padding-desktop: 48px
  section-gap: 32px
  section-gap-lg: 48px
  card-gap: 24px
  header-gap: 32px
  card-padding: 24px
  card-padding-lg: 32px
components:
  glass-card:
    background: "{colors.surface}"
    backdropFilter: "blur(12px)"
    border: "1px solid {colors.border}"
    borderRadius: "{rounded.card}"
    hover: "background→{colors.surface-hover},transition-all duration-300"
  stat-card:
    base: "glass-card p-6 flex flex-col justify-between h-full group"
    top: "标签 text-sm {colors.text-60} tracking-wider uppercase(左)+ 图标容器 p-2 {colors.icon-bg} rounded-xl group-hover:scale-110(右)"
    value: "text-3xl font-extrabold {colors.text}"
    subtitle: "text-sm {colors.text-40}"
    icon: "lucide-react,语义色(icon-orange/icon-blue/negative 等)"
  hero-card:
    base: "glass-card overflow-hidden relative;尺寸按内容和可用空间确定"
    header: "小标签 text-sm {colors.text-40} uppercase tracking-widest + 大数值 text-6xl font-black + 趋势标签({colors.positive}/{colors.positive-bg}/{rounded.trend-tag}) + 时间戳 {colors.text-30}"
    avatars: "flex -space-x-2,头像 w-8 h-8 rounded-full border-2 border-black {colors.surface-hover},计数块 bg-white text-black text-[10px] font-bold"
    chart-layer: "absolute inset-0 top-32,面积图铺满剩余空间"
  navigation:
    base: "使用 {colors.surface} 毛玻璃表面与 {colors.border} 分隔，位置和形态由应用信息架构决定"
    logo: "w-12 h-12 rounded-full border-2 border-white/20,hover:border-white"
    nav-item: "p-4 {rounded.nav-item},激活=bg-white text-black shadow-lg shadow-white/20;非激活={colors.text-40} hover:text-white hover:{colors.icon-bg}"
  time-toggle:
    base: "flex items-center space-x-4 {colors.surface-hover} p-2 {rounded.button-group} backdrop-blur-md"
    active: "px-6 py-2 {rounded.button} {colors.button-active-bg} {colors.button-active-text} font-bold text-sm"
    inactive: "px-6 py-2 {rounded.button} {colors.text-60} font-bold text-sm hover:text-white"
  charts:
    palette: "{colors.accent} {colors.text} #FFA366 #4DFF88(红/白/橙/绿,序列固定顺序)"
    container: "glass-card,{rounded.card},无阴影,p-6(标准)/p-8(大图表)"
    tooltip: "背景 rgba(0,0,0,0.80),{rounded.tooltip},backdrop-blur(8px),文字 {colors.text}"
    axis: "yAxis 默认隐藏标签,xAxis 标签 {colors.text-30},网格线 rgba(255,255,255,0.05)"
    area-fill: "折线区域渐变 {colors.accent-area-top} → {colors.accent-area-bottom}"
    bar: "水平条形,首项(最大值) {colors.accent},其余 {colors.inactive-bar},borderRadius {rounded.bar-end}"
anchors:
  - id: black-glass-base
    type: pattern
    desc: 纯黑背景(colors.bg)+固定模糊背景图+三段渐变遮罩(colors.header-from/via/to)作全页底层,毛玻璃卡片浮于其上
  - id: glass-card-signature
    type: component
    desc: 毛玻璃卡片(components.glass-card)半透明白底+backdrop-blur+细白边框+大圆角(rounded.card),是全页核心识别单元
  - id: crimson-accent
    type: token
    desc: 强调色(colors.accent)专用于主数据系列/图标/趋势标记,点缀式使用不铺大面积
  - id: oversized-heading
    type: pattern
    desc: 页面主标题超大字重(font-extrabold~font-black)搭配 tracking-tighter,弱化词用 text-40 斜体细体
  - id: no-shadow-depth
    type: pattern
    desc: 层次感几乎不依赖阴影,靠毛玻璃透明度分级(surface/surface-hover/border)营造深度
  - id: four-color-chart-sequence
    type: token
    desc: 图表统一序列色(components.charts.palette 红/白/橙/绿固定顺序),不随意扩展色数
gaps:
  - 无表单控件(input/select/checkbox 等)规范
  - 无 Empty/Loading/Error 状态定义
  - 单一暗色主题,无 light mode 定义
  - Sidebar 具体图标集未列出,仅注明限定 lucide-react 图标库
  - 头像图片/背景模糊图片来源未定义,仅注明 URL 可替换
exceptions:
  - 圆形头像/Logo/进度环使用全圆 rounded.avatar,不套用卡片 24px 大圆角体系
  - 导航激活态/移动浮动按钮/滚动条滑块允许有阴影(shadow-lg/shadow-2xl),不受"整体无阴影"规则约束
  - 断点适配下的字号/间距/网格列数、图表高度、Section 子网格列数、背景模糊图片 URL、头像图片 URL、切换按钮数量与文案允许按需微调
  - 图标限定 lucide-react 图标库,可按需更换具体图标
---

## Overview

毛玻璃暗色界面风格。纯黑背景 + 固定模糊背景图 + 三段渐变遮罩打底,浮层为半透明白毛玻璃卡片(细边框+大圆角+无阴影),红色强调色专用于主数据系列/图标/趋势标记的点缀式强调。内容区使用杂志式大小对比和错落节奏，具体导航与模块结构服从任务。情绪基调:高端、沉浸、数据自信。

## Colors

| 角色 | 值 | 用法 |
|-----|-----|------|
| bg | {colors.bg} | 页面背景,纯黑 |
| surface | {colors.surface} | 毛玻璃卡片/Sidebar/图标容器背景 |
| surface-hover | {colors.surface-hover} | 卡片/按钮组 hover 背景 |
| header-from/via/to | {colors.header-from} → {colors.header-via} → {colors.header-to} | 固定背景层三段渐变遮罩 |
| text | {colors.text} | 主要文字 |
| text-60/50/40/30 | {colors.text-60}/{colors.text-50}/{colors.text-40}/{colors.text-30} | 四档次要文字:标签/描述/辅助/极小字 |
| accent | {colors.accent} | 主强调色:数据系列、图标、趋势标记、按钮激活强调 |
| border | {colors.border} | 卡片边框、Sidebar 分隔线 |
| icon-bg | {colors.icon-bg} | 图标容器背景(值同 surface) |
| button-active-bg/text | {colors.button-active-bg}/{colors.button-active-text} | 激活态按钮/浮动按钮反色底 |
| accent-area-top/bottom | {colors.accent-area-top} → {colors.accent-area-bottom} | 面积图渐变填充 |
| inactive-bar | {colors.inactive-bar} | 条形图非强调条 |
| positive/positive-bg | {colors.positive}/{colors.positive-bg} | 趋势正向文字/标签底 |
| negative | {colors.negative} | 趋势负向文字、图标-红色(复用同值) |
| icon-orange/icon-blue | {colors.icon-orange}/{colors.icon-blue} | 辅助图标色 |

## Typography

全局样式首行原样写入(HARD REQUIREMENT,禁止替换):

```css
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
```

| 层级 | 样式 | 颜色 |
|-----|-----|-----|
| 页面主标题 | text-5xl md:text-7xl font-extrabold tracking-tighter leading-none | {colors.text},弱化部分 {colors.text-40} italic font-light |
| Hero KPI 数值 | text-6xl font-black | {colors.text} |
| Section 标题 | text-2xl font-black italic | {colors.text} |
| 卡片内标题 | text-xl font-bold | {colors.text} |
| KPI 数值(卡片) | text-3xl font-extrabold | {colors.text} |
| 标签/分类 | text-sm font-medium tracking-wider uppercase | {colors.text-60} |
| 小标签 | text-sm font-bold uppercase tracking-widest | {colors.text-40} |
| 趋势标签 | text-xs font-bold | {colors.positive},bg {colors.positive-bg},{rounded.trend-tag} |
| 描述文字 | text-lg leading-relaxed | {colors.text-50} |
| 辅助小字 | text-sm | {colors.text-40} |
| 极小字 | text-[10px] uppercase tracking-tighter | {colors.text-30} |
| 按钮文字 | text-sm font-bold | 激活 {colors.button-active-text};非激活 {colors.text-60} |
| 突出标题 | text-4xl font-black uppercase | {colors.text} |

## Layout

- 固定背景层(最底层,均 fixed inset-0 pointer-events-none):模糊图片 opacity-40 + 渐变遮罩 linear-gradient(to bottom, {colors.header-from}, {colors.header-via}, {colors.header-to})。
- 页面模块按业务内容自由组织，可用大小悬殊的毛玻璃卡片形成杂志式焦点；不得固定导航位置、3/4+1/4 分栏、洞察列数或区块顺序。
- 间距:主内容 padding {spacing.content-padding-mobile} → md:{spacing.content-padding-desktop};Section 间 {spacing.section-gap}~{spacing.section-gap-lg};卡片间 {spacing.card-gap};Header 内 gap {spacing.header-gap};卡片内边距 {spacing.card-padding}(标准)/{spacing.card-padding-lg}(大图表)。
- 响应式:宽屏可强化错落层级；窄屏按阅读和操作优先级重排，标题缩放、图例简化，导航采用适合当前应用的移动形态。
- 滚动条:宽 6px,轨道 {colors.bg},滑块 #333,圆角 10px。

## Elevation & Depth

- 整体不依赖阴影分层,靠毛玻璃透明度梯度({colors.surface} → {colors.surface-hover})+ 1px 边框({colors.border})营造深度。
- 例外阴影:导航激活态 shadow-lg shadow-white/20;移动浮动按钮 shadow-2xl;其余元素无阴影。
- Hover:卡片背景微亮(surface→surface-hover),图标 group-hover:scale-110,按钮/导航文字色反转或加深,浮动按钮 hover:rotate-45,过渡统一 transition-all duration-300。

## Shapes

- 圆角体系(全部见 frontmatter rounded):卡片 {rounded.card},按钮组 {rounded.button-group},按钮/图标 {rounded.button}/{rounded.icon},导航项 {rounded.nav-item},趋势标签 {rounded.trend-tag},头像/Logo/进度环 {rounded.avatar}(全圆,例外见 Exceptions),Tooltip {rounded.tooltip},条形图右端 {rounded.bar-end}。
- 边框:卡片 1px solid {colors.border};Sidebar 右边框同色;Logo border-2 border-white/20(hover→border-white);头像堆叠 border-2 border-black;Sidebar 头像 border border-white/20。
- 无手绘/有机形态语言,全部规则矩形/圆形几何。

## Components

frontmatter components 已含核心规格,补充细节:

- **glass-card**:所有卡片基座,毛玻璃背景+细边框+大圆角,无阴影。
- **stat-card**:紧凑数据卡，顶部标签+图标，底部数值+副标题，可按信息关系独立使用。
- **hero-card**:用于主数据焦点的较大卡片，包含面积图背景层和顶部信息层；尺寸和位置按内容决定。
- **navigation**:若业务需要导航，沿用毛玻璃表面、图标容器和反色激活态，不限制侧栏或顶栏。
- **time-toggle**:时间段切换按钮组,激活态反色(白底黑字)。
- **图例**:自定义 HTML/CSS 实现(非 ECharts 内置 legend),水平图例 flex + 圆点色块 + 大写标签;垂直图例 space-y-3 + 圆点+名称+数值。
- **SVG 圆环进度**:relative w-24 h-24,背景环 stroke white/5,进度环 stroke {colors.negative} strokeWidth 3 strokeLinecap round,中心数字 font-bold text-xl。
- **图表(ECharts)**:序列色/容器/Tooltip/坐标轴规则见 frontmatter components.charts;折线默认 smooth+区域渐变,阶梯折线用于辅助系列;饼图环形 55%~73% padAngle 5 无描边;水平条形首项高亮其余灰。

## Do's and Don'ts

- 图表配色优先使用 charts.palette 四色顺序,不随意扩展或调换顺序。
- Hover 交互统一 transition-all duration-300,避免不同组件使用不一致的过渡时长。
- 弱化文字用透明度阶梯(text-60/50/40/30)表达层级,不引入新的灰度色板。
- 大圆角(rounded.card)与强调色(accent)是核心识别特征,新增卡片类组件应延用而非另起圆角值。

## Hard Rules

- 背景必须为纯黑({colors.bg})+固定模糊背景图+三段渐变遮罩,禁止改为浅色或纯色背景。
- 卡片类容器必须使用毛玻璃(components.glass-card):半透明白底+backdrop-blur+细边框+{rounded.card},禁止实色不透明卡片。
- 强调色 {colors.accent} 仅用于主数据系列/图标/趋势标记的点缀式强调,禁止大面积铺色。
- 字体 @import 必须原样写入全局样式首行,禁止替换或省略(HARD REQUIREMENT)。
- 图表序列色必须使用 charts.palette 固定顺序(红/白/橙/绿),禁止引入额外颜色。

## Exceptions

- 圆形头像/Logo/进度环使用全圆 {rounded.avatar},不套用卡片 {rounded.card} 大圆角体系。
- 导航激活态、移动浮动按钮、滚动条滑块允许有阴影(shadow-lg/shadow-2xl),不受"整体无阴影"规则约束。
- 断点适配下的字号/间距/网格列数、图表高度、Section 子网格列数、背景模糊图片 URL、头像图片 URL、切换按钮数量与文案允许按需微调。
- 图标限定 lucide-react 图标库,可按需更换具体图标。
