---
version: "neuform-staff-featured-2026-05-22"
name: cybernetic-vault-terminal
name_zh: 赛博机库
description: "深空蓝黑底的赛博数据终端：亮青蓝为唯一高能强调，深色嵌套面板、等宽技术标签与模块化网格共同形成高信息密度但清晰的操作界面。适合分析、监控、后台、工作流工具与产品展示；动态网格或粒子只作内容后的环境层。"
colors:
  primary: "#0EA5E9"
  secondary: "#FFFFFF"
  accent: "#3B82F6"
  background: "#020617"
  surface: "#0F172A"
  text-primary: "#FFFFFF"
  text-secondary: "#A1A1AA"
  border: "#27272A"
typography:
  display-lg:
    fontFamily: "Inter"
    fontSize: "64px"
    fontWeight: 500
    lineHeight: "1.04"
    letterSpacing: "0"
  body-md:
    fontFamily: "Inter"
    fontSize: "16px"
    fontWeight: 400
    lineHeight: "1.6"
  label-md:
    fontFamily: "JetBrains Mono"
    fontSize: "12px"
    fontWeight: 600
    lineHeight: "1.2"
spacing:
  base: "8px"
  gap: "16px"
  card-padding: "24px"
  section-padding: "80px"
rounded:
  card: "24px"
  control: "23px"
  pill: "9999px"
components:
  card:
    background: "Use the surface token with subtle borders and restrained shadow depth"
    radius: "Match the declared card radius token"
  button:
    background: "Use primary or accent colors for the main action"
    radius: "Use the declared control or pill radius according to component role"
---
# Cybernetic Vault Terminal
Source: Neuform staff featured templates. Author: Aksonvady Phomhome (@aksonvady). Views: 583; favorites: 13; remixes: 2.
Tags: dashboard, animated, webgl, threejs, bento, dither, charts, support.
## Overview
深空蓝黑界面以清晰的信息密度、模块化面板和稳定节奏呈现工作流。亮青蓝只强调关键动作、主指标与当前状态；Inter 承担正文，JetBrains Mono 承担标签和技术元数据。适合产品展示、管理后台、分析体验、监控与支持工具。
## Composition
建立一个明确焦点，并可用不对称模块网格展开内容；保持紧凑导航、嵌套表面和主次指标层级。具体首屏结构和模块顺序由任务决定，窄屏按阅读顺序重排，操作不能因装饰层遮挡。
## Colors
Anchor the palette in primary #0EA5E9, secondary #FFFFFF, accent #3B82F6, background #020617, surface #0F172A, text-primary #FFFFFF. Keep background, surface, text, and border roles distinct so generated layouts retain the same contrast pattern as the source.
## Typography
Use Inter for display moments and Inter for body copy unless the HTML clearly demands a compatible fallback. Labels and technical metadata should use JetBrains Mono or an equivalent mono face.
## Layout
Keep spacing deliberate and stable. Choose grid direction, max-width, card density, and responsive stacking from the content relationships. Source layouts are examples, not structures to reproduce.
## Components
Dashboard, chart, and data panels should preserve their compact operational hierarchy, nested surfaces, and metric emphasis.
## Motion
Preserve existing motion cues such as masked reveals, staggered entrance, hover lift, scroll-triggered transitions, and ambient movement. Keep easing smooth and restrained.
## WebGL & Effects

If the source includes canvas, WebGL, Three.js, gradients, particles, or atmospheric effects, rebuild them as supporting layers behind the content. Keep effects performant, responsive, and secondary to the interface.

## Guardrails
- Do not flatten the source into a generic card grid.
- Do not swap the color mode unless the source clearly supports it.
- Preserve a strong focal signal and the intended visual density without copying a fixed first-viewport composition.
- Keep buttons, cards, and badges aligned to the same radius and border language.
