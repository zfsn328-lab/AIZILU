---
version: alpha
name: nebula-crimson
name_zh: 深红星云
description: >
  高端商务年报美学：权威、庄重、高端科技感。深红 #8B0000 被极度克制地用作点睛色（品牌区块背景、强调数值、进度条、装饰线、hover），
  大面积由白 / 浅灰 #FAFAFA / 近纯黑 #1A0000–#050505 承担，可用全幅明暗区块营造呼吸节奏，但区块数量与顺序服从内容。
  视觉签名是超黑字重（font-black/900）配超紧字距（tracking-tighter）的巨型标题，搭配全大写英文注释标签（uppercase tracking-widest），
  中英双语层次分明。暗区用玻璃态透明白容器（bg-white/5~/20 + backdrop-blur），叠加网格线、carbon-fibre 纹理、径向渐变与品牌色模糊光斑。
colors:
  bg: "#FAFAFA"
  surface: "#FFFFFF"
  header: "#8B0000"
  text: "#111827"
  textMuted: "#9CA3AF"
  accent: "#8B0000"
  border: "#F3F4F6"
  heroDark: "#1A0000"
  outlookDark: "#030712"
  footerDark: "#050505"
  growthText: "#16A34A"
  growthBg: "#DCFCE7"
  lightRedTint: "#FEF2F2"
  gridLine: "#EEEEEE"
  axisLabel: "#999999"
  axisLabelAlt: "#666666"
  seq1: "#8B0000"
  seq2: "#A52A2A"
  seq3: "#CD5C5C"
  seq4: "#E9967A"
  seq5: "#FFA07A"
typography:
  fontImport: "@import url('https://miaoda.feishu.cn/fonts/css2?family=Inter:wght@300;400;500;600;700;900&display=swap');"
  base:
    fontFamily: "'Inter', 'PingFang SC', 'Microsoft YaHei', sans-serif"
  h1Hero:
    fontSize: "text-6xl md:text-9xl"
    fontWeight: "900"
    lineHeight: "0.9"
    letterSpacing: "tracking-tighter"
  h1Number:
    fontSize: "text-6xl md:text-8xl"
    fontWeight: "900"
    letterSpacing: "tracking-tighter"
    color: "{colors.accent}"
  h2Section:
    fontSize: "text-5xl"
    fontWeight: "900"
    letterSpacing: "tracking-tight"
  h2Outlook:
    fontSize: "text-8xl"
    fontWeight: "900"
    letterSpacing: "tracking-tighter"
  h3Card:
    fontSize: "text-2xl"
    fontWeight: "900"
    letterSpacing: "tracking-tight"
  h3Panel:
    fontSize: "text-xl"
    fontWeight: "700"
  h4Data:
    fontSize: "text-5xl / text-4xl"
    fontWeight: "900"
    letterSpacing: "tracking-tight"
  eyebrow:
    fontSize: "text-xs"
    fontWeight: "900"
    letterSpacing: "tracking-widest"
    upper: true
    color: "{colors.accent}"
  metricLabel:
    fontSize: "text-[10px]"
    fontWeight: "700"
    letterSpacing: "tracking-[0.15em]"
    upper: true
    color: "{colors.textMuted}"
  body:
    fontSize: "text-lg / text-sm"
    lineHeight: "relaxed"
    color: "{colors.textMuted}"
  microLabel:
    fontSize: "text-[10px]"
    fontWeight: "900"
    letterSpacing: "tracking-widest"
    upper: true
  footerBrand:
    fontSize: "text-xl"
    fontWeight: "900"
    letterSpacing: "tracking-[0.3em]"
    upper: true
rounded:
  sm: "8px"
  card: "12px"
  panel: "16px"
  large: "24px"
  mega: "32px"
  full: "9999px"
spacing:
  sectionXMobile: "2rem"
  sectionY: "8rem"
  sectionXDesktop: "6rem"
  titleGap: "5rem"
  gridGap: "1.5rem"
  cardPad: "2rem"
components:
  metricCard:
    background: "{colors.surface}"
    border: "border border-gray-100 = {colors.border}"
    borderRadius: "{rounded.large}"
    boxShadow: "0 10px 40px -15px rgba(0,0,0,0.1)"
    description: "浅色指标卡；hover 投影转品牌色深投影 0 20px 60px -15px rgba(139,0,0,0.2)，底部进度线 w-0→w-full bg-accent，图标 bg-red-50/text-crimson → bg-crimson/text-white"
  crimsonBlock:
    background: "{colors.header}"
    description: "全幅品牌区块（Hero 深红黑 / Business 纯深红）；叠加 skew 模糊光斑 bg-nebula-crimson opacity-10 blur-3xl 与深红点阵 radial-gradient(circle at 2px 2px, white 1px, transparent 0) 40px"
  glassCard:
    background: "rgba(255,255,255,0.05)"
    border: "border border-white/10"
    borderRadius: "{rounded.panel}"
    description: "暗区玻璃态容器；hover bg-white/5→/10；配 backdrop-blur-md"
  emphasisBar:
    border: "border-l-4 {colors.accent}"
    description: "数据高亮左强调条；hover bg 淡红 hover:bg-red-50/30；emphasis-box 用 border-l-8"
  productCard:
    background: "{colors.surface}"
    border: "border-b-[12px] {colors.border} hover:border-nebula-crimson"
    borderRadius: "{rounded.large}"
    boxShadow: "shadow-lg"
    description: "hover:-translate-y-4 上浮 + 图标 hover:scale-110；transition duration-500"
  progressBar:
    background: "linear-gradient(to right, #7F1D1D, {colors.accent})"
    borderRadius: "{rounded.full}"
    description: "填充动画 transition-all duration-[1.5s] ease-out；from-red-900(#7F1D1D 内置)→nebula-crimson"
  chartTooltipLight:
    background: "{colors.surface}"
    borderRadius: "{rounded.card}"
    boxShadow: "shadowBlur:30, shadowColor:rgba(0,0,0,0.1), shadowOffsetY:10"
    description: "浅区图表 tooltip"
  chartTooltipDark:
    background: "{colors.header}"
    border: "rgba(255,255,255,0.2)"
    borderRadius: "8px"
    color: "#FFFFFF"
    description: "暗/深红区图表 tooltip 变体"
anchors:
  - id: crimson-accent
    type: token
    desc: 深红点睛色，仅用于品牌区块背景、强调数值、进度条、装饰线与 hover（见 colors.accent），绝不入正文或大面积辅助面
  - id: full-bleed-rhythm
    type: pattern
    desc: 可用全幅明暗区块与大留白形成呼吸节奏，明暗顺序和段落数量按内容决定
  - id: mega-black-title
    type: pattern
    desc: 超黑字重 + 超紧字距的巨型标题，搭配全大写英文注释标签，中英双语层次
  - id: eyebrow-line
    type: component
    desc: 小节 eyebrow 前置一段深红短装饰线 + 大写英文标签
  - id: metric-card
    type: component
    desc: 浅色指标卡，hover 时品牌色投影加深、底部进度线展开、图标翻色
  - id: crimson-chart-seq
    type: token
    desc: 图表固定的深红→鲑橙 5 段序列色，图表不出现其他色相（见 colors.seq1–seq5）
  - id: glass-on-dark
    type: component
    desc: 暗区玻璃态透明白容器 + backdrop-blur，边框极淡白
gaps:
  - Inter 声明加载权重为 300/400/600/700，但 font-black(900) 驱动几乎所有标题、font-medium(500) 用于 footer 描述——二者均未在声明加载集里。本档 @import 已补齐 300;400;500;600;700;900，供消费侧忠实加载（源加载集不全）。
  - 进度条渐变 from-red-900 依赖 Tailwind 内置 red-900(#7F1D1D)，非自定义 token；自定义类仅 *-nebula-crimson。
  - 未声明负向/危险/警告语义色，仅有绿色增长标记（growthText/growthBg）。
  - 中大号标题多数未显式声明 line-height，依赖浏览器默认（仅 Hero 有 leading-[0.9]、正文有 leading-relaxed）。
  - shadow-2xl 列出但无具体使用位置；ECharts 轴标签在 #999999(BASE) 与 #666666(横向条形变体) 间混用无明述理由。
  - text-gray-500 / text-gray-700 在组件中临时使用，但仅 gray-400/gray-900 被正式 token 化。
  - 未声明 motion 缓动曲线 token（仅进度条一处内联 ease-out）。
---

## Overview

高端商务年报美学：权威、庄重、自信、高端科技感。深红主色 `#8B0000` 被克制地用作点睛色，仅出现在品牌区块背景、强调数值、装饰线与 hover 态；大面积由白色 / 浅灰 `#FAFAFA` / 近纯黑 `#1A0000`–`#050505` 承担。可用明暗交替的全幅区块营造呼吸感，但不固定区块顺序。

视觉签名 = 超黑字重（`font-black` / 900）+ 超紧字距（`tracking-tighter`）的巨型标题，搭配全大写英文注释标签（`uppercase tracking-widest`），中英双语层次分明。背景系统性叠加网格线、carbon-fibre 纹理、径向渐变与模糊色块（含品牌色 `blur-3xl` 光斑）；暗色区使用玻璃态透明白容器 `bg-white/5 ~ /20`。

## Colors

角色 × 值 × 用法：

| 角色 | 值 | 用法 |
|------|-----|------|
| bg 主内容区底 | `#FAFAFA` | 浅色段落基底（`bg-[#fafafa]`）|
| surface 卡片/面板 | `#FFFFFF` | 卡片、面板、容器 |
| header 强调区背景 | `#8B0000` | 全幅品牌区块（Hero、业务分析）|
| text 主文字 | `#111827` | 标题与正文（`text-gray-900`）|
| textMuted 弱文字 | `#9CA3AF` | 标签、副标、说明（`text-gray-400`）|
| accent 点睛 | `#8B0000` | 关键数值、图标高亮、进度条、分隔线 |
| border 边框 | `#F3F4F6` | 浅色卡片/面板边框（`border-gray-100`）|

深/暗区背景：Hero `#1A0000`（深红黑）、Outlook `#030712`（`bg-gray-950` 近纯黑）、Footer `#050505`（极深黑）。

语义色（唯一声明）：增长/正向 = 绿 `#16A34A` 文字 / `#DCFCE7` 底（`text-green-600` / `bg-green-50`）。未声明负向/危险/警告色。

浅色辅助：淡红底 `#FEF2F2`（`bg-red-50`，图标/高亮底）。暗区玻璃容器 = `rgba(255,255,255,0.05~0.2)`。

图表序列色（ECharts，放这里作 token）：`seq1 #8B0000 → seq2 #A52A2A → seq3 #CD5C5C → seq4 #E9967A → seq5 #FFA07A`，深红 → 鲑橙 5 段固定序列，用作默认 `color` 数组、线填充、柱填充、饼环等。图表不出现其他色相。ECharts 网格线 `#EEEEEE`、轴标签 `#999999`（横向条形变体用 `#666666`）；线面积渐变 `rgba(139,0,0,0.15)→rgba(139,0,0,0)`；散点阴影 `rgba(139,0,0,0.3)`；轴指针阴影 `rgba(139,0,0,0.05)`。

自定义品牌类（原样保留）：
```css
.bg-nebula-crimson { background-color: #8B0000; }
.text-nebula-crimson { color: #8B0000; }
.border-nebula-crimson { border-color: #8B0000; }
```

## Typography

**字体加载（HARD REQUIREMENT，原样写入全局样式首行，禁止替换域名）：**
```css
@import url('https://miaoda.feishu.cn/fonts/css2?family=Inter:wght@300;400;500;600;700;900&display=swap');
```
字体栈：`font-family: 'Inter', 'PingFang SC', 'Microsoft YaHei', sans-serif;`。英文用 Inter，中文用 PingFang SC / Microsoft YaHei（系统字体，零成本兜底），末位 `sans-serif`。ECharts `textStyle.fontFamily` 同栈，部分轴/标签组件覆盖为 `Inter`。

> Inter 是拉丁正文/展示无衬线体，非手写体，含完整拉丁字形；中文由系统 PingFang SC / Microsoft YaHei 承接，无需额外镜像加载。@import 权重已从源声明的 300/400/600/700 补齐 500 与 900（源全文用 `font-black`(900) 与 `font-medium`(500) 却未列入加载集，此处忠实补齐，见 gaps）。

字号体系（verbatim Tailwind）：

| 层级 | 用途 | 类 |
|------|------|-----|
| H1 Hero | 页面主标题 | `text-6xl md:text-9xl font-black leading-[0.9] tracking-tighter` |
| H1 数字 | 巨型统计数值 | `text-8xl font-black tracking-tighter text-nebula-crimson` |
| H2 章节 | 小节标题 | `text-5xl font-black tracking-tight` |
| H2 Outlook | 展望标题 | `text-6xl md:text-8xl font-black tracking-tighter` |
| H3 卡片 | 子块标题 | `text-2xl font-black tracking-tight` |
| H3 面板 | 图表面板标题 | `text-xl font-bold` |
| H4 数据 | 大数据展示 | `text-5xl` 或 `text-4xl` + `font-black tracking-tight` |
| 章节英文标签 | eyebrow | `text-xs font-black tracking-widest uppercase text-nebula-crimson` |
| 指标标签 | 卡片顶标签 | `text-[10px] font-bold uppercase tracking-[0.15em] text-gray-400` |
| 正文 | 段落 | `text-lg leading-relaxed text-gray-400` 或 `text-sm text-gray-500` |
| 脚注/微标签 | micro label | `text-[10px] uppercase font-black tracking-widest` |
| Footer 品牌名 | | `text-xl font-black tracking-[0.3em] uppercase` |

字距：`tracking-tighter`（Hero/Outlook/数字巨标）；`tracking-tight`（多数 H2/H3/H4 与指标值）；`tracking-widest`（英文大写 eyebrow/微标签）；`tracking-[0.15em]`（指标标签）；`tracking-[0.2em]`（强调框小标题）；`tracking-[0.3em]`（Footer 品牌名）；正文无字距。行高仅 `leading-[0.9]`（Hero）与 `leading-relaxed`（正文/描述）显式声明。

## Layout

容器：`max-w-7xl mx-auto`；水平内边距 `px-8 md:px-24`（移动 2rem / 桌面 6rem）；区块垂直内边距 `py-32`（8rem）。

区块间距：标题→内容 `mb-20`（5rem）；标准网格间距 `gap-6`（1.5rem），宽松 `gap-10 ~ gap-24`；卡片内边距 `p-8 ~ p-12`；元素间距 `mb-3 ~ mb-6`。

根据内容在浅色、深红和近黑表面间建立节奏；不要求年报章节、Hero、Overview、Business、Team、Outlook 或 Footer 按固定顺序出现。深色区适合巨型标题或关键结论，浅色区适合高密度内容，玻璃卡用于暗区承载信息。

网格列数和主次比例按信息关系确定。窄屏减少列数、缩放巨型标题并保持内容顺序清晰，不保留桌面端的固定分栏。

## Elevation & Depth

| 级别 | 值 | 用途 |
|------|-----|------|
| 微 | `shadow-sm` | 图表面板 |
| 标准 | `shadow-lg` | 产品卡 |
| 强 | `shadow-xl` | 浮层信息面板 |
| 巨 | `shadow-2xl` | 暗区特殊容器（无具体使用位，见 gaps）|
| 指标卡默认 | `0 10px 40px -15px rgba(0,0,0,0.1)` | 指标卡 |
| 指标卡 hover | `0 20px 60px -15px rgba(139,0,0,0.2)` | 品牌色染色投影 |
| 暗区白面板 | `0 40px 100px -20px rgba(0,0,0,0.3)` | 深区内白面板 |

ECharts：浅区 tooltip `shadowBlur:30, shadowColor:rgba(0,0,0,0.1), shadowOffsetY:10`；散点 `shadowBlur:4, shadowColor:rgba(139,0,0,0.3)`。

背景装饰：Hero 复合 = `bg-[#1a0000]` + 径向渐变 `radial-gradient(circle at 20% 30%, rgba(139,0,0,0.4) 0%, transparent 50%)` 与 `radial-gradient(circle at 80% 70%, rgba(165,42,42,0.3) 0%, transparent 50%)` + 网格线 `1px rgba(255,255,255,0.05)` @60px `opacity-20` + carbon-fibre 纹理 `opacity-[0.03]`。暗区模糊色块：`w-2/3 bg-nebula-crimson skew-x-12 opacity-10 blur-3xl`，反向计数块 `w-1/2 bg-blue-900 skew-x-[-12deg] opacity-5 blur-3xl`。浅区柔光：`w-64 h-64 bg-red-50 rounded-full blur-3xl opacity-50`。深红点阵：`radial-gradient(circle at 2px 2px, white 1px, transparent 0)` `backgroundSize:40px 40px` `opacity-10`。玻璃：`backdrop-blur-md`。

## Shapes

圆角：`rounded-lg`(8px, badge/图标容器) · `rounded-xl`(12px, 标准卡) · `rounded-2xl`(16px, 中面板) · `rounded-3xl`(24px, 大面板/产品卡) · `rounded-[2rem]`(32px, 巨容器) · `rounded-full`(进度条)。图表容器 `rounded-2xl` 或 `rounded-[2rem]`；图表 tooltip `borderRadius:12`(浅) / `8`(暗变体)；柱 itemStyle 顶角 `[10,10,0,0]`、横向 `[0,10,10,0]`。

边框：标准浅色 `border border-gray-100`；暗区玻璃 `border border-white/10`；左强调 `border-l-4 border-nebula-crimson`（强调框 `border-l-8`）；产品卡底强调 `border-b-[12px] border-gray-100 hover:border-nebula-crimson`；hover 底部进度线 `h-1 w-0 bg-nebula-crimson group-hover:w-full`；Footer 顶 `border-t border-white/5`；分隔 `h-px w-full bg-gray-100`，品牌分隔 `h-px w-24 bg-nebula-crimson`；目标卡增长徽章 `border border-red-800/30`。

## Components

- **指标卡**：`{components.metricCard}` — 浅色卡；hover 投影转品牌色深投影、底部进度线展开、图标翻色，`transition-all duration-500`。
- **品牌区块**：`{components.crimsonBlock}` — 全幅深红/深红黑区块，叠加 skew 模糊光斑与深红点阵。
- **玻璃卡**：`{components.glassCard}` — 暗区透明白容器 + `backdrop-blur-md`，hover 提亮。
- **左强调条**：`{components.emphasisBar}` — 数据高亮，hover 淡红底。
- **产品卡**：`{components.productCard}` — hover 上浮 + 图标放大 + 底边线变品牌色。
- **进度条**：`{components.progressBar}` — 红→深红渐变，`transition-all duration-[1.5s] ease-out`。
- **图表**：序列色见 `{colors.seq1}`–`{colors.seq5}`（深红→鲑橙 5 段，不引入其他色相）；浅区 tooltip `{components.chartTooltipLight}`，暗/深红区 tooltip `{components.chartTooltipDark}`。

交互动效：阴影加深 / 上浮 `-translate-y-4` / 底线展开 `w-0→w-full` / 图标 `scale-110` 均 `duration-500`；文字微移 `hover:translate-x-1 duration-300`；图标翻色 `duration-300`；玻璃提亮 `bg-white/5→/10 duration-300`。动画：滚动提示 `animate-bounce opacity-40`；Hero 标题渐变 `animate-pulse`；进度条 `duration-[1.5s] ease-out`。

## Hard Rules

- 标题始终 `font-black`(900) + `tracking-tight` 或 `tracking-tighter`；英文辅助标签始终 `uppercase tracking-widest text-[10px]`。
- 深红 `#8B0000` 极度克制：仅用于品牌区块背景、强调数值、进度条、装饰线与 hover 过渡；正文与大面积辅助面禁用深红，改用白/灰承载。
- 页面应使用浅色与暗色表面建立对比节奏，但不规定颜色顺序、段数或每段必须全幅。
- 内容容器可参考 `max-w-7xl mx-auto`，并按任务形态调整。
- eyebrow 行在大写英文标签前必须前置小装饰线 `h-0.5 w-8 bg-nebula-crimson`。
- 图表配色必须是固定的深红→鲑橙 5 段序列（`{colors.seq1}`–`{colors.seq5}`）；图表内不引入其他色相。
- 组件圆角下限为 `rounded-lg`(8px)，禁止直角卡片。
- 字体 @import 域必须走 `https://miaoda.feishu.cn/fonts/css2`，禁止 `fonts.googleapis.com` 直连。

## Exceptions

- `bg-blue-900` 仅允许作为暗区 `opacity-5 blur-3xl` 背景光斑出现（反向计数块），绝不作为可用 UI 色相。
- 进度条渐变起点 `from-red-900`(#7F1D1D) 借用 Tailwind 内置色，属唯一允许的非 `nebula-crimson` 品牌红。
- 暗色背景为逐区块选择（Hero/Outlook/Footer），非全局明暗主题切换系统；不存在 theme toggle。

## Do's and Don'ts

- Do：用白/深灰的大量留白框住深红点睛；中英双语标题保持层次（超黑巨标 + 大写英文 eyebrow）。
- Do：图表容器统一 `rounded-2xl`/`rounded-[2rem]` + `shadow-sm`；hover 态优先用品牌色染色投影传达高端感。
- Don't：不引入第二强调色相（除绿色增长标记外，全系仅深红 + 灰阶）。
- Don't：不使用衬线体；不加 `rounded-lg` 以下的小圆角组件。
