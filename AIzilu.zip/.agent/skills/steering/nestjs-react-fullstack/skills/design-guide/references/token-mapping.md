# 风格 token → 全栈主题槽位的语义映射规则

> 匹配到预置风格后读本文。前提：已读过该风格的 `references/<slug>.md`，现在要把它落进 `client/src/tailwind-theme.css`。

## 0. 先判明暗，这一步决定后面四条

看风格的画布色（`bg` / `canvas` / 最底层那个）。亮度低于 50% 视为**深色风格**，深色时必须改这四个模板默认值，否则交互反馈整体失效：

| 变量 | 浅色（模板默认） | 深色必须改成 |
|---|---|---|
| `--elevate-1` / `--elevate-2` | `rgba(0,0,0,.03)` / `.08` | `rgba(255,255,255,.04)` / `.10` |
| `--button-outline` / `--badge-outline` | `rgba(0,0,0,.10)` / `.05` | `rgba(255,255,255,.12)` / `.06` |
| `--opaque-button-border-intensity` | `-8`（压暗） | `+8`（提亮） |

这四个是 hover / active / 按钮描边的唯一来源，模板里写死了黑色。深色底上不改 = 悬停无反馈、按钮无边。

## 1. 按角色读，不按名字读

风格的 token 名不可信：不同风格会用同一个 token 名表达完全不同的角色，也会用不同名字表达同一种角色；`accent` 就可能是品牌主色、细线或点睛色。不要按名字机械映射，必须先看值和使用位置。

所以先判角色，再落槽位：

| 角色（问自己这个色在风格里干什么） | 落到 |
|---|---|
| 最底层页面画布 | `--background` |
| 卡片 / 内容块的面 | `--card`、`--popover` |
| 比画布略深或略浅的次级面、区块底 | `--muted`、`--secondary` |
| 正文主文字 | `--foreground`、`--card-foreground`、`--popover-foreground` |
| 次要 / 弱化文字 | `--muted-foreground` |
| 分隔线、描边 | `--border`、`--input` |
| **唯一那个高亮色**（CTA、激活态、数值点睛所用） | `--primary` + `--ring`；其上的文字给 `--primary-foreground` |
| 悬停高亮底、标签底这类**弱强调面** | `--accent` + `--accent-foreground` |
| 导航栏 / 侧边栏 / 顶栏专用色 | `--sidebar*` 那 8 个（见 §4） |

`--primary` 与 `--accent` 是最容易搞反的一对：shadcn 里 `--accent` 是**一块浅色底**（默认 `hsl(220 14% 96%)`），不是强调色。风格里那个高饱和签名色一律进 `--primary`。

三条同名不同义的坑，一律以角色为准：

- **`--x-foreground` 是「压在 x 上的文字色」**，不是 x 的浅色底。风格里的 `success-bg` / `danger-bg` 这类徽章底色角色相反，按 §3 另加变量。
- **风格里叫 `secondary` 的通常是第二数据色**（图表第二序列），不是 shadcn 的次级面。`--secondary` 该由「比画布深/浅一档的面」来填。
- **风格里叫 `accent` 的可能是任何东西**——品牌主色、细线或点睛色。看值和用法，别看名。

## 2. 缺源怎么办（这是多数情况，不是例外）

实测缺口：`warning` 缺 17/20、chart 缺 17/20、`danger` 缺 12/20、`success` 缺 11/20、`primary` 缺 8/20。照抄模板默认的蓝/红/绿/橙会把风格外的色相直接注进去。按下面推：

- **缺 `primary`**：风格若明确宣称无强调色（暗夜鎏金、夜航灯塔那类），`--primary` 填最高对比的中性色（深色风格填最亮的 ink，浅色风格填最深的 ink），`--primary-foreground` 填画布色。**不要自己发明一个强调色。**
- **缺 `success` / `danger` / `warning`**：保留语义可辨的最低要求，但把饱和度和明度拉到风格的水位——取模板默认的色相，饱和度与明度对齐风格里已有的彩色 token。**风格一个彩色 token 都没有时（暗夜鎏金那类），饱和度取 35% 为下限**，不要跟着中性色降到 7%——那样红绿橙互相分不出来。这种情况下状态色只用于 badge 与文字，不做面。风格明确禁止某类色（克莱因蓝的双色绝对主义、暗夜鎏金的严格中性）时，只在状态标记这一个位置破例，其余不用。
- **缺 chart-1..5**：从 `--primary` 的色相出发生成 5 档单色阶（改明度与饱和度，不引入新色相），不要直接套模板默认图表色。

## 3. 风格专有 token 不塞进槽位

`surface-dark-elevated`、`hero-stripe-start`、`axisColor`、`tooltipBorder`、`header-start/end` 这类没有对应槽位的，**按原名另加 CSS 变量**（`--surface-dark-elevated: …`），在组件里直接引用。塞进最近似的 shadcn 槽位会让全局组件跟着变形。

## 4. 别漏的三处联动

1. **`--sidebar*` 是独立的 8 个变量**，不跟随 `--background`/`--card`。风格有 `header` / `nav` 类 token（8 个风格有）就落这里；没有就按画布与卡片的关系推一档。漏改 = 导航栏还是模板的默认蓝灰。
2. **`--primary-border` / `--secondary-border` / `--destructive-border` / `--accent-border` / `--muted-border` 把源色内联写死了**，形如 `hsl(from hsl(221 83% 53%) h s calc(l + var(--opaque-button-border-intensity)))`。只改 `--primary` 不改它，按钮边框还是原来的蓝。**这 5 个必须同步替换内联的那个色。**
3. **阴影是 8 个 `--shadow-*` 加 6 个参数，全是黑色 1-5% 透明度。** 风格说「全局无阴影」就把 8 个全设 `none`；说「硬阴影」（牛皮粉彩 4px 零模糊、波普艺术色块偏移）要把 `--shadow-blur` 设 0 并给实色；说「漫射深投影」（暗夜鎏金）要加大 blur 与不透明度。只改颜色不改这套 = 风格的层次语言没落地。

## 5. 非颜色槽位

- `--radius` 一个值驱动 sm/md/lg/xl（`calc(--radius ± 4px)`）。零圆角风格设 `0`；超大圆角（有机极简 40-48px、翡翠光晕 32-40px）设到 `2rem` 以上后要复核 sm 档是否还合理。
- `--font-sans` / `--font-serif` / `--font-mono`：风格指定了字体族就替换，**保留模板原有的中文与 emoji 回退链**（`PingFang SC`、`Microsoft Yahei`、`Apple Color Emoji` 那串），只在最前面插入风格字体。删掉回退链会让中文掉字形。

## 6. 值的写法

模板里 hex（`--shadow-color: #000000`）、`hsl(...)`、`rgba(...)` 三种并存，**都合法，照风格原值写即可**。带透明度的色（`rgba(255,255,255,.04)` 这种发丝边）保留 rgba，不要强行转 hsl。
