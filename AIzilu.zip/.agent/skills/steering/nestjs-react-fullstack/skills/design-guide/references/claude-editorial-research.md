---
version: alpha
name: claude-editorial-research
name_zh: 陶色书卷
description: 暖奶油画布 + 珊瑚强调 + 深藏青产品面的社论式 AI 界面。以带暖调的奶油底色（非纯白、非冷灰）为默认地板，板衬线展示标题走 400 字重 + 负字距（Copernicus / Tiempos，替代 Cormorant Garamond），配人文无衬线正文（StyreneB / Inter）。品牌电压只来自「奶油 + 珊瑚」这对暖色，珊瑚仅点在主 CTA 与整幅召唤卡上。三种表面模式（奶油画布 / 奶油卡 / 深藏青产品面）逐屏交替形成节奏，深色面承载真实代码窗、终端、模型对比等产品 chrome，而非抽象营销插画。整体读感是长文杂志专栏而非 SaaS 落地页。
anchors:
  - id: canvas
    type: token
    desc: 暖调奶油底色，全站默认地板，刻意不用纯白/冷灰，见 colors.canvas
  - id: primary
    type: token
    desc: 品牌珊瑚色，稀用于主 CTA、慷慨用于整幅召唤卡，从不作第三强调色
  - id: display-serif
    type: pattern
    desc: 板衬线展示标题配负字距，文学社论气质，绝不加粗、绝不换无衬线
  - id: surface-dark
    type: token
    desc: 深藏青产品面，承载代码窗、终端、模型对比卡等真实产品 chrome
  - id: callout-card-coral
    type: component
    desc: 整幅珊瑚召唤卡，珊瑚面本身即品牌电压，内部按钮反相为奶油
  - id: code-window-card
    type: component
    desc: 深色代码窗卡片，带行号与语法高亮，开发页面的招牌视觉元素
  - id: three-surface-rhythm
    type: pattern
    desc: 奶油画布 / 奶油卡 / 深藏青三种表面按内容需要穿插，构成页面的节奏与呼吸
colors:
  primary: "#cc785c"
  primary-active: "#a9583e"
  ink: "#141413"
  body: "#3d3d3a"
  muted: "#6c6a64"
  hairline: "#e6dfd8"
  canvas: "#faf9f5"
  surface-card: "#efe9de"
  surface-cream-strong: "#e8e0d2"
  surface-dark: "#181715"
  surface-dark-elevated: "#252320"
  surface-dark-soft: "#1f1e1b"
  on-primary: "#ffffff"
  on-dark: "#faf9f5"
  on-dark-soft: "#a09d96"
  accent-teal: "#5db8a6"
  success: "#5db872"
  error: "#c64545"

typography:
  display-xl:
    fontFamily: "Copernicus, Tiempos Headline, Cormorant Garamond, Noto Serif SC, serif"
    fontSize: 64px
    fontWeight: 400
    lineHeight: 1.05
    letterSpacing: -1.5px
  display-lg:
    fontFamily: "Copernicus, Tiempos Headline, Cormorant Garamond, Noto Serif SC, serif"
    fontSize: 48px
    fontWeight: 400
    lineHeight: 1.1
    letterSpacing: -1px
  display-md:
    fontFamily: "Copernicus, Tiempos Headline, Cormorant Garamond, Noto Serif SC, serif"
    fontSize: 36px
    fontWeight: 400
    lineHeight: 1.15
    letterSpacing: -0.5px
  display-sm:
    fontFamily: "Copernicus, Tiempos Headline, Cormorant Garamond, Noto Serif SC, serif"
    fontSize: 28px
    fontWeight: 400
    lineHeight: 1.2
    letterSpacing: -0.3px
  title-lg:
    fontFamily: "StyreneB, Inter, PingFang SC, sans-serif"
    fontSize: 22px
    fontWeight: 500
    lineHeight: 1.3
    letterSpacing: 0
  title-md:
    fontFamily: "StyreneB, Inter, PingFang SC, sans-serif"
    fontSize: 18px
    fontWeight: 500
    lineHeight: 1.4
    letterSpacing: 0
  body-md:
    fontFamily: "StyreneB, Inter, PingFang SC, sans-serif"
    fontSize: 16px
    fontWeight: 400
    lineHeight: 1.55
    letterSpacing: 0
  body-sm:
    fontFamily: "StyreneB, Inter, PingFang SC, sans-serif"
    fontSize: 14px
    fontWeight: 400
    lineHeight: 1.55
    letterSpacing: 0
  caption-uppercase:
    fontFamily: "StyreneB, Inter, PingFang SC, sans-serif"
    fontSize: 12px
    fontWeight: 500
    lineHeight: 1.4
    letterSpacing: 1.5px
  code:
    fontFamily: "JetBrains Mono, ui-monospace, monospace"
    fontSize: 14px
    fontWeight: 400
    lineHeight: 1.6
    letterSpacing: 0
  button:
    fontFamily: "StyreneB, Inter, PingFang SC, sans-serif"
    fontSize: 14px
    fontWeight: 500
    lineHeight: 1
    letterSpacing: 0
  nav-link:
    fontFamily: "StyreneB, Inter, PingFang SC, sans-serif"
    fontSize: 14px
    fontWeight: 500
    lineHeight: 1.4
    letterSpacing: 0

rounded:
  md: 8px
  lg: 12px
  xl: 16px
  pill: 9999px

spacing:
  lg: 24px
  xl: 32px
  xxl: 48px
  section: 96px

components:
  button-primary:
    background: "{colors.primary}"
    color: "{colors.on-primary}"
    typography: "{typography.button}"
    rounded: "{rounded.md}"
    padding: 12px 20px
    height: 40px
    description: 招牌珊瑚 CTA；按下态转 primary-active，不设其它 hover
  button-secondary-on-dark:
    background: "{colors.surface-dark-elevated}"
    color: "{colors.on-dark}"
    typography: "{typography.button}"
    rounded: "{rounded.md}"
    padding: 12px 20px
    description: 深色面上的次级按钮，保持深色，从不反相为浅色
  text-link:
    background: transparent
    color: "{colors.primary}"
    typography: "{typography.body-md}"
    description: 正文内联链接用珊瑚色，是系统最有辨识度的小细节
  top-nav:
    background: "{colors.canvas}"
    color: "{colors.ink}"
    typography: "{typography.nav-link}"
    height: 64px
    description: 奶油顶栏，左侧 Anthropic 星芒标 + Claude 字标，右侧珊瑚主按钮
  hero-band:
    background: "{colors.canvas}"
    color: "{colors.ink}"
    typography: "{typography.display-xl}"
    padding: 96px
    description: 奶油画布英雄区，6/6 栅格：左标题右插画或产品 mockup
  feature-card:
    background: "{colors.surface-card}"
    color: "{colors.ink}"
    typography: "{typography.title-md}"
    rounded: "{rounded.lg}"
    padding: 32px
    description: 比画布深一档的奶油特性卡，3-up 栅格，无阴影
  product-mockup-card-dark:
    background: "{colors.surface-dark}"
    color: "{colors.on-dark}"
    typography: "{typography.title-md}"
    rounded: "{rounded.lg}"
    padding: 32px
    description: 深藏青产品卡，展示真实 Claude 产品界面片段
  code-window-card:
    background: "{colors.surface-dark}"
    color: "{colors.on-dark}"
    typography: "{typography.code}"
    rounded: "{rounded.lg}"
    padding: 24px
    innerBlock: "{colors.surface-dark-soft}"
    description: 深色代码窗，带行号与语法高亮，内嵌块用 surface-dark-soft
  pricing-tier-card-featured:
    background: "{colors.surface-dark}"
    color: "{colors.on-dark}"
    typography: "{typography.title-lg}"
    rounded: "{rounded.lg}"
    padding: 32px
    description: 主推档位卡，深色面本身即「featured」信号，其余档位为奶油描边
  callout-card-coral:
    background: "{colors.primary}"
    color: "{colors.on-primary}"
    typography: "{typography.title-md}"
    rounded: "{rounded.lg}"
    padding: 48px
    description: 整幅珊瑚召唤卡，内部 CTA 反相为奶油按钮
  cta-band-coral:
    background: "{colors.primary}"
    color: "{colors.on-primary}"
    typography: "{typography.display-sm}"
    rounded: "{rounded.lg}"
    padding: 64px
    description: 页脚前珊瑚 CTA 带，标题仍是衬线
  badge-coral:
    background: "{colors.primary}"
    color: "{colors.on-primary}"
    typography: "{typography.caption-uppercase}"
    rounded: "{rounded.pill}"
    padding: 4px 12px
    description: NEW / BETA 珊瑚胶囊徽章
  text-input-focused:
    background: "{colors.canvas}"
    color: "{colors.ink}"
    typography: "{typography.body-md}"
    rounded: "{rounded.md}"
    border: 1px {colors.primary}
    description: 聚焦态输入框，边框转珊瑚 + 3px 珊瑚 15% 透明外环
  footer:
    background: "{colors.surface-dark}"
    color: "{colors.on-dark-soft}"
    typography: "{typography.body-sm}"
    padding: 64px
    description: 深藏青页脚收束每页，4 列链接，星芒标 + Anthropic 字标，从不反相
gaps:
  - "Copernicus / StyreneB / Tiempos Headline 是 Anthropic 授权字体、无公开 web font；本档用 Cormorant Garamond / Inter / Noto Serif SC 作替代项（源推荐字体无可用镜像源），气质近似但非精确。"
  - "Anthropic 星芒标（四芒放射）为品牌 glyph，作 logo 资产处理，未形式化为系统 token（未取到完整 SVG path，落 gap 不凭二手重绘）。"
  - "动画与转场时序（消息揭示、代码打字机、agentic-flow 图动画）不在抽取范围。"
  - "text-input-focused 之外的表单校验态（error / success 输入态）未抽取。"
  - "claude.ai 产品面的对话气泡、消息工具、文件上传芯片、会话侧栏等产品专属组件不在本营销面文档范围。"
  - "primary-disabled、body-strong、muted-soft、surface-soft、hairline-soft、accent-amber、warning 等源中次要 token 与 title-sm / caption / xs / sm 半径为收敛体量已删减，需要时回查 raw-source。"
---

## Overview

Claude 是 AI 产品品类里最暖、最社论化的界面。基底气质是一层**带暖调的奶油画布**（`{colors.canvas}`）——刻意不用其它 AI 品牌惯用的冷灰白或纯白。标题走**板衬线展示体**（Copernicus / Tiempos Headline，替代 Cormorant Garamond）400 字重 + 负字距，配 **StyreneB / Inter** 人文无衬线正文，读感是文学出版物而非 SaaS 营销页。

品牌电压只来自**奶油 + 珊瑚**这对暖色：珊瑚（`{colors.primary}`）是 Anthropic 招牌强调色，稀用于每个主 CTA 与品牌字标，慷慨用于整幅召唤卡，从不作第三强调色。珊瑚偏暖略哑，绝不偏青蓝——是对冷色调 AI 品牌的刻意反位。

三种表面模式逐屏交替：
1. **奶油画布** `{colors.canvas}` —— 默认正文地板
2. **奶油特性卡** `{colors.surface-card}` —— 比画布深一档
3. **深藏青产品面** `{colors.surface-dark}` —— 代码窗、模型卡、页脚前 CTA、页脚本身

深色面是 Claude 展示真实产品 chrome（代码块、终端、模型对比表）之处，而非抽象营销插画；奶油到深色的对比即页面节奏。层级半径：`{rounded.md}` 用于按钮与输入框，`{rounded.lg}` 用于内容与产品卡，`{rounded.xl}` 用于英雄插画容器，`{rounded.pill}` 用于徽章。段落节奏 `{spacing.section}` 恒定，卡内留白慷慨 `{spacing.xl}`。

## Colors

### 品牌与强调
- **珊瑚 / 主色** `{colors.primary}`：招牌暖珊瑚，用于每个主 CTA 背景、整幅珊瑚召唤卡、品牌字标强调。
- **珊瑚按下态** `{colors.primary-active}`：按下 / hover 变深。
- **强调青** `{colors.accent-teal}`：极少量用于次级产品面（终端状态点、连接器「活跃」指示）。

### 表面
- **画布** `{colors.canvas}`：默认地板，暖奶油，非纯白。
- **奶油卡** `{colors.surface-card}`：特性卡、内容卡，比画布深一档。
- **强奶油** `{colors.surface-cream-strong}`：选中态分类标签、强调段落带。
- **深藏青** `{colors.surface-dark}`：代码窗、模型卡、页脚，主导深色面。
- **深藏青抬升** `{colors.surface-dark-elevated}`：深色带内的抬升卡与次级按钮。
- **深藏青柔** `{colors.surface-dark-soft}`：大深色卡内代码块背景。
- **发丝线** `{colors.hairline}`：奶油面上的 1px 边框色，边界像一档抬升而非墨线。

### 文本
- **墨** `{colors.ink}`：所有标题与主文本，暖深、略偏离纯黑。
- **正文** `{colors.body}`：默认行文色。
- **弱化** `{colors.muted}`：子标题、面包屑、次要文本。
- **珊瑚上白字** `{colors.on-primary}`：珊瑚按钮上文字。
- **深面上字** `{colors.on-dark}`：深色面上的奶油调白（呼应画布）。
- **深面弱字** `{colors.on-dark-soft}`：页脚正文、深 mockup 内次级标签。

### 语义
- **成功** `{colors.success}`：绿色状态点、「可用」指示。
- **错误** `{colors.error}`：校验错误。

## Typography

字体加载（`@import` 原样写入全局样式首行，**HARD REQUIREMENT：域名一律走自有镜像，禁止替换为 fonts.googleapis.com 直连**）：

```css
@import url('https://miaoda.feishu.cn/fonts/css2?family=Cormorant+Garamond:wght@500;600&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400&family=Noto+Serif+SC:wght@400;600&display=swap');
```

Copernicus / Tiempos Headline / StyreneB 是 Anthropic 授权字体、无公开 web font；本档以 **Cormorant Garamond**（weight 500、`-0.02em` 字距）作衬线展示体最近开源替代，**Inter** 作 StyreneB 替代，**JetBrains Mono** 处理代码。

- 展示（`{typography.display-xl}` / `{typography.display-lg}` / `{typography.display-md}` / `{typography.display-sm}`）→ 板衬线，400 字重 + 负字距，用于 h1–h3 与英雄标题。负字距（-0.3 至 -1.5px）不可省——去掉后衬线读感偏离品牌。**绝不加粗**：加重靠更大字号而非更粗字重。
- 标签 / 正文（`{typography.title-lg}` / `{typography.title-md}` / `{typography.body-md}` / `{typography.body-sm}` / `{typography.caption-uppercase}` / `{typography.button}` / `{typography.nav-link}`）→ 人文无衬线，正文 400、标签 500。
- 代码（`{typography.code}`）→ JetBrains Mono。

**中文兜底与行高转译**：本风格仅有拉丁展示体，无源推荐 CJK 字体；展示体末位补 **Noto Serif SC**（气质最近的优雅简中衬线），正文补 PingFang SC 系统兜底。中文标题回退时**清零负字距**、`line-height` 保持 ≥1.05（当前 1.05–1.2 已达标），中文正文 `line-height` ≥1.5（当前 1.55 达标），避免中文字形占满 em 盒后重叠。

## Layout

- **间距刻度**：`{spacing.lg}` 24px · `{spacing.xl}` 32px · `{spacing.xxl}` 48px · `{spacing.section}` 96px。
- **段落节奏**：主内容组之间可参考 `{spacing.section}`（96px），信息紧凑时允许缩减。
- **卡内留白**：特性 / 定价 / 模型卡 `{spacing.xl}`（32px）；代码窗卡 `{spacing.lg}`（24px）；珊瑚召唤卡 `{spacing.xxl}`（48px）；深色 CTA 带 64px。
- **容器**：最大内容宽可参考 ~1200px 居中；分栏比例和卡片列数按内容关系与可用宽度决定。
- **留白哲学**：奶油画布 + 衬线展示 + 慷慨卡内留白共同营造社论节奏，读感是长文杂志专栏而非营销模板。

## Elevation & Depth

深度以**色块优先、阴影稀有**：大部分层次来自奶油 vs 深藏青的表面对比，而非投影。

| 层级 | 处理 | 用途 |
|---|---|---|
| 平 | 无阴影无边框 | 正文段、顶栏、英雄带 |
| 发丝线 | 1px `{colors.hairline}` 边框 | 输入框、次级导航、偶尔卡片 |
| 奶油卡 | `{colors.surface-card}` 背景、无阴影 | 特性卡、内容卡 |
| 深面卡 | `{colors.surface-dark}` 背景、无阴影 | 代码窗、模型卡 |
| 微投影 | `0 1px 3px rgba(20,20,19,0.08)`（稀用） | 仅 hover 抬升态 |

深色 mockup 自带内部产品 chrome（编辑器滚动条、行号、语法高亮），无需外部阴影即有细节。Anthropic 星芒标（四芒放射星号）作为小黑标出现在字标前缀与内联内容标记处。

## Shapes

| Token | 值 | 用途 |
|---|---|---|
| `{rounded.md}` | 8px | 标准 CTA 按钮、文本输入、分类标签 |
| `{rounded.lg}` | 12px | 内容卡（特性 / 定价 / 代码窗 / 模型对比）|
| `{rounded.xl}` | 16px | 英雄插画容器、大幅陈列组件 |
| `{rounded.pill}` | 9999px | 徽章胶囊、NEW 标 |

英雄区极少用照片；主流做法是珊瑚 + 深藏青线描插画、代码窗 mockup、终端输出 mockup、模型对比卡（Opus / Sonnet / Haiku 抽象几何缩略图）。测评头像裁为 40px 正圆。

## Components

- **`button-primary`** —— 招牌珊瑚 CTA，`{colors.primary}` 底 + `{colors.on-primary}` 字，`{typography.button}`，`{rounded.md}`，按下态转 `{colors.primary-active}`。
- **`button-secondary-on-dark`** —— 深色面上次级按钮，`{colors.surface-dark-elevated}` 底，保持深色不反相。
- **`text-link`** —— 正文珊瑚内联链接，系统最有辨识度的小细节。
- **`top-nav`** —— 64px 奶油顶栏，星芒标 + Claude 字标 + 珊瑚主按钮。
- **`hero-band`** —— 奶油英雄区，6/6 分栏，纵向 `{spacing.section}` 留白。
- **`feature-card`** —— 奶油特性卡（`{colors.surface-card}`），3-up 栅格，`{rounded.lg}`，`{spacing.xl}` 内边距。
- **`product-mockup-card-dark`** —— 深藏青产品卡，展示真实 Claude 界面片段。
- **`code-window-card`** —— 深色代码窗，行号 + 语法高亮，内嵌块用 `{colors.surface-dark-soft}`，开发页面招牌视觉。
- **`pricing-tier-card-featured`** —— 主推档位卡翻为 `{colors.surface-dark}`，深色面本身即 featured 信号。
- **`callout-card-coral`** —— 整幅珊瑚召唤卡，`{colors.primary}` 面即电压，内部按钮反相为奶油。
- **`cta-band-coral`** —— 页脚前珊瑚 CTA 带，标题仍走 `{typography.display-sm}` 衬线。
- **`badge-coral`** —— NEW / BETA 珊瑚胶囊徽章，`{typography.caption-uppercase}`。
- **`text-input-focused`** —— 聚焦态输入框，边框转珊瑚 + 3px 珊瑚 15% 透明外环。
- **`footer`** —— 深藏青页脚，4 列链接，星芒标 + Anthropic 字标，从不反相。

### 图表与产品面色序
报表 / 数据可视化容器落在深色面上时，序列色从 `{colors.accent-teal}`、`{colors.primary}`、`{colors.on-dark-soft}` 中取，容器背景 `{colors.surface-dark}`，网格线用 `{colors.surface-dark-elevated}`；语义状态点用 `{colors.success}` / `{colors.error}`。

## Hard Rules

- 每页必须锚定 `{colors.canvas}` 奶油画布，**禁止用纯白或冷灰作画布**——暖调即品牌差异。
- 展示标题必须用板衬线（Copernicus / Cormorant Garamond）400 字重 + 负字距，**禁止加粗、禁止换无衬线做展示**；加重用更大字号。
- `{colors.primary}` 珊瑚**仅**用于主 CTA 与整幅 `callout-card-coral` / `cta-band-coral`，**禁止**作第三强调色四处点缀。
- **禁止**在相邻两个带用同一表面模式；节奏须交替：奶油 → 奶油卡 → 深藏青 → 奶油 → 珊瑚召唤 → 深藏青页脚。
- `@import` 字体加载域名**禁止替换**为 `fonts.googleapis.com`，一律走自有镜像。
- 只定义默认态与按下 / 聚焦态，**禁止**新增其它 hover 样式。
- **禁止**引入第四种表面色调（无紫卡、无绿区块）：奶油 + 珊瑚 + 深藏青是唯一三元组。

## Exceptions

- 微投影 `0 1px 3px rgba(20,20,19,0.08)` 仅允许出现在 hover 抬升态，是「阴影稀有」规则下的明确例外。
- `button-icon-circular` 类图标按钮触达尺寸 36×36px，略低于 WCAG 44 但视觉居中，允许。
- 页脚与深色 CTA 带内边距用 64px（不在 spacing 刻度上），是深色带专属留白，允许。

## Do's and Don'ts

### Do
- 用 `feature-card`（奶油）与 `product-mockup-card-dark`（深藏青）交替成带，节奏即品牌机制。
- 用 `code-window-card` / `product-mockup-card-dark` 展示真实产品 chrome，而非画营销代码插画。
- 用星芒标作字标前缀；定价主推档用深色面而非彩色描边。

### Don't
- 别用 Inter 做展示标题——衬线气质才是品牌声音。
- 别把珊瑚铺满：它在单个元素上稀缺、只在整幅召唤卡上慷慨。
- 别在字标内把星芒标反相为深底白色。
