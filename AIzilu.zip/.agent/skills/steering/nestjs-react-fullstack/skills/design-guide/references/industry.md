---
version: alpha
name: industry
name_zh: 工业图纸
description: 工程图纸风格：冷灰白技术底配单一钢蓝，Barlow Condensed 标题与 Barlow 正文形成压缩对比；卡片、图框和按钮采用直角发丝边框与四角套准标，内容照片双色化为钢蓝。
colors:
  bg: "#f2f2f3"
  surface: "#e9e9ea"
  text: "#1d1f20"
  accent: "#5980a6"
  accent-dark: "#416180"
  accent-deep: "#1d2d3d"
  accent-2: "#728fab"
  neutral-dark: "#2b2b2d"
typography:
  heading:
    fontFamily: "'Barlow Condensed', 'Noto Sans SC', 'PingFang SC', system-ui, sans-serif"
    fontWeight: "600"
    lineHeight: "1.12"
  body:
    fontFamily: "'Barlow', 'Noto Sans SC', 'PingFang SC', system-ui, sans-serif"
    fontSize: "15px"
    lineHeight: "1.55"
  h1:
    fontSize: "42px"
  h2:
    fontSize: "32px"
  h3:
    fontSize: "25px"
spacing:
  space-1: "3.4px"
  space-2: "6.8px"
  space-3: "10.2px"
  space-4: "13.6px"
  space-6: "20.4px"
  space-8: "27.2px"
rounded:
  sm: "2px"
  md: "4px"
  lg: "7px"
components:
  blueprint-frame:
    border: "1px solid color-mix(in srgb, {colors.text} 16%, transparent)"
    borderRadius: "0"
    background: "transparent"
    description: "四角各带一个由两条 1px 线构成的套准十字标"
  primary-button:
    background: "{colors.accent}"
    color: "{colors.bg}"
    border: "1px solid {colors.accent}"
    borderRadius: "0"
  duotone-image:
    description: "图片去饱和后覆盖钢蓝混合层，并与 blueprint-frame 组合"
anchors:
  - id: drawing-paper
    type: token
    desc: 冷灰白图纸底与钢蓝构成单色技术基调
  - id: condensed-heading
    type: token
    desc: 压缩标题与常规宽度正文形成明确对比
  - id: blueprint-frame
    type: component
    desc: 透明直角线框配四角套准十字标
  - id: solid-primary-only
    type: component
    desc: 主按钮是图板上主要的实体钢蓝区域
  - id: modular-grid
    type: pattern
    desc: 内容沿等宽模块网格形成可见的横纵节奏
  - id: steel-blue-duotone
    type: pattern
    desc: 内容照片统一进行钢蓝双色化处理
gaps:
  - 原始 styles.css、_ds_bundle.js 与模板资产未随 markdown 提供；接入时需使用来源资产。
  - 暗色模式未定义。
exceptions:
  - 对话框是带 surface 填充的容器例外。
  - 单选按钮保留圆形；主按钮允许实心钢蓝。
  - accent-deep 仅可在演示分节页使用大面积色场。
---

## Overview

一张工程图纸：冷灰白技术底、钢蓝、压缩标题、模块网格与带四角套准标的透明线框构成主体。

## Colors

页面使用 {colors.bg} 技术底、{colors.text} 正文和 {colors.accent} 钢蓝；段落级钢蓝文字使用 {colors.accent-dark}，大面积 {colors.accent-deep} 仅用于演示分节色场。

## Typography

@import url('https://miaoda.feishu.cn/fonts/css2?family=Barlow:wght@400;500;700&family=Barlow+Condensed:wght@400;600&family=Noto+Sans+SC:wght@400;500;600;700&display=swap');

HARD REQUIREMENT：字体加载与字体族分工禁止替换。标题使用 {typography.heading.fontFamily}，正文使用 {typography.body.fontFamily}；中文多行标题行高不低于 1.05，正文不低于 1.5，中文负字距归零。

## Layout

内容沿模块化等宽网格组织，保持清晰的横向与纵向节奏；网格列数与模块顺序根据内容和容器宽度自适应。

## Elevation & Depth

线稿卡片和图框通常不使用投影；需要层级时仅采用源规格的墨色调柔投影，不自造阴影。

## Shapes

组件采用直角、发丝边框和完整的四角套准标；图片使用钢蓝双色化包装器，图标统一 1.5 描边。

## Components

按钮、标签、原生表单、透明卡片、表格、对话框、blueprint 框架与 duotone 图像的精确规格见下方“来源规格”。

## Hard Rules

- 卡片、图框与按钮保持直角；透明卡片和图框保留完整四角套准标。
- 卡片与图框保持透明线稿，主按钮是主要的实体钢蓝区域。
- 标题使用压缩字族，正文使用常规宽度字族。
- 内容照片使用 blueprint + duotone 包装器，图标描边为 1.5。

## Exceptions

- 对话框可使用 surface 填充；单选按钮保留圆形。
- 演示分节页可使用 {colors.accent-deep} 整幅色场。

## Source Specification

以下内容从用户提供的原始 design.md 原样保留，仅将标题层级下调以纳入 DSM v1 单文件结构。

### 一句话定位

一张工程图纸。浅色技术底上的钢蓝，Barlow Condensed 标题配 Barlow 正文，模块化网格；卡片、图框、按钮都是**蓝图对象**——直角、发丝边框、四角带 `+` 套准标记。卡片和图框永远保持**透明线稿**；主按钮是图板上唯一的实体——实心钢蓝填充，但直角和角标一样不丢。照片双色化为钢蓝，图标细线。

---

### 1. 颜色

#### 基础角色

| Token | 值 | 用途 |
| --- | --- | --- |
| `--color-bg` | `#f2f2f3` | 图纸底（冷灰白） |
| `--color-surface` | `#e9e9ea` | 仅 `.input` / `.dialog` 用（卡片**不用**它） |
| `--color-text` | `#1d1f20` | 正文墨色 |
| `--color-accent` | `#5980a6` | 钢蓝，唯一强调色 |
| `--color-accent-2` | `#728fab` | 机器派生占位，视作与 accent 同一角色 |
| `--color-divider` | `text` 16% 混合 | 所有发丝边框和分隔 |

**单色方案**：没有第二强调色。`accent-2` 的整条色阶存在只为让两组变量都能解析——`.tag-accent-2` 看起来和 `.tag-accent` 基本一样。

#### 色阶（OKLCH 同一感知明度轴，同 step 视觉重量一致）

**Neutral** `#f5f5f8` · `#e7e7ea` · `#d4d4d7` · `#b7b7ba` · `#98989b` · `#7a7a7d` · `#5d5d60` · `#424244` · `#2b2b2d`

**Accent** `#eef6ff` · `#d6ebff` · `#b5d9fd` · `#94bce3` · `#749dc4` · `#597ea3` · `#416180` · `#2c455d` · `#1d2d3d`

**Accent-2（占位）** `#eef6ff` · `#d6ebff` · `#bdd8f2` · `#9ebbd8` · `#7e9cb8` · `#627d98` · `#486077` · `#314457` · `#1f2d3a`

用法规则：
- 100–300 → 浅色填充、hover 底、细边框
- 500 → 该角色基准
- 700–900 → 浅色填充上的文字、按下态
- 优先取色阶 step，不要临时 `color-mix()`

#### `--color-accent-900` 的特权

`#1d2d3d` 可以铺**整幅色场**——deck 的分节页就用它：钢蓝作地，文字反白成纸色。这是唯一允许大面积上色的地方。（landing 的数字改走「画出来的规格牌」，落在纸底上，是另一套语法，不是色场。）

#### 对比度红线

accent 对底色只到 **3:1** —— 够图标、大字号、界面 chrome，**不够正文**。段落级钢蓝文字必须用 `--color-accent-700`（`#416180`）。

---

### 2. 字体

| Token | 值 |
| --- | --- |
| `--font-heading` | `"Barlow Condensed", system-ui, sans-serif` |
| `--font-heading-weight` | `600` |
| `--font-body` | `"Barlow", system-ui, sans-serif` |

从 Google Fonts 载入：`Barlow:wght@400;500;700` + `Barlow+Condensed:wght@400;600`

**标题压缩、正文不压缩** —— 这是本系统最容易被做错的一条：全篇都用 Condensed 就毁了对比。

#### 字号阶梯

| 元素 | 字号 | 备注 |
| --- | --- | --- |
| h1 | 42px | line-height 1.12，letter-spacing −0.015em |
| h2 | 32px | 同上 |
| h3 | 25px | 同上 |
| h4 | 20px | 同上 |
| h5 | 16px | 同上 |
| h6 | 13px | **全大写**，letter-spacing 0.08em |
| body | 15px | line-height 1.55，weight 400 |
| figcaption | 11px | text 55% |
| `.card-title` | 17px | heading 族 600 |
| `.card-kicker` | 10px | 大写，ls 0.1em，钢蓝 |
| `.btn` / `.input` | 14px | 刻意同字号——注册行里两者并排 |
| `.tag` | 11px | |
| `.table th` | 11px | 大写，ls 0.08em，text 60% |
| `.dialog-title` | 20px | |

---

### 3. 间距与圆角

密度 **0.85×**（偏紧，已烘进变量）：

```
--space-1: 3.4px   --space-2: 6.8px   --space-3: 10.2px
--space-4: 13.6px  --space-6: 20.4px  --space-8: 27.2px
```

圆角 token：`--radius-sm: 2px` / `--radius-md: 4px` / `--radius-lg: 7px`

**但组件层把它们全部覆盖掉了** —— 样式表末尾：

```css
.card, .btn, .input, .tag, .seg, .dialog { border-radius: 0; }
.card, .dialog { background: transparent; border: 1px solid var(--color-divider); }
.btn { border: 1px solid var(--color-divider); }
.btn-primary { border-color: var(--color-accent); }
```

所以实际渲染出来**全部是直角**。radius 变量只对你自己写的元素有意义，组件一律方角。

### 4. 阴影

```
--shadow-sm: 0 1px 2px  (#2b2b2d 14%)
--shadow-md: 0 3px 10px (#2b2b2d 16%)
--shadow-lg: 0 12px 32px (#2b2b2d 22%)
```

工具类 `.elev-sm / -md / -lg`。但线稿系统里阴影用得极少——透明卡片配投影是矛盾的，谨慎使用。不要自造 box-shadow。

---

### 5. 蓝图框架（本系统的核心标识）

```html
<div class="card blueprint">
  <i class="corner tl"></i><i class="corner tr"></i>
  <i class="corner bl"></i><i class="corner br"></i>
  …
</div>
```

`.blueprint` = `position: relative` + 1px `--color-divider` 边 + `border-radius: 0`。

四个 `.corner` 是 11×11px 的十字标，用 `::before`（1px 竖线）+ `::after`（1px 横线）画出，颜色是 `text` 55%，定位在框外 −6px 处。

**注意**：`.blueprint` 与图像处理类（`.halftone` / `.plate` / `.duotone`）共用一个包装器时，样式表强制 `overflow: visible`——因为角标画在盒子外面，框必须赢过图像裁剪。

**绝不许从已加框元素上去掉套准标记。** 四个都要，少一个就破了语法。

### 6. 图像处理

```html
<figure class="blueprint duotone">
  <i class="corner tl"></i>…
  <img src="…">
</figure>
```

`.duotone` = `position: relative; overflow: hidden` + 一层 `::after` 铺满 `--color-accent`，`mix-blend-mode: color`。效果是照片去饱和后被钢蓝洗过一遍，像跟着主题重新上色的丝网印。

**所有内容照片都必须过这个包装器。** 图和图框跟卡片同样待遇：方角、发丝边、带角标，永不圆角、永不裁切成异形。

### 7. 组件

| 类名 | 说明 |
| --- | --- |
| `.btn` + `.btn-primary / -secondary / -ghost / -icon / -block` | 全部方角带边。primary 是实心钢蓝 + 钢蓝边 + 纸色字（图板上唯一实体）；ghost 边框透明；`.btn-icon` 36×36；字体 heading 族 600 / 14px |
| `.tag` + `.tag-accent / -accent-2 / -neutral / -outline` | 方角小标签（100 底 + 800 字）。单色调色板下 accent-2 与 accent 观感相同 |
| `.field` + `label` / `.input` / `.radio` + `.dot` / `.seg` + `.seg-opt` | 原生元素表单，无脚本。`.input` 36px 高、surface 底、方角、caret 钢蓝 |
| `.card` + `.card-kicker / -title / -body / -meta` | **透明**、发丝边、方角；配 `.blueprint` + 四角标使用。`.elev-sm/md/lg` 可选高度 |
| `.nav` + `.nav-brand` | 顶栏，`border-bottom: none` |
| `.table` | 大写细字表头 + 8% 墨行线，hover 行底 4% |
| `.dialog-backdrop` + `.dialog`（`-title / -body / -actions`） | 背景 `neutral-900` 50%；对话框 `min(440px, 100%)`、方角、**surface 填充 + 发丝边**（唯一带填充的容器例外） |
| `.hr` | 1px 细线，存在但本系统偏好留白——**避免使用** |
| `.blueprint` + 四个 `.corner` | 上面第 5 节 |
| `.duotone` | 上面第 6 节 |
| `.text-muted` | text 55% |

#### 交互态（已内建，不要逐页重写）

- `.btn-primary` hover → `--color-accent-600`；active → `--color-accent-700`
- `.btn-secondary` hover → text 7%；active → 14%
- `.btn-ghost` hover → 钢蓝 10%；active → 18%
- `.input:hover` → 边框 text 45%；`:focus-visible` → 钢蓝边框，`outline-offset: 0`
- `.radio input:checked + .dot` → 钢蓝填充 + `inset 0 0 0 4px var(--color-bg)` 做内圈（这里是圆的——radio 保留 `border-radius: 50%`）
- `.seg-opt:has(input:checked)` → 钢蓝底 + 纸色字
- 键盘焦点：`:focus-visible { outline: 2px solid var(--color-accent); outline-offset: 2px }`
- `::selection` → 钢蓝 30%
- disabled → `opacity: 0.45` + `cursor: not-allowed`
- `a` → 钢蓝，`text-underline-offset: 3px`；`.nav a:hover` / `[aria-current=page]` → 钢蓝

### 8. 图标

Lucide（lucide.dev），**统一 stroke-width 1.5**。不许用粗描边。

### 9. 布局方向

模块化网格：内容放进**等宽单元格**，强横向与纵向节奏，结构可见。别把它做成流动的、居中的、卡片浮起的常规网页——它是图板。

---

### 禁止清单

1. 给卡片、图框、按钮加圆角
2. 给卡片或图框加填充底（它们是线稿；实心 accent 主按钮是唯一刻意的例外）
3. 从已加框元素上去掉套准标记
4. 粗描边图标（Lucide 固定 1.5）
5. 钢蓝之外的装饰色（唯一放行：`--color-accent-900` 在 deck 分节页铺整幅）
6. 正文用 `--color-accent` 本值（要用 `-700`）
7. 正文也用 Barlow Condensed
8. `.hr` 当主要分隔手段
9. 硬编码 hex / 字体名 / px（token 里已有的）

### 接入方式

```html
<helmet>
  <link rel="stylesheet" href="_ds/industry-7eb0c315-f7e5-4fe7-9873-401826ed322b/styles.css">
  <script src="_ds/industry-7eb0c315-f7e5-4fe7-9873-401826ed322b/_ds_bundle.js"></script>
</helmet>
```

组件直接在模板里挂载：

```html
<x-import component-from-global-scope="Industry_indust.Button" hint-size="auto,40px">Label</x-import>
```

### 可用模板

- `templates/deck/` —— 21 页演示起点：封面、目录、分节页、分栏、四宫格、数据表、SVG 图表与时间轴、出血图、引言、结尾
- `templates/landing/` —— 单页产品落地页（虚构产品 Holdfast，紧固件目录）：压缩字 hero、编号规格牌、线框单元格、双色照片
- `assets/photo.jpg` —— 图像处理页用的参考照片

## Do's and Don'ts

- Do：按上述 token 与签名组件实现视觉语言，并根据用户内容组织信息。
- Don't：不要为套用示例而改变用户内容的业务语义。
