---
version: alpha
name: wild-orange
name_zh: 橙色野性
description: 野性主义(Brutalist)×包豪斯几何×杂志编辑排版。纯白画布上黑色粗边框(2-4px)构建骨架,硬偏移阴影(4px/8px,零模糊)强化层次,橙色作为唯一暖色强调锚点,严格黑白橙三色配色。零圆角方形卡片(完全圆形徽章/头像除外),标题无衬线粗体大写,斜体衬线(Playfair Display)点缀装饰文字与数值,几何装饰圆呼应包豪斯语言。情绪基调:自信、大胆、现代。
colors:
  bg: "#ffffff"
  surface: "#ffffff"
  header: "#ff6600"
  text: "#000000"
  text-muted: "#666666"
  primary: "#ff6600"
  accent: "#ffd1b3"
  border: "#000000"
  gray-state: "#999999"
typography:
  heading-body:
    fontFamily: 'Space Grotesk, "PingFang SC", "Microsoft YaHei", "Noto Sans SC", sans-serif'
    fontWeight: 500
    usage: 全局无衬线字体(标题/正文/标签/图表文字),标题额外 font-bold(700)+uppercase
  decorative:
    fontFamily: '"Playfair Display", serif'
    fontStyle: italic
    usage: 装饰性文字/副标题/信息卡片(小)数值,斜体点缀,不用于长正文
rounded:
  card: 0px
  full: 9999px
spacing:
  page-px: "16px~32px(px-4 sm:px-6 lg:px-8)"
  section-gap: 48px
  card-padding: 24px
  header-padding: "32px~64px(p-8 lg:p-16)"
  component-gap: "16px/32px(gap-4/gap-8)"
components:
  brutal-card:
    background: "{colors.surface}"
    border: "2px solid {colors.border}"
    borderRadius: "{rounded.card}"
    boxShadow: "4px 4px 0px 0px {colors.border}"
    padding: "{spacing.card-padding}"
    hover: "transform translate(2px,2px);boxShadow 收缩至 2px 2px 0px 0px {colors.border};transition all 0.2s ease"
  header-banner:
    background: "{colors.primary}"
    border: "4px solid {colors.border}"
    boxShadow: "8px 8px 0px 0px {colors.border}"
    padding: "{spacing.header-padding}"
    decoration: "几何装饰圆(absolute rounded-full border-2 border-black opacity-20,大圆/小圆两档)+黑底状态卡片"
  navigation:
    background: "{colors.surface}"
    borderBottom: "2px solid {colors.border}"
    height: 64px
    logo: "{colors.border}底,32×32,白字加粗"
    versionBadge: "{rounded.full},{colors.primary}底,border 1px {colors.border},文字加粗"
  badge:
    borderRadius: "{rounded.full}"
    border: "1px solid {colors.border}"
    background: "{colors.surface}或{colors.primary}"
    padding: "4px 16px"
    fontWeight: 700
  info-card-small:
    background: "{colors.surface}"
    border: "2px solid {colors.border}"
    padding: 12px
    valueFont: "{typography.decorative}"
  charts:
    palette: "{colors.primary} {colors.text} {colors.text-muted} {colors.accent} {colors.gray-state}"
    container: "{colors.surface}底+2px {colors.border}边框+4px 偏移阴影(即 brutal-card 样式)"
    axis: "轴线/刻度 2px {colors.border},标签 11px 加粗(600),字体见 {typography.heading-body}"
    tooltip: "{colors.surface}底,2px {colors.border}边框,{rounded.card}(直角),硬阴影 4px 4px 0 {colors.border}"
    legend: "icon=rect 16×16,itemGap 16,文字加粗(600)"
anchors:
  - id: brutal-border-shadow
    type: pattern
    desc: 全局粗黑边框叠加硬偏移阴影(见 components.brutal-card 的 boxShadow),零模糊,是品牌核心签名
  - id: tri-color-strict
    type: pattern
    desc: 严格黑白橙三色系统(见 colors 各角色),不引入其他色相干扰纯粹性
  - id: zero-radius-shape
    type: pattern
    desc: 卡片一律零圆角方形,唯一例外是完全圆形的徽章与头像(见 Exceptions)
  - id: header-banner
    type: component
    desc: 橙色强调横幅+粗边框+几何装饰圆，可在最重要的内容区域作为视觉锚点
  - id: playfair-italic-accent
    type: token
    desc: 衬线斜体(Playfair Display)专用于装饰性文字与信息卡数值,与无衬线正文对比
  - id: hover-press-shift
    type: pattern
    desc: 卡片 hover 位移配合阴影收缩,模拟物理按压反馈
  - id: geometric-circle-decor
    type: component
    desc: 低透明度描边几何圆装饰散布 Header 与卡片背景,呼应包豪斯几何语言
gaps:
  - 无暗色模式定义
  - 无表单控件(input/select 等)规范
  - 补充项:本文件 colors 全部 hex 值由源 HSL 值换算得出(源全部以 HSL 给出,无 hex),按标准 HSL→RGB→hex 公式精确换算,非凑整/非取默认值,可能有 ≤1 的舍入误差,不改变色相/饱和度/明度语义
  - 补充项:字体加载语法由源 `<link>` 标签按 DSM 规范转换为等效 `@import`(URL/字重参数原样保留,仅切换加载语法)
exceptions:
  - 完全圆形的徽章/头像/滚动条滑块使用 {rounded.full},是零圆角规则唯一例外
  - gray-state(灰色状态色)仅用于图表次级序列与灰色圆点标记,不用于正文/边框/主要强调
  - Playfair Display 只承载拉丁装饰文字；中文装饰文字回退到 Songti SC / Noto Serif SC
---

## Overview

野性主义(Brutalist)× 包豪斯几何 × 杂志编辑排版。极简主义与强对比结合:纯白画布上黑色粗边框(2-4px)构建骨架,硬偏移阴影(4px/8px,零模糊)强化层次,橙色作为唯一暖色强调锚点。严格黑白橙三色配色,几何装饰圆与椭圆徽章点缀,零圆角方形卡片(完全圆形徽章/头像除外),标题无衬线粗体大写,斜体衬线(Playfair Display)点缀装饰文字与数值。情绪基调:自信、大胆、现代。

## Colors

| 角色 | 值 | 用法 |
|-----|-----|-----|
| bg | {colors.bg} | 页面背景(纯白) |
| surface | {colors.surface} | 卡片背景(纯白) |
| header | {colors.header} | Header 橙色横幅背景(与 primary 同值) |
| text | {colors.text} | 正文(纯黑) |
| text-muted | {colors.text-muted} | 次要文字(深灰) |
| primary | {colors.primary} | 主交互色:橙色强调、CTA、状态激活、图表主色,权重最高 |
| accent | {colors.accent} | 弱强调色:浅橙背景、头像底色、hover 轻底,权重低于 primary |
| border | {colors.border} | 边框(纯黑粗线),承担结构角色;与 text 同值 |
| gray-state | {colors.gray-state} | 中灰状态色、图表次级序列色 |

三色原则:页面仅使用黑/白/橙三色(surface/bg 白,text/border 黑,primary/header 橙);accent 由 primary 提亮得到(H/S 不变,L 50%→85%);gray-state 为独立辅助状态色,不计入三色主色板。成功/激活语义色复用 primary;浅橙背景语义色复用 accent。选区样式:`::selection { background: {colors.primary}; color: white }`。

换算说明:源色值为 HSL,本文件按标准 HSL→RGB→hex 公式换算为等值 hex(无信息损失,可能有 ≤1 舍入),详见 frontmatter gaps。

## Typography

全局样式首行原样写入(HARD REQUIREMENT,禁止替换):

```css
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,400;1,400;1,600&display=swap');
```

Space Grotesk 的 fontFamily 已含 CJK 兜底(PingFang SC/Microsoft YaHei/Noto Sans SC,系统字体无需 @import)。Playfair Display 仅用于拉丁装饰文字；中文装饰文字回退到 Songti SC / Noto Serif SC。

| 层级 | 样式(Tailwind) | 颜色 |
|-----|-----|-----|
| H1 超大标题 | text-5xl lg:text-7xl font-bold uppercase tracking-tighter leading-[0.9] | text |
| H2 章节标题 | text-3xl font-bold uppercase | text |
| 装饰性文字 | font-serif italic text-lg({typography.decorative}) | text |
| 正文 | text-sm font-normal | text |
| 次要文字 | text-xs | text-muted |
| 标签文字 | text-xs font-bold uppercase tracking-wider | text |

## Layout

- 导航若存在，可用 Logo 黑方块、粗体大写标题和橙色徽章延续视觉语言；位置和是否固定由应用信息架构决定。
- 橙色强调横幅可用于主标题、关键结论或主要行动区域，使用 4px 黑边、brutal-shadow-lg 和几何装饰圆；不要求位于首屏。
- 章节标题、内容卡片和其他模块按任务关系组合，不固定页面顺序。
- 间距:页面边距 {spacing.page-px};区块间距 {spacing.section-gap};卡片内边距 {spacing.card-padding};组件间距 {spacing.component-gap}。
- 响应式断点按信息关系减少列数和内边距；窄屏保证粗边框、硬阴影与文本之间有足够空间。

## Elevation & Depth

硬偏移阴影两档,全部零模糊,颜色一律 {colors.border}(黑):

| 档位 | 值 |
|-----|-----|
| brutal-shadow | 4px 4px 0px 0px {colors.border} |
| brutal-shadow-lg | 8px 8px 0px 0px {colors.border} |

层次感 = 粗黑边框 + 硬偏移阴影,不用模糊阴影/渐变。Hover 交互:卡片位移 translate(2px,2px)+阴影收缩至 2px 2px 0px 0px {colors.border},transition all 0.2s ease。

## Shapes

- 圆角:卡片一律零圆角方形({rounded.card});完全圆形徽章/头像/滚动条滑块用 {rounded.full}(见 Exceptions)。
- 边框语言:全局卡片 2px 实线 {colors.border};Header Banner 4px 实线;导航底边 2px;信息卡片(小)2px;装饰性描述文字左侧 4px 竖线({colors.border})。
- 装饰元素:几何装饰圆(absolute rounded-full border-2 border-black opacity-20,大圆/小圆两档),散布 Header 与卡片背景;SVG 线性图标装饰(absolute top-0 right-0 p-12 opacity-10 {colors.text} stroke-width-1.5)。
- 滚动条:轨道 #f1f1f1,滑块 {colors.border},宽 8px(源特定 UI 细节,未纳入 colors 命名色板)。
- 动画:transition-all duration-200(卡片 hover 位移+阴影收缩)。

## Components

核心组件规格见 frontmatter components(brutal-card / header-banner / navigation / badge / info-card-small / charts)。补充细节:

- **BrutalCard**:所有内容卡片的基座,头部 border-b-2 border-black pb-4 mb-6。
- **HeaderBanner**:含标签(rounded-full border border-black bg-white px-4 py-1 text-sm font-bold)+描述(border-l-4 border-black pl-4 text-lg font-medium)。
- **章节标题**:编号圆 w-10 h-10 border-2 border-black bg-primary rounded-full text-lg font-bold;标题 text-3xl font-bold uppercase;副标题 font-serif italic text-lg。
- **野性主义卡片(内容卡)**:头像 w-12 h-12 rounded-full border-2 border-black bg-accent;橙色三角标记 text-primary "->" / 灰色圆点 w-2 h-2 rounded-full border border-black bg-gray-200(对应 colors.gray-state)。
- **信息卡片(小)**:bg-white border-2 border-black p-3,标签 text-xs uppercase font-bold,值 font-serif italic text-lg(见 {typography.decorative})。
- **图表(ECharts)**:序列色按 components.charts.palette 顺序;line/area smooth:false(硬朗折线)+symbol:'rect'(方形标记)+面积透明度 0.15;bar barWidth '50%'+borderRadius 0+2px 黑描边+硬阴影偏移 3px;pie 环形 50%~75%+padAngle 0+2px 黑描边;外部 label 加粗。图表容器高度与排列按数据量和可用空间确定。

## Do's and Don'ts

- Primary/Accent 分工:primary(橙)用于核心强调与交互,accent(浅橙)用于次级装饰与底色,权重不互换。
- 大胆字重对比:标题用 font-bold(700)+装饰性文字用 Playfair 斜体,避免整段常规字重独立展示为标题。
- Grid 优先布局:卡片网格严格对齐,图表边框/标记/阴影风格与整体统一,不单独设计。
- 装饰圆/SVG 线性图标是低透明度点缀,避免高对比度喧宾夺主。

## Hard Rules

- 仅使用黑/白/橙三色(见 colors),禁止引入其他色相干扰画面纯粹性(gray-state 为独立辅助状态色,不计入三色主色板)。
- 卡片圆角必须为 {rounded.card}(零圆角方形),完全圆形徽章/头像/滚动条滑块除外(见 Exceptions)。
- 阴影必须是纯偏移硬阴影(0 模糊,{colors.border} 色),禁止使用模糊(blur)阴影或渐变阴影。
- 卡片必须带 2px 实线 {colors.border} 边框(Header Banner 用 4px),禁止无边框卡片。
- 字体 @import 必须原样写入全局样式首行,禁止替换或省略(HARD REQUIREMENT)。
- 标题一律 uppercase + font-bold,禁止小写标题或常规字重独立展示为标题。

## Exceptions

- 完全圆形的徽章/头像/滚动条滑块使用 {rounded.full},是零圆角规则唯一例外。
- gray-state(灰色状态色)仅用于图表次级序列与灰色圆点标记,不用于正文/边框/主要强调。
- Playfair Display 仅用于拉丁装饰文字；中文装饰文字使用 Songti SC / Noto Serif SC。
