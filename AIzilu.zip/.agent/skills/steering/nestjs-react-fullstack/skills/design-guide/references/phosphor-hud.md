---
version: alpha
name: phosphor-hud
name_zh: 赛博光幕
description: 纯黑底色+单一霓虹绿色相的赛博朋克/军事级 HUD 终端风格,通过 primary 10 级透明度建立全部视觉层级(不引入第二色相,含风险/预警等语义状态色);CRT 扫描线+胶片噪点叠加、等宽字体全大写+方括号语法(模拟终端命令行)、L 型转角方括号取代传统圆角(全局零圆角)、发光效果(text-shadow/box-shadow)营造深度;情绪基调工业化、机械感、矩阵终端压迫感。
colors:
  bg: "hsl(0 0% 4%)"
  surface: "hsl(0 0% 7%)"
  header: "hsl(0 0% 0%)"
  text: "hsl(0 0% 100%)"
  textMuted: "hsla(137 100% 50% / 0.4)"
  primary: "hsl(137 100% 50%)"
  accent: "hsla(137 100% 50% / 0.1)"
  border: "hsla(137 100% 50% / 0.3)"
  inverse: "hsl(0 0% 0%)"
typography:
  mono:
    fontFamily: '"Space Mono", monospace'
    usage: 主字体/正文/代码等宽基础字体(Tailwind font-mono)
  heading:
    fontFamily: '"Inter", "Space Mono", monospace'
    fontWeight: 900
    usage: 标题黑体字重(Tailwind font-black)
rounded:
  none: "0px"
  scrollbar-thumb: "3px"
spacing:
  container-wide: "1400px"
  container-standard: "1280px"
  container-narrow: "896px"
  container-text: "672px"
  section-gap: "96px"
  hero-pt: "160px"
  hero-pb: "80px"
  cta-gap: "128px"
  heading-gap: "80px"
  card-padding: "32px~48px"
components:
  hud-card:
    border: "1px solid {colors.primary}/30"
    background: "{colors.surface}"
    padding: "{spacing.card-padding}"
    corner: "四角 10px×10px,border 2px solid {colors.primary}(L 型方括号,取代圆角)"
    hover: "bg-{colors.primary}/5"
    highlight-variant: "border-{colors.primary}(实色)+发光阴影(见 Elevation)+bg-{colors.primary}/5"
  button:
    primary: "bg-{colors.primary} text-{colors.inverse} font-black uppercase tracking-[0.2em] px-10 py-5,零圆角"
    secondary: "border border-{colors.primary}/50 text-{colors.primary} hover:bg-{colors.primary}/10,零圆角"
    full-width: "w-full py-5 tracking-[0.3em]~[0.4em]"
    disabled: "bg-{colors.primary}/20 text-{colors.primary}/40"
  navbar:
    position: "fixed top-0 z-[110]"
    idle: "py-6 bg-transparent"
    scrolled: "py-4 bg-{colors.header}/90 border-b border-{colors.primary}/30 transition-all duration-300"
  badge:
    base: "px-4 py-1 border border-{colors.primary}/50 bg-{colors.primary}/10 text-{colors.primary} text-[10px] font-bold tracking-[0.3em] uppercase"
  icon-box:
    base: "w-16 h-16 border border-{colors.primary}/30 flex items-center justify-center text-{colors.primary}"
    hover: "group-hover:bg-{colors.primary} group-hover:text-{colors.inverse}"
  divider:
    horizontal: "h-px w-full bg-{colors.primary}/20 shadow-[0_0_15px_hsla(137,100%,50%,0.2)]"
    left-accent: "border-l-2 border-{colors.primary}"
    list-dot: "w-1.5 h-1.5 bg-{colors.primary} mr-3"
  data-status:
    critical: "bg-{colors.primary} text-{colors.inverse} px-2 py-0.5 text-[10px] font-bold uppercase tracking-[0.15em],前缀方括号文字标签「[高危]」/「[异常]」,复用 button.primary 反转配色,禁止红色底"
    warning: "border border-{colors.primary}/50 text-{colors.primary} px-2 py-0.5 text-[10px] font-bold uppercase tracking-[0.15em],前缀方括号文字标签「[预警]」,禁止黄/橙色底"
    normal: "border border-{colors.primary}/20 text-{colors.textMuted} px-2 py-0.5 text-[10px] uppercase tracking-[0.15em],前缀方括号文字标签「[正常]」"
anchors:
  - id: pure-black-neon-primary
    type: token
    desc: 页面主背景为近纯黑(colors.bg)搭配霓虹绿(colors.primary)作为唯一强调色相,靠透明度分层
  - id: crt-scanline-overlay
    type: pattern
    desc: 全屏固定扫描线+胶片噪点叠加层模拟 CRT 显示器质感
  - id: hud-corner-bracket
    type: component
    desc: 卡片四角 L 型方括号装饰(见 components.hud-card)取代传统圆角边框
  - id: zero-radius-global
    type: token
    desc: 全局卡片/按钮圆角归零(见 rounded.none),唯一例外是滚动条滑块
  - id: uppercase-mono-typography
    type: pattern
    desc: 标题/标签/按钮统一大写等宽字体+宽字距排版(见 typography),正文段落保持常规大小写
  - id: bracket-nav-syntax
    type: component
    desc: 导航链接与区段小标签使用方括号语法包裹,模拟终端命令行界面
  - id: cta-color-inversion
    type: pattern
    desc: 页面末尾 CTA 区段整体色彩反转为主色实底+反转文字色,形成全页唯一强对比锚点
  - id: grayscale-imagery
    type: token
    desc: 全部图片统一去色处理(灰度+提升对比度),呼应终端灰阶氛围
gaps:
  - 无 deck 画布/幻灯片专属排版规格(源为单页营销落地页,非幻灯片场景)
  - 无暗色/亮色双模式定义(本身即暗色单模式风格)
  - 无图表/ECharts 组件规格(源未提及数据可视化组件);图表序列色若需多序列,一律用 primary 不同不透明度分级,不引入第二色相
  - 无表单控件(input/select 等)规范
exceptions:
  - 滚动条滑块使用 rounded.scrollbar-thumb(3px),是全局零圆角的唯一例外
  - 高亮卡片(highlight variant)边框改为 primary 实色+发光阴影,而非默认 primary/30
  - CTA 反转区段允许 primary 作大面积实色底,是全局黑底外唯一的大面积主色应用场景
  - 按钮/CTA 上的反转文字色使用 colors.inverse(纯黑),是 primary 填充区域上文字色的唯一例外
  - components.data-status 的 critical 等级复用 button.primary 反转配色(非新增色彩,与 CTA 反转同源),不算引入第二色相
---

## Overview

赛博朋克 × 军事级 HUD(抬头显示器)终端风格。纯黑背景模拟 CRT 显示器环境,霓虹绿(primary)作为唯一色相,通过 10 级透明度建立严格视觉层级,不引入第二色相。视觉信号:CRT 扫描线+胶片噪点叠加、等宽字体全大写+方括号语法(模拟终端命令行)、L 型转角方括号 HUD 边框取代传统圆角、图片统一 grayscale 去色。情绪基调:工业化、机械感、矩阵终端压迫感。

## Colors

| 角色 | 值 | 用法 |
|-----|-----|-----|
| bg | {colors.bg} | 页面主背景,近纯黑 |
| surface | {colors.surface} | 卡片/面板底色 |
| header | {colors.header} | 导航栏滚动后背景 |
| text | {colors.text} | 标题、姓名等高层级白色文字;**不含 KPI/统计数字**(后者固定用 primary,见 Hard Rules) |
| textMuted | {colors.textMuted} | 低透明度绿,标签、辅助说明、脚注、data-status normal 态文字 |
| primary | {colors.primary} | 霓虹绿:主交互、主按钮、激活边框、品牌标识、KPI 数字、风险/预警等级标签,视觉权重最高 |
| accent | {colors.accent} | 极弱绿色着色:hover 底色、区段微着色,权重低于 primary |
| border | {colors.border} | 卡片边框(HUD 边框线) |
| inverse | {colors.inverse} | primary 填充区域上的反转文字色(按钮/CTA 反转区段/data-status critical 态) |

透明度层级:primary 通过 10 级透明度(5%~100%)建立完整视觉层次;正文描述用 primary/80;边框默认 primary/30(卡片描边)、primary/50(标签/Badge 边框)。发光效果:`text-shadow: 0 0 8px hsla(137,100%,50%,0.6)` 模拟 CRT 自发光;关键元素 `box-shadow: 0 0 50px hsla(137,100%,50%,0.1)` 霓虹绿光晕。选中态:`selection:bg-{colors.primary} selection:text-{colors.inverse}`。

**风险/预警/异常/VIP 等级、表格状态标签等仪表盘常见语义状态,禁止套用红=危险/黄=警告/绿=正常的通用配色惯例**,一律用 `components.data-status`(primary 不同强度 + 方括号文字标签)表达,见 Components 与 Hard Rules。

## Typography

全局样式首行原样写入(HARD REQUIREMENT,禁止替换):

```css
@import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap');
```

| 用途 | 字体栈 |
|-----|-------|
| 主字体/正文/代码 | {typography.mono.fontFamily} |
| 标题(黑体) | {typography.heading.fontFamily} |

| 层级 | 样式(Tailwind) | 颜色 |
|-----|-----|-----|
| 品牌名 | text-xl font-black tracking-widest + scanline 发光 | primary |
| 页面主标题 H1 | text-6xl~text-8xl font-black tracking-tighter uppercase leading-none + scanline | text |
| 区段标题 H2 | text-5xl~text-6xl font-black tracking-tighter uppercase | text |
| 卡片标题 H3 | text-xl~text-2xl font-black tracking-[0.2em] uppercase | text |
| 区段小标签 | text-[10px] font-bold tracking-[0.3em]~[0.5em] uppercase | primary |
| 导航链接 | text-[10px] font-bold tracking-[0.2em] uppercase,方括号包裹 | primary/70 |
| 正文段落 | text-lg~text-xl font-mono tracking-tight leading-relaxed,前缀「[系统信息]:」 | primary/80 |
| 统计数字 | text-3xl~text-5xl font-black,禁止用 text(白色) | primary |

## Layout

- 可按内容层级选择宽幅、标准、窄幅或文字容器，容器 token 是尺度参考，不绑定 Navbar、Hero、Pricing 等业务区块。
- 区段纵向间距参考 {spacing.section-gap}，标题与内容间参考 {spacing.heading-gap}，卡片内边距使用 {spacing.card-padding}；具体模块顺序和列数由任务决定。
- 主色反转面可作为一次强对比锚点出现在最重要的行动或状态区域，不要求位于页面末尾。
- 窄屏减少列数、缩小间距并保证按钮可操作；HUD 转角装饰可在空间不足时简化，但不影响内容可读性。

## Elevation & Depth

无常规投影分级(纯平面终端美学),仅两类发光效果:

| 效果 | 值 | 用途 |
|-----|-----|-----|
| 关键元素光晕 | box-shadow: 0 0 50px hsla(137,100%,50%,0.1) | 高亮卡片、CTA |
| 文字发光 | text-shadow: 0 0 8px hsla(137,100%,50%,0.6) | 品牌名、H1,模拟 CRT 自发光 |

不使用模糊常规投影(偏移+blur 阴影);深度感全靠边框(border)+发光(glow)+HUD 转角装饰营造。

## Shapes

- 圆角:全局 {rounded.none}(border-radius: 0),唯一例外滚动条滑块 {rounded.scrollbar-thumb}。
- HUD 转角:四角 L 型方括号装饰,`position: absolute; width: 10px; height: 10px; border: 2px solid {colors.primary}`,取代传统圆角边框。
- CRT 特效:扫描线叠加(fixed inset-0 z-100,4px 横线+3px RGB 竖线);噪点纹理(fixed inset-0 z-99 opacity-0.05 stardust 图案);扫描动画(2px h-full 绿色线条,animation: scan 4s linear infinite);图片去色(grayscale + contrast-125)。

## Components

组件规格见 frontmatter components(hud-card / button / navbar / badge / icon-box / divider / data-status)。补充说明:

- **hud-card**:所有卡片的基座,四角 L 型方括号取代圆角(见 Shapes)。highlight 变体边框升级为 primary 实色并叠加光晕阴影。
- **button**:主按钮反转配色(primary 底+inverse 字),次按钮描边;disabled 态整体降低 primary 透明度。
- **navbar**:滚动前透明,滚动后切换为 header 底色+底部描边,300ms 过渡。
- **badge**:方括号标签语义的载体,搭配区段小标签使用。
- **icon-box**:默认描边容器,hover 反转为 primary 实底+inverse 图标色。
- **divider**:水平分隔线自带霓虹光晕阴影;左侧强调用实色竖线;列表项用小方点(非圆点)标记,呼应零圆角基调。
- **data-status**:仪表盘/报表场景的风险等级、表格异常状态、预警提示专用,替代传统红/黄/绿语义配色约定——critical(实底反转)、warning(描边)、normal(弱描边)三级仅靠 primary 强度 + 方括号文字标签(如「[高危]」「[预警]」「[正常]」)区分,不引入红/黄/橙。

## Do's and Don'ts

- 方括号语法建议用于导航链接/区段小标签,强化终端命令行感,非强制所有文本元素都包裹方括号。
- CTA 反转区段建议全页仅在末尾使用一次,避免削弱纯黑底的整体氛围。
- 扫描线/噪点叠加层建议保持低透明度(噪点 opacity 0.05 量级),避免影响正文可读性。
- 发光效果(box-shadow/text-shadow)建议只用于关键元素(高亮卡片、品牌名、主标题),避免全局滥用打断视觉层级。

## Hard Rules

- 全局仅使用 primary 单一色相区分视觉层级,**禁止引入第二色相,包括红/黄/橙等语义状态色**;层级差异只靠 primary 透明度与字号区分。
- 风险/预警/异常/VIP 等级、表格状态标签等仪表盘常见语义状态,一律用 `components.data-status`(primary 不同强度 + 方括号文字标签)表达,**禁止套用红=危险/黄=警告/绿=正常的通用配色惯例**,即使内容语境(如"高危""异常""缺口")在常见仪表盘中习惯用红黄标注。
- KPI/统计数字(仪表盘核心指标大数字)必须使用 primary 色,**禁止使用 text(白色)作为强调数字色**;text 仅用于页面标题、姓名等非数据类文字。
- 卡片与按钮统一零圆角(border-radius: 0),唯一例外是滚动条滑块 3px 圆角。
- 卡片四角必须保留 L 型 HUD 转角方括号装饰,不得省略或替换为传统圆角。
- 标题、区段标签、导航链接、按钮统一 uppercase + tracking-widest/[0.2em]~[0.5em] 宽字距;正文段落保持常规大小写。
- 所有图片必须应用 grayscale + contrast-125 去色处理,禁止彩色图片直出。
- 字体 @import 必须原样写入全局样式首行,禁止替换或省略(HARD REQUIREMENT)。
- Primary 用于所有交互与视觉焦点(按钮/边框/品牌),Accent 仅用于 hover 微光底色/区段极弱着色,不可互换用途。

## Exceptions

- 滚动条滑块:{rounded.scrollbar-thumb} 圆角,是全局零圆角的唯一例外。
- 高亮卡片(highlight variant):边框改为 primary 实色+发光阴影,非默认 primary/30 描边。
- CTA 反转区段:允许 primary 作大面积实色底,是全局黑底外唯一的大面积主色应用场景。
- 按钮/CTA 反转文字色使用 colors.inverse(纯黑),是 primary 填充区域上文字色的唯一例外。
- data-status.critical 复用 button.primary 反转配色(primary 底+inverse 字),与 CTA 反转同源,不算引入第二色相。
