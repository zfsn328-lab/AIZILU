---
version: alpha
name: pop-art
name_zh: 波普艺术
description: 美式漫画/丝网印刷波普风——高饱和四色(黄/红/绿/蓝)+纯黑纯白,零渐变零透明叠加;所有容器纯黑粗描边(2~8px)配纯色零模糊硬阴影(色块偏移,非 blur),背景叠加半色调圆点纹理(致敬 Ben-Day dots);装饰大标题用漫画体 Bangers,全部标题/标签 uppercase+宽字距+font-black(900);圆角只取极端两端(超大圆角或完全无圆角);标题色块/CTA 施加 1~3deg 微倾斜模拟拼贴剪报感;交互强调硬位移("按下"感)而非缓动渐变。视觉冲击、直接、图形化。
colors:
  primary: "#FFDE00"
  accent: "#FF3B30"
  success: "#4CD964"
  info: "#007AFF"
  ink: "#000000"
  surface: "#FFFFFF"
  surface-warm: "#FFF9C4"
  surface-warm-alt: "#FFFDF5"
  button-yellow: "#FFCC00"
  status-green: "green-400(Tailwind 默认色,源未给 hex)"
  status-red: "red-400(Tailwind 默认色,源未给 hex)"
  overlay: "black/60"
typography:
  display:
    fontFamily: 'Bangers, "PingFang SC", "Microsoft YaHei", "Noto Sans SC", cursive'
    fontWeight: 400
    usage: 装饰性大标题/Section Header(.pop-font),全大写宽字距
  heading:
    fontFamily: '"Noto Sans SC", system-ui, sans-serif'
    fontWeight: 900
    usage: 弹窗标题/卡片标题/侧边栏标题/统计数值等 font-black 主体文本,全大写
  quote:
    fontFamily: '"Noto Sans SC", system-ui, sans-serif'
    fontWeight: 700
    usage: 引言/描述性斜体文本,opacity 70%,唯一非 font-black 角色
rounded:
  xl: 4rem
  lg: "3rem / 2.5rem"
  full: 9999px
spacing:
  sidebar-width: 20rem
  container-max: 80rem
  content-padding: "24px~48px"
  card-padding: "20px~32px"
  sidebar-padding: 32px
  modal-padding: 48px
  column-gap: 48px
  column-gap-v: 40px
  nav-gap: 16px
components:
  pop-card:
    background: "{colors.surface}(默认) | {colors.surface-warm-alt} | {colors.ink}"
    border: "6px solid {colors.ink}(弹窗用 8px)"
    boxShadow: "12px 12px 0px 0px {colors.ink}(默认档,见 Elevation)"
    padding: "{spacing.card-padding}"
    borderRadius: "{rounded.lg}"
  pop-button:
    border: "4px solid {colors.ink}"
    boxShadow: "4px 4px 0px 0px {colors.ink}"
    padding: "24px 12px(默认) | 24px(大按钮)"
    borderRadius: "{rounded.full}"
    fontStyle: font-black uppercase tracking-widest
    variants: "red={colors.accent}白字(暂停/停止) | green={colors.success}黑字(开始/选中) | blue={colors.info}白字(选择/商店) | yellow={colors.button-yellow}黑字(默认/重置) | black={colors.ink}白字(强调) | white={colors.surface}黑字(未选中)"
    active: "translate(2px,2px)+阴影缩小至 2px;disabled opacity-50;选中态 scale-105+ring-4 ring-black ring-offset-2"
  section-header:
    background: "{colors.ink} | {colors.accent}(按主题)"
    color: "{colors.surface}"
    padding: "32px 12px"
    borderRadius: "0(完全无圆角,方形色块呼应剪报/漫画分格感)"
    rotate: "-1deg | 1deg"
    boxShadow: "8px 8px 0 0 {colors.success} | 8px 8px 0 0 {colors.ink}"
    typography: text-5xl font-black pop-font uppercase tracking-tighter
  status-bar:
    background: "{colors.ink}"
    color: "{colors.surface}"
    padding: "32px 20px"
    borderRadius: "0 0 2.5rem 2.5rem"
    typography: font-black uppercase tracking-widest text-xs
    layout: flex justify-between items-center
  progress-bar:
    track: "{colors.ink}底,border-4 {colors.ink},{rounded.full},内 padding 4px"
    inner-track: "bg-gray-900,高 32px,{rounded.full}"
    fill: "{colors.success},{rounded.full}"
    label: "覆盖居中,{colors.surface} 10px font-black uppercase tracking-widest"
  stat-item:
    layout: flex justify-between items-center
    divider: "border-b-4 {colors.ink}/5(见 Exceptions),底 padding 20px"
    label: font-black text-lg opacity-60 uppercase tracking-widest
    value: "font-black text-5xl + 主题色 + drop-shadow(2px 2px 0 {colors.ink})"
  pill-tag:
    background: "语义色浅底(如 -50)"
    color: "语义色主色(如 -500)"
    padding: "16px 8px"
    typography: text-xs font-black uppercase
    borderRadius: "{rounded.full}"
    border: "2px solid 语义色浅描边(如 -100)"
    boxShadow: "2px 2px 0 0 {colors.ink}(纯色偏移,禁止半透明)"
  modal-overlay:
    mask: "{colors.overlay}+backdrop-blur-md,z-[100],fixed inset-0 flex center,padding 24px"
    card: "{colors.surface}底,border-[8px] {colors.ink},padding {spacing.modal-padding},{rounded.xl},boxShadow 24px 24px 0 0 {colors.button-yellow}"
    enter: "scale 0.8→1,rotate -10deg→0"
  quote-block:
    typography: font-bold italic leading-relaxed opacity-70
    border: "border-l-8 border-yellow-400,左 padding 24px"
  chart-container:
    background: "{colors.surface}"
    border: "4px solid {colors.ink}"
    boxShadow: "12px 12px 0 0 {colors.ink}(见 Elevation 标准档,禁止默认 blur 投影)"
    borderRadius: "{rounded.lg}"
    padding: "{spacing.card-padding}"
    seriesColors: "循环取用 {colors.primary}/{colors.accent}/{colors.success}/{colors.info}/{colors.button-yellow},不使用渐变/半透明系列色"
    axisLabel: "font-black text-xs {colors.ink};刻度/数值本身非标题语义,不强制 uppercase"
    legend: "font-black uppercase tracking-wide text-xs,图例色块用方形(非圆点),呼应硬边气质"
anchors:
  - id: halftone-dot-bg
    type: pattern
    desc: 主内容区/黑底区块背景叠加半色调圆点纹理(见 Shapes),Ben-Day dots 印刷致敬,是风格辨识度的关键细节
  - id: hard-offset-shadow
    type: token
    desc: 全部阴影零模糊纯色块偏移(见 Elevation 分级),禁止 blur,拟丝网印刷错版效果
  - id: heavy-ink-border
    type: token
    desc: 卡片/按钮/容器统一纯黑粗描边(见 Shapes 边框系统),是区分波普与普通扁平化的关键特征
  - id: bangers-display-type
    type: token
    desc: 装饰性大标题用漫画体(见 typography.display),全大写宽字距,视觉冲击直接
  - id: micro-tilt-collage
    type: pattern
    desc: 标题色块/CTA/装饰元素施加微倾斜(见 components 各处 rotate),模拟拼贴剪报感
  - id: extreme-rounded-or-none
    type: pattern
    desc: 圆角要么取极端超大档(见 rounded),要么完全无圆角,拒绝居中档
  - id: pop-card
    type: component
    desc: 核心卡片基座(见 components.pop-card),粗描边+硬阴影+超大圆角三件套
  - id: pop-button
    type: component
    desc: 核心按钮(见 components.pop-button),六色语义变体+按下位移无缓动
gaps:
  - 无暗色模式定义
  - 无表单控件(input/select 等)规范
  - 状态指示灯(colors.status-green/status-red)源仅给 Tailwind 默认色名,未给具体 hex,已照抄色名而非编造 hex(补充项:如需精确 hex 需与调用方确认)
  - 源应用绑定特定业务插画动效(如吉祥物呼吸、收获弹跳)未纳入通用组件规范,仅收录按钮/卡片/进度条等通用交互动效
  - 字体 @import 具体 URL 源未给出字符串(仅注明 Google Fonts 加载),已按标准 Google Fonts CDN 语法补充为补充项
  - 动效缓动函数:v_n 仅有定性描述"弹跳突然",无具体缓动值;本版补充 cubic-bezier(0.34,1.56,0.64,1) 回弹曲线作为可执行默认值(补充项,非源文件原有数值)
exceptions:
  - 引言(quote-block)字重为 font-bold(非通用规则的 font-black),是唯一非 font-black 主体文本
  - 弹窗遮罩自带 backdrop-blur,是唯一允许的模糊效果(不属于阴影系统)
  - 次级分隔线/边框允许不透明度衰减(border-black/5、/10、/20),不违反"边框必须纯黑实线"的硬规则;stat-item 的行内 divider 属此例外,该行作为列表行不要求单独描边,其可见容器边界由外层承载的 pop-card 提供
  - 状态指示灯(status-green/status-red)使用 Tailwind 默认命名色,不入常规九色主色板引用
---

## Overview

美式漫画 × 丝网印刷波普美学。用高饱和色块、粗黑描边、硬偏移阴影和半色调纹理组织内容；导航与模块布局按实际应用决定。情绪基调:直接、有力、图形化、视觉冲击。

## Colors

| 角色 | 值 | 用法 |
|-----|-----|-----|
| primary | {colors.primary} | 页面主背景、主按钮默认态 |
| accent | {colors.accent} | 强调/危险操作、暂停停止按钮、成就标题背景 |
| success | {colors.success} | 开始按钮、进度条填充、侧边栏标题阴影 |
| info | {colors.info} | 选中态、CTA 卡片、连续记录数值、选择按钮 |
| ink | {colors.ink} | 描边、阴影、头部导航栏、标题块背景、主要文本 |
| surface | {colors.surface} | 卡片基底、内容面板、未选中按钮底色 |
| surface-warm | {colors.surface-warm} | 侧边栏背景,降低纯白刺眼感 |
| surface-warm-alt | {colors.surface-warm-alt} | 计时器一类卡片内底色 |
| button-yellow | {colors.button-yellow} | 重置按钮、激活态、统计数值高亮 |
| status-green | {colors.status-green} | 运行态指示灯(配 animate-pulse) |
| status-red | {colors.status-red} | 就绪态指示灯 |
| overlay | {colors.overlay} | 弹窗背景遮罩,配 backdrop-blur-md |

## Typography

全局样式首行原样写入(HARD REQUIREMENT,禁止替换;URL 为标准 Google Fonts CDN 语法补充项):

```css
@import url('https://fonts.googleapis.com/css2?family=Bangers&family=Noto+Sans+SC:wght@400;700;900&display=swap');
```

Bangers 为拉丁漫画体,无中文字形,fontFamily 已含 CJK 兜底(PingFang SC/Microsoft YaHei/Noto Sans SC,系统字体无需额外 @import)。

| 层级 | 尺寸 | 权重 | 附加样式 | 角色 |
|-----|-----|-----|---------|-----|
| 巨屏数字 | 6.5rem~8.5rem(md) | 900 | tracking 0.1em,leading-none | heading |
| 弹窗标题 | text-6xl(3.75rem) | 900 | italic uppercase tracking-widest | heading |
| 区块大标题 | text-5xl(3rem) | 900 | uppercase tracking-tighter,带背景色块 | display/heading |
| 侧边栏标题 | text-3xl(1.875rem) | 900 | uppercase leading-none tracking-tighter,居中 | heading |
| 卡片标题 | text-2xl~text-3xl | 900 | uppercase italic tracking-tight | heading |
| 引言标题 | text-xl(1.25rem) | 900 | uppercase,decoration-8 下划线 | heading |
| 标签文字 | text-xs~text-sm | 900 | uppercase tracking-widest | heading |
| 微型标签 | text-[10px] | 900 | uppercase tracking-[0.2em] | heading |
| 引言正文 | text-base(1rem) | 700 | italic leading-relaxed opacity-70 | quote |

排版规则:全部标题/标签 uppercase(禁止小写),这一条硬约束不因层级而异;但**宽字距(tracking-widest 或以上)只是标签/按钮/微型文字类角色的强制要求**(对应上表"标签文字""微型标签"两行),展示级大标题(区块大标题/侧边栏标题/卡片标题)按上表走 tracking-tighter/tracking-tight,是漫画大字号海报的正当紧凑排版,不视为"宽字距不足";两类角色不互相覆盖,禁止把大标题也拉成 tracking-widest。强调数值叠加 drop-shadow(2px 2px 0 {colors.ink}) 增加立体感。

## Layout

- 页面可使用 {colors.primary} 底叠加半色调纹理，内容容器最大宽度参考 {spacing.container-max}，内边距使用 {spacing.content-padding}。
- 导航、核心视图、统计、引言和 CTA 按实际任务组织；侧栏和左右双列只是可选构图，不是风格要求。
- 视图切换:进入 opacity 0→1 配 scale 0.95→1 或 y 30→0,退出反向;缓动统一用 cubic-bezier(0.34,1.56,0.64,1)(回弹感,见 Hard Rules),禁止用框架默认的 ease/ease-out。
- 响应式(移动优先):按内容关系减少列数，导航选择适合当前应用的窄屏形态；不得简单隐藏业务必要内容，主内容 padding 随宽度调整。

## Elevation & Depth

阴影分级,全部零模糊纯色块偏移,颜色随语境变化(不固定同一色):

| 档位 | 值 | 用途 |
|-----|-----|-----|
| 超大 | 24px 24px 0 0 {colors.button-yellow} | 弹窗卡片 |
| 大 | 16px 16px 0 0 {colors.ink} | 计时器一类主卡片 |
| 标准 | 12px 12px 0 0 {colors.ink} | 普通内容卡片、CTA 卡片、图表容器(见 Components.chart-container) |
| 中 | 8px 8px 0 0 {colors.success} 或 {colors.ink} | 区块标题色块 |
| 小 | 6px 6px 0 0 {colors.accent} 或 {colors.success} | 侧边栏卡片、品牌标题 |
| 按钮 | 4px 4px 0 0 {colors.ink} | 所有按钮默认态 |
| 按钮按下 | 2px 2px 0 0 {colors.ink} | 按钮 active 态 |
| 标签 | 2px 2px 0 0 {colors.ink} | pill-tag 等小型标签容器 |
| 文字 | drop-shadow 2px 2px 0 {colors.ink} | 统计数字高亮 |

所有阴影均为零模糊纯色偏移(禁止任何 rgba/半透明色值),这是波普风格的核心视觉标识(见 Hard Rules)。

## Shapes

- 圆角:见 frontmatter rounded,**只有 xl(4rem)/lg(3rem~2.5rem)/full(9999px 全圆)三档可选**,不存在任何 16~32px 区间的"中等圆角"选项;需要方形直角时直接写字面值 0(如 section-header),禁止引入新的居中档半径。
- 边框:超粗 8px(弹窗)、主 6px(pop-card)、标准 4px(按钮/CTA/进度条/图表容器)、细 2px(次级/标签)、虚线 4px dashed(提示占位区域),统一纯黑 {colors.ink};次级分隔线允许低透明度(见 Exceptions)。
- 半色调纹理:`radial-gradient(rgba(0,0,0,0.1) 2px, transparent 2px)`,background-size 20px 20px,叠加于主内容区/黑底区块背景,致敬 Ben-Day dots 印刷技法。
- 微倾斜:标题色块/CTA 约 -1deg~2deg,装饰元素随机小角度,营造拼贴/剪报感,幅度不超过 3deg 避免阅读困难。

## Components

核心组件规格见 frontmatter components(pop-card / pop-button / section-header / status-bar / progress-bar / stat-item / pill-tag / modal-overlay / quote-block / chart-container)。补充细节:

- **PopCard**:所有内容卡片的基座;variant=黑底用于对比色块,可视强调需要升级到 Elevation 大/超大档。
- **PopButton**:六色变体覆盖主要操作语义(红=危险/暂停、绿=开始/选中、蓝=选择、黄=默认/重置、黑=强调、白=未选中);圆角改为 {rounded.full} 药丸形,选中态叠加 ring-4 ring-black ring-offset-2 + scale-105。
- **SectionHeader**:承担页面/模块分区职责,accent/ink 背底与 success/ink 阴影交替使用,方形直角(borderRadius:0)呼应剪报分格,保持区域可扫描。
- **ProgressBar**:外框/内轨/填充三层结构,标签绝对居中覆盖,填充色随语义变化(默认 success)。
- **StatItem**:关键数值展示,标签 60% 不透明度弱化,数值用主题色 + drop-shadow 强调立体感;该行不单独描边(边界由外层 pop-card 提供,见 Exceptions)。
- **PillTag**:用语义色浅底/主色/浅描边组合承载标签场景,阴影为纯色 2px 偏移(禁止 rgba 半透明),非主色板核心角色,轻量补充。
- **ModalOverlay**:遮罩 60% 黑 + backdrop-blur-md,卡片入场 scale 0.8→1 + rotate -10deg→0,是全局唯一使用模糊效果的场景。
- **QuoteBlock**:左侧粗色条(border-l-8)+ 斜体正文,是唯一非 font-black 主体文本角色。
- **ChartContainer**:报表/图表类页面(折线图、饼图、柱状图、雷达图、热力图、桑基图等)统一套用与 PopCard 同级的边框+阴影+圆角三件套(4px 纯黑描边 + 标准档硬偏移阴影 + {rounded.lg}),禁止套用常规仪表盘的细边框+软阴影+默认圆角;图表序列色循环取 primary/accent/success/info/button-yellow,图例用方形色块 + font-black uppercase 标签,坐标轴刻度数值本身不强制 uppercase。

## Do's and Don'ts

- 微倾斜控制在 1~3deg,过度会导致阅读困难。
- 半色调圆点纹理保持 2px 点径/20px 间距的比例,过密或过疏都会喧宾夺主。
- 优先用色块区分内容层级(如黑底白字/强调色底白字),而非仅靠字号变化。
- 装饰性大标题字体(Bangers)仅用于强调型标题,不作长段正文字体。
- 报表/图表类内容不因"数据展示"豁免波普容器规格,ChartContainer 与 PopCard 同规格,不得退化为默认仪表盘卡片样式。

## Hard Rules

- 所有阴影必须零模糊纯色块偏移,禁止使用 blur 阴影或任何 rgba/半透明色值(Material/扁平化风格特征禁止混入)。
- 每个可见容器至少 2px 纯黑描边起,禁止无描边容器;图表/数据可视化容器同样适用,不得因内容类型豁免(见 Components.ChartContainer)。
- 标题与标签统一 uppercase,禁止小写标题;宽字距(tracking-widest 或以上)仅强制要求标签/按钮/微型文字类角色,展示级大标题按 Typography 表使用 tracking-tighter/tracking-tight(紧凑排版是正当设计选择,不算违规,见 Typography 排版规则)。
- 字重优先 font-black(900)或 font-bold(700),禁止 regular(400)/light(300)正文字重。
- 圆角只能取 xl/lg/full 三档或字面值 0,禁止任何 16~32px 区间的中等圆角(见 Shapes)。
- 配色保持高饱和纯色块,禁止半透明叠加/柔和渐变。
- 交互动画使用位移/缩放/旋转的"弹跳突然"感,禁止 ease/ease-out/ease-in-out/linear 等 CSS 内置缓动关键字;统一使用 cubic-bezier(0.34,1.56,0.64,1) 回弹曲线,悬停/点击类瞬时反馈 duration-75~150,页面级入场 duration-200~300。
- 字体 @import 必须原样写入全局样式首行,禁止替换或省略(HARD REQUIREMENT)。

## Exceptions

- 引言(quote-block)字重为 font-bold,是唯一非 font-black 主体文本角色。
- 弹窗遮罩自带 backdrop-blur,是唯一允许的模糊效果(不属于阴影系统)。
- 次级分隔线/边框允许不透明度衰减({colors.ink}/5、/10、/20),不违反"边框必须纯黑实线"的硬规则;stat-item 行内 divider 属此例外,不代表该行需要独立完整描边。
- 状态指示灯(colors.status-green/colors.status-red)使用 Tailwind 默认命名色,不入常规九色主色板引用。
