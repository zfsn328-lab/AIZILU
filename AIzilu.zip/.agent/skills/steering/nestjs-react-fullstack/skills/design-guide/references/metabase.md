---
version: alpha
name: metabase
name_zh: 湖光蓝调
description: "简洁数据驱动的开源分析仪表盘:纯白底 + 深蓝墨字 + 醒目主色蓝强调,人文无衬线全局承载(标题 700 字重),标准居中容器 + 清晰分节线;柔和漫射阴影 + 纤细半透明中性边框定义卡片,开放通透、专业可靠,让数据与可视化成为焦点。"

colors:
  bg: "#FFFFFF"
  bg-soft: "#F0F8FF"
  bg-quiet: "#FAFBFE"
  ink: "#222C3E"
  ink-soft: "#5A6072"
  muted: "#8D93A5"
  muted-soft: "#4C5773"
  accent: "#509EE3"
  line: "rgba(90, 96, 114, 0.15)"

typography:
  display:
    fontFamily: '"Lato", "Noto Sans SC", "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: 48px
    lineHeight: 1.1
    fontWeight: 700
    letterSpacing: "-0.5px"
  h1:
    fontFamily: '"Lato", "Noto Sans SC", "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: 40px
    lineHeight: 1.2
    fontWeight: 700
    letterSpacing: "0"
  h2:
    fontFamily: '"Lato", "Noto Sans SC", "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: 28px
    lineHeight: 1.3
    fontWeight: 700
    letterSpacing: "0"
  body:
    fontFamily: '"Lato", "Noto Sans SC", "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: 16px
    lineHeight: 1.5
    fontWeight: 400
    letterSpacing: "0"
  small:
    fontFamily: '"Lato", "Noto Sans SC", "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: 14px
    lineHeight: 1.4
    fontWeight: 400
    letterSpacing: "0"

rounded:
  sm: 4px
  md: 8px
  lg: 12px
  pill: 999px

spacing:
  xs: 4px
  sm: 8px
  md: 12px
  lg: 16px
  xl: 20px
  2xl: 24px
  3xl: 32px

components:
  button:
    background: "{colors.accent}"
    color: "{colors.bg}"
    borderRadius: "{rounded.md}"
    description: "主按钮用强调蓝实底 + 8px 圆角;次级为描边按钮(border {colors.line}、文字 {colors.ink})。"
  card:
    background: "{colors.bg}"
    border: "1px solid {colors.line}"
    borderRadius: "{rounded.lg}"
    boxShadow: "0 1px 2px rgba(16, 24, 40, 0.05)"
    description: "干净白卡,纤细半透明中性边框 + 柔和漫射阴影,避免生硬边缘。"
  chip:
    borderRadius: "{rounded.pill}"
    description: "柔和药丸标签,弱底 {colors.bg-soft} 用于分类与筛选。"
  input:
    background: "{colors.bg}"
    border: "1px solid {colors.line}"
    borderRadius: "{rounded.md}"
    description: "干净描边输入框,聚焦描边转 {colors.accent}。"
  hero:
    background: "{colors.bg}"
    description: "大号标题 + 副标 + 两个醒目 CTA,纯白平面无渐变。"

anchors:
  - id: white-plus-vivid-blue
    type: token
    desc: "纯白底 + 醒目主色蓝强调(见 colors.accent),柔和中性调色板不与数据竞争"
  - id: humanist-sans-bold-heads
    type: token
    desc: "人文无衬线全局承载,标题用 700 字重建立清晰层级"
  - id: blue-solid-button
    type: component
    desc: "主按钮强调蓝实底 + 中圆角(见 rounded.md),次级为描边按钮"
  - id: soft-shadow-card
    type: component
    desc: "白卡靠柔和漫射阴影 + 纤细半透明中性边框(colors.line)定义,无生硬边缘"
  - id: open-airy-layout
    type: pattern
    desc: "标准居中容器 + 清晰分节线 + 充足留白,开放通透"
  - id: rounded-corners-only
    type: pattern
    desc: "卡片与按钮一律圆角,不用尖锐 90 度直角"

gaps:
  - "深色模式:源明确排除,只做明亮浅色主题"
  - "chip:源未明确出现,按柔和药丸形推导(见 Components)"
  - "看板图表序列色:源未逐一给出,已按 accent 主序列 + 中性梯度补推(见 Components)"
---

## Overview

利用 AI 回答问题的开源分析平台。设计系统是一个简洁、数据驱动的仪表盘——一个精确的仪器面板,信息清晰度是首要结构原则;身份建立在开源、分析、AI 驱动与数据之上,构成从颜色到组件每个决策的逻辑基础。

**One-liner:** 利用 AI 回答问题的开源分析平台。
**Keywords:** 开源 · 数据分析 · AI 驱动 · 数据
**Analogy:** 一个简洁、数据驱动的仪表盘。

## Colors

色彩系统简洁且以数据为中心,醒目主色蓝点缀白色背景,创造高清晰度画布,让数据可视化与交互元素呈现而不产生视觉竞争;调色板作为专业中立的框架。

- **底色 `colors.bg` `#FFFFFF`** — 主背景,纯白平面。
- **柔底 `colors.bg-soft` `#F0F8FF`** — 卡片/浅蓝静区底色。
- **静区 `colors.bg-quiet` `#FAFBFE`** — 极浅静区。
- **正文 `colors.ink` `#222C3E`** — 主要文本与关键数字。
- **次级文本 `colors.ink-soft` `#5A6072`** — 说明性文本。
- **弱化 `colors.muted` `#8D93A5`** — 占位符。
- **弱提示 `colors.muted-soft` `#4C5773`** — 次级提示文字。
- **强调 `colors.accent` `#509EE3`** — 醒目主色蓝,用于主按钮与交互焦点。
- **分隔线 `colors.line` `rgba(90, 96, 114, 0.15)`** — 纤细半透明中性边框。

**用色原则:** 简洁数据导向,以白底上的醒目强调蓝为主色;不引入高对比霓虹色。

## Typography

字体由 Lato 人文主义无衬线系列处理,因干净专业与跨屏可读性被选用;比例从主标题到辅助文本逐步递进,为数据驱动内容建立清晰层级。

- **@import(HARD REQUIREMENT / 禁止替换,原样写入全局样式首行):**
  `@import url('https://miaoda.feishu.cn/fonts/css2?family=Lato:wght@400;700&family=Noto+Sans+SC:wght@400;500;700&display=swap');`
- **字体栈:** `"Lato", "Noto Sans SC", "PingFang SC", "Microsoft YaHei", sans-serif` —— 拉丁用 Lato(源推荐,人文无衬线),中文用 Noto Sans SC(气质同为清晰人文无衬线),系统字体末位保底。

| 角色 | Size | Line-height | Weight | Letter-spacing | 用法 |
|---|---|---|---|---|---|
| display | 48px | 1.1 | 700 | -0.5px | 主标题 |
| h1 | 40px | 1.2 | 700 | 0 | 主要章节标题 |
| h2 | 28px | 1.3 | 700 | 0 | 子章节标题 |
| body | 16px | 1.5 | 400 | 0 | 正文文本 |
| small | 14px | 1.4 | 400 | 0 | 辅助文本 |

**字体规则:**
- 标题用 Lato 700 字重建立层级;正文用 400 字重保持易读。
- display 用 -0.5px 负字距收紧,其余标题字距为 0。
- **CJK 行高转译:** display 负字距在中文场景清零;中文标题 line-height 保持 ≥1.1,中文正文 ≥1.5,避免字形重叠。

## Layout

标准居中容器,提供稳定熟悉的框架;用清晰分节线与充足空白划分内容,保持开放通透。

- **Container max:** 1280px
- **Paragraph max:** 680px
- **Grid:** 12 columns, gutter 24px
- **Breakpoints:** 768 / 1024 px
- **Rhythm:** 8px 基础单位 + 4px 微间距(见 spacing.xs / spacing.sm)。

12 列仅作为对齐工具，不要求固定分栏、组件位置或页面骨架；实际列数与跨度按内容关系决定。

## Elevation & Depth

表面靠柔和漫射阴影创造微妙深度,避免生硬边缘;边框始终纤细浅淡,用半透明中性色定义卡片与输入框而不增加视觉重量。

- 0 1px 2px rgba(16, 24, 40, 0.05)
- 0 16px 28px -6px rgba(24, 39, 75, 0.12)
- 0 32px 88px -4px rgba(24, 39, 75, 0.14)
- **Borders:** 1px 实线 colors.line。

## Shapes

圆角一致,卡片与按钮用小到中圆角,药丸标签用满圆角;不用尖锐直角。

- **Radius:** sm 4px(见 rounded.sm) · md 8px(rounded.md) · lg 12px(rounded.lg) · pill 999px(rounded.pill)
- **Borders:** 1px 半透明中性边框 colors.line。

## Components

- **button:** 主按钮强调蓝实底(background {colors.accent}、文字 {colors.bg}、圆角 {rounded.md});次级为描边按钮(border {colors.line}、文字 {colors.ink})。
- **card:** 干净白卡(background {colors.bg}、border 1px {colors.line}、圆角 {rounded.lg}),柔和漫射阴影 rgba(16,24,40,0.05)。
- **chip:** 柔和药丸标签(圆角 {rounded.pill}),弱底 {colors.bg-soft},用于分类与筛选。
- **input:** 干净描边输入框(border 1px {colors.line}、圆角 {rounded.md}),聚焦描边转 {colors.accent}。
- **hero:** 大号标题 + 副标 + 两个醒目 CTA,纯白平面无渐变。
- **看板图表(数据看板落地补充):** 主序列用 colors.accent 醒目蓝,次序列/对比用 colors.muted 与柔和中性梯度;图表容器为白卡,柔和漫射阴影 + colors.line 纤细边框成组,不引入高对比霓虹色。

## Do's and Don'ts

**Do:**
- 用清晰分节线与充足留白保持开放通透。
- 标题用 700 字重建立粗体层级。
- 卡片/按钮一律圆角,配柔和漫射阴影。

**Don't:**
- 别在正文用纤细优雅衬线 —— 一律人文无衬线。
- 别用密集大段文字缺留白 —— 布局开放通透。
- 别用复杂渐变做主背景 —— 背景纯白或极浅浅蓝。

## Hard Rules

- 不使用深色模式:背景始终明亮浅色 colors.bg(#FFFFFF),只做浅色主题。
- 不使用高对比霓虹色:强调统一用醒目主色蓝 colors.accent,其余为柔和中性。
- 卡片与按钮不用尖锐 90 度直角,一律圆角。
- 正文一律人文无衬线,不用纤细优雅衬线承载可读文本。
- 主背景不用复杂渐变,保持纯白或极浅浅蓝平面。

## Exceptions

- 主按钮允许唯一的强调蓝实底(colors.accent):它是界面上主要的实底色块,承担关键行动召唤;次级动作用描边按钮。
- 悬浮层/模态可用更深的第二/三层漫射阴影(0 16px 28px / 0 32px 88px),平铺卡片仍用第一层 0.05 极轻投影。
