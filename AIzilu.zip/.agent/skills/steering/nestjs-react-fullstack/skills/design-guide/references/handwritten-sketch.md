---
version: alpha
name: handwritten-sketch
name_zh: 手绘草稿
description: 手绘白板笔记风——米黄纸张底(圆点网格纹理)上散落白色卡片,卡片一律有机不规则 wobbly 圆角+3px 墨黑粗边框+纯偏移硬阴影(无模糊),配 Kalam(标题)/Patrick Hand(正文)手写体、透明胶带/图钉/别针物理装饰与卡片微旋转(±0.5~2deg 奇偶交替);标记笔红/钢笔蓝/便利贴黄点缀,黑板反色区块作全页唯一对比锚点。亲和、创意、手工感。
colors:
  bg: "#fdfbf7"
  surface: "#ffffff"
  muted: "#e5e0d8"
  ink: "#2d2d2d"
  text-muted: "rgba(45,45,45,0.6)"
  marker-red: "#ff4d4d"
  pen-blue: "#2d5da1"
  postit-yellow: "#fff9c4"
  highlight-bg: "#fef9c3"
  success: "#16a34a"
typography:
  marker:
    fontFamily: 'Kalam, "PingFang SC", "Microsoft YaHei", "Noto Sans SC", cursive'
    fontWeight: 700
    usage: 标题/强调标记(Tailwind font-marker)
  hand:
    fontFamily: '"Patrick Hand", "PingFang SC", "Microsoft YaHei", "Noto Sans SC", cursive'
    usage: 正文/描述/列表(Tailwind font-hand)
rounded:
  wobbly-1: "255px 15px 225px 15px / 15px 225px 15px 255px"
  wobbly-2: "20px 225px 15px 255px / 255px 15px 225px 15px"
  wobbly-3: "15px 225px 15px 255px / 255px 15px 225px 15px"
  wobbly-4: "225px 15px 225px 15px / 15px 225px 15px 255px"
  badge: 9999px
  postit: 8px
spacing:
  section-gap: 80px
  grid-gap: 24px~32px
  grid-gap-lg: 48px
  container-max: 1024px
  container-px: 24px
  card-padding: 24px~48px
  page-bottom: 80px
components:
  wobbly-card:
    border: "3px solid {colors.ink}"
    borderRadius: "{rounded.wobbly-1}(四组预设按 index 轮换)"
    boxShadow: "4px 4px 0px 0px {colors.ink}"
    transform: rotate(±0.5~2deg,index 奇偶交替)
    variants: "white={colors.surface}底 | yellow={colors.postit-yellow}底 | black={colors.ink}底白字 | blue={colors.pen-blue}底白字"
    decoration: tape(透明胶带)/tack(红图钉)/none
  section-header:
    layout: flex items-center gap-3 mb-8
    badge: "accent 底白字图标,border-2 {colors.ink},rounded-full,shadow 2px 2px 0 {colors.ink},rotate(±1~3deg)"
    title: "text-4xl font-marker,波浪下划线 decoration-wavy decoration-2 underline-offset-4,交替 accent 色"
  kpi-card:
    base: "wobbly-card p-6,hover:-translate-y-1 hover:shadow(8px 8px 0 {colors.ink})"
    value: "text-5xl font-marker {colors.marker-red}"
    old-value: "text-lg font-hand line-through,ink 40% 透明度"
    mini-chart: "底部迷你水平条形图,border-t-2 dashed 分隔,h-24"
  feature-card:
    header: "muted/30 底 p-4,border-b-2 dashed {colors.ink},圆形图标徽章"
    keyword-highlight: "{colors.highlight-bg} px-1"
    tag: "bg-white border-2 {colors.ink} wobbly 圆角,hover:-rotate-2"
  roadmap-card:
    connector: "阶段间垂直连接线 w-1 {colors.ink}"
    priority: "P0={colors.marker-red}底白字 | P1={colors.postit-yellow}底墨字,rounded-full rotate-2"
    deadline: "font-hand {colors.pen-blue},bg-white border-2 {colors.ink} -rotate-1"
  chalkboard-block:
    base: "wobbly-card variant=black,p-8~12,rotate(1deg),圆点 SVG 纹理 opacity 0.10 叠加"
    keyword: "{colors.postit-yellow} 波浪下划线"
    note: 每页最多一处
  charts:
    palette: "{colors.marker-red} {colors.muted} {colors.pen-blue} {colors.postit-yellow}"
    container: "透明背景继承卡片底色,border-t-2 dashed 分隔,迷你内嵌 h-24(96px)"
    tooltip: "{colors.postit-yellow}底,2px {colors.ink}边框,硬阴影 4px 4px 0 {colors.ink},圆角 10px"
    axis: "轴标签 Patrick Hand 14px {colors.text-muted},网格线 {colors.muted} 虚线,轴刻度隐藏"
    legend: "Patrick Hand 14px {colors.ink},icon=roundRect 14×10,itemGap 16"
anchors:
  - id: wobbly-radius
    type: pattern
    desc: 全部卡片有机不规则圆角(rounded 四组 wobbly 预设按 index 轮换),每张卡片形态各异如手撕纸片
  - id: hard-shadow-ink-border
    type: token
    desc: 纯偏移无模糊硬阴影(见 components.wobbly-card.boxShadow)配粗墨线边框(colors.ink),平面插画式深度
  - id: handwriting-type
    type: token
    desc: 标题 Kalam+正文 Patrick Hand 全页手写体(见 typography),无任何无衬线体
  - id: physical-decorations
    type: component
    desc: 透明胶带/红图钉/别针装饰散布卡片顶部,每 Section 一至两处
  - id: micro-rotation
    type: pattern
    desc: 所有卡片微旋转,index 奇偶交替正负方向,白板随意粘贴感
  - id: dot-grid-paper
    type: pattern
    desc: 米黄纸张底色(colors.bg)叠加圆点网格纹理(radial-gradient,间距见正文),整页如牛皮纸白板
  - id: chalkboard-contrast
    type: component
    desc: 深色黑板反色区块(components.chalkboard-block)作全页唯一视觉对比锚点
gaps:
  - 无 deck 画布/幻灯片专属排版规格(源为单页纵向滚动白板布局,幻灯片场景沿用同一体系)
  - 无暗色模式定义
  - 无表单控件(input/select 等)规范
exceptions:
  - 痛点便签用常规 8px 圆角(rounded.postit)与虚线边框,是唯一非 wobbly 圆角的卡片
  - 圆形徽章/优先级标签用全圆(rounded.badge)
  - 语义色 colors.success 仅用于成功状态图标,不入主色板
---

## Overview

手绘白板笔记 × 便利贴质感 × 有机不规则形态。模拟在大白板/牛皮纸上自由排列的笔记卡片，各内容组可用「图标徽章+波浪下划线大字标题」划分，并以宽松间距营造自然散落的节奏。情绪基调:亲和、创意、手工感、轻松自由。

## Colors

| 角色 | 值 | 用法 |
|-----|-----|-----|
| bg | {colors.bg} | 页面纸张背景,叠加圆点网格纹理 |
| surface | {colors.surface} | 卡片白色底;黑板区块上作粉笔白文字色 |
| muted | {colors.muted} | 次级背景、网格点、分隔区域、灰底标签 |
| ink | {colors.ink} | 墨水黑:主要文字、全部粗边框、硬阴影;黑板区块反转为底色 |
| text-muted | {colors.text-muted} | 次要文字、描述、坐标轴标签 |
| marker-red | {colors.marker-red} | 标记笔红:强调数值、重点标记、图钉;每屏 1-2 处 |
| pen-blue | {colors.pen-blue} | 钢笔蓝:链接、标签、辅助强调、工时数值 |
| postit-yellow | {colors.postit-yellow} | 便利贴黄:高亮卡片背景、Tooltip 背景 |
| highlight-bg | {colors.highlight-bg} | 行内关键词底色标记 |
| success | {colors.success} | 成功状态图标(仅此用途) |

文字选中色:`selection:bg-marker-red selection:text-white`。

## Typography

全局样式首行原样写入(HARD REQUIREMENT,禁止替换):

```css
@import url('https://fonts.googleapis.com/css2?family=Kalam:wght@700&family=Patrick+Hand&display=swap');
```

Kalam/Patrick Hand 为拉丁手写体,无中文字形,fontFamily 已含 CJK 兜底(PingFang SC/Microsoft YaHei/Noto Sans SC,系统字体无需 @import)。

| 层级 | 样式(Tailwind) | 颜色 |
|-----|-----|-----|
| 页面主标题 | text-3xl font-marker font-bold tracking-wide | ink |
| Section 标题 | text-4xl font-marker font-bold + 波浪下划线(decoration-wavy decoration-2 underline-offset-4,accent 色交替) | ink |
| 卡片标题 | text-2xl font-marker font-bold | ink |
| 列表项标题 | text-xl font-marker font-bold | ink |
| KPI 数值 | text-5xl font-marker font-bold | marker-red |
| KPI 旧值 | text-lg font-hand line-through decoration-2 | ink 40% |
| 正文描述 | text-lg font-hand leading-relaxed | ink 70% |
| 标签/分类 | text-sm font-bold uppercase tracking-widest | ink 50% |
| 副标题 | text-lg font-hand | ink 60% |
| 辅助小字 | text-sm font-hand | ink 50% |

## Layout

- 内容容器:max-w-5xl(1024px),px-6;Section 间 space-y-20(80px);页底 pb-20。
- 网格 gap-6~gap-8(24~32px),大组件 gap-12(48px);卡片内边距 p-6 或 p-8 md:p-12。
- 标题、导航或状态区若存在，可使用白色 wobbly 卡片、胶带装饰和轻微旋转；是否固定以及放置位置由实际交互决定。
- 痛点便签、指标卡、功能卡、路线图和黑板区块均是可选视觉组件，不构成固定页面顺序，也不要求为无关内容补齐。
- 响应式按卡片内容和任务优先级减少列数；窄屏避免装饰遮挡文字，并适当缩小内边距。
- 滚动条:宽 12px,轨道 bg 色,滑块 ink 色+3px bg 色边框+20px 圆角。

## Elevation & Depth

硬阴影三档,全部纯偏移 0 模糊,颜色一律 ink:

| 档位 | 值 |
|-----|-----|
| small | 2px 2px 0px 0px |
| 标准(hard) | 4px 4px 0px 0px |
| extra-large | 8px 8px 0px 0px |

层次感 = 粗墨线边框 + 硬阴影 + 微旋转,不用模糊阴影/渐变。Hover 交互:KPI 卡片上浮(-translate-y-1 → xl 阴影,300ms);列表项右移(translate-x-1,阴影消失,边框变 marker-red);标签 hover:-rotate-2;图标 group-hover rotate-12 或 scale-110;分组标题 hover 变 pen-blue 或 marker-red。

## Shapes

- 卡片圆角一律 wobbly 四组预设轮换(见 frontmatter rounded);标签/tag 同 wobbly-1;圆形徽章全圆;痛点便签 8px(唯一例外)。
- 边框语言:全局卡片 3px 实线 ink;卡片内分区 2px 虚线;列表项 2px 实线;表格行分隔 1px 浅虚线(ink 20%);页脚 4px 粗虚线;痛点便签 2px 虚线(marker-red 或 ink)。
- 装饰元素:透明胶带(absolute -top-3 居中,w-24 h-6,灰 30% 透明+backdrop-blur,rotate-1)、图钉(w-4 h-4 圆点,marker-red 底+2px ink 边)、别针(lucide Pin 图标,fill marker-red,rotate-12,卡片右上角)、圆点背景纹理(radial-gradient,muted 色 1px 点,24px 间距)、黑板纹理(SVG 圆点 pattern,opacity 0.10)、波浪下划线(Section 标题)。
- 动画:transition-all duration-300(卡片)/transition-transform(标签、图标),无入场动画定义。

## Components

核心组件规格见 frontmatter components(wobbly-card / section-header / kpi-card / feature-card / roadmap-card / chalkboard-block / charts)。补充细节:

- **WobblyCard**:所有卡片的基座。variant=black 时阴影升级为 extra-large 档。
- **KPI 卡片**:顶部标题(左)+归属标签(右,-rotate-2 白底小标签),中部大数值+单位+删除线旧值+描述,底部虚线分隔迷你条形图。
- **功能卡片**:卡片头 muted 30% 底+虚线下边框,卡片体 p-6 space-y-6,小标题带左侧 accent 圆点标记,列表项左侧 ArrowRight 图标(marker-red,strokeWidth=3)。
- **路线图表格**:表头 font-marker ink 60% 下边框 2px;行 font-hand text-lg,hover 淡黄底;复选框 w-5 h-5 2px ink 边框;负责人标签 muted 30% 底;工时 pen-blue 加粗右对齐。
- **图表(ECharts)**:序列色按 charts.palette 顺序;水平条形用 yAxis category+xAxis value(符合手绘阅读习惯);折线 smooth+areaStyle opacity 0.08;柱状 barWidth 32+不对称圆角(4/10/10/4)+2px ink 描边;饼图环形 40%~65%+2px ink 描边;雷达/散点同样 muted 网格+ink 描边。
- **页脚**:4px 粗虚线上边框,居中引言(font-marker text-3xl,hover:rotate-2),marker-red 20% 圆条下划线装饰,副文字 hand 体 ink 50%。

## Do's and Don'ts

- 微旋转通过 index 奇偶切换正负方向,保持视觉韵律;幅度 ±0.5~2deg,不要超过 3deg。
- 装饰元素(胶带/图钉/别针)是点睛之笔:每个 Section 1~2 处,过度堆砌会削弱自然随意感。
- 扩展新组件时延续 wobbly 圆角预设轮换模式。
- 大面积暖白底中插入黑板反色区块可打断视觉疲劳,建议作对比锚点使用。

## Hard Rules

- 全部文字使用 Kalam(标题)/Patrick Hand(正文)手写体,禁止混入其他无衬线/衬线体(CJK 兜底字体除外)。
- 字体 @import 必须原样写入全局样式首行,禁止替换或省略(HARD REQUIREMENT)。
- 所有阴影必须纯偏移硬阴影(0 模糊,ink 色),禁止 blur 阴影。
- 卡片圆角必须使用 wobbly 四组预设(rounded.wobbly-1~4)轮换,禁止常规 rounded-* 类(Exceptions 列明的除外)。
- 黑板反色区块每页最多一处。
- 卡片必须带 3px ink 实线边框,禁止无边框卡片。

## Exceptions

- 痛点便签:常规 8px 圆角+2px 虚线边框(marker-red 或 ink),是唯一非 wobbly 圆角卡片。
- 圆形图标徽章/优先级标签/滚动条滑块:全圆或 20px 常规圆角。
- success 绿仅限成功状态图标,不得用于装饰或强调。
- 透明胶带装饰自带 backdrop-blur,是唯一允许的模糊效果(不属于阴影)。
