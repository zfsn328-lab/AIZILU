---
version: "neuform-top-creators-featured"
name: nexuscore-analytics
name_zh: 核心分析
description: "近黑底配电光紫的精密分析界面：紧凑直角面板、清晰的数据层级与等宽元数据组成克制的未来感。适合分析看板、运营后台、工作台、开发者工具和界面型产品展示；动态光效只用于建立焦点，不能取代内容结构。"
colors:
  primary: "#6D5DFB"
  secondary: "#18181B"
  accent: "#6D5DFB"
  background: "#0F1115"
  surface: "#18181B"
  text-primary: "#FFFFFF"
  text-secondary: "#A1A1AA"
  border: "#27272A"
typography:
  display-lg:
    fontFamily: "Inter"
    fontSize: "64px"
    fontWeight: 500
    lineHeight: "1.04"
    letterSpacing: "0"
  body-md:
    fontFamily: "Inter"
    fontSize: "16px"
    fontWeight: 400
    lineHeight: "1.6"
  label-md:
    fontFamily: "JetBrains Mono"
    fontSize: "12px"
    fontWeight: 600
    lineHeight: "1.2"
spacing:
  base: "8px"
  gap: "16px"
  card-padding: "24px"
  section-padding: "80px"
rounded:
  card: "8px"
  control: "8px"
  pill: "9999px"
components:
  card:
    background: "Use the surface token with subtle borders and restrained shadow depth"
    radius: "Match the declared card radius token"
  button:
    background: "Use primary or accent colors for the main action"
    radius: "Use the declared control or pill radius according to component role"
---
# NexusCore Analytics
Source: Neuform Featured templates from top creators. Author: Meng To (@mengto). Views: 18; favorites: 2; remixes: 0.
Tags: dashboard, charts, bento, animated, webgl, threejs, cta, navigation.
## Overview
近黑背景与深灰表面承载密集但可读的数据层级，电光紫只落在关键指标、当前状态与主操作。Inter 负责正文，JetBrains Mono 负责标签和技术元数据。适合分析看板、运营后台、开发者工具、工作台与界面型产品展示。
## Composition
用核心指标或关键工作区建立焦点，再以紧凑模块组织次级信息；具体位置与顺序按任务决定。桌面端可保留横向比较和数据密度，窄屏按任务优先级重排，主操作保持可见。
## Colors
Anchor the palette in primary #6D5DFB, secondary #18181B, accent #6D5DFB, background #0F1115, surface #18181B, text-primary #FFFFFF. Keep background, surface, text, and border roles distinct so generated layouts retain the same contrast pattern as the source.
## Typography
Use Inter for display moments and Inter for body copy unless the HTML clearly demands a compatible fallback. Labels and technical metadata should use JetBrains Mono or an equivalent mono face.
## Layout
Keep spacing deliberate and stable. Choose grid direction, max-width, card density, and responsive stacking from the content relationships. Source layouts are examples, not structures to reproduce.
## Components
Dashboard, chart, and data panels should preserve their compact operational hierarchy, nested surfaces, and metric emphasis.
## Motion
Preserve existing motion cues such as masked reveals, staggered entrance, hover lift, scroll-triggered transitions, and ambient movement. Keep easing smooth and restrained.
## WebGL & Effects

If the source includes canvas, WebGL, Three.js, gradients, particles, or atmospheric effects, rebuild them as supporting layers behind the content. Keep effects performant, responsive, and secondary to the interface.

## Guardrails
- Do not flatten the source into a generic card grid.
- Do not swap the color mode unless the source clearly supports it.
- Preserve a strong focal signal and the intended visual density without copying a fixed first-viewport composition.
- Keep buttons, cards, and badges aligned to the same radius and border language.
