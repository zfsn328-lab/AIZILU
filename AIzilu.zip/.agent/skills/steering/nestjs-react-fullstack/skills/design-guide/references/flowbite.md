---
version: alpha
name: flowbite
name_zh: Flowbite
description: "教科书式 Tailwind 营销/应用风 DSM:蓝色 CTA(blue-700,hover 800) + gray-900 大标题 + 规整 8px 圆角 + Inter 字体;组件用 Flowbite canonical class 组合书写,交互一律 data-attributes 声明式(不手写 JS);暗色模式全程 dark: 前缀成对;务实、快速、可深浅切换。"

colors:
  brand: "#1d4ed8"
  brand-hover: "#1e40af"
  heading: "#111827"
  body: "#4b5563"
  surface-50: "#f9fafb"
  surface-100: "#f3f4f6"
  border: "#e5e7eb"
  input-border: "#d1d5db"
  success: "#047857"
  danger: "#be123c"
  warning: "#f97316"
  badge-bg: "#dbeafe"
  badge-text: "#1e40af"

typography:
  heading:
    fontFamily: 'Inter, "Noto Sans SC", "PingFang SC", "Microsoft YaHei", sans-serif'
    fontWeight: 800
    letterSpacing: "-0.025em"
  body:
    fontFamily: 'Inter, "Noto Sans SC", "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: 14px
    fontWeight: 400

rounded:
  xs: 4px
  sm: 6px
  default: 8px
  base: 12px
  lg: 16px

spacing:
  section-y: 32px
  section-y-lg: 64px
  card-padding: 24px

components:
  button:
    background: "{colors.brand}"
    description: "主按钮 canonical class:text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5(bg-blue-700 = {colors.brand}、hover = {colors.brand-hover})。"
  button-secondary:
    description: "次按钮:白底 border border-gray-200 text-gray-900 hover:bg-gray-100(边 = {colors.border})。"
  input:
    background: "{colors.surface-50}"
    description: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 p-2.5(底 = {colors.surface-50}、边 = {colors.input-border})。"
  badge:
    background: "{colors.badge-bg}"
    color: "{colors.badge-text}"
    description: "bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded-sm(底 = {colors.badge-bg}、字 = {colors.badge-text};状态换色族)。"
  card:
    border: "1px solid {colors.border}"
    description: "bg-white border border-gray-200 rounded-lg shadow-sm p-6(边 = {colors.border}、内距见 spacing.card-padding)。"

anchors:
  - id: blue-cta
    type: token
    desc: "主按钮/链接用品牌蓝(见 colors.brand),hover 加深;不混用多个蓝"
  - id: tailwind-canonical-classes
    type: pattern
    desc: "组件用 Flowbite canonical class 组合书写,不自造与之重复的组件样式"
  - id: rounded-language
    type: token
    desc: "规整圆角语言,按钮/输入/卡片统一中圆角(见 rounded.default)"
  - id: dark-mode-pairs
    type: pattern
    desc: "暗色模式全程 dark: 前缀成对书写,浅深两态同时给出"
  - id: data-attribute-interactions
    type: component
    desc: "Modal/Dropdown/Drawer/Tooltip 用 data-attributes 声明式,不手写 JS"
  - id: adaptable-page-composition
    type: pattern
    desc: "按产品需求组合 Flowbite 组件，营销页和后台示例只提供组件用法，不固定页面骨架"

gaps:
  - "Pro 付费区块:不纳入(许可限制),开源项目禁止复制 Pro 代码"
  - "官方另有 minimal/enterprise/playful/mono 四套主题,换主题 = 换语义变量映射;此处只给 default 主题的映射值"
  - "暗色映射:heading dark:white、body dark:gray-400、边框 dark:gray-800 等 dark 侧值源以 Tailwind scale 给出,此处未逐一展开为 hex"
---

## Overview

教科书式的 Tailwind 营销/应用风:蓝色 CTA、gray-900 大标题、规整 8px 圆角。务实、快速、可深浅切换,单文件 HTML 原型到工程化 admin dashboard 都能覆盖。

**One-liner:** 蓝 CTA + Inter 大标题 + 规整圆角的 Tailwind 教科书风。
**Keywords:** Tailwind · 营销页 · CTA · 暗色模式 · 声明式交互
**Analogy:** 一套 Flowbite 官方落地页 + admin dashboard:蓝按钮 + 特性卡 + 定价表。

## Colors

default 主题的语义层,映射到 Tailwind 调色板;换主题即换映射。

- **品牌 `colors.brand` `#1d4ed8`(blue-700)** / **hover `colors.brand-hover` `#1e40af`(blue-800)** — 主按钮/链接。
- **标题 `colors.heading` `#111827`(gray-900,dark: white)** — 大标题。
- **正文 `colors.body` `#4b5563`(gray-600,dark: gray-400)** — 正文。
- **次要底 `colors.surface-50` `#f9fafb`(gray-50)** / **`colors.surface-100` `#f3f4f6`(gray-100)** — 区块/输入底。
- **边框 `colors.border` `#e5e7eb`(gray-200,dark: gray-800)** / **输入边 `colors.input-border` `#d1d5db`(gray-300)** — 结构线。
- **成功 `colors.success` `#047857`(emerald-700)** / **危险 `colors.danger` `#be123c`(rose-700)** / **警告 `colors.warning` `#f97316`(orange-500)** — 状态色(各配 50 淡底)。
- **徽章 `colors.badge-bg` `#dbeafe`(blue-100)** / **`colors.badge-text` `#1e40af`(blue-800)** — 状态徽章。

**用色原则:** 不混用多个蓝;暗色模式全程 `dark:` 前缀成对写,浅深两态同时给出。

## Typography

Inter 承载全部角色,大标题 font-extrabold + tracking-tight,中文用 Noto Sans SC 兜底。

- **@import(HARD REQUIREMENT / 禁止替换,原样写入全局样式首行):**
  `@import url('https://miaoda.feishu.cn/fonts/css2?family=Inter:wght@400;500;600;700;800&family=Noto+Sans+SC:wght@400;500;700;900&display=swap');`
- **字体栈:** `Inter, "Noto Sans SC", "PingFang SC", "Microsoft YaHei", sans-serif` —— 拉丁用 Inter(几何无衬线),中文用 Noto Sans SC(气质相近),系统字体末位保底。

| 角色 | Size | Weight | Letter-spacing | 用法 |
|---|---|---|---|---|
| heading | text-4xl~5xl | 800(extrabold) | -0.025em(tracking-tight) | Hero 大标题 |
| body | 14px(text-sm) | 400 | — | 正文 |

**字体规则:**
- Hero 标题用 `text-4xl~5xl font-extrabold tracking-tight`。
- 中文标题回退到 Noto Sans SC 900 时 line-height ≥1.05、正文 ≥1.5,中文场景负字距清零(tracking-tight 仅作用于拉丁)。

## Layout

按实际任务组合 Flowbite 组件，节区纵向留白规整。

- **营销页与后台:** Navbar、Hero、特性卡、定价、FAQ、Footer、侧栏和卡片栅格都是可选组件，不要求成套出现或保持示例顺序。
- **节区间距:** 纵向 `py-8 lg:py-16`(见 spacing.section-y / spacing.section-y-lg)。
- **卡片内距:** `p-6`(见 spacing.card-padding)。

## Elevation & Depth

层级靠卡片 `shadow-sm` 轻投影 + `colors.border` 1px 描边 + `colors.surface-50/100` 浅底分区;不堆叠重投影,深度克制。

## Shapes

规整圆角语言,按钮/输入/卡片统一中圆角。

- **Radius:** xs 4px(rounded.xs) · sm 6px(rounded.sm) · default 8px(rounded.default) · base 12px(rounded.base) · lg 16px(rounded.lg)。
- **Borders:** 1px `colors.border`(卡片/次按钮),输入用 `colors.input-border`。

## Components

canonical class 写法,原样保留:

- **button(主):** `text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5`(bg-blue-700 = {colors.brand}、hover = {colors.brand-hover})。
- **button-secondary(次):** 白底 `border border-gray-200 text-gray-900 hover:bg-gray-100`(边 = {colors.border})。
- **input:** `bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 p-2.5`(底 = {colors.surface-50}、边 = {colors.input-border})。
- **badge:** `bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded-sm`(底 = {colors.badge-bg}、字 = {colors.badge-text};状态换色族)。
- **card:** `bg-white border border-gray-200 rounded-lg shadow-sm p-6`(边 = {colors.border}、内距见 spacing.card-padding)。
- **交互组件(Modal/Dropdown/Drawer/Tooltip):** 用 data-attributes(`data-modal-target` 等)声明式驱动,不手写 JS。

## Do's and Don'ts

**Do:**
- 暗色模式全程 `dark:` 前缀成对写。
- 节区纵向 `py-16`。
- 图标用 Flowbite Icons / Heroicons。

**Don't:**
- 别自造与 Flowbite 重复的组件样式。
- 别把 Pro 区块代码复制进开源项目(付费许可)。
- 别混用多个蓝。

## Hard Rules

- 组件优先用 Flowbite canonical class 组合,禁止自造与之重复的组件样式。
- 交互组件(Modal/Dropdown/Drawer/Tooltip)一律 data-attributes 声明式,禁止手写 JS。
- 暗色模式必须 `dark:` 前缀成对书写,浅深两态齐全。
- 品牌蓝只用 `colors.brand` 一种,禁止一页混用多个蓝。
- 禁止把 Pro 付费区块代码复制进开源(MIT)项目。

## Exceptions

- 官方另有 minimal / enterprise / playful / mono 四套主题:切换主题即整体替换 `colors` 语义映射,不视为对 default 主题的违例。
- 单文件 HTML 原型允许直接用 CDN 两行(jsdelivr flowbite.min.css + flowbite.min.js)运行,免 npm 构建。
