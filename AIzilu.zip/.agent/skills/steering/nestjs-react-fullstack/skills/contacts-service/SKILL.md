---
name: contacts-service
description: "服务端按 ID 批量查用户（AuthNPaasService.listUsersByIds，返回项只有 miaodaUserID / name / avatar，没有 userId / userName）+ 前端搜人选人。Use when 在产物服务端 / OpenAPI 接口里按 ID 查用户姓名头像、搜人/选人/人员选择器/部门选择器/群组选择、获取或展示用户与部门信息、把用户/部门/群组 ID 传给飞书内置插件或飞书开放平台 API、人员字段入库或导出。统一妙搭 ID 体系（miaoda_user_id / employee_id / open_department_id / open_chat_id；lark_* 内部 ID 禁用）、字段获取分级与权限引导、服务端可用与不可用的通讯录能力边界。触发词：AuthNPaasService, listUsersByIds, 服务端查用户, 后端查用户, 批量查用户, 按ID查人, 查用户姓名, 查用户头像, MiaodaUserInfo, 搜人, 选人, 人员选择器, 部门选择器, 群组选择, UserSelect, DepartmentSelect, ChatSelect, 获取用户信息, 用户字段, 部门信息, 群组信息, employee_id, open_id, union_id, open_department_id, open_chat_id, miaoda_user_id, lark_id, 飞书用户ID, 飞书部门ID, 外部用户, 工号, 手机号, 直属上级, 人员入库, 人员导出, id_convert, 通讯录, 选负责人, 选审批人, 传插件, 传开放平台, 选中的人传给, 把选中的人, OpenAPI 查用户"
steering: true
steering-topic: contacts_service
match-template-name: nestjs-react-fullstack
---

# 妙搭通讯录服务 — 用户与部门信息获取指南

> 本 Skill 定义妙搭 Agent 处理**用户 / 部门 / 群组信息**的完整规范：ID 体系、接口返回结构、ID 选择决策、字段获取分级与权限引导。
>
> **相关 skill**：当前登录用户（"我是谁"、useCurrentUserProfile、req.userContext）见 [`user-identity`](../user-identity/SKILL.md)；选择器/展示组件的 props 与用法见 [`client-builtins-user-service`](../client-builtins-user-service/SKILL.md)；飞书原生接口（通讯录 API、id_convert）见 [`feishu`](../../../feishu/SKILL.md)；对外开放接口的编码规范见 [`openapi-guide`](../openapi-guide/SKILL.md)。
>
> **⚠️ 先分流**：一~五节讲的是**浏览器里**的搜人 / 选择器口径。代码跑在**产物服务端**（NestJS service / controller，尤其 `*.openapi.controller.ts`）时，能力边界完全不同——直接看[第六节](#六服务端--openapi-态怎么查通讯录)。

> `AuthNPaasService` 分流：`getCurrentUserLarkUserId`、`getBatchLarkUserIds`、`getBatchMiaodaUserIds` 属于 ID 转换，见 [`user-identity`](../user-identity/SKILL.md) 第三节；`listUsersByIds` 属于按妙搭 userId 查他人姓名 / 头像，见本 skill 第六节。
>
> `listUsersByIds` 返回 `(MiaodaUserInfo | null)[]`，与入参等长同序；单项只有 `miaodaUserID` / `name`（I18nText）/ `avatar`，没有 `userId` / `userName`。字段以第六节或 `node_modules/@lark-apaas/nestjs-authnpaas/dist/index.d.ts` 为准，禁止按常见 SDK 命名猜字段。

## 命名约定（必读）

**以服务端字段为准。** 同一个 ID 在不同层有不同书写：

| 层 | 命名 | 例 |
|---|---|---|
| 服务端 wire / 原始 SDK（client-toolkit） | 小驼峰 + ID 全大写 | `employeeID` `openDepartmentID` `openChatID` |
| 组件 normalize 后 / Agent 写的应用代码 | 下划线 | `employee_id` `open_department_id` `open_chat_id` |

下文用下划线（Agent 面）书写；直接用 client-toolkit 原始 service 时换成小驼峰。

---

## 一、ID 体系规范（全局强制）

### 1.1 用户 ID

| 标准名 | 含义 | 适用用户 | 默认返回 | 可直传飞书 API |
|---|---|---|:---:|:---:|
| **miaoda_user_id** | 妙搭用户全局唯一 ID | 所有用户 | 是 | 否 |
| **employee_id** | 飞书企业内 user_id | 仅内部飞书用户 | 是 | **是** |
| **open_id** | 飞书应用级用户 ID | 内部 + 外部飞书 | 否（需 id_convert） | 是 |
| **union_id** | 飞书开发者级用户 ID | 内部 + 外部飞书 | 否（需 id_convert） | 是 |

### 1.2 部门 ID

| 标准名 | 含义 | 可直传飞书 API |
|---|---|:---:|
| **open_department_id** | 飞书部门 ID（od- 开头） | **是** |

### 1.3 群组 ID

| 标准名 | 含义 | 可直传飞书 API |
|---|---|:---:|
| **open_chat_id** | 飞书群组 ID（oc_ 开头） | **是** |

> 群组接口可能同时返回旧字段 `chat_id` 和新增 `open_chat_id`。**按前缀判断**：`oc_` 开头可直传飞书 IM API；纯数字即 `lark_chat_id`（禁用）。优先用 `open_chat_id`。

### 1.4 历史兼容字段（仍返回，但**禁止使用**）

| 兼容字段 | 标准替代 | 为什么禁用 |
|---|---|---|
| **lark_id** | employee_id | 纯数字内部 ID，飞书开放平台 API 无法识别，传入报错或返回空 |
| **lark_department_id** | open_department_id | 纯数字内部 ID，飞书 API 只接受 od- 格式 |
| **lark_chat_id** | open_chat_id | 纯数字内部 ID，飞书 IM API 只接受 oc_ 格式 |

> 搜人返回里同时有 `lark_id` 和 `employee_id` 时，**必须取 `employee_id`**；用户提到 lark_id 时主动纠正。

### 1.5 废弃名称映射

| 废弃名称 | 应理解为 |
|---|---|
| userID / user_id / suda_user_id | miaoda_user_id |
| larkUserID / larkUserId（纯数字） | lark_id（禁用）→ 飞书用 employee_id |
| departmentID / larkDepartmentID（纯数字） | open_department_id |
| lark_user_id / 飞书用户ID / 飞书ID | 用户口中的这些 = **可用的飞书 user_id**：搜人/选择器场景用 `employee_id`，当前登录用户用 `useCurrentUserProfile().lark_user_id`（二者 == employee_id）。**绝不是**禁用的纯数字 `lark_id` |

---

## 二、搜人 / 选择器返回结构

### 2.1 内部用户（user_type = "_employee"）

```json
{
  "miaoda_user_id": "17xxxxxxxxxx",
  "user_type": "_employee",
  "name": "张三",
  "avatar": "https://xxx/avatar.png",
  "employee_id": "abcdef",
  "email": "zhangsan@company.com",
  "mobile": "138xxxx0001",
  "open_department_id": "od-xxxxxxx",
  "job_title": "产品经理",
  "employee_no": "10086",
  "lark_id": "700001"               // ⚠️ 兼容字段，禁止使用
}
```

### 2.2 外部用户（user_type = "_externalUser"）

```json
{
  "miaoda_user_id": "17xxxxxxxxxx",
  "user_type": "_externalUser",
  "name": "李四",
  "avatar": "https://xxx/avatar.png"
}
```

> 外部用户**没有 employee_id**；需要飞书 ID 时走 id_convert 拿 open_id（见第三节）。

---

## 三、ID 使用决策逻辑

```
用户请求涉及用户 ID
   │
   ├─ 目标：飞书内置插件（发消息/审批/多维表格写人员）？
   │     └─ 是 → 传 miaoda_user_id（插件内部自动转换，对调用方透明）
   │
   └─ 目标：飞书开放平台 API？
         ├─ 内部用户(_employee) → 直接用 employee_id（零额外调用）
         └─ 外部用户(_externalUser) → 先 id_convert（miaoda_user_id → open_id）再传
```

### 规则总结

| 场景 | Agent 行为 |
|---|---|
| 调飞书内置插件 | 传 **miaoda_user_id** |
| 调飞书开放平台 API · 内部用户 | 用 **employee_id** |
| 调飞书开放平台 API · 外部用户 | 先 id_convert 拿 **open_id** 再传 |
| 跨应用识别用户 | id_convert 拿 **union_id** |
| 人员字段入库 | 存 **miaoda_user_id** |
| 部门相关操作 | 用 **open_department_id** |
| 群组相关操作 | 用 **open_chat_id** |

### ID 转换接口

外部用户 / 取 open_id·union_id 时用 `id_convert`，详见 [`feishu` skill › references/id-convert.md](../../../feishu/references/id-convert.md)。

---

## 四、字段获取路径分级

### Level 1 — 默认返回（搜人接口直接返回，needFullFields=false）

`miaoda_user_id`、`user_type`、`name`、`avatar`（所有用户）；`employee_id`、`email`、`open_department_id`（仅内部用户，follow 飞书 admin「成员字段可见范围」）。

### Level 2 — 搜人 full 字段（**必须 needFullFields=true**）

`nickname`、`mobile`(手机)、`gender`、`country`、`work_station`、`employee_no`(工号)、`city`、`job_title`(职位)、`employee_type`、`leader`(直属上级)、`dotted_line_leaders`(虚线上级)。

> **命中方式**：`UserService.searchUsers({ query, needFullFields: true })` → SDK 入 body `{"needFullFields":true}` → 后端 `DirectorySearchUserRequest.NeedFullFields=true` 返回；仍 follow admin 字段权限。
> ⚠️ 默认 false——**工号/手机/职位/上级 不传 needFullFields 就拿不到**。dataloom 的 search 暂不支持该参数，需要 full 字段走 toolkit `UserService`。

### Level 3 — 需 id_convert（open_id / union_id）

| 字段 | 获取方式 |
|---|---|
| open_id / union_id | id_convert 接口 + 开放平台应用凭证（见 feishu › id-convert.md） |

### Level 4 — 搜人拿不到的字段（需开放平台通讯录 API + 字段权限）

如 `status`(在职状态)、`join_time`、`enterprise_email`、`custom_attrs`、`department_path` 等。`GET /open-apis/contact/v3/users/:user_id`（user_id 传 employee_id），**字段 ↔ 权限点映射见 [`feishu` skill › references/contacts.md](../../../feishu/references/contacts.md)**。

---

## 五、用户引导策略

### 5.1 核心原则
- ID 转换对用户透明，Agent 自动处理
- Level 1 字段零配置，直接用，**禁止**为它引导开平流程
- 仅特定场景才引导创建/使用飞书开放平台应用
- 精准映射：按用户请求的字段精确告知所需权限

### 5.2 决策流程
```
是否非用户触发获取（批量/定时/任务）？
  ├─ 是 → 场景 A：开放平台应用 + TAT（应用身份）
  └─ 否 → 需要默认外/无权限字段？
            ├─ 是 → 场景 B：开放平台应用 + UAT（用户身份）
            └─ 否 → 场景 C：直接搜人接口查询
```
> TAT = tenant_access_token（应用身份，后端/无交互场景）；UAT = user_access_token（用户身份，取用户有权数据）。

**场景 A（TAT 批量/定时）**：批量拉部门/全员、定时同步组织架构、任务回调取人、外部用户 id_convert。引导：飞书开放平台建应用 → app_id+app_secret 取 tenant_access_token → 调对应 API。

**场景 B（UAT，搜人拿不到的字段）**：请求 Level 4 字段（如在职状态/入职时间/自定义字段），搜人接口即便 needFullFields=true 也不返回。引导：建应用 → 申请字段权限（映射见 contacts.md）→ OAuth 取 user_access_token → `contact/v3/users/:user_id`（user_id 传 employee_id）。

**场景 C（妙搭搜人直接拿，无需开平应用）**：Level 1 字段直接取；Level 2 字段（工号/手机/职位/性别/上级）**带 `needFullFields: true`** 取——两者都不用开平应用，follow admin 字段权限即可。传内置插件取 miaoda_user_id、调开放平台内部用户取 employee_id、部门取 open_department_id。

### 5.3 常见话术
| 用户需求 | 策略 |
|---|---|
| 工号 / 手机号 / 职位 / 性别 / 直属上级 | 搜人带 **needFullFields=true**（Level 2，无需开平，follow admin 权限） |
| 在职状态 / 入职时间 / 自定义字段 | 引导开平应用 → 通讯录 API（场景 B，Level 4） |
| open_id / union_id | 引导配置应用 → id_convert（场景 A，Level 3） |
| 部门信息 | 直接取 open_department_id |
| 发消息给某人 | 取 miaoda_user_id 传插件 |
| 批量同步部门/全员、定时同步 | 引导配置应用 → 通讯录 API（场景 A） |

---

## 六、服务端 / OpenAPI 态怎么查通讯录

### 6.1 先确认两类上下文

`userId` 标识当前用户，`appId` 标识当前应用，两者不能互相替代。`AuthNPaasService.listUsersByIds` 不要求当前 `userId`，但要求请求上下文已有**非空 `appId`**；已有 `miaoda_user_id` 不能证明或推导出该前置条件。匿名 / OpenAPI 请求没有登录用户，也不能默认具有 `appId`。

按以下顺序决策：

1. 区分业务数据中的人员 ID、当前 `userId` 与请求上下文 `appId`。
2. 确认已支持的运行时机制是否为当前入口提供非空 `appId`，不得凭空补身份头。
3. 再选择查询能力并定义响应字段语义。

### 6.2 有非空 appId 时按 ID 批量查人

请求上下文有非空 `appId` 时，从项目统一入口 `@lark-apaas/fullstack-nestjs-core` 取 `AuthNPaasService` 并调用 `listUsersByIds`。`PlatformModule.forRoot()` 已注册 global 的 `AuthNPaasModule`，不要在业务 module 加 `providers` 或增加直接依赖：

```ts
import { AuthNPaasService } from '@lark-apaas/fullstack-nestjs-core';

@Injectable()
export class TicketService {
  constructor(private readonly authn: AuthNPaasService) {}

  async attachAssignees(ids: string[]) {
    const users = await this.authn.listUsersByIds(ids);
    return users.map((user, index) => ({
      miaoda_user_id: ids[index],
      name: user?.name?.zh_cn ?? user?.name?.en_us,
      avatar: user?.avatar?.image?.large,
    }));
  }
}
```

- 入参是 **miaoda_user_id**，单次最多 **100** 个；返回 `(MiaodaUserInfo | null)[]`，与入参等长同序，未命中的位置是 `null`
- 只有 `miaodaUserID` / `name` / `avatar` 三个字段；`name` 是 `I18nText`，按语言字段映射
- 平台错误抛 `HttpException`(502)，不要吞掉；它与返回 `null` 的查无此人语义不同
- `import` 不到说明 core 版本未提供该能力：报告阻塞，不要增加直接依赖或自实现替代品

登录态内部 `/api` 请求若具有非空 `appId`，保留上述合法批量查询；是否有 `userId` 不是这项能力的判据。

### 6.3 无法保证 appId 的匿名入口

匿名 / OpenAPI 入口无法证明非空 `appId` 时，主体资源读取必须独立于人员查询：

- 返回业务数据中已有的稳定 `miaoda_user_id`，不要因展示名查询失败而让主体读取失败
- 在 `shared/api.interface.ts` 和 `docs/openapi.json` 中把 `name`、`avatar` 等展示值建模为可空或可选；不要用固定“未知用户”或空字符串伪装已取得展示值
- 用户明确要求匿名响应必须返回真实姓名、但当前没有受支持的 `appId` 来源时，报告运行时能力阻塞；不要把未完成实现当作成功

### 6.4 能力边界与禁止项

| 想做的事 | 条件 / 路径 |
|---|---|
| 按 miaoda_user_id 批量查人 | 请求上下文有非空 `appId` → `AuthNPaasService.listUsersByIds` |
| 妙搭 ↔ 飞书 ID 转换 | `AuthNPaasService.getBatchLarkUserIds` / `getBatchMiaodaUserIds`；不能用来判断外部用户是否存在 |
| 搜人 / 搜部门 / 搜群 | 飞书开放平台通讯录 API（应用身份 + 显式授权的通讯录范围） |
| 取手机号 / 职位 / 工号 / 直属上级 | 同上，字段 ↔ 权限映射见 [`feishu` › contacts.md](../../../feishu/references/contacts.md) |
| 知道当前调用者是谁 | 登录态内部 `/api` 才读取 `req.userContext.userId` |
| 按 ID 批量查群 | 暂无服务端能力；在前端获取或使用开放平台 IM API |

以下做法不能作为匿名人员展示的替代方案：

1. 凭空补身份头或把人员 ID 当作 `appId`
2. 复用依赖登录态的用户资料 service，或自己写 HTTP 裸调平台通讯录接口
3. 在数据库持久化姓名 / 头像副本再 join 返回；通讯录展示值会过期且受权限约束
4. 用 service 广域 `try/catch` 吞掉人员查询错误，或固定返回“未知用户”
5. 用 `getCurrentUserLarkUserId()` 查目标用户，或用 `getBatchLarkUserIds()` 判断用户是否存在
6. 把 `name` 当字符串直接渲染或入库

---

## 七、禁止行为
1. **禁用兼容字段**：任何调用不得用 lark_id / lark_department_id / lark_chat_id
2. **禁止混用废弃名**：不得用 userID / suda_user_id / larkUserId 等旧名
3. **禁止给飞书内置插件传 employee_id**：插件入参必须是 miaoda_user_id
4. **禁止让用户手动做 ID 转换**：Agent 自动判断并执行
5. **禁止不看 user_type 就猜 ID 类型**：先判断内部/外部
6. **禁止对 Level 1 字段引导开平流程**

---

## 八、错误处理
| 错误场景 | Agent 行为 |
|---|---|
| 用户说"获取 user_id" | 追问：妙搭 miaoda_user_id 还是飞书 employee_id？ |
| 用户说要 `lark_user_id` / "飞书用户ID" / "飞书 ID" | 多数指**可用的飞书 user_id = `employee_id`**。搜人/选择器结果里**没有**叫 lark_user_id 的字段、可用的就是 `employee_id`，**别返回禁用的纯数字 `lark_id`**；当前登录用户场景取 `useCurrentUserProfile().lark_user_id`（== employee_id）。歧义时确认"是调飞书 API 用吗"，是则一律 employee_id |
| 用户用了 lark_id | 纠正："lark_id 是禁用兼容字段，飞书 API 不认，请用 employee_id（搜人已默认返回）" |
| 用户用了 lark_department_id | 纠正："请用 open_department_id（od- 格式）" |
| 用户用了 lark_chat_id | 纠正："请用 open_chat_id（oc_ 格式）" |
| 外部用户请求 employee_id | 说明外部用户无 employee_id，建议 open_id（需 id_convert） |
| id_convert 报错 | 检查 miaoda_user_id 是否正确、开放平台应用凭证是否有效 |
| 通讯录 API 权限不足 | 引导检查开放平台应用字段权限（场景 B） |
| 批量拉取但只会搜人接口 | 说明搜人是交互式，批量走通讯录 API（场景 A） |
