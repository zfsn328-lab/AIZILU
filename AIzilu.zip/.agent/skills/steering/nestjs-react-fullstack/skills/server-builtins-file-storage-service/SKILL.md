---
name: server-builtins-file-storage-service
description: "Use when server-side code needs to upload or download files programmatically, such as file format conversion, automated report generation, or background tasks that produce files. NOT for frontend file operations. 触发词：服务端文件上传, 服务端文件下载, FileService, nestjs file, 后端文件处理, 文件格式转换, 生成文件上传"
steering: true
steering-topic: server_builtins_file_storage_service
match-template-name: nestjs-react-fullstack
---

# NestJS File Service SDK

在 NestJS 服务端代码中使用 `FileService` 进行文件上传、下载、删除和管理。

> **使用注意**: 仅用于服务端文件处理场景，非必要文件上传下载场景请使用前端 `client-builtins-file-storage-service` skill。
> **入口边界**：本 SDK 是**服务端代码**读写应用存储的入口；Agent 在对话 / 开发中自己上传或调试文件，先加载应用文件存储操作 skill（按「应用文件存储 / 文件上传 / 文件下载」召回），用其 CLI 命令操作，具体命令一律以该 skill 为准。二者与本 SDK 操作同一个应用存储桶，但**该 CLI 命令只供 Agent 在沙箱终端使用，禁止写进服务端代码**。

## 展示 URL 边界

- 服务端上传或读取文件元信息后，`FileMeta.downloadURL` 是前端展示 / 下载的权威 URL。普通 `text` / `varchar` / `JSON` 业务字段回显文件时，接口应返回这个 URL（字段名如 `fileUrl` / `downloadUrl`）。
- 后台异步解析、格式转换等流程可保存稳定 `filePath` 作内部定位；列表 / 详情接口仍必须同时返回 `downloadURL`，或用 `getFileMetadata(filePath).downloadURL` 换出展示 URL。禁止只把普通 path 字段交给前端再生成 URL。
- `filePath` 不是前端展示 URL，不得让前端手拼 `/runtime/api/v1/storage/object`、`/app/{appId}/runtime`、`/spark/app/{appId}/runtime`、`__runtime__` 等运行态前缀。只有数据库字段类型明确为 `file_attachment` 且保存 `bucket_id + file_path` 时，才由前端按 file_attachment 规则换 URL。

## 使用场景

| 场景 | 说明 |
|------|------|
| 服务端文件处理 | 下载文件到本地处理后重新上传，如图片格式转换、docx 格式转换等 |
| 自动化任务生成文件 | 定时任务或事件触发后，根据数据库/插件内容生成文件并上传，如定时生成 PDF 报告、图片海报等 |

## Quick Reference

| 方法 | 说明 | 返回值 |
|------|------|--------|
| `upload(file, options?)` | 上传文件 | `FileMeta` |
| `download(path)` | 下载文件（≤50MB） | `FileDownloadBuilder` |
| `createSignedUrl(filePath, expiresIn)` | 默认 bucket 下生成临时 http(s) 签名 URL | `string` |
| `from(bucketId).createSignedUrl(filePath, expiresIn)` | 指定 bucket 生成临时 http(s) 签名 URL | `string` |
| `remove(filePaths)` | 删除文件 | `RemoveResponse` |
| `getFileMetadata(filePath)` | 获取文件元信息 | `FileMeta` |

## 注入 FileService

```typescript
import { FileService } from '@lark-apaas/fullstack-nestjs-core';

@Injectable()
export class MyService {
  constructor(private readonly fileService: FileService) {}
}
```

## 公共类型

```typescript
interface FileMeta {
  id: string;
  name: string;
  filePath: string;
  metadata: { contentLength: string; mimeType: string };
  downloadURL: string;
  createdAt: string;
  updatedAt: string;
  bucketID: string;
}
```

## 核心操作

### 1. 上传文件

**入参：**

| 参数 | 类型 | 必需 | 说明 |
|------|------|------|------|
| `file` | `FileBody` | 是 | 文件内容（支持 `Buffer`、`ReadableStream`、`ArrayBuffer`、`Blob`、`string` 等） |
| `options` | `UploadOptions` | 否 | 上传选项 |

**UploadOptions：**

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| `fileName` | `string` | 否 | 文件名称 |
| `contentType` | `string` | 否 | MIME 类型 |
| `cacheControl` | `string \| number` | 否 | 缓存控制 |
| `upsert` | `boolean` | 否 | 是否覆盖已有文件 |

**返回值：** `FileMeta`

`FileMeta.downloadURL` 可直接返回给前端展示 / 下载。业务需后台处理文件时，可同时保存 `filePath` 作内部定位；接口给前端的展示字段仍应是 `downloadURL`。

**示例：**

```typescript
// 基本上传
const result = await this.fileService.upload(buffer);

// 带选项上传
const result = await this.fileService.upload(fileBody, {
  fileName: 'report.pdf',
  contentType: 'application/pdf',
  upsert: false,
});
```

### 2. 下载文件

**入参：**

| 参数 | 类型 | 必需 | 说明 |
|------|------|------|------|
| `path` | `string` | 是 | downloadURL 或文件存储路径 |

**返回值 `DownloadResult`：**

| 字段 | 类型 | 说明 |
|------|------|------|
| `content` | `Blob`（默认）/ `ReadableStream`（流式） | 文件内容 |
| `metadata` | `FileMeta` | 文件元信息 |

> **推荐始终使用 `.asStream()`**，避免大文件导致内存溢出。直接 `await download()` 有 50MB 限制。

**示例：**

```typescript
// 推荐：使用 downloadURL + 流式下载
const downloadURL = fileMeta.downloadURL; // 从上传返回值或数据库获取
const { content, metadata } = await this.fileService
  .download(downloadURL)
  .asStream();

// 也可以使用文件存储路径
const { content, metadata } = await this.fileService
  .download('file.pdf')
  .asStream();

// 不推荐：Blob 下载（限制 50MB，会将整个文件加载到内存）
const { content, metadata } = await this.fileService.download(downloadURL);
```

### 3. 生成临时签名 URL

服务端把应用存储中的文件/图片传给 AI capability（如 `ai-doc-parser`、`ai-image-understanding` 或 `plugin-file-url` / `plugin-image-url` 入参）时，不要把站内 download URL 直接作为插件最终入参。优先用数据库保存的 `file_path`，必要时带上 `bucket_id`。旧记录只有标准 `/app` 或 `/spark/app/.../runtime/api/v1/storage/object/<bucket>/<key>` download URL 时，先解析其中的 bucket 与 file path，再从对应 bucket 生成临时 http(s) 签名 URL。默认 `createSignedUrl()` 只使用默认 bucket；它即使能从 download URL 提取 file path，也不会使用 URL 里的 bucket。误拼 origin 的路径、非标准相对路径、前端展示 URL 或 base64 data URL 不作稳定输入。

`download()` 是服务端自己读取文件内容的接口，不是给 AI capability 准备 URL 的默认方案；需要给插件一个可访问 URL 时用 `createSignedUrl()`。

**示例：**

```typescript
// 默认 bucket
const signedUrl = await this.fileService.createSignedUrl(filePath, 3600);

// 指定 file_attachment 记录里的 bucket
const signedUrl = await this.fileService
  .from(bucketId)
  .createSignedUrl(filePath, 3600);
```

签名失败时记录 `warn`，业务状态保持为 `failed`、`pending` 或结果字段 `null`，让前端能看到失败/待处理；禁止吞掉错误后写入“已解析成功”。

### 4. 删除文件

**入参：**

| 参数 | 类型 | 必需 | 说明 |
|------|------|------|------|
| `filePaths` | `string[]` | 是 | downloadURL 或文件存储路径数组 |

**返回值：** `FileMeta[]` - 删除成功的文件元信息数组

**示例：**

```typescript
// 推荐：使用 downloadURL
const result = await this.fileService.remove([fileMeta.downloadURL]);

// 也可以使用文件存储路径
const result = await this.fileService.remove(['file1.pdf', 'file2.png']);
```

### 5. 获取文件元信息

**入参：**

| 参数 | 类型 | 必需 | 说明 |
|------|------|------|------|
| `filePath` | `string` | 是 | downloadURL 或文件存储路径 |

**返回值：** `FileMeta | null` - 文件元信息或 `null` 表示文件不存在或删除失败。内部已有 `filePath` 且需前端回显时，用 `getFileMetadata(filePath).downloadURL` 换出展示 URL，并随列表 / 详情接口返回。

**示例：**

```typescript
// 推荐：使用 downloadURL
const meta = await this.fileService.getFileMetadata(fileMeta.downloadURL);

// 后台保存 filePath 时，先换出展示 URL 再返回前端
const meta = await this.fileService.getFileMetadata('file.pdf');
const fileUrl = meta?.downloadURL;
```

## Common Mistakes

| 错误 | 正确做法 |
|------|----------|
| 直接 `await download()` 导致内存溢出 | 始终使用 `.asStream()` 流式下载 |
| 把 `download()` 结果或站内 `downloadURL` 直接当作 AI capability 最终入参 | 优先用 `file_path + bucket_id` 签名；只有 download URL 时先解析 bucket 与 file path，再从对应 bucket 生成签名 URL |
| 忘记设置 `contentType` 导致浏览器无法预览 | 上传时明确指定 `contentType` |
| 直接 `new FileService()` 手动实例化 | 通过 NestJS DI 注入 `FileService` |
| 在异步回调中调用 `download()` 导致上下文丢失 | 在请求处理函数中立即调用，SDK 内部已处理上下文捕获 |
| 删除时传单个字符串 | `remove()` 参数为 `string[]` 数组 |
| 普通业务字段只返回 filePath，让前端二次生成展示 URL | 接口另返 `downloadURL`，前端直接消费该 URL |
