---
name: coding-guide
description: "项目全局编码规范，必须在任何代码编写、阅读、修改、排查前加载。覆盖：项目结构、目录组织、文件命名、NestJS 后端（MVCS/Drizzle ORM/API 规范/异常处理/用户上下文）、React 19 前端（shadcn/ui/Tailwind/路由/样式/组件规范）、前后端联调（shared 类型/axiosForBackend）、数据库操作、插件能力、质量保障流程、日志规范。Use when: 编写任意前端或后端代码、新建页面或模块、修改接口或数据库操作、排查编译错误或运行时问题、代码审查、理解项目架构。"
steering: true
steering-inclusion: always
steering-topic: coding_guide
match-template-name: nestjs-react-fullstack
unavailable-agents:
  - AppInit
  - SpecDoc
---

# 平台关键文件红线（CRITICAL — 任何修改 / 排查前先读）

下列文件 / 目录由平台模板与 SDK 预置，是应用运行的地基，**不建议改 / 非必要不改**——尤其禁止删除或重写（删坏会直接导致白屏 / 启动失败 / 鉴权链断）：

- `server/main.ts`
- `client/src/index.tsx`
- `client/index.html`
- `client/src/app.tsx`（加路由 / Provider 可改，但**禁止删除其中的平台根组件 / Provider 包裹**，禁止用 `eslint-disable` 关掉平台校验规则）
- `client/src/components/business-ui/*`
- `server/modules/view/view.controller.ts`
- `vite.config.ts`

**修改 / 排查上列文件时**：

1. **禁删、禁重写**；类型与平台代码不兼容时，在**调用点写 adapter / 包一层**消化差异，禁止改平台文件去迁就（更禁止 `as any`）。
2. 文件疑似被**清空 / 损坏**时，**从模板恢复原版**（对照同模板初始版本还原），禁止凭记忆从零重写——空文件不是「可以自由发挥」的信号。
3. 同一症状已尝试 **3 种以上修法仍未解决** → 停手回溯根因，不要再叠第 4 种 hack（3+ 次失败通常是把平台关键文件改坏了）。

# 项目结构

## 根目录组织

```
├── client/          # React 前端
├── server/          # NestJS 后端
├── shared/          # 共享类型定义
└── package.json     # 根配置
```

任何需要被代码引用的文件均需在 `client`、`server`、`shared` 目录中，你需要将文件复制到正确位置。

## 后端结构 (`server/`)

基于 MVCS 架构，**禁止新增一级目录**。 

```
server/ # 符合 NestJS 项目基本规范
├── main.ts                  # 应用程序入口点，平台关键文件，禁删禁重写（见顶部红线）
├── app.module.ts            # 根模块，模块需要在该文件中导入
├── config/                  # 配置文件
│   └── app.config.ts        # 主要应用配置
├── modules/                 # 功能模块（领域驱动）。新 module 在 app.module.ts 中的引入必须在 ViewModule 之前！编写代码前请 glob `server/modules/**` 目录，检查已有的文件。注意，module 修改或编写完成后，必须检查 app.module.ts 中是否已经引入该模块。
│   ├── view/                # 模板渲染模块
│   └── hello/               # 演示 hello world 端点（参考该结构即可）。遵循 Nest.js 最佳实践进行文件组织
│       ├── hello.controller.ts # controller 示例
│       ├── hello.module.ts  # module 示例
│       └── hello.service.ts # service 示例（可选）
├── database/                # Drizzle ORM 数据库相关。应用仅能进行 DML 操作。若用户需求设计表结构变更，DDL 相关操作先加载数据库操作 skill（按「应用数据库 / 建表 / 改表 / SQL」召回），按其中的执行通道与建表规范操作。
│   ├── schema.ts              # Drizzle ORM 数据库 Schema 定义。会在执行完 DDL 操作后自动生成，必须从该文件导入数据库类型，禁止自行编写 schema 文件。如有需要可调用 CodeGen 工具手动生成。
└── common/                  # 共享工具和接口
│      ├── filters/          # 通用错误处理。
│      ├── constants/         # 通用常量。
│      └── utils/          # 通用工具方法。
shared/ # 前后端共享的目录
│   └── api.interface.ts             # 前后端共享的类型定义
```

## 前端结构 (`client/`)

```
client/
├── index.html              # HTML 模板
├── public/                 # 静态资源
├── src/
│   ├── index.tsx          # React 应用入口点，平台关键文件，禁删禁重写（见顶部红线）
│   ├── index.css          # 全局样式
│   ├── tailwind-theme.css          # tailwindcss 全局css主题变量定制
│   ├── app.tsx            # 主应用组件(包含路由定义)
│   ├── api/
│   │   └── index.ts       # 所有请求后端的 API 的逻辑均应聚合在该文件内。请先读取该文件再修改，禁止直接编写该文件
│   ├── pages/             # 页面目录
│   │   ├── HomePage     # 单个页面目录
│   │    |        ├── HomePage.tsx             # 页面文件
│   │    |        └── HomeComponentA.tsx  # 页面依赖的组件（非必须，除非页面文件大于 500 行，否则组件应该写在页面文件内）
│   │   └── NotFound       # 404 页面所在目录
 |     │   |        └── NotFound.tsx   # 404 页面文件
│   ├── components/        # 可复用的 UI 组件
│   │   ├── ui/            # shadcn/ui 组件[Use the components for functionality, but heavily style them.]
│   │   │   ├── README.md      # shadcn/ui 组件库使用说明 [请务必参考该文档进行组件使用]
{% if projectMeta['flags']['supportBusinessUser'] %}
│   │   ├── business-ui/            # 封装好的用户，部门选择组件以及展示组件
│   │   │   ├── README.md      # 用户展示，用户头像展示，部门选择展示逻辑必须使用 [请务必参考该文档进行组件使用]，禁止直接使用avatar组件等方式自行实现
{% endif %}
│   │   ├── Layout.tsx     # 布局包装器
│   ├── hooks/             # 自定义 React hooks
│   └── utils/             # 工具函数
│   │   └── config.ts      # 应用初始化执行的配置
shared/ # 前后端共享的目录
│   └── api.interface.ts    # 前后端共享的类型定义
```

---

# 全局编码约定

## TypeScript 规范

- **TypeScript 优先**：所有代码都用 TypeScript 编写，具有适当的类型
- **路径别名**：`@client/` → `client/`；`@server/` → `server/`；`@shared/` → `shared/`。优先使用别名
- **环境配置**：不支持配置文件，写在代码中即可
- **命名约定**：Class → PascalCase，函数/变量 → camelCase，常量 → UPPER_CASE
- **跨子组件共享常量加语义前缀**：父级桶导出聚合多子组件时，子组件中相同语义的常量必须前缀化（如 `USER_DEFAULTS` / `ORDER_DEFAULTS`），禁止跨子组件复用裸通用名（`DEFAULT_CONFIG` / `STYLES` / `OPTIONS`），避免 barrel re-export 触发 `no-redeclare`
- **类型约束**：
  - 使用 interface 定义类型，type 用于复杂类型。禁止 `any`
  - 禁止自定义与 TypeScript 内置工具类型同名的类型（如 `Record`, `Omit`）
  - 类型转换必须显式（如 `String(num)`），优先让 TS 自动推断泛型
  - **禁止将 interface/type 作为值使用**（如 `instanceof`），运行时判断用 enum/const 对象
  - **禁止 `{} as T` 和 `as any` 类型断言**：用 `useState<T | null>(null)` + 空值检查代替。修复类型错误时必须找到根因，禁止用 `as any` 绕过
  - **`import type` 只能导入类型**：不能导入 const/enum/function（编译后被擦除→undefined）
  - **变量和函数参数必须显式声明类型**（禁止隐式 `any`）：所有变量声明必须有明确类型注解；`.map()/.filter()/.forEach()/.reduce()` 等回调的参数必须显式标注类型，否则触发 TS7006

  ```typescript
  // ❌ 错误：变量无类型注解 → 回调参数隐式 any → TS7006
  const items = await this.service.getItems();
  items.map(item => item.name);  // TS7006: item 隐式具有 any 类型

  // ✅ 正确：变量显式类型 + 回调参数显式类型
  const items: Item[] = await this.service.getItems();
  items.map((item: Item) => item.name);
  ```

## shared/api.interface.ts 规范（CRITICAL）

- 新建/修改后端接口时，**必须先完成 shared/api.interface.ts 中的类型定义，再编写后端实现**
- 编写前后端代码前，**必须先读取该文件**，严格按照定义实现。禁止凭记忆编写
- **严格使用已定义的属性名和类型**，禁止使用不存在的属性名。需要新增字段必须先在此文件添加
- **import 类型前必须确认实际导出**：先读取文件确认类型名称存在且拼写一致，禁止臆造类型名
- 属性统一 camelCase（禁止 snake_case），server 端 schema 的 snake_case 不应泄漏到接口类型
- shared 目录是前后端共享文件，**禁止反向引用** `@server/*`、`@client/*` 等路径别名
- **请求 DTO 中的 shared 字符串联合别名**：`shared/api.interface.ts` 是前后端契约权威。带 `class-validator` 的 NestJS 请求 DTO 字段若对应 shared 字符串字面量联合 `type` alias，不把 imported alias 直接写在 DTO 属性上；改用等价 inline literal union + `@IsString()` + `@IsIn([...])`，DTO class 仍 `implements` shared 请求接口。
  - ❌ `type!: ExpressionElementType`
  - ✅ `@IsString()` + `@IsIn(['tile', 'operator'])` + `type!: 'tile' | 'operator'`
  - **机械核对**：先数 shared alias 字面量个数 N，inline union 和 `@IsIn` 数组都必须恰好 N 个，且每个字面量完全一致；数量或名称不等就是错，不能只写“不得窄于”。
  - 边界：shared 真实 `enum` 用 `@IsEnum(EnumName)`；嵌套 DTO 用 `@ValidateNested()` + `@Type(() => XxxDto)`；普通对象字段用 `@IsObject()`；Date 转换按 `@Type(() => Date)` 处理。禁止用 `@Type(() => String)` 只为绕过 lint。

## 代码质量约束

- **代码行长度**：单行不超过 80-120 字符，import 成员多时及时换行
- **嵌套层级**：不超过 4 层，用 early return 减少嵌套
- **单文件预估（写之前）**：动笔写 page / module 前先估规模——若预期 ≥400 行（按字段数 / 子区块数 / 表单 schema 数粗算），**在动手前**就规划拆分（抽提子组件 / Hook / 服务子模块），不要先写大文件再 refactor
- **单文件硬上限**：**禁止**在 ≥800 行文件上继续 patch 新功能，新增内容先抽提最大子区块到 `pages/<X>/<X>ComponentA.tsx` 或同模块 sub-page（页面≤500 / 组件≤300 / hook≤100 的行数上限见系统任务流程约束）
- **大型闭包风险**：组件内大型回调/处理函数（如 handleApplyResults）应拆到独立文件（如 `apply-results.ts`），避免 Vite React Refresh 循环引用导致白屏
- **将风格问题视为编码错误**：项目使用 `@eslint/js` + `typescript-eslint` 推荐配置
- **ESLint 规范**（`@eslint/js` + `typescript-eslint`）：
  - 正则控制字符用 unicode 标志：`/\x1b\[/u`
  - 避免无意义转义：字符串 `"'"` 非 `"\'"`, 正则 `[.]` 非 `[\.] `
  - switch-case 中声明变量用 `{}` 包裹作用域

## 依赖使用规范

1. **子包完整性检查**：部分库有多个子包（如 `@radix-ui/react-*` 系列每个组件都是独立子包），添加 import 后必须确认 package.json 中包含所有需要的子包
2. **禁止安装时需现场编译的 native addon**（`node-gyp rebuild`、`binding.gyp`、需要系统头文件或编译器）。依赖按平台内置能力 / 浏览器能力 → 纯 JS 或 WASM → 有预编译二进制的 native addon 的顺序选型
3. 用法不清时查看 readme，可进一步搜索或网页访问获取信息

## 文件命名约定

- **语言**：文件/文件夹命名全部英文
- **组件**：PascalCase（`HelloWorld.tsx`）
- **模块**：kebab-case 文件夹，PascalCase 文件（`hello/hello.controller.ts`）
- **配置**：dot.case（`app.config.ts`）
- **导入导出**：使用桶导出，优先命名导出，使用路径别名避免相对导入；**同一符号 `export const X` 与底部 `export { X }` 二选一**，优先底部桶导出作为单一来源，禁止行内 + 桶导出双轨

## 开发环境与内置服务

- **登录/注册/用户系统**：内置，禁止自行实现
- 项目依赖已安装完整，前后端 devServer 已启动并自动重启（无需怀疑），文件变更自动热重载
- `/api` 和 `/openapi` 代理已配置，前端 TS 严格模式已禁用，后端已启用
- Rspack 用于构建，已配置好，**禁止修改**
- **禁止修改的工程配置文件与目录**：
  - `package.json`、`tsconfig.json`、`jest.config.js`、`.env*`
  - `package-lock.json`、`pnpm-lock.yaml`、`yarn.lock`
  - `webpack.config.js`、`vite.config.js`、`babel.config.js`
  - `.eslintrc.js`、`.prettierrc`
  - `node_modules/`、`.git/`、`dist/`、`build/`

### 沙箱 dev 不提供平台 runtime 接口（`__runtime__`）

dev server 只代理 `/api`、`/openapi`、`/__innerapi__`（外加 legacy 的 `/af/p/:appId/api`、`/af/p/:appId/__innerapi__`）。`/app/<appId>/__runtime__/*` 这一整类**平台 runtime 接口在沙箱 dev 下打不通**，只有发布态才由网关接管。

**症状分两种，按请求方法区分**：POST 直接 404；**GET 会落到 Vite 的 SPA fallback，拿回 200 + `index.html`**，业务侧表现为「返回了一坨 HTML，JSON 解析失败」——见下方「问题排查指引」里「API 测试返回 HTML 内容时」那条，两者是同一回事。

已知受影响端点：

| 端点 | 方法 | 谁会打到它 |
|------|------|-----------|
| `api/v1/permissions/roles` | GET | `AppContainer` **每次加载应用自动打**，不需要你写任何代码 |
| `api/v1/observability/{logs,traces,metrics}/collect`、`current_server_timestamp` | POST/GET | 平台埋点上报，**自动打** |
| `api/v1/account/login/user` | POST | `useCurrentUserProfile()` → `authClient.session.getUserInfo()` |
| `api/v1/account/search_user`、`list_users`、`user_profile`、`search_department`、`convert_lark_user` | POST / `user_profile` 是 GET | `business-ui` 的 UserSelect / DepartmentSelect / UserDisplay |
| `api/v1/account/search`、`api/v1/account/chat/list_chats` | POST | ChatSelect 选群组件 |
| `api/v1/studio/user/profile` | GET | `getUserProfile()` |
| `api/v1/storage/object/<bucket>/pre_upload` | POST | `dataloom.storage.uploadFile()` 前端上传 |
| `api/v1/studio/plugins/tmp_files/acquire_upload_url`、`acquire_download_url` | POST | `capabilityClient` 的文件类入参 |

> `useCurrentUserProfile()` 打的是 `account/login/user`，**不是** `user_profile`/`search_user` 那一排；它另外还打一个 `GET /api/authnpaas/lark-user-id`，那条走 `/api`、被代理、正常。

**这是环境限制，不是应用缺陷，也不是组件坏了。** 看到这些 404 / HTML 响应时：

- **禁止**改 `client/src/components/business-ui/**`（平台保护文件）、**禁止**给组件加兜底请求或改用自研选人控件绕过——发布后这些端点是正常的，绕过写法反而是错的
- 需要在开发期验证「按当前用户过滤」「展示用户姓名」这类逻辑：改由服务端出数据。服务端的 `req.userContext` 和 `AuthNPaasService` 由网关注入，**不受此限制**，始终可用（见 `user-identity` / `contacts-service` skill）。`useCurrentUserProfile()` 在这里长期停在加载态就是这个原因
- 需要在开发期验证上传链路：改用接口测试直接打后端接口，或复用库里已有的文件 URL，不要在浏览器里点上传
- 依赖上述端点的 E2E 用例不要写成浏览器交互 Case，改走接口层往返验证

另外，`UserSelect` 弹层是**搜索驱动**的：不输关键词时列表为空属预期行为，不是接口挂了。

## 应用访问入口（404 / 白屏先看这里）

沙箱内页面入口、API 入口、NestJS 端口不是一回事，禁止用 `5173/3000/8001/8080` 枚举猜测。

- **看页面 / 白屏 / 交互**：优先用截图、视觉检查或 E2E 工具，并只传相对路径；工具会打开沙箱真实预览入口（E2E 走 8080 nginx/openresty 鉴权代理）。不要用 `curl` 拿 HTML 判断页面是否渲染。
- **测后端接口**：优先用接口测试工具，只传以 `/api` 或 `/openapi` 开头的业务路径；工具会自动拼 `CLIENT_BASE_PATH`、选择正确 dev 端口，并补 CSRF 与用户身份。
- **必须手写 curl 调 `/api/*` 时**：打 client dev server，不要打 NestJS `SERVER_PORT`；URL 必须带 `$CLIENT_BASE_PATH`，并同时带 `Cookie: suda-csrf-token=<X>` 与 `X-Suda-Csrf-Token: <X>`（两值字面相等）。漏 basePath 是 404，漏 CSRF 是 403，都不是业务代码 bug，不要为此改 csrf 中间件或给接口加白名单。
- **不要直连 NestJS 端口**：会绕过 dev server / 网关注入，`x-larkgw-suda-webuser` 缺失后 `userContext.userId` 为空，依赖身份的接口会误判。
- **判断服务是否启动**：看 `client-devserver` / `server-devserver` 日志的 ready / 编译成功。裸端口访问返回 404 或连不上（只监听 IPv6 等）都不能当服务故障的依据；同一 URL 连续两次同状态码就换排查方向，不要 `sleep` + curl 重试。

## 质量保障流程

通用提交前检查（代码检查 / 接口测试 / 读日志确认无错误）见系统任务流程约束；本栈具体落点：

- **日志源**：服务端读 `server-devserver` / `server` 日志，客户端读 `client-devserver` 日志
- **dev 服务无响应**：`pkill -f "npm run dev"` 触发重启

---

# 后端开发指南

- **运行时**: Node.js >=22.0.0
- **框架**: NestJS 10.x + TypeScript，每个功能组织为 NestJS 模块，利用内置 DI 容器
- **控制器-服务模式**：Controller 处理 HTTP 请求响应，Service 负责业务逻辑和数据层交互
- **通信协议**：仅支持标准 HTTP（POST/GET/PUT/PATCH/DELETE），不支持 SSE/WebSocket。流式输出改为一次性返回；状态同步用短轮询
- **模板引擎**: Nunjucks
- **数据库**：Drizzle ORM + Postgres
- **验证（可选）**: class-validator + class-transformer
- **一方插件**：服务端内置 AI 和飞书相关插件，PluginInstance 属于平台插件调用链路，不等同于自建 SSE/WS。涉及插件调用**必须先阅读 Plugin 集成指南**。**调用侧选择原则**：结果不需存储（即时展示/发消息）→ Client 侧调用；结果需要持久化到数据库 → Server 侧调用并落库，或 Client 侧调用后通过 CRUD 接口保存
- **聚合文件与模块边界（CRITICAL — 启动失败 + 并发编辑冲突 Top 原因）**：

  项目有三个**聚合文件**：`server/app.module.ts`、`client/src/app.tsx`、`client/src/api/index.ts`。它们是所有业务模块的汇聚入口，**必须由主 agent 在派发任何业务模块任务之前一次性串行预填**，业务模块任务（可能并行执行）**不得编辑**这三个文件。多方并发编辑同一聚合文件会触发 `old_string` mismatch 和 LLM 兜底重写，显著拖慢生成。

  **主 agent 预填职责**（规划阶段产出**业务模块清单**后立即执行，任务派发前完成）：

  - 清单命名约定：目录名 / 路由 / namespace / `api_prefix` 末段统一 `kebab-case`；`module_class` / 页面组件名统一 `PascalCase`；目录名与模块 `name` 一致
  - **严格串行**编辑以下三个文件（一次一个 tool 调用）：
    - `server/app.module.ts`：在文件顶部追加 `import { UsersModule } from './modules/users/users.module';`，在 `@Module` 的 `imports` 数组里加入 `UsersModule`；`ViewModule` 必须保持 `imports` 数组最后一项（fallback 路由）
    - `client/src/app.tsx`：顶部追加 `import UsersPage from './pages/users';`，在 `<Routes>` 内加 `<Route index element={<UsersPage />} />`（或其他业务首页组件作为 index 路由），并加 `<Route path="users" element={<UsersPage />} />`
    - `client/src/api/index.ts`：每行 `export * as <namespace> from './<name>';`（用命名空间导出避免跨模块 export 名冲突）
  - 预填完成后才派发业务模块任务；聚合文件引用的符号（`UsersModule` / `UsersPage` / `./users`）在任务产出前暂时悬空，任务完成后自然对齐

  **业务模块任务的工作边界**：

  - 产出只能落在以下目录之一：`server/modules/<name>/`（Module / Controller / Service / DTO）、`client/src/pages/<name>/`、`client/src/api/<name>/`
  - **禁止编辑** `server/app.module.ts` / `client/src/app.tsx` / `client/src/api/index.ts`（已由主 agent 预填）
  - 跨模块依赖（不涉及聚合文件）：在源 Module 的 `exports` 中导出即可
  - 若开发中发现规划外的跨模块需求（罕见，如发现需要一个主 agent 未规划的 shared helper 模块），**不要擅自改聚合文件**，在完成摘要里声明：

    ```yaml
    cross_module_needs:
      - type: extra_module       # 或 extra_route / extra_provider
        reason: "需要 SharedAuthModule 让 UsersController 使用 @Auth"
        module_class: SharedAuthModule
        module_file: server/modules/shared-auth/shared-auth.module.ts
    ```

    主 agent 在所有模块任务完成后统一串行处理 `cross_module_needs`（补丁阶段，仍是单 agent 编辑聚合文件，无并发冲突）

- **@Injectable() Service 注册**：创建 `@Injectable()` Service → 在对应 Module 的 `providers` 中注册（这条在模块目录内部完成，与聚合文件无关）
- **三方集成**：调用第三方 API 需在后端实现，使用 @nestjs/axios
- **能力边界**：服务端不支持文件上传（FaaS 限制），前端用 dataloom SDK 上传，服务端仅保存元信息
- **环境判断**：`process.env.NODE_ENV === "production"` 表示生产环境
- **运行时文件系统（CRITICAL）**：生产 FaaS 中 `process.cwd()` 指向只读部署目录 `/opt/bytefaas`；禁止在该目录或项目目录下创建或写入 `uploads`、`logs`、缓存等，也禁止“先写工作目录，失败再回退 `/tmp`”。临时文件、下载内容和处理中间产物必须直接写入 `/tmp` 下的独立目录
- **服务端运行时资源文件**（字体 / 证书 / 模板 / wasm 等需在运行时读取的非代码文件，CRITICAL — 发布后静默失效根因）：① 必须在 `nest-cli.json` 的 `assets` 中声明（如 `{"include": "assets/<dir>/**/*", "outDir": "dist/server"}`），否则不会进 `dist/` 构建产物；② 路径用 `__dirname` 相对**编译产物**定位（如 `path.join(__dirname, "../assets/...")`），**禁止 `process.cwd()` 相对源码路径**——dev 跑源码能命中、发布跑 `dist/` 会落空；③ 资源缺失或加载失败必须 **fail-loud**（抛错或明确错误日志），禁止 `catch` 后静默返回残缺产物
- **启动生命周期**：`bootstrap`、`constructor`、`onModuleInit` 和 `onApplicationBootstrap` 都位于服务启动或就绪关键路径，应快速完成，只做必要且确定的装配、内存初始化和配置校验；不得在其中执行或直接发起 DDL、下载大文件、全量同步、批量迁移、长轮询或无界外部请求。仅将钩子声明为 `async`，或在钩子内用 `void Promise`、异步 IIFE、定时器等 fire-and-forget 写法启动任务，都不算移出启动流程；耗时工作必须由平台支持的独立异步任务或外部触发机制执行

## 日志约定

前后端是两个独立的 logger，签名不同，不要互相套用。

**前端** `@lark-apaas/client-toolkit/logger`：同一个 `logger` 对象，六个方法分两类签名。

- `debug` / `info` / `warn` / `error` / `success`: `(message: any, ...args: any[])`
  级别已在方法名里；可多参，`message` 不限 string。
  例：`logger.error('创建失败', error)`
- `log`: `({ level, args, meta? }: LogWithMeta)`
  级别不在方法名里必须显式传；只接对象，传裸字符串会 TS2345。
  例：`logger.log({ level: 'info', args: ['创建成功', id] })`

**后端** `@nestjs/common` 的 `Logger`：

- 没有 `info` 方法，用 `logger.log` 代替；有 `debug` / `verbose` / `fatal`
- `(message: any, ...optionalParams)`，可多参
- 最后一个 string 参数会被当作 `context`（`error` 是 `stack` + `context`），传对象前自己 `JSON.stringify`

两端共同：禁止 `console`；错误日志输出完整堆栈。

## Database

**必须使用注入的 Drizzle 实例**，禁止自建连接：

```typescript
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from "@lark-apaas/fullstack-nestjs-core";

@Injectable()
export class TestService {
  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}
}
```

- **每次编写或修改数据库操作代码前，必须重新读取 `server/database/schema.ts`**——该文件由系统在 DDL 执行后自动重新生成，内容随时可能变化。禁止凭记忆或之前读取的版本编写字段名和类型，否则会引用不存在的字段导致 TS2339 批量报错
- **事务**：多条写操作需要整体成功/失败时（如扣库存 + 写审批流水），用 `db.transaction` 包裹；单条语句能完成的操作不要套事务
- 条件查询用三元分支，禁止 `let query` 重赋值（类型不兼容）：

```typescript
// ✅ 条件查询
const conditions = [];
if (status) conditions.push(eq(users.status, status));
const query = conditions.length > 0
  ? db.select().from(users).where(and(...conditions))
  : db.select().from(users);
```

- Count 查询：
```typescript
// 简单 count
const result = await this.db.select({ count: count() }).from(users).where(eq(users.status, "active"));
// 子查询 count（关联计数）
const users = await this.db.select({
  ...users,
  postsCount: this.db.$count(posts, eq(posts.authorId, users.id)),
}).from(users);
```

### userProfile 自定义类型

`userProfile` 是 Drizzle ORM custom_type，TypeScript 中对应 `string`。所有相关变量**必须显式类型注解**，禁止隐式推断。

```typescript
// schema 示例
export const mockTable = pgTable("mock_table", {
  adminUser: userProfile("admin_user"), // custom_type, TS 中为 string
});
// 使用示例
const userId: string = "user123"; // ✅ 显式注解
await db.insert(users).values({ adminUser: userId });
await db.select().from(users).where(eq(users.adminUser, userId));
```

**被迫写原生 `sql\`...\`` 时（service 中已大量存在原生查询），user_profile 列按下表写法（读侧优先用上方 Drizzle ORM；被迫写原生 SQL 时按此表，不要在多种写法间反复横跳试错）：**

| 场景 | 推荐写法 | 避免 |
| ---- | ------------ | ---- |
| 读 | `SELECT (col).user_id AS alias`（解引用） | 裸列 `SELECT col`（返回 `(<id>,,,,)` 前端不可用） |
| 写（insert/update） | `ROW(${userId})::user_profile`（整体赋值） | 只更新复合类型单字段 |
| 过滤（where） | `WHERE (col).user_id = ${userId}` | `col::text = ${id}` / 裸 `col = ${id}` / `col = ROW(${id})::user_profile` 比较 |

> 权威来源是数据库操作 skill（按「应用数据库 / 建表 / 改表 / SQL」召回）的「`user_id` / `user_profile`」小节。原生 SQL 现场遇到 user_profile 列直接套用本表，不要在 `ROW()::user_profile` / `::text` / 裸值之间反复试错。

### 使用侧边界陷阱

- **Postgres 不做 MySQL 式隐式转换**：where 的参数类型要和 `schema.ts` 的列类型一致，否则报 `42883 operator does not exist`。

  | 场景 | 写法 |
  | --- | --- |
  | 按月 / 按天筛 date、timestamptz | 半开区间 `and(gte(col, "2026-08-01"), lt(col, "2026-09-01"))`；日期列不能用 `like(col, "2026-08%")` |
  | 数字列过滤（`@Query` 取到的是 string） | 先 `Number(q)` 再进 `eq` |

- **区分 Drizzle helper 与原生 SQL `COUNT()`**：当前模板的 `drizzle-orm@0.44.6` 中，`count()` helper 返回 `number`；原生 SQL `COUNT()` 返回 PostgreSQL `bigint`，驱动结果可能是 `string`。需要保留超过 `Number.MAX_SAFE_INTEGER` 的精确值时，使用 `BigInt` 或保留字符串，不要转成 `Number`。

  ```typescript
  const [{ total }] = await db.select({ total: count() }).from(users); // total: number

  const rawTotal = '9007199254740993';
  const exactTotal = BigInt(rawTotal); // ✅ 9007199254740993n
  const unsafeTotal = Number(rawTotal); // ❌ 9007199254740992，精度丢失
  ```

- **UUID 多值过滤不要直接插值数组到 `ANY(...::uuid[])`**：在 sql 模板中直接插入 ids 这类 JS 数组，可能被展开成 `($1, $2, ...)::uuid[]`，运行时报 `42846: cannot cast type record to uuid[]`。

  ```typescript
  // ✅ 优先使用 Drizzle 安全 helper
  where: inArray(tasks.id, ids)

  // ✅ 被迫写原生 SQL 时，逐个参数化数组元素
  where: sql`${tasks.id} = ANY(ARRAY[${sql.join(ids.map(id => sql`${id}`), sql`, `)}]::uuid[])`

  // ❌ 禁止：数组直接插值会变成 record cast
  where: sql`${tasks.id} = ANY(${ids}::uuid[])`

  // ❌ 禁止：字符串拼接 raw SQL，易注入且易生成坏语法
  where: sql`${tasks.id} = ANY(${sql.raw(`ARRAY['${ids.join("','")}']::uuid[]`)})`
  ```

  多 ID 数据库接口（如按班级查课程/考试/成绩统计）写完后必须实际调用验证，避免隐藏 500。

- **Drizzle raw `sql` 参数不走列 encoder**：绑定 schema 列的 helper 会编码；raw `sql` 的 `${...}` 只是 driver 参数。Date / custom type 进 raw SQL 前先转 driver-safe 标量（时间用 ISO string）或改回 helper；`user_profile` 仍按上一小节专表处理。
- raw SQL 聚合、`filter (...)`、`CASE WHEN`、窗口函数或复杂 where 涉及 Date / custom type 时，按 `raw-sql-boundary-audit` 审计，并实际调用对应 API 验证 HTTP 200，避免隐藏 500。

- **时间字段：写库前查 `schema.ts`，别按 SQL 列名猜**（drizzle-date-boundary-v1）。用 `typeof table.$inferInsert` / `$inferSelect` 看这列在 TS 里是 `Date` 还是 `string`——custom type 会改掉默认映射。
  - 列是 `Date`、DTO 给字符串 → 转成 `Date` 再写，非法值抛 `BadRequestException`，update 保留 `null`。
  - 列是 `string` → 原样写，别转 `Date`。
  - 读出 `Date` → 出口 `.toISOString()`；读出 `string` → 原样返回。`shared/api.interface.ts` 里两类都声明为 `string`。
  - `toDriver` 收得比应用类型宽，但 `.values()` / `.set()` 只认 `$inferInsert`；别靠放宽 custom type 消错。

- **禁止删类型注解消除报错**（`as unknown as T` 同禁）：典型症状是「改完 service，错误跑到 controller 了」——错误没有转移，是校验点被往外推了一层；推到最外层删完，报错归零而契约失守。

### 业务日期

需求里的日期是**自然日**（哪一天 / 哪一周 / 哪一月）而不是精确时刻时，按业务时区计算，未指定时默认 `Asia/Shanghai`。

项目里放一个 helper 统一产出 `day` / `month` / `weekStart` / `shiftDay`；服务端写入、统计聚合、前端展示都比较它的返回值。

### PostgreSQL SQLSTATE / Drizzle 异常处理（CRITICAL）

- 可预期幂等 / 冲突优先用数据库原子语义（`ON CONFLICT`、`UPDATE ... WHERE ... RETURNING`），不要靠异常流兜底。
- 必须 catch 数据库异常时，**禁止只读顶层 `error.code`**：Drizzle 可能把原始 PostgreSQL error 放在 `cause` 链里。判断 `23505` 等 SQLSTATE 时用 cause-aware helper：

  ```typescript
  function extractPostgresErrorCode(error: unknown): string | undefined {
    let current: unknown = error;
    for (let depth = 0; depth < 4 && current && typeof current === "object"; depth += 1) {
      const { code, cause } = current as { code?: unknown; cause?: unknown };
      if (typeof code === "string") return code;
      current = cause;
    }
    return undefined;
  }
  ```

- 只处理明确 SQLSTATE：`23505`（unique violation）可转业务态或 `ConflictException`；`23503` 外键、`42501` 权限 / RLS 按业务语义失败；未知错误继续抛出，禁止吞成成功。
- 依赖约束 / 权限分支的写接口，至少验证正常写入 + 冲突 / 重复写入，确认不是 500 且无重复 / 部分写入。

### 写操作与批量读（CRITICAL）

- **PATCH/UPDATE 更新契约**：`PATCH` 和增量 `update` 接口只写入请求 DTO 中明确提供的可选字段，禁止用 `dto.field ?? 默认值`、空数组、空字符串等默认值覆盖未提供字段；用户明确清空时由 DTO 传入清空语义值（如空数组、空字符串或 `null`）并按业务规则写入。业务字段发生更新且接口/页面展示最后修改时间或最后修改人时，不能依赖 `DEFAULT CURRENT_TIMESTAMP` 等建表默认值刷新 UPDATE；必须在同一次 Drizzle update 的 `set(patch)` 调用中维护 `schema.ts` 暴露的更新时间和更新人字段，更新人从 `req.userContext.userId` 传入 service，禁止从前端传递。

  ```typescript
  const patch: Partial<typeof table.$inferInsert> = {};
  if (dto.title !== undefined) patch.title = dto.title;
  if (dto.labels !== undefined) patch.labels = JSON.stringify(dto.labels);
  if (Object.keys(patch).length === 0) throw new BadRequestException('未提供可更新字段');

  patch.updatedAt = new Date();
  patch.updatedBy = userId;

  const updated = await this.db.update(table)
    .set(patch)
    .where(eq(table.id, id))
    .returning({ id: table.id });
  if (updated.length === 0) throw new NotFoundException('记录不存在');
  ```

- **`Partial<$inferInsert>` 仅用于 update 的 `set()`**：insert 的 `.values()` 要求必填字段齐全，套 `Partial` 会把必填字段变可选、报缺属性错误；create 直接构造完整对象（类型用 `typeof table.$inferInsert`），禁止把上面的 patch 写法复制到 create

- **禁止 N+1 查询**：列表接口禁止在循环 / `Promise.all` 里逐条查子记录。先收集主记录 ids，用 `inArray` 一次查回，内存中按外键 `Map` 分组回填：

  ```typescript
  // ❌ N+1：每条 order 单独查 items
  for (const order of orders) {
    order.items = await this.db.select().from(items).where(eq(items.orderId, order.id));
  }
  // ✅ 批量查 + Map 分组
  const allItems: Item[] = await this.db.select().from(items)
    .where(inArray(items.orderId, orders.map((o: Order) => o.id)));
  const byOrder = new Map<string, Item[]>();
  for (const it of allItems) {
    byOrder.set(it.orderId, [...(byOrder.get(it.orderId) ?? []), it]);
  }
  ```

- **写操作必须校验生效行数**：update / delete 必须带 `.returning({ id })`，返回空数组 = 目标不存在或条件不满足 → 抛对应异常（见「异常处理」），禁止盲发 delete 后直接返回成功
- **禁止 SELECT→计算→UPDATE 写数值**：库存 / 余额 / 计数的增减必须用单条原子 UPDATE，把业务校验放进 WHERE。注意：仅用 `db.transaction` 包裹 SELECT+UPDATE **不能**防止并发超卖（两个事务可同时读到旧值），除非 SELECT 加 `FOR UPDATE` 行锁——优先用原子 UPDATE，简单且无锁等待：

  ```typescript
  // ❌ 竞态：先 select 库存，JS 里算完再 update（两请求并发会超卖）
  // ✅ 原子条件更新 + 生效行数校验（同时满足上一条规则）
  const updated = await this.db.update(products)
    .set({ stock: sql`${products.stock} - ${qty}` })
    .where(and(eq(products.id, id), gte(products.stock, qty)))
    .returning({ id: products.id });
  if (updated.length === 0) throw new ConflictException("库存不足或商品不存在");
  ```

- 原子 UPDATE 需要与其他写操作保持一致时（如同时写审批流水），把原子 UPDATE 放进 `db.transaction`，生效行数为 0 时抛异常令事务回滚

### 数据库使用强约束

- 优先通过 schema.ts 暴露的客户端和类型读写；**被迫手写 SQL 时 user_profile 列必须按上表三侧写法**，禁止临时 `::text` 转换或裸值比较
- **变更流程（CRITICAL）**：DDL 先加载数据库操作 skill（按「应用数据库 / 建表 / 改表 / SQL」召回），按其中的 SQL 执行通道执行（建表 / 改表规则、具体命令与必填参数一律以该 skill 为准，不要凭记忆拼命令，也不要裸连数据库）→ 系统自动 codegen → **立即重新读取 schema.ts** → 再编写业务代码。跳过重新读取直接编码是 TS2339 批量错误的主要根因
- 连接失败/SSL 错误：立即停机并提示用户联系技术支持

## API 规范

1. **必须遵循 JSON API 规范**：GET=读、POST=创建、PUT=全量更新、PATCH=部分更新、DELETE=删除
2. **路径前缀约定**：
   - `/api` — 内部业务接口（默认）：`@Controller('api/hello')`
   - `/openapi` — 对外开放接口（鉴权/用户身份规则不同，详见 `openapi-guide` skill）：`@Controller('openapi/hello')`
3. **路由设计最佳实践**：
   - 静态路由在前，动态路由在后（`/search` 必须在 `/:id` 之前）
   - 使用描述性路径如 `/meetings/detail/:id` 避免冲突
4. **前后端一致性**（CRITICAL）：
   - 前端 API 调用的 HTTP method 和 path **必须**与后端 Controller 装饰器完全匹配（`GET≠POST` → 405）
   - 后端 Service 返回值结构**必须**与 `shared/api.interface.ts` 中定义的响应类型完全匹配（禁止后端直接返回数组而 shared 定义为 `{items: T[]}`）
   - 编写前端 API 时必须先读取对应 Controller 确认 method 和路径
5. **路由注册验证**：创建新 Controller 后必须用接口测试工具验证路由是否生效。**遇到 404 排查路径**：① 检查 `@Controller(...)` 是否以 `api/` 或 `openapi/` 开头 ② 检查 Module 是否在 `app.module.ts` 注册 ③ 检查静态路由是否在动态路由 `/:id` 之前
6. **@Query/@Param 类型转换**：默认 string，必须在 controller 层手动转换（如 `parseInt(limit, 10)`）
7. **写接口鉴权**：POST/PUT/PATCH/DELETE 不一刀切。个人/后台/依赖当前用户的写入加 `@NeedLogin()`；未登录访客表单/报名/反馈可公开，但每张被写入的 RLS 表都要有 `FOR INSERT TO anon WITH CHECK (true)` 或等价 Drizzle `withCheck`，并用未登录 HTTP POST 验证。`FOR SELECT TO anon` 只读、`FOR INSERT TO authenticated` 只登录态；公开只读页的增删改仍按登录态处理。
   ```typescript
   import { NeedLogin } from "@lark-apaas/fullstack-nestjs-core";

   @NeedLogin()
   @Post()
   async createItem(@Req() req, @Body() dto) { ... }

   // 公开匿名写：不加 @NeedLogin()，DDL 需 anon INSERT WITH CHECK
   @Post("public-submit")
   async submitPublic(@Body() dto) { ... }
   ```
8. **OpenAPI 文档同步**：改动 `*.openapi.controller.ts` 或其引用的 interface / service 返回值 / schema 字段时，加载 `openapi-guide` skill，同步更新 `docs/openapi.json`
9. **服务端查用户信息（CRITICAL）**：先区分当前用户 `userId`、应用 `appId` 与人员 ID，再确认请求上下文是否已有非空 `appId`，最后选择查询能力和响应字段语义。仅有 `userId` 或给定人员 ID 都不能推导出 `appId`；只有已具备非空 `appId` 时才用 `AuthNPaasService.listUsersByIds`，并保留批量字段映射、平台错误与查无此人的区别。匿名入口无法证明该前置条件时，主体读取保持独立，返回已有稳定 ID，展示名 / 头像建模为可空或可选；明确要求匿名真实姓名但无受支持 `appId` 来源时报告能力阻塞。禁止凭空补身份头、裸调平台、持久化姓名副本、service 广域 `try/catch` 或固定“未知用户”降级。动手前加载 `contacts-service` skill 第六节

## 异常处理

| 分层 | 目标 |
|------|------|
| service | 抛业务异常，**必须用 NestJS 内置 HttpException 子类**（`@nestjs/common`），禁止裸 `throw new Error`（会被全局 Filter 兜成 500，前端拿不到语义状态码） |
| controller | 不处理异常，交全局 Error Filter |

场景 → 异常类型映射：

| 场景 | 异常 |
|------|------|
| 资源不存在（含 update / delete 未命中） | `NotFoundException` |
| 参数 / 状态非法 | `BadRequestException` |
| 并发冲突、库存 / 余额不足 | `ConflictException` |
| 无权限操作他人数据 | `ForbiddenException` |

## 当前用户信息

- **必须从 `req.userContext` 获取**，禁止从前端传递，禁止硬编码（`const { userId } = req.userContext`）
- 依赖用户信息的接口不要用 API 测试工具测试，用 `think` 工具思考
- 后端按 `user-identity` 和 `@lark-apaas/fullstack-nestjs-core` 的 Express `Request` 增强读取 `req.userContext`；`tenantId` 为可选 number，不能套用前端 `window.tenantId` / `viewContext` 字符串语义。
- Controller 直接用 `@Req() req: Request`；测试、mock 或业务窄类型用独立接口，只声明实际读取字段。不要继承 Express `Request` 或重声明 `userContext`；未读 `tenantId` 就省略，必须保留时用 `unknown` 或 SDK 兼容类型。

```typescript
// req.userContext 字段（由身份认证中间件挂载，完整合同见 user-identity）：
// - userId/appId: string
// - tenantId: SDK Request.userContext 的可选 number
// - env: 'preview' | 'runtime'  (preview=预览态, runtime=发布运行态)
// - userName/userNameEn: string
// - userNameI18n: string  (多语名字, 如 {zh_cn: '用户', en_us: 'user'})

@Post('articles')
async createArticle(@Req() req: Request, @Body() dto: CreateArticleDto) {
  const { userId } = req.userContext;
  return this.articleService.create({ ...dto, author: userId });
}
```

> 飞书 ID（`lark_user_id` / `open_id` / `union_id`）、查任意用户、`useCurrentUserProfile` 用法详见 `user-identity` skill。

## 插件能力（Plugin）

### 召回规则（强制执行）

当用户需求涉及以下关键词时，**必须查询相应 Skill 获取开发指南**：

| 关键词 | 对应能力 |
|-------|---------|
| 多维表格、飞书表格、Base、bitable | 飞书多维表格增删改查 |
| 飞书消息、发送通知、消息推送 | 发送飞书消息 |
| 飞书群、创建群组、群聊 | 创建飞书群组 |
| AI生文、AI写作、文本生成 | AI智能生文 |
| AI总结、文本摘要、内容提炼 | AI文本总结 |
| AI翻译、多语言翻译、语言互译 | AI智能翻译 |
| AI分类、文本分类、自动归类 | AI智能分类 |
| 文本转JSON、结构化提取、文本解析 | AI文本转JSON |
| AI生图、图片生成、智能配图 | AI智能生图 |
| 图生图、图片编辑、图片修改 | AI图片编辑 |
| 图片理解、图片识别、图片分析 | AI图片理解 |
| 图片转JSON、图片提取、图片结构化 | AI图片转JSON |
| 图片对比、图片比较、图片差异 | AI图片对比 |
| 抠图、去背景、去水印、去文字 | AI智能抠图 |
| 背景替换、换背景、背景合成 | AI背景替换 |
| 文档解析、PDF解析、文件提取 | AI文档解析 |
| 搜索总结、网页搜索、搜索摘要 | AI搜索总结 |
| 语音合成、文本转语音、TTS | AI语音合成 |
| 语音识别、音频转文字、STT | AI语音转文字 |
| 插件实例、PluginInstance、Capability | 通用插件调用 |

> ⚠️ **语义检索 / 相似推荐场景例外**：若需求是对**应用自有数据**做语义检索、向量检索、相似推荐、相关推荐、按内容找相似，**不要**用上表的「AI搜索总结 / AI文本转JSON / AI智能生文」等通用插件替代，必须召回 `/semantic-search`。上表的 AI 搜索/文本插件用于公网搜索、文本生成、结构化抽取，**不具备对自有数据库的向量检索能力**。

### 关键区分：多维表格 vs 数据库表

| 场景 | 判断 | 操作 |
|-----|------|-----|
| 明确提到"多维表格/飞书/Base/bitable" | 飞书平台外部服务 | 加载 `plugin-guide` skill |
| "建表/DDL/schema变更" | 应用内数据库结构 | 加载数据库操作 skill（按「应用数据库 / 建表 / 改表 / SQL」召回），按其执行通道操作 |
| "往XX表插入数据"（无明确来源） | 检查 `schema.ts` | 有定义→Drizzle ORM；无定义→询问用户确认 |

> 插件实例的复用/创建、`get_plugin_ai_json`、调用签名（`capabilityClient.load().call/callStream`）、配置完整性（`CapabilityNotFoundError`）、多维表格数据架构选择等**详细开发指南，见 `plugin-guide` skill**（按上表关键词召回）。

## 自动化任务

需要设计自动化任务配置与开发时，请调用文档工具召回自动化任务配置与代码编写文档

## 分页最佳实践

### 传统分页（后台管理表格、跳页场景）
- 1-indexed page，`@Max()` 限制 pageSize
- 响应含 items/total/page/pageSize，page 超出返回空数组
- 深分页性能差，大数据集考虑游标分页

### 游标分页（移动端/无限滚动，优先推荐）
- 使用「唯一 + 可排序」字段作为游标排序依据，默认 创建时间+id 降序
- cursor(首次空) + limit(默认12, @Max(50))
- 响应仅 items/nextCursor/hasMore，不返回 total
- **最后一页时 nextCursor 必须为 undefined**
- DESC 降序配 LessThan(游标)，ASC 升序配 GreaterThan(游标)

## 问题排查指引

1. 使用 API 测试工具测试不依赖用户信息的接口
2. 积极使用 `read_logs` 工具，如无有效日志可增加 logger 打印
3. API 测试返回 HTML 内容时：检查模块注册顺序、路由顺序、请求路径。禁止修改内置 ViewController。若路径含 `__runtime__`，那就是下一条——GET 未被代理时会落 SPA fallback 返回 index.html
4. 请求路径含 `__runtime__` 的 404（POST）或 200 + HTML（GET）：属沙箱 dev 环境限制，不是应用缺陷，见「沙箱 dev 不提供平台 runtime 接口」
5. 服务端启动即崩、`/api` 全部 502 且报 `UnknownDependenciesException ... argument Function at index [0]`：查构造函数有没有空参 `@Inject()`（见 plugin-guide），不要先去改 Module 的 imports / providers

---

# 前端开发指南

## 技术栈

- **框架**: React 19 + TypeScript
- **路由**: React Router DOM v6
- **样式**: tailwindcss（语义化 token）
- **UI 组件库**: shadcn/ui — Use components for functionality, heavily style them
- **图表**: ReactECharts，**开发前必须调用 `/charts-skill`**
- **图标**: Lucide React（唯一图标库，禁止 Emoji 和其他图标库）
- **表格/表单/图表**: 见下方"组件 Skill 召回规则"，开发前必须先调用对应 Skill
{% if projectMeta['flags']['supportBusinessUser'] %}
- **用户**: 用户信息展示/选择必须用 `business-ui` 组件（阅读 README.md），禁止直接展示 userId
{% endif %}
{% if projectMeta['flags']['supportTiptapAndStreamdown'] %}
- **富文本**: `business-ui/tiptap-editor`（阅读 README.md）
- **Markdown 渲染**: `components/ui/streamdown`（内置 prose 排版）
{% else %}
- **Markdown 渲染**: `components/ui/markdown`（react-markdown + remark-gfm，内置 prose 排版）
{% endif %}

## API 请求

**禁止** `fetch`，必须使用 `axiosForBackend`（不用会报 `Tenant not found`）：

```typescript
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
// ✅ axiosForBackend({ url: '/api/users', method: 'GET' })
// ✅ axiosForBackend.get('/api/users') / .post(...) 等实例方法（axiosForBackend 是 axios.create 返回的实例）
```

- **前后端联调**：编写前端 API 对接代码前**必须先读取后端接口定义**，禁止对后端接口请求进行兜底和过度封装
- **全栈项目禁止 mock 数据**：只要有服务端接口就当全栈对待，严禁 mock。纯前端项目（静态展示、无后端）可以使用 mock
- **提交前检查 mock 残留**：禁止硬编码用户 ID、项目 ID 等 mock 数据。提交前确认无 `"user_xxx"`、`"project_1"` 等占位值

## 日志与错误处理

- **日志**: 必须用 `logger` from `@lark-apaas/client-toolkit/logger`，**禁止所有 console 方法**
- **禁止静默处理异常**：显示明确错误信息，禁止掩盖问题
- **无内置多语言/深浅色切换**：如需要需自行实现

## 工程规范

- **glob 文件查找**：目录存在嵌套，glob 前端页面时必须使用 `client/src/pages/**`

## 官方内置组件

| 组件 | 来源 | 用途 |
|------|------|------|
| Table | `@lark-apaas/client-toolkit/antd-table` | 数据表格，**先调 `/table-skill`** |
{% if projectMeta['flags']['supportBusinessUser'] %}
| UserSelect/UserDisplay/UserProfile/DepartmentSelect | `business-ui/*` | 用户/部门选择展示 |
{% endif %}
{% if projectMeta['flags']['supportTiptapAndStreamdown'] %}
| TiptapEditorComplete | `business-ui/tiptap-editor` | 富文本编辑器 |
| Streamdown | `components/ui/streamdown` | Markdown/流式渲染 |
{% else %}
| Markdown | `components/ui/markdown` | Markdown 渲染（react-markdown + remark-gfm） |
{% endif %}

### 组件 Skill 召回规则（强制执行）

| 场景 | Skill | 说明 |
|------|-------|------|
| 表单、Form、Zod | `/forms-skill` | Shadcn Form + React Hook Form + Zod |
| 图表、Chart、ECharts | `/charts-skill` | shadcn/ui + ReactECharts |
| 表格、Table | `/table-skill` | antd-table |

禁止未调用 Skill 直接编写表单/图表/表格代码。

### 检索 Skill 召回规则（强制执行）

| 场景 | Skill | 说明 |
|------|-------|------|
| 语义检索、向量检索、相似推荐、相关推荐、相似内容、按内容找相似、猜你喜欢 | `/semantic-search` | 对应用自有数据库的数据做向量检索 / 相似召回 |

禁止未调用 Skill 直接用「AI搜索总结 / AI文本转JSON / AI智能生文」等通用插件实现对自有数据的语义检索。

### 组件使用规范

- 优先使用 `client/src/components` 下已有组件（Card/Button/Badge 等）
- 使用前查看 `ui/README.md` 或组件源码
- 禁止 Card 嵌套 Card
- shadcn props 值必须从实际联合类型中选取（如 Button variant），不确定时看源码
- 输入组件用 shadcn，**禁止原生 `<input>`/`<textarea>`/`<select>`/`input[type="date"]`**
- SelectItem 的 value 禁止空值，占位用 `<SelectValue placeholder="..." />`
- 版本锁定、按需导入、唯一图标库 lucide-react

## @lark-apaas/client-toolkit

**零假设原则**：绝不基于假设使用任何子模块。使用任何 `@lark-apaas/client-toolkit` 子模块前**必须**：① 查询 Skills 或 `steering_doc_search` → ② 等待响应获取文档 → ③ 严格按文档编码。**禁止直接调用 `@lark-apaas/client-toolkit` 任何函数/方法**（不基于查询到的文档）。该库是**前端/浏览器侧 SDK**，仅可在 `client/**`、React 组件、hooks、前端工具函数中使用；**禁止在 `server/**`、NestJS controller/service/module、Node.js runtime、migration、script 中 import 或调用**。

**服务端替代原则**：后端需要当前用户身份时用 `req.userContext`；需要飞书 user_id 转换时用 `AuthNPaasService`（见 `user-identity`）；没有明确 server-side API 时只保留/透传用户 ID，不要为了展示姓名头像在服务端引入前端 SDK。

| 功能 | 导入路径 |
|------|----------|
| 插件调用（Client） | `import { capabilityClient } from "@lark-apaas/client-toolkit"` |
| 日志 | `import { logger } from "@lark-apaas/client-toolkit/logger"` |
| 文件上传下载 | `import { getDataloom } from "@lark-apaas/client-toolkit/dataloom"` |
| 应用信息 | `import { useAppInfo } from "@lark-apaas/client-toolkit/hooks/useAppInfo"` |
| 当前用户 | `import { useCurrentUserProfile } from "@lark-apaas/client-toolkit/hooks/useCurrentUserProfile"` |
| URL 解析 | `import { resolveAppUrl } from "@lark-apaas/client-toolkit/utils/resolveAppUrl"` |
| 批量用户信息 | `import { UserService } from "@lark-apaas/client-toolkit/tools/services"` |

> 用户信息获取/展示（`useCurrentUserProfile`、`UserService.listUsersByIds`、`UserInfo` 字段、UserDisplay/UserProfile 组件）详见 `user-identity` / `client-builtins-user-service` skill；文件上传下载（`getDataloom`）详见 `client-builtins-file-storage-service` skill。飞书 ID（`lark_user_id` / `open_id` / `union_id`）一律见 `user-identity`。

## 样式开发

**设计规范遵从（最高优先级）**：必须严格遵循 `AGENTS.md` 中定义的设计规范，代码实现必须是对设计文档的精准还原，**严禁随意简化**。所有设计必须响应式。项目使用单套色彩系统，无需支持深色/浅色模式切换。

### 样式技术选型

```
需要写样式？
├─ 基础布局/间距/颜色/动画/伪元素 → Tailwind ✅
├─ 全局/复杂 CSS → index.css / tailwind-theme.css ✅
└─ JS动态计算值 → 行内 style ✅
```

### Tailwind 规范

- `justify-between/around/evenly` 必须配合 `space-x-*` 或 `gap`
- `justify-start/end` 的水平 flex 行应加 `flex-wrap`
- shadcn Button 不要显式控制 padding/height，用 sizes/variants API
- 颜色优先级：语义化 token（`bg-primary`）> 自定义 token > Tailwind 预设。禁止 `bg-[--primary]`（Tailwind 4 限制）
- **arbitrary values 中空格用下划线**：`from-[hsl(215_60%_18%)]` 非 `from-[hsl(215 60% 18%)]`
- `tailwind-theme.css` 自定义属性用 `hsl(H, S%, L%)` 格式（非 `23 10% 23%`）

### 布局/排版

- Spacing 保持一致（small/medium/large 三级），Panel 风格统一
- 文本溢出：用户输入/URL 用 `break-words`，标题用 `truncate`

## 页面与路由

- **新增页面流程**：判断是否需要隔离布局 → 创建 `pages/` 下组件 → `app.tsx` 配置路由 → 更新导航
- **数据获取**：页面级数据获取在页面组件顶层处理，通过 props 向下传递
- **禁止 React.lazy**：严禁异步加载路由组件
- **页面跳转**：必须用 `NavLink`/`Link`/`useNavigate`，**严禁 `window.location.href`**
- **分享链接/二维码**（CRITICAL）：应用部署后 URL 与本地路由不同，**必须**用 `resolveAppUrl` 转换：
  ```typescript
  import { resolveAppUrl } from '@lark-apaas/client-toolkit/utils/resolveAppUrl';
  const shareUrl = resolveAppUrl(`/detail/${id}`);     // ✅ 路由路径→完整 URL
  const fixedUrl = resolveAppUrl(`${origin}/detail/${id}`); // ✅ 自动修正
  resolveAppUrl('https://other-site.com/page');        // ✅ 外部链接原样返回
  // ❌ 严禁自行拼接：`${window.location.origin}/detail/${id}`
  ```
- **首页路由**：必须含指向 `/` 的 index 路由
- **路由唯一性**：每页一个唯一路由
- **导航**：NavLink + active 高亮，路径必须与 `app.tsx` 路由精确对应。全局 Layout 中使用 `useAppInfo`/`useCurrentUserProfile` 获取站点和用户信息
- **路由动态调整**：更新路由时检查现有路由表，及时将 index 路由指向最合适的页面
- **禁止混用页面跳转和页内锚点**

### 组件代码风格

- 箭头函数 + React.FC，Props 接口用 `组件名Props`
- 编写顺序：① Hook 声明 → ② useEffect → ③ 事件处理 → ④ JSX
- 导入顺序：React → 三方库 → 内置工具 → 相对路径
- 交互对话框用 Dialog 组件
- 弹窗禁止 `alert`/`confirm`/`prompt`

### 数据安全渲染

- **渲染前必须检查数据是否存在**
- **使用条件渲染处理 loading/error 状态**
- **为可能 undefined 的数据提供 fallback UI**

```jsx
if (loading) return <div>加载中...</div>;
if (!data) return <div>暂无数据</div>;
return <h1>{data?.title || '未知标题'}</h1>;
```

## 组件区块类型标记

为特定功能的顶层容器添加 `data-ai-section-type` 属性：

| 值 | 场景 |
|----|------|
| `card-stat` | 横向指标卡容器 |
| `card-list` | Card 组件的 flex 列表 |
| `button` | 任意 Button |
| `card-menu` | Card 组件的 grid 网格菜单 |

## 图片规范

- **展示**：必须用 `@client/src/components/ui/image` 组件（非原生 `<img>`），响应式设 `sizes`，固定宽设 `width`
{% if projectMeta['flags']['supportBusinessUser'] %}
- 用户头像用 business-ui 组件
{% endif %}

### 图片资源优先级

1. 用户上传图片（最高）
2. `generate_image`（主要方案）— 每个位置独立图片，禁止重复。提示词格式：`[主体] + [环境] + [风格] + [色彩] + [无文字说明]`
   - **必须包含**：「无文字、无字母、无符号」明确说明
   - **禁止出现**：① 使用场景（"适合移动端"）② 功能描述（"适合/用于/作为"）③ 目标用途（"品牌展示/课程封面"）④ 观众定位（"吸引年轻人"）⑤ 预期效果（"视觉冲击力/引人注目"）⑥ 媒介格式（"移动端/印刷品"）
3. 内置 Avatar（仅头像）— `@client/src/utils/img-resources/avatar-placeholders.ts`
4. Picsum（临时）— `https://picsum.photos/seed/${seed}/${w}/${h}`（必须带 seed）

### 静态资产引用（图片/视频/字体等同理）

应用部署在 `/app/<appId>/` 路径前缀下，组件内**禁止用根绝对路径**引用静态资产（如 `src="/x.svg"`、`src="/bg.mp4"`）——根绝对路径脱离前缀，预览与线上必 404。

- 用户上传的媒体要在页面展示 → 默认用上传返回或后端返回的 `download_url` / `downloadURL`；仅明确使用 `file_attachment` 类型字段时，才按 client-builtins-file-storage-service 用 `generateDownloadUrlFromFilePath` 从该字段的 `file_path` 换 URL。不要下载进 `public/` 再硬编码路径。
- 项目自带的静态资产 → 放 `client/src/assets/` 用 ES import（`import logoUrl from '@/assets/x.svg'`），构建管线自动带前缀；新增 `.svg`/`.mp4` 等类型须在 `client/src/types/global.d.ts` 补 `declare module` 声明。

### 排查资源 404

排查 HTTP 404 时**必须读响应体**（用 `curl` 而非 `curl -I`，HEAD 只返回头）——dev server 的 404 响应体通常已给出正确地址指引（如 did-you-mean 提示），据此一步纠偏，不要凭猜测改动。

## 核心功能依赖

| 类别 | 库 |
|------|-----|
| 动画 | Framer Motion, GSAP |
| 日期 | dayjs |
| 日期选择器 | shadcn Calendar + Popover（禁止 input[type="date"]） |
| 验证 | zod |
| 工具函数 | lodash |
| 样式 | clsx |
| 用户反馈 | sonner |


## 滚动分页最佳实践

- 使用 `useInfiniteQuery` 管理数据
- `IntersectionObserver` 实现自动加载（防抖 200ms）
- 调用 `fetchNextPage()` 前检查 `!isFetchingNextPage && hasNextPage`
- 底部状态：loading → 加载中；无更多 → "没有更多"；空 → 空状态

## 数据筛选器

- 用 shadcn 组件（Date Picker/Input），禁止原生 input
- 筛选项合理宽度分布
