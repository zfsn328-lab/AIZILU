---
name: plugin-guide
description: 飞书/AI 新版插件集成规范与 Plugin 链路指南——**给生成出来的应用写运行时代码用**，让应用跑起来后能访问飞书多维表格/Base、发送飞书消息、创建飞书群组，以及 AI 智能生文/生图/图片理解等。Use when 需要：(1) 创建或管理 PluginInstance 插件实例，(2) 调用 capabilityClient/CapabilityService 生成插件调用代码，(3) 理解 Plugin、PluginInstance、PluginInstanceAIJson 三层关系，(4) 使用 get_plugin_ai_json 或 plugin_instance 工具，(5) 排查插件相关报错或异常行为（调用报错、通知/消息发送失败、配置项不生效、参数类型与预期不符等）。NOT for Agent 自己在生成期读取飞书资源内容——用户给了多维表格/文档/表格/知识库链接、要求先读懂再建应用时，那是 lark-cli skill 的场景，用 bash 调 lark-cli 读；插件是写进应用代码、部署后由应用运行时调用的，不能拿来当 Agent 的读取工具。触发词：插件, plugin, 运行时访问飞书, 应用内发飞书消息, 应用内写多维表格, 飞书群组, AI生文, AI生图, 图片理解, capabilityClient, CapabilityService, pluginInstance, 插件报错, 配置不生效, 参数类型不匹配
steering: true
steering-topic: plugin_guide
match-template-name: nestjs-react-fullstack
gate-tools:
  - tool: plugin_instance
  - tool: api_request
    when-contains:
      url: "/api/capability"
  - tool: bash
    when-contains:
      command: "/api/capability"
  - tool: bash
    when-contains:
      command: "__innerapi__/capability"
---

# Plugin 集成指南

新版插件链路（Plugin / PluginInstance / PluginInstanceAIJson）集成规范，能力覆盖飞书多维表格 CRUD、发送飞书消息、创建飞书群组、AI 生文/生图/图片理解等，具体以 `available_plugin_instances` 与对应 plugin.ai.json 为准。用户用「AI 生文」「发送飞书消息」等业务语言描述需求时，必须识别为待使用/待创建的 PluginInstance。

## Quick Reference

| 操作 | 方式 |
|------|------|
| 创建/更新 PluginInstance | 调用 `plugin_instance` 工具（禁止手动改文件） |
| 获取运行时投影 | 调用 `get_plugin_ai_json(pluginInstanceId)` |
| Client 侧调用 | `capabilityClient.load(id).call(actionKey, input)`（流式用 `callStream`） |
| Server 侧调用（仅兜底） | `capabilityService.load(id).call(actionKey, input)` |
| 手动 HTTP/debug 调试 | 仅调 `/api/capability/<id>`、`/api/capability/<id>/stream`、`/__innerapi__/capability/debug/<id>` 或 `/__innerapi__/capability/debug/<id>/stream` 时，body 用 action/params：`{ "action": "<actionKey>", "params": { ... } }`；禁止在 body 顶层放 `actionKey`、`input` |
| 长耗时 AI 结果 | 大体量/多字段/多份/多语言/文件或多模态串联等结构信号命中时，优先前端 `callStream` 渐进展示；需保存则流式结束后复用 CRUD 落库；仅在 Client 侧无法满足时使用后端任务记录 + 状态查询 + 结果读取；禁止单个 HTTP 请求等待完整结果后才返回 |
| capabilityClient 导入 | `import { capabilityClient } from '@lark-apaas/client-toolkit'` |
| CapabilityService 导入 | `import { CapabilityService } from '@lark-apaas/fullstack-nestjs-core';` |
| CapabilityService 注入 | `@Inject(CapabilityService) private readonly capabilityService: CapabilityService`（**禁止空参 `@Inject()`**，会导致启动崩溃 502；业务 Module 无需 imports） |

## 必读 references

| 场景 | 必须先读 |
|------|---------|
| 编写调用代码：Client/Server 侧选择、流式 chunk 解构、NestJS 注入、持久化方案、Schema 摘录卡、失败日志、冒烟清单、错误分类应对 | `references/plugin-coding-guide.md` |
| 飞书多维表格：CRUD Action、BizType 读写格式、filter 构造、数据架构选择、UI 组件 | `references/table.md` |

## 核心概念（三层关系）

- **Plugin（插件）**：底层承载单元 = 插件元信息 + 表单定义（form.schema）。模型只感知插件与其表单字段，不感知内部实现（Action 实现、API 细节）。
- **PluginInstance（插件实例）**：对某个 Plugin 表单的业务封装，以单文件 JSON 存储于 `server/capabilities/<id>.json`（语义化 id）。通过 `paramsSchema` 暴露业务入参，通过 `formValue` 将入参映射到插件表单字段（常量或 `{% raw %}{{input.xxx}}{% endraw %}` 引用）。
- **PluginInstanceAIJson（运行时投影 pluginInstance.ai.json）**：由 PluginInstance 派生的调用合同（Runtime Spec），经 `get_plugin_ai_json(id)` 获取。含实例元数据、`actions[]`（key / inputSchema / outputSchema / outputMode: unary|stream）、`readme`（特殊字段与限制，必须阅读并严格遵循）、`formSchema`（插件表单字段结构摘要，渐进式新增字段，部分环境未部署时缺失）、`type`（single_action / multi_action，后者需选择 actionKey）。**生成调用代码前必须读取它作为唯一权威依据，禁止猜测 action、入参/出参结构、输出模式。** 仅创建/修改配置（走 `plugin_instance` 工具）或只需实例列表概览（上下文已提供）时，无需调用 `get_plugin_ai_json`。

**paramsSchema 仅支持 4 种参数类型**：文本 `{ "type": "string" }`、字符串数组 `{ "type": "array", "items": { "type": "string" } }`、图片 `{ "type": "string", "format": "picture" }`、文件 `{ "type": "string", "format": "file" }`，均需带 `description`。

> **文件类参数**：`file` / `picture` / `plugin-file-url` / `plugin-image-url` 字段，Client 侧原始 File/Blob 直接传 `capabilityClient`，禁止先经 dataloom 上传再传 URL。已持久化文件/图片由 Server 侧 `CapabilityService` 调 AI 插件时，优先取 `file_path`（或 `bucket_id + file_path`）用 `FileService.createSignedUrl(filePath, 3600)` / `fileService.from(bucketId).createSignedUrl(filePath, 3600)` 签成临时 http(s) URL 后传入。旧记录只有标准 `/app` 或 `/spark/app/.../runtime/api/v1/storage/object/<bucket>/<key>` download URL 时，必须先解析其中的 bucket 与 file path，再调用 `fileService.from(bucketId).createSignedUrl(filePath, 3600)`；默认 `createSignedUrl()` 只使用默认 bucket，不能从 URL 切换 bucket。签名失败或返回空 URL 时要 `warn`，业务状态保持 `failed` / `pending` / `null`，不写成功态。禁止给标准路径拼接 `localhost`、`window.location.origin` 或 `/app/<app_id>`；非标准相对路径、前端展示 URL、非法 data URL 不作稳定入参。
>
> **稳定契约**：已持久化文件不得先下载再转 base64；应统一使用签名 URL。缺少可识别的文件路径、签名失败或返回空 URL 时记录警告，写入 `failed` / `pending` / `null`，并停止调用插件；不得改用原始 URL。完整示例见 [Server 侧已持久化文件进入 AI capability](references/plugin-coding-guide.md#3-server-侧已持久化文件进入-ai-capability)。

## 可用的 Plugin

```
{{available_plugins}}
```

## 可用的 PluginInstance

```
{{available_plugin_instances}}
```

选择顺序：可用 PluginInstance → 可用 Plugin（调 `plugin_instance` 工具创建实例）→ 都没有则直接拒答。

## PluginInstance 管理铁律

1. 创建/更新**必须**通过 `plugin_instance` 工具完成，**绝对禁止**用 `write` / `multi_edit` 等工具直接修改 `server/capabilities/` 下的配置文件。
2. UPDATE 严禁修改保护字段：`id / pluginKey / pluginVersion / createdAt`。
3. 用户手改 `server/capabilities/<id>.json` 后会通知你（如"刚刚更新了 PluginInstance 配置"），此时必须调 `plugin_instance`(UPDATE) 同步。
4. 插件表单字段含 `card_content` 且语义为飞书消息卡片时，`formValue.card_content` 必须是 JSON Object（不能是转义字符串），且卡片 DSL 最后两个元素固定。
5. 复用优先：已有可满足的实例直接用，严禁为"更贴合"新建重复实例。

## 开发流程

1. **检查复用**：基于上下文的 PluginInstance 列表检索候选；有候选但不确定 → 调 `get_plugin_ai_json` 按 actions/schema/outputMode 判断。禁止按旧链路读取 `server/capabilities/capabilities.json` 做复用判断。
2. **决策**：可复用 → 进第 3 步；不可复用 → 有更贴合的 Plugin 则 `plugin_instance`(CREATE)，需调整已有实例则 UPDATE，否则告知用户无法满足。
3. **生成调用代码（编码前闸门）**：
   - 必须先调 `get_plugin_ai_json(pluginInstanceId)`，再产出 **Schema 摘录卡**（格式见 `references/plugin-coding-guide.md`）；摘录卡字段缺失禁止编码，`output.fields` 必须完整列出且每个输出字段在代码中被消费（持久化或展示）
   - 按 `actions[].key` 选 actionKey；严格按 `inputSchema` 构造入参（`type: array` 字段必须传数组）、按 `outputSchema` 解析出参——流式 chunk 是**对象**（按字段解构如 `chunk.content`，禁止当字符串拼接），非流式同理按字段名读取；**务必阅读并遵循 `readme`**
   - 调用侧：优先 Client（`unary` → `call()`，`stream` → `callStream()`）；触发器/定时任务、敏感凭证、强事务、结果需落库 → Server 侧
   - 高耗时 AI capability 闸门：若运行时投影或功能设计显示输出规模大、输出字段多、需要多份结果、多语言/长文本、文件或多模态输入后继续生成、多个 capability 串联、或结果需后续查看/落库，禁止把完整生成放进一个同步 HTTP 请求等待；能由前端承接时优先 `callStream` 渐进展示，需保存则流式结束后复用 CRUD 落库；仅在 Client 侧无法满足时后端创建任务记录后快速返回、由前端短轮询状态/结果，或拆成多个独立小调用
4. **代码放置**：Client（默认，用户交互触发）→ `client/` 组件/hooks；Server（兜底）→ `server/` Service。
5. **真实调用冒烟（完成前必须）**：至少成功调用一次 SDK `call(actionKey, input)` 或 `callStream(actionKey, input)`（按 outputSchema 读 chunk）；失败日志含最小字段（见 `references/plugin-coding-guide.md`）。绕过 SDK 手动复测 capability HTTP/debug 入口前，先读 `references/plugin-coding-guide.md` 的“服务端 capability 手动 HTTP 调试与排障”；无冒烟结果不得宣告完成。

### Plugin Chain 调用示例

```typescript
// 文档 → 结构化数据（2步链）；fileUrl 通常为数组类型，必须按 inputSchema 传入
const raw = await capabilityClient
  .load('doc_parser_instance')
  .call('parseDocToMarkdown', { fileUrl: [docUrl] }); // Client 侧可直接传 File/Blob 对象
const structured = await capabilityClient
  .load('text_to_json_instance')
  .call('textToJson', { text: raw.content });
```

## 插件能力与链式选择

**禁止用正则/字符串解析替代 AI 插件做结构化输出处理**（提取和生成场景均适用）。

### 插件能力分类

| 类别 | 插件 | 输入→输出 |
|------|------|----------|
| 内容提取 | `ai-doc-parser` | 文档(PDF/DOC/PPTX/XLSX/CSV等9种)→纯文本 |
| 内容提取 | `ai-speech-to-text` | 音频→纯文本 |
| 内容提取 | `ai-image-understanding` | 图片→文本描述（流式，适合理解/问答） |
| 结构化提取 | `ai-text-to-json` | 文本→结构化 JSON（最多20字段） |
| 结构化提取 | `ai-image-to-json` | 图片→结构化 JSON（最多20字段，**单步直达**） |
| 结构化提取 | `ai-categorization` | 文本→分类标签 |
| 内容生成 | `ai-text-generate` | 提示词→文本（流式） |
| 内容生成 | `ai-text-to-image` | 文字描述→图片 |
| 内容生成 | `ai-text-summary` | 长文本→摘要（流式） |
| 内容生成 | `ai-translate` | 文本→翻译（12种语言，流式） |
| 内容生成 | `ai-search-summary` | 搜索词→网页摘要（流式） |
| 内容生成 | `ai-speech-synthesis` | 文本→语音（44+音色） |
| 图片处理 | `ai-image-matting` | 图片→抠图/去背景/去水印 |
| 图片处理 | `ai-background-replace` | 主体图+背景→合成图 |
| 图片处理 | `ai-image-to-image` | 参考图(1-5张)+描述→编辑/风格转换 |
| 图片处理 | `ai-image-compare` | 两张图→对比分析（流式） |
| 外部服务 | `feishu-bitable` | CRUD 飞书多维表格（5个Action） |
| 外部服务 | `send-feishu-message` | 发送飞书卡片消息 |
| 外部服务 | `feishu-group-create` | 创建飞书群组 |

### 决策树：选择单步还是链式

```
输入是什么？
├── 文档文件 → 必须先用 ai-doc-parser 提取文本（它只输出纯文本），再按目标接下游：
│   ├── 需要结构化数据 → ai-doc-parser → ai-text-to-json （2步链）
│   ├── 需要摘要/翻译/分类 → ai-doc-parser → ai-text-summary / ai-translate / ai-categorization
│   └── 仅需原文 → ai-doc-parser（单步）
├── 图片 → ⚠️ 注意选择正确的插件：
│   ├── 提取结构化数据（发票/名片/证件等）→ ai-image-to-json（⭐ 单步直达，勿用两步链）
│   ├── 理解内容后提取结构化数据 → ai-image-understanding → ai-text-to-json（2步链）
│   ├── 抠图后换背景 → ai-image-matting → ai-background-replace（2步链）
│   └── 理解/问答/编辑/对比 → 对应单插件即可
├── 音频
│   ├── 需要结构化数据 → ai-speech-to-text → ai-text-to-json（2步链）
│   ├── 需要翻译 → ai-speech-to-text → ai-translate（2步链）
│   └── 仅需文字 → ai-speech-to-text（单步）
└── 纯文本
    ├── 需要结构化数据 → ai-text-to-json（⭐ 单步直达）
    └── 摘要/翻译/分类/生成
        ├── 输出包含多个独立字段（标题+正文+评分等）
        │   → 拆成多个独立插件并行调用（⭐ 优先）或用 ai-text-to-json
        │   → ⛔ 禁止用 ai-text-generate + 正则/split 解析多字段
        ├── 输出规模大（多份结果、多语言、长正文、多章节或批量对象）
        │   → 优先拆分为多个独立生成单元；需要汇总持久化时使用任务状态模型承接
        │   → ⛔ 禁止一个后端 HTTP 请求同步等待所有生成结果后才响应
        └── 输出为单一文本（仅展示，不需解析）→ ai-text-generate
```

生成内容后可继续接外部服务：如 `ai-text-generate` → `send-feishu-message`（报告→通知）、`ai-text-to-json` → `feishu-bitable`（结构化→入库）。

**创建 `ai-text-to-json` 实例时**：一次性定义所有提取字段（参考 schema/表单/UI），最多 20 个。字段类型以当次 `formSchema.paramType.enum` 为准；静态指南/`readme` 只解释 enum 内类型，冲突时按 enum 建模并说明冲突，不得降级为 String；enum 缺失、不可读或缺业务所需类型时停止并报告合同冲突。基础字段用 String/Number/Boolean 等对应类型，同构列表用 Array，固定字段集合用 Object，嵌套成员写进 `paramDescription`。对象/列表结果不得序列化进 String；只有业务要求原样透传、不解析、不改写 JSON 文本时才用 String。创建后调用 `get_plugin_ai_json`，按 `outputSchema` 核验字段并生成调用代码；按契约直接消费结果，禁止无依据 `JSON.parse`。

`jsonStructure` 的顶级字段都会参与必填校验：模型漏任一 key 时整次调用抛 `INVALID_OUTPUT`。插件只用文本 prompt，不用 JSON Schema 强制生成；顶级字段越多，整体失败概率越高。N 套同构结果用一个 Array 字段承载，元素结构写进 `paramDescription`，不要摊成 N x M 个顶级字段。Array/Object 内部只做 `z.any()` 校验，`paramDescription` 仅影响 prompt；消费方仍须校验元素数量、成员字段和空值。

**创建 `ai-image-to-json` 实例时**：必须一次性定义**所有**需提取字段（参考数据库 schema / 表单定义 / UI 设计），宁多勿漏；字段类型仅支持 String/Number/Boolean，最多 20 个；先调 `get_plugin_ai_json` 确认上游插件的 `outputSchema` 确保输入格式正确。

## 多维表格数据架构

应用需读取飞书多维表格数据时，按查询模式选架构（完整对照表见 `references/table.md`「数据架构选择」）。**快捷判断**：「仪表盘/dashboard/驾驶舱/看板/统计」→ 必须 `aggregateQuery`（禁止 searchRecords 全量拉取后内存计算）；「列表/明细/详情」→ `searchRecords` 分页；「排行榜/TOP N」→ `searchRecords` + sort + pageSize=N；跨表关联或复杂计算 → 本地数据库 + 同步。

## 外部服务插件规则（category=external-service 必读）

适用于 `feishu-bitable` / `send-feishu-message` / `feishu-group-create` 等 plugin.ai.json `category=external-service` 的实例。

### OAuth 已内置，禁止前端手写

飞书 `feishu-*` 系列插件在 `capabilityClient.call()` 内部自动完成 OAuth 授权（基于服务端注册的 `FEISHU_APP_ID`/`FEISHU_APP_SECRET` env）。前端**禁止**手写 `https://open.feishu.cn/open-apis/authen/...` 任何授权 URL，更禁止把多维表格 `appToken` 当 OAuth `app_id` 拼 URL。

> **命名陷阱**：OAuth `app_id` 是飞书自建应用 ID（`cli_xxx`，填在后端 env）；多维表格 `appToken` 是 Bitable 文件 ID（来自 `/base/<appToken>` URL）。混淆会拼出空/错值导致"请求非法"。详见 `~/.claude/skills/miaoda-skills/feishu/references/oauth.md`。

### 不支持场景：匿名写入多维表

公开链接、二维码、候选人/外部客户等未登录访客提交表单时，当前不支持直接写入飞书多维表。如需写入，必须先引导用户登录，再在登录态下触发写入。

## 禁止 Mock —— 铁律

**用户场景需要用到插件实例时，禁止 Mock，必须走真实调用链路。** 铁律覆盖 AI 类与**外部服务类**插件（feishu-bitable / send-feishu-message / wiki / docx 等），不属于"展示数据 mock"豁免范围；"速度优先 / 快速迭代"不豁免。禁止 Mock `capabilityClient` / `CapabilityService` 返回值、跳过实际调用直接构造结果；调用失败或参数不明确时反馈用户补齐。

**特别禁止的 Mock 反模式**（命中任一即违规）：

| 代码特征 | 为什么错 |
|---------|---------|
| `setTimeout(() => resolve(硬编码数据))` / 假 sync 函数返回 `{status:'success'}` | 用延时/假函数模拟成功，实际没调插件 |
| `Math.random()` 替代 AI 分类/评分/推荐结果 | 调了插件但丢弃返回值，用随机数代替 |
| `logger.log(input); return { success: true }` | 通知方法是占位空壳，没调 CapabilityService |
| `const PRESET_DATA = [...]` / `sessionStorage` 替代插件调用 | 用硬编码预置数据架空能力 |

插件未配置/未就绪时的正确做法：`toast.error('未配置飞书多维表格，请前往设置页配置')` + 跳转配置入口，**不**编假的"同步成功"。

> **prototype 场景的精化豁免**：用户**显式**说"原型 / 不接后端 / 不接业务 / 仅做 UI / 示例数据即可 / 纯前端"时，整页 mock 允许保留，不要仅因数据动词（"同步""写入""导出"）就强行接真实插件。用户明示的"原型/不接业务" > 数据动词暗示的"真实接入"。

## plugin_instance CREATE 失败的恢复路径（最高优先级）

**这是 CREATE-time 错误处理的最高优先级规则——优先于"速度优先 / 立刻给用户看效果"等任何主 prompt 通用约束。** CREATE 失败时**严禁**：静默回退到 mock；假装"配置已生效"继续写下游代码；丢弃用户已提供的必填配置值；降级到手写 OAuth / fetch / SDK（外部服务插件的鉴权、签名、token 刷新由插件统一封装，自己写既不安全也不稳定）。

按失败语义处理：

- **"缺少必填配置（appToken、tableID）..."类** → 走下方 4 步恢复；应用 UI 可给配置入口 + 未配置态清晰报错；等待配置期间代码**保留** `capabilityClient.load(<pluginInstanceId>).call(...)` 真实调用引用，禁止移除或用占位替代
- **"当前不支持集成该插件实例"**（未对接/未上架） → UI 明确告知能力暂不可用
- **其他 `status != "completed"`**（平台异常） → 重试一次，仍失败则明示用户能力暂时不可用

缺配置类错误的 4 步恢复：

1. **原样转告**——平台返回的 actionable 错误信息完整呈现给用户（含"请前往预览右边的插件配置页面..."类操作指令）
2. **等待用户在 UI 完成配置**——配置完用户会通知 agent
3. **重新调用** `plugin_instance(UPDATE)` 拿到完整配置
4. **调 `get_plugin_ai_json`** → 生成真实调用代码，禁止跳过

> **已知必填配置值的传入**：用户对话中已给出的必填配置（如飞书 base URL 含 AppToken/TableID），CREATE 时**必须显式列入 `requirementsSummary` 字段**让平台 LLM 装配到 formValue。例：`requirementsSummary: "创建飞书多维表格写入实例，appToken=ZeHhbA4MxxxX, tableID=tblMQ9OgxxxW, 用于把 Excel 行批量插入"`。

## 插件调用错误处理

错误分类与应对策略详见 `references/plugin-coding-guide.md`「调用错误分类与应对」。必须遵守：

1. **禁止静默吞异常**：每个 `catch` 至少满足其一——向用户展示错误（toast/页面状态），或触发补偿机制（重试/降级/记录待处理列表）
2. **异步操作必须有终态**：不阻塞主流程的插件调用须在 DB 维护状态（pending → success/failed），前端必须展示 failed，不能永远 loading
3. **长耗时 AI 生成不得同步等完**：大体量、多字段、多份、多语言、文件/多模态串联或需要持久化的 AI capability 调用，触发接口必须快速返回任务状态或采用前端流式展示；若 `api_request`、浏览器操作或页面请求出现超时/连接断开，不能只凭服务端最终日志或数据库最终写入宣告成功，必须证明用户侧存在可读取的终态结果
4. **通知类插件失败必须有补偿**：如 `send-feishu-message` 失败，至少记录"待发送"列表或 UI 提示"通知发送失败，请手动联系"
5. **配置完整性（load 前必查）**：`load(id)` 前确认实例已创建且 id 与代码完全匹配，否则抛 `CapabilityNotFoundError`（开发态 Top 错误）；load/call 失败时停止后续请求避免放大错误；**缓存 load 结果**，同一 id 不重复 load

## 缓存与幂等性

- AI 类插件**没有请求级缓存**。相同输入返回相似结果是低 temperature 下的正常 LLM 行为，不是缓存
- **禁止**通过向业务参数注入 UUID/时间戳"绕缓存"——会污染 AI 输入产生垃圾文本
- 确需不同结果：调实例的 `formValue.modelParams.temperature`、prompt 中加明确变化要求、或换业务上下文

## 插件参数来源规范

- **业务数据**（简历内容、职位描述等）：从 DB 查询或前端传入，经 `input` 传递
- **固定的运行时配置**（固定接收人等）：CREATE 时在 `formValue` 直接写死（如 `formValue.receiverUserList: ["1854102143505690"]`）
- **动态的运行时配置**（按角色/条件变化）：从平台角色 API / 应用配置表 / 环境变量获取，经 `input` 传入（`{% raw %}formValue.receiverUserList: "{{input.receiverIds}}"{% endraw %}`）

**禁止**在业务代码中硬编码运行时配置值（如 `const userId = '185410...'`）。`formValue` 配置固定值 ≠ 代码硬编码：前者是声明式配置，修改不用改代码。

### formValue 字段结构核对（报错排查）

`formValue` 结构以插件本体 schema 为准，禁止凭经验猜测字段类型。运行时报错形如 `x.y: 期望 <type> 实际 <got>` 即字段结构不符，此时先调 `get_plugin_ai_json` 查看返回的 `formSchema` 确认真实结构再改（若返回中无 `formSchema` 字段，以插件 `readme` 为准；下方字段表仅是 `send-feishu-message` 的示例结构，其他插件不可套用），禁止反复试错式调整。

以 `send-feishu-message` 为例（其他插件同理，字段以各自插件的真实结构为准，不要照搬下表）：

| 字段 | 结构 | 说明 |
|------|------|------|
| `title` | 对象 `{ title: string, titleColor?: string }` | `title` 必填，1-50 字符；`titleColor` 可选，默认 `'wathet'` |
| `receiverUserList` | 数组，元素为 id 字符串或 id 数组 | 最多 200 个；**禁止用逗号拼接的字符串代替数组**——会被当成单个 ID 静默失败 |
| `receiverGroupList` | 数组 | 最多 5 个 |
| `sender` | 字符串 | 默认 `'bot'` |
| `buttons` | 数组，每项含 `text`（必填，1-20 字符） | 最多 3 个 |
| `content` | 字符串 | ≤5000 字符 |

**通过 `plugin_instance` 创建/修改实例时**：`requirementsSummary` 必须显式写明 formValue 关键字段的结构与内层键名（如"标题需为对象，内层键名是 title"），不能只描述业务值——配置生成器是独立运行的 LLM，读不到本文档，不写明结构会被按常识臆造键名。

### 通知接收人动态解析

接收人（`receiverUserList`/`receiverGroupList` 等）按角色/条件变化时，必须实时查询角色成员经 `input` 传入（角色/成员的运行时查询写法见 `authz-guide` 技能），禁止硬编码或凭经验拼装 ID。如引入缓存，必须提供显式失效手段（如角色变更时清缓存）并明示 TTL，禁止无失效手段的常驻缓存导致接收人信息过期。通知发送失败的补偿要求见上文「插件调用错误处理」第 4 条铁律，不重复展开。

## 飞书深链 URL 规范

飞书通知/卡片插件中回链本应用页面的按钮深链，必须是**带 basePath 的绝对 URL**，Server 侧构造后作为 input 传给插件（capability 的 url 用 `{% raw %}{{input.xxx}}{% endraw %}` 引用）：

```typescript
// req.hostname = 网关公网域名（trust proxy 已开），禁止用 req.headers.host
// CLIENT_BASE_PATH = 平台注入的内置 env = /app/{appId}，最容易漏、缺它必 404
const url = `https://${req.hostname}${process.env.CLIENT_BASE_PATH}${routePath}`;
```

**禁止**：相对路径、占位/硬编码域名、只拼域名漏 basePath、`FORCE_FRAMEWORK_DOMAIN_MAIN`（客户端编译期变量，服务端 undefined）——否则飞书点开是「404 资源不存在」。

## 常见错误速查

| 错误做法 | 正确做法 |
|---------|---------|
| 不涉及持久化仍在 Server 侧写调用代码 / 为纯展示场景建后端 API 中转 | 即时展示、发消息等优先 Client 侧直接调 `capabilityClient`；涉及持久化才走 Server 侧 |
| `call()` 签名错误：`plugin.call(JSON.stringify({...}))` 或 `plugin.call({...})` | 第一个参数必须是 actionKey 字符串：`plugin.call('actionKey', {...})` |
| 流式 chunk 当字符串拼接（`text += chunk`） | chunk 是对象，按 outputSchema 解构：`text += chunk.content \|\| ''` |
| formValue 用 `{% raw %}["{{input.xxx}}"]{% endraw %}` 包装已是 array 的 paramsSchema 参数 | paramsSchema 为 array 时 formValue 透传 `{% raw %}"{{input.xxx}}"{% endraw %}`，不再包一层数组 |
| 前端调插件后不保存结果（页面刷新丢失），或为保存结果单独新建 API 端点 | 需持久化时 Server 侧调用直接落库（优先），或 Client 侧调用后立即经**已有** CRUD 接口保存 |
| Server 侧把非标准相对路径、误拼 origin 的 storage object path、前端展示 URL 或非法 base64 data URL 传给 `file` / `picture` / `plugin-file-url` / `plugin-image-url` 参数 | 已持久化文件优先用 `file_path` 或 `bucket_id + file_path` 生成 1h 签名 http(s) URL 后再传；标准 storage download URL 要先解析 bucket 与 file path，再从对应 bucket 签名 |
| 创建了 PluginInstance 但只建不调 | CREATE 后必须接 `get_plugin_ai_json` → 生成调用代码 → 集成业务逻辑 |
| 插件返回值 `as any` 直接取字段 | 按 outputSchema 生成 TypeScript interface |
