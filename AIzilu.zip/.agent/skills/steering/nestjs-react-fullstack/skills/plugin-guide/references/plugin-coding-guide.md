## PluginInstance 代码编写指南

### 核心原则：根据场景选择调用侧

**默认优先在 Client 侧调用 capabilityClient；流式或高耗时 AI 生成优先 `callStream` 渐进展示。结果需要持久化时，优先在流式结束后通过已有后端接口保存；只有 Client 侧无法满足时才切到 Server 侧。**

**高耗时 AI capability 先判调用形态**：只要输出规模大、输出字段多、需要多份结果、多语言/长文本、文件或多模态输入后继续生成、多个 capability 串联、或结果需后续查看/落库，就不得把完整 AI 结果塞进一个同步 HTTP 请求等待。能由前端承接时，优先用前端 `callStream` 渐进展示，并在流式结束后按需复用已有 CRUD 接口保存结果；只有 Client 侧无法满足（触发器/敏感凭证/强事务/必须由后端保证落库一致性等）时，才采用后端任务记录 + 状态/结果查询，避免把后台任务作为默认方案。

**严禁** import ｛ capabilityClient ｝ from '@lark-apaas/client-capability'。
**唯一指定**的导入方式是 import { capabilityClient } from '@lark-apaas/client-toolkit';

| 优先级 | 场景 | 调用方式 |
|-------|------|---------|
| **首选** | 绝大多数即时展示场景 | `capabilityClient.load(id).call()` |
| **首选** | 流式输出，或高耗时但可由前端承接的 AI 生成 | `capabilityClient.load(id).callStream()`（流式结束后按需持久化） |
| **必要时** | 高耗时且 Client 侧无法满足：触发器、敏感凭证、强事务、必须由后端保证落库一致性 | 后端任务记录 + 后台调用 `CapabilityService.load(id).call()` + 前端短轮询状态/结果 |
| **兜底** | Client 侧无法满足且单次调用可在交互边界内完成 | `CapabilityService.load(id).call()` |

#### 什么情况下应使用 Server 侧？

以下场景适合在 Server 侧调用：

1. **涉及敏感凭证**：调用需要服务端私密 token/secret，不适合暴露给前端
2. **必须后端编排**：多个插件调用之间有强事务依赖，需要后端统一编排
3. **触发器/定时任务场景**：没有前端上下文，只能由后端发起
4. **插件结果需要持久化**：调用结果需要保存到数据库；能由前端承接时，优先前端 `callStream` 渐进展示并在结束后复用已有 CRUD 接口保存；只有 Client 侧无法满足或必须由后端保证落库一致性时，才在 Server 侧调用并落库。若此时输出规模大、字段多、结果多份或需多步能力串联，必须改为任务记录 + 后台执行 + 状态/结果查询，避免一个 HTTP 请求等待完整生成

> **提示**：如果插件结果不需要存储、仅用于即时展示（如流式生成文本、发送消息），优先在前端调用。但当结果需要保存到数据库时，不要回避使用 Server 侧。

---

### 插件结果持久化决策

#### 何时必须持久化（强制规则）

以下任一条件成立时，插件结果**必须**保存到数据库，不能只存在前端 state 中：

1. **结果会在其他页面展示**：如列表页展示 AI 摘要、详情页展示分类标签
2. **结果供后续功能消费**：如 AI 分析结果用于生成报表、AI 分类结果用于筛选过滤
3. **用户再次访问时需要看到结果**：如刷新页面后结果不应消失
4. **结果对应数据库中已有字段**：如表中有 `summary`、`tags`、`analysis_result` 等 AI 产出字段

仅当插件结果**纯粹用于一次性即时展示**（如聊天式对话、临时预览）时，才可以不持久化。

#### 持久化方案选择

```
插件结果是否需要持久化到数据库？
├── 否（一次性即时展示）
│   ├── `outputMode=stream` 或内容生成较慢 → Client 侧 `callStream()` 渐进展示
│   └── 单次短输出 → Client 侧 `call()`（默认）
└── 是
    ├── `outputMode=stream` 且前端可承接 → 推荐方案 A：Client 侧 `callStream()` 渐进展示，成功后通过已有 CRUD 接口保存结果
    ├── 输出较小且可在交互边界内完成、且必须由后端保证一致性 → Server 侧调用并在同一方法中落库
    └── Client 侧无法满足且输出规模大/多字段/多份/多语言/多步骤 → 方案 B：Server 侧创建任务记录，快速返回任务状态；后台调用插件并落库；前端短轮询状态/结果
```

| 应避免的做法 | 推荐做法 |
|------------|---------|
| 前端调用插件后不保存结果，导致数据丢失 | 插件调用成功后及时持久化 |
| 为保存插件结果单独新建 API（如 `PATCH /api/xxx/ai-analysis`） | 优先复用已有的 create/update 接口，扩展字段即可 |
| 仅在前端 state 中暂存插件结果，不写入数据库 | 通过后端接口保存到数据库 |

---

### Client 侧调用方式（默认首选）

#### 1. 调用前获取权威依据
在为某个插件实例生成调用代码前，必须先通过 `get_plugin_ai_json` 工具获取该插件实例的运行时投影（plugin_Instance.ai.json），并以其中信息为准：
- `actions[].key`：调用时要传的 `actionKey`
- `actions[].inputSchema / outputSchema`：入参/出参结构
- `actions[].outputMode`：`unary | stream`（决定调用与结果处理方式）

**编码前闸门（必须）**：先产出 Schema 摘录卡，再开始代码编辑。

```markdown
[Schema 摘录卡]
- pluginInstanceId / actionKey / outputMode
- input.required: [字段名: 类型, ...]
- output.fields: [字段名: 类型, ...]（每个字段必须在代码中被消费，未消费需注释说明原因）
- readme.constraints
- 调用侧决策: Client | Server
```

若摘录卡字段缺失，不得进入实现阶段。

#### call / callStream 函数签名

```typescript
// 前端 capabilityClient（@lark-apaas/client-toolkit，实际类型来自 @lark-apaas/client-capability）
.call<T = unknown>(actionKey: string, params?: Record<string, unknown>): Promise<T>              // 非流式
.callStream<T = unknown>(actionKey: string, params?: Record<string, unknown>): AsyncIterable<T>  // 流式
```

- **第一个参数 `actionKey`**：必须是字符串，值来自 `get_plugin_ai_json` 返回的 `actions[].key`（如 `'sendFeishuMessage'`、`'textGenerate'`）
- **第二个参数 `params`**：类型是 `Record<string, unknown>`，结构符合 `actions[].inputSchema`
- 上面是**前端**签名，带泛型。**服务端 `CapabilityService` 的 `call` / `callStream` / `callStreamWithEvents` 都没有泛型**，两者不通用，详见「Server 侧调用方式」

> **`Record<string, unknown>` 不接 `interface` 声明的对象**（interface 没有隐式索引签名），直接传会撞
> `Argument of type 'XxxInput' is not assignable to parameter of type 'Record<string, unknown>'. Index signature for type 'string' is missing in type 'XxxInput'.`
> 三种正确写法：① 直接传内联对象字面量；② 入参类型用 `type XxxInput = { ... }` 而非 `interface`（type 别名有隐式索引签名）；③ 已有 interface 时在调用点显式 `input as unknown as Record<string, unknown>`。**不要为此改用 `as any`。**

```typescript
// ❌ 错误：把参数 JSON.stringify 后当作 actionKey
plugin.call(JSON.stringify({ meeting_title: '...' }));
// ❌ 错误：漏掉 actionKey，直接传参数对象
plugin.call({ meeting_title: '...' });

// ✅ 正确：第一个参数是 actionKey 字符串，第二个参数是 input 对象
plugin.call('send_feishu_message', { meeting_title: '...' });
```

#### 2. 非流式调用（outputMode = "unary"）

```typescript
import { capabilityClient } from '@lark-apaas/client-toolkit';
import { logger } from "@lark-apaas/client-toolkit/logger";

const result = await capabilityClient
  .load('create_feishu_group')
  .call('createGroup', {
    group_name: '项目讨论群',
    members: ['user_001', 'user_002'],
  });

logger.info(result);
```

#### 3. 流式调用（outputMode = "stream"）

##### 流式 chunk 字段速查表（必须遵守）

capabilityClient `callStream` 返回的每个 chunk 是**扁平对象**，字段名与 `outputSchema` 一致。**禁止使用 `chunk.data?.text`、`chunk.choices[0]`、`chunk.message` 等非 capabilityClient 格式。**

| 插件 | chunk 字段 | 正确写法 | 错误写法 |
|------|-----------|---------|---------|
| ai-text-generate | `content` | `chunk.content` | ~~`chunk.data?.text`~~ |
| ai-translate | `translation` | `chunk.translation` | ~~`chunk.content`~~ ~~`chunk.text`~~ |
| ai-text-summary | `summary` | `chunk.summary` | ~~`chunk.content`~~ ~~`chunk.data?.text`~~ |
| ai-image-understanding | `content` | `chunk.content` | ~~`chunk.data?.text`~~ |
| ai-search-summary | `content` | `chunk.content` | ~~`chunk.data?.text`~~ |

> **⚠️ 同一应用多个页面调用同一插件时，所有页面必须使用一致的 chunk 字段名。** 常见错误：PageA 正确用 `chunk.content`，PageB 错误用 `chunk.data?.text`。parallel_write 并发生成多页面时尤其注意。

##### 必须处理返回形态差异（重点）

`callStream()` 可能返回 `AsyncIterable<chunk>` 或 `{ output: AsyncIterable<chunk> }`，必须先归一化。

```typescript
type AnyRecord = Record<string, unknown>;

function isAsyncIterable(value: unknown): value is AsyncIterable<AnyRecord> {
  return !!value && typeof (value as AnyRecord)[Symbol.asyncIterator] === 'function';
}

function normalizeStream(resultOrStream: unknown): AsyncIterable<AnyRecord> {
  if (isAsyncIterable(resultOrStream)) {
    return resultOrStream;
  }
  if (
    resultOrStream &&
    typeof resultOrStream === 'object' &&
    'output' in (resultOrStream as AnyRecord) &&
    isAsyncIterable((resultOrStream as AnyRecord).output)
  ) {
    return (resultOrStream as AnyRecord).output as AsyncIterable<AnyRecord>;
  }
  throw new Error('Invalid callStream result: cannot find AsyncIterable stream');
}

function readFirstStringField(
  chunk: AnyRecord,
  keys: string[],
): string {
  for (const key of keys) {
    const value = chunk[key];
    if (typeof value === 'string') {
      return value;
    }
  }
  return '';
}
```

##### 场景判断与推荐方案

| 场景 | 特征 | 推荐度 |
|-----|------|-------|
| **多插件并行流式** | 多个插件各返回单一输出，并行调用 |  **优先推荐** |
| **单插件 JSON 流式解析** | 单插件返回结构化 JSON，需边接收边解析 | ⚠️ 仅在必要时 |

**核心原则**：在插件设计阶段按「原子化拆解」拆分，避免单插件返回多字段 JSON。

#####  推荐：多插件并行流式

适用于需求涉及多种输出（标题、正文、图片等），各输出相对独立。

```tsx
import { logger } from "@lark-apaas/client-toolkit/logger";

function MultiPluginStreamExample({ recordId }: { recordId: string }) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [coverUrl, setCoverUrl] = useState('');

  const handleGenerate = async (keywords: string) => {
    // 1. 封面图（非流式，异步不阻塞）
    capabilityClient
      .load('cover_generator')
      .call<{ images: string[] }>('textToImage', { keywords })
      .then(res => res?.images?.[0] && setCoverUrl(res.images[0]))
      .catch(err => logger.warn('封面生成失败', err));

    // 2. 标题（非流式）
    const titleResult = await capabilityClient
      .load('title_generator')
      .call<{ content: string }>('textGenerate', { keywords });
    const generatedTitle = titleResult?.content || '';
    setTitle(generatedTitle);

    // 3. 正文（流式，边生成边展示）
    const streamResult = capabilityClient
      .load('content_generator')
      .callStream<{ content: string }>('textGenerate', { keywords });
    const contentStream = normalizeStream(streamResult);

    // 🎯 按 outputSchema 字段提取，禁止把 chunk 当字符串
    let fullContent = '';
    for await (const chunk of contentStream) {
      const delta = readFirstStringField(
        chunk as Record<string, unknown>,
        ['content'], // 必须来自 get_plugin_ai_json.actions[].outputSchema
      );
      if (delta) {
        fullContent += delta;
        setContent(fullContent);
      }
    }

    // 4. ⚠️ 流式完成后，必须将结果持久化到数据库
    //    复用已有 CRUD 接口，不要单独建 API
    await updateRecord(recordId, {
      title: generatedTitle,
      content: fullContent,
      coverUrl,
    });
  };

  return (/* 各字段独立渲染 */);
}
```

> **⚠️ 前端流式调用的持久化义务**：前端 `callStream` 完成后，如果结果需要持久化（参见上方"何时必须持久化"），**必须在流式结束后调用已有的后端 CRUD 接口保存结果**。仅存在 `useState` 中的数据会在页面刷新后丢失。

**优点**：代码简洁、各插件独立、某个失败不影响其他。

##### ⚠️ 兜底：单插件 JSON 流式解析

当无法拆分为多插件时，需处理不完整 JSON 的逐字符到达，需实现 `parseStreamingStringField` 和 `extractJsonObject` 工具函数。**强烈建议在插件设计阶段拆分为多插件并行流式调用，避免此场景。**

---

### 失败日志最小集（必须）

失败日志至少包含以下字段：

```typescript
{
  pluginInstanceId: string,
  actionKey: string,
  outputMode: 'unary' | 'stream',
  inputKeys: string[],
  resultType?: string,
  resultKeys?: string[],
  firstChunkKeys?: string[],
  error: string
}
```

### 改后冒烟验证清单（必须）

完成调用代码后，最少执行并记录：

1. 一个 `unary` action 的真实调用结果（字段按 `outputSchema` 读取）
2. 一个 `stream` action 的真实调用结果（chunk 按 `outputSchema` 字段读取）
3. 调用失败时的最小日志字段齐全
4. 若无法执行真实调用，必须明确写明阻塞原因，禁止直接标记“开发完成”
5. 若用户触发 AI 生成的请求超时、连接断开或工具返回超时，必须判定为验收失败；只有触发请求快速返回、随后能通过页面或接口读到明确完成或失败终态和结果，才允许标记通过

### 服务端 capability 手动 HTTP 调试与排障

仅绕过 SDK 做请求级复测或排障时使用本节，应用业务代码仍调用 SDK：Client 侧 `capabilityClient.load(id).call(actionKey, input)` / `callStream(actionKey, input)`；Server 侧兜底 `capabilityService.load(id).call(actionKey, input)`。

#### 1. 手动 HTTP/debug body 合同

调试入口与 body：

| 场景 | URL | body |
|------|-----|------|
| 运行态 unary | `POST /api/capability/<capabilityId>` | `{ "action": "<actionKey>", "params": { ... } }` |
| 运行态 stream | `POST /api/capability/<capabilityId>/stream` | `{ "action": "<actionKey>", "params": { ... } }` |
| 内部 debug unary | `POST /__innerapi__/capability/debug/<capabilityId>` | `{ "action": "<actionKey>", "params": { ... } }`，可按调试需要附带 `capability` |
| 内部 debug stream | `POST /__innerapi__/capability/debug/<capabilityId>/stream` | `{ "action": "<actionKey>", "params": { ... } }`，可按调试需要附带 `capability` |

- `action` 仍来自 `get_plugin_ai_json(...).actions[].key`；`params` 仍按 `actions[].inputSchema`。
- HTTP body 用 action/params；禁止写成 `{ "actionKey": "...", "input": { ... } }`。
- `Action 'undefined' not found` 先查 HTTP body 顶层字段：确认 body 顶层有 `action`，且插件输入放在 `params` 下；再查 action 名称是否存在。

#### 2. 先读 server 日志再归因

插件调用失败时，先读 `server` 日志，记录同一次请求的 `path`、`action`、`input`、`pluginName`、`actionName`、`status_code`、`detail.code`、`logID`。只看前端报错或只说“应检查日志”不算完成排障。

按日志分层：

| 日志信号 | 归因 |
|----------|------|
| `path` 命中 capability HTTP/debug 入口，`action` 为空或缺失，错误类似 `Action 'undefined' not found` | 协议错误：手动 HTTP body 没按 action/params 写 |
| `action` 正确，但 `input` 缺必填字段、类型不符或数组/文件格式错误 | 参数错误：按 `inputSchema` 修正 `params` |
| `pluginName` / `actionName` 已命中，`detail.code` 或下游日志指向插件服务、模型、TOS、限流等 | 插件后端错误：保留 `logID` 和下游错误码，避免改应用代码掩盖 |
| capability 调用成功，但应用接口、持久化、状态流转或 UI 读取失败 | 应用代码错误：排查业务接口、数据库和前端状态，不改插件合同 |

手动 HTTP/debug 复测只用于确认请求级合同和日志归因；最终实现仍回到 SDK 调用或既定 Server 侧编排。

### Server 侧调用方式（仅兜底场景）

> 以下场景适合使用 Server 侧调用；若前端 `callStream` + 既有 CRUD 保存即可满足展示和持久化，不要优先引入后端后台任务。

#### 1. 何时适合用 Server 侧？

| 场景 | 原因 | 示例 |
|------|------|------|
| 触发器/Webhook | 无前端上下文 | 数据变更时自动发送通知 |
| 定时任务 | 无前端上下文 | 每日定时生成报告 |
| 敏感凭证调用 | 凭证不能暴露给前端 | 调用需要 admin token 的 API |
| 强事务编排 | 多步骤需要原子性 | 创建记录 → 发通知 → 更新状态必须全成功或全回滚 |
| 插件结果需持久化 | 调用结果需保存到数据库 | AI 分类/摘要结果需落库、文档解析的结构化数据需入库、图片识别结果需关联业务记录、语音转文字结果需存档等 |
| 高耗时 AI 生成需后续查看 | 请求不能长期占用用户交互链路 | 批量、多版本、多语言、长文本、多字段结构化生成，或文件/多模态分析后再生成内容 |

#### 2. NestJS 注入方式

```typescript
import { Injectable, Inject, Logger } from '@nestjs/common';
import { CapabilityService } from '@lark-apaas/fullstack-nestjs-core';

@Injectable()
export class XxxService {
  private readonly logger = new Logger(XxxService.name);

  // 注入 token 必须显式写成 @Inject(CapabilityService)
  constructor(
    @Inject(CapabilityService) private readonly capabilityService: CapabilityService,
  ) {}
}
```

**禁止空参 `@Inject()`**。本 stack 的 `nest-cli.json` 用 `builder: swc`，空参 `@Inject()` 会把注入 token 置为 undefined，Nest 回退读 `design:type` 拿到 `Function`，服务端启动即崩溃、所有 `/api` 请求返回 502：

```
UnknownDependenciesException: Nest can't resolve dependencies of the XxxService (?).
Please make sure that the argument Function at index [0] is available in the XxxModule context.
```

见到这段报错先查构造函数有没有空参 `@Inject()`，不要去改 Module 的 `imports` / `providers`。

**业务 Module 不需要注册 CapabilityModule**。`PlatformModule` 是 `@Global()` 且已把 `CapabilityModule` 放进 `exports`，`CapabilityService` 全局可注入。不要在业务 Module 里写 `imports: [CapabilityModule.forRoot(...)]` 或 `imports: [PlatformModule.forRoot()]`。

同一规则适用于从 `@lark-apaas/fullstack-nestjs-core` 注入的其他平台服务（`AuthNPaasService`、`FileService` 等）。

#### 3. Server 侧已持久化文件进入 AI capability

Client 侧拿到用户刚选择的原始 `File` / `Blob` 时，直接传 `capabilityClient`，不要为了调用插件先上传到应用存储。文件/图片已作为业务数据持久化，且必须由 Server 侧 `CapabilityService` 调 `ai-doc-parser`、`ai-image-understanding` 或其它 `file` / `picture` / `plugin-file-url` / `plugin-image-url` 参数时，才在服务端把存储路径换成临时 http(s) URL 后传入插件。

优先从业务记录读取存储 `file_path`；字段类型是 `file_attachment` 时，同时读取 `bucket_id` 与 `file_path`。旧记录只有标准 `/app` 或 `/spark/app/.../runtime/api/v1/storage/object/<bucket>/<key>` download URL 时，可以解析出 bucket 与 file path 后再签名；不能把它直接交给默认 `createSignedUrl()`，因为该入口只使用默认 bucket，不会使用 URL 里的 bucket。签名 URL 才能交给 AI plugin。禁止给标准路径拼接 `localhost`、`window.location.origin` 或 `/app/<app_id>`，否则会绕过内部路径解析并被当成不安全的外部 URL。非标准相对路径、前端展示 URL、非法 base64 data URL 不应作为 Server 侧插件稳定入参。

```typescript
import { FileService } from '@lark-apaas/fullstack-nestjs-core';

type StoredFileRef = {
  file_path?: string | null;
  bucket_id?: string | null;
  download_url?: string | null;
};

const STORAGE_DOWNLOAD_URL_RE =
  /^\/(?:spark\/)?app\/app_[\w]+\/runtime\/api\/v1\/storage\/object\/([^/]+)\/(.+)$/;

function parseStorageDownloadUrl(
  downloadUrl: string,
): { bucketId: string; filePath: string } | null {
  const match = STORAGE_DOWNLOAD_URL_RE.exec(downloadUrl);
  if (!match) return null;

  try {
    const bucketId = decodeURIComponent(match[1]);
    const filePath = decodeURIComponent(match[2]);
    return bucketId && !bucketId.includes('/') && filePath
      ? { bucketId, filePath }
      : null;
  } catch {
    return null;
  }
}

async function createTemporaryFileUrl(
  fileService: FileService,
  file: StoredFileRef,
): Promise<string | null> {
  try {
    let signedUrl: string;
    if (file.file_path) {
      signedUrl = file.bucket_id
        ? await fileService
          .from(file.bucket_id)
          .createSignedUrl(file.file_path, 3600)
        : await fileService.createSignedUrl(file.file_path, 3600);
    } else {
      const parsed = file.download_url
        ? parseStorageDownloadUrl(file.download_url)
        : null;
      if (!parsed) return null;
      signedUrl = await fileService
        .from(parsed.bucketId)
        .createSignedUrl(parsed.filePath, 3600);
    }
    return signedUrl || null;
  } catch (error) {
    // 这里不要返回伪成功 URL；由调用方把业务状态置为 failed/pending/null 等可见状态
    return null;
  }
}
```

调用 AI 插件前先签名并校验 URL：

```typescript
const docParserPluginInstanceId = '<doc-parser-plugin-instance-id>';
const signedUrl = await createTemporaryFileUrl(this.fileService, storedFile);
if (!signedUrl) {
  this.logger.warn('missing file path or create signed url failed before AI capability call', {
    filePath: storedFile.file_path,
    bucketId: storedFile.bucket_id,
    hasDownloadUrl: Boolean(storedFile.download_url),
    pluginInstanceId: docParserPluginInstanceId,
    actionKey: 'parseDocToMarkdown',
  });
  await this.updateRecord(recordId, { parseStatus: 'failed', parsedText: null });
  return;
}

const output = await this.capabilityService
  .load(docParserPluginInstanceId)
  .call('parseDocToMarkdown', {
    fileUrl: [signedUrl], // 是否数组必须以 inputSchema 为准
  });
```

稳定契约：已持久化文件统一使用签名函数返回的 URL，不要先下载后转 base64，也不要把原始 URL 作为备用值传给插件。缺少可识别的文件路径、签名失败或返回空 URL 时记录警告，写入 `failed` / `pending` / `null`，并停止调用插件。

#### 4. 调用示例

服务端 `CapabilityExecutor` 的**三个方法全都没有泛型参数**（`@lark-apaas/nestjs-capability`）：

```typescript
call(actionName: string, input: unknown, context?: Partial<PluginActionContext>): Promise<unknown>;
callStream(actionName: string, input: unknown, context?): AsyncIterable<unknown>;
callStreamWithEvents(actionName: string, input: unknown, context?): AsyncIterable<StreamEvent<unknown>>;
```

写 `.call<T>(...)` / `.callStream<T>(...)` / `.callStreamWithEvents<T>(...)` 都会报「应有 0 个类型参数，但获得 1 个」。泛型只存在于前端 `capabilityClient`。注意服务端 `input` 是**必传**（没有 `?`），且类型是 `unknown` 而非前端的 `Record<string, unknown>`。服务端接 `unknown` 后在运行时收窄，禁止 `as any`：

```typescript
const inputParams = {
  // 严格按 get_plugin_ai_json.actions[].inputSchema 构造
};

try {
  const output: unknown = await this.capabilityService
    .load('')
    .call('', inputParams);
  // 运行时收窄后再取字段，例如：
  // if (typeof output === 'object' && output !== null && 'content' in output) { ... }
  return output;
} catch (error) {
  this.logger.error('pluginInstance call failed', {
    pluginInstanceId: '',
    actionKey: '',
    error: error instanceof Error ? error.message : 'Unknown error',
  });
  throw error;
}
```

#### 5. Server 侧编排与容错原则

- PluginInstance 调用在 Server 侧通常属于 **外部依赖 / side-effect**
- 除非业务明确要求强一致性，**默认不应阻塞主业务流程**
- 已选择 Server 侧承接的高耗时 AI capability 必须有可观测状态：创建任务时记录处理进度、完成终态、失败终态、输入摘要、错误信息和结果引用；触发接口只返回任务标识与当前状态，前端通过短轮询读取进度和最终结果
- 文件/图片签名 URL 生成失败时必须 `warn` 并把业务记录保持在 `failed` / `pending` / `null` 等用户可见状态，禁止构造假 URL 或写入“解析成功”

推荐写法：异步触发 + catch 兜底：

```typescript
this.somePluginInstanceSideEffect(input).catch(error => {
  this.logger.warn('PluginInstance side-effect failed, ignored', {
    error: error instanceof Error ? error.message : 'Unknown error'
  });
});
```

---

### 调用错误分类与应对

| 错误类型 | 含义 | 应对策略 |
|----------|------|---------|
| `InputValidationError` | 入参不符合 schema | 修复参数后重试，不应出现在生产环境 |
| `RateLimitError` | 触发限流 | 指数退避重试（1s/2s/4s），最多 3 次 |
| `ExecutionError` | 插件执行失败 | 记录日志 + 降级方案（如规则计算）+ 通知用户 |
| `OutputValidationError` | 返回值不符合 schema | 记录异常返回 + 使用默认值或降级 |
| 网络超时 | 请求超时 | 重试 + 超时后降级 |

---

### outputMode 与调用侧选择

先通过 `get_plugin_ai_json(pluginInstanceId)` 获取 `actions[].outputMode`：

| outputMode | 推荐调用侧 | 调用方式 |
|------------|-----------|---------|
| `unary` | **Client 侧优先** | `capabilityClient.load(id).call(actionKey, input)` |
| `stream` | **Client 侧优先** | `capabilityClient.load(id).callStream(actionKey, input)` |
| 任意（兜底场景） | Server 侧 | `capabilityService.load(id).call(actionKey, input)` |

**选择原则**：
- 不涉及持久化时，优先在 Client 侧直接调用
- `outputMode = stream` 时，Client 侧使用 `callStream` 做渐进式渲染
- 涉及持久化、触发器、敏感凭证、事务编排等场景时，使用 Server 侧

---
