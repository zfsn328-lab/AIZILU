---
name: connections-sdk
description: "用于 Miaoda fullstack app 的 NestJS 服务端代码读取用户在妙搭开发态配置的三方集成凭证（代码概念：Miaoda Connection；读取参数：connectionName），并通过 @lark-apaas/miaoda-connections-sdk、ConnectionsService 或 MiaodaConnectionsModule 使用。不要用于前端代码、非妙搭凭证配置、妙搭自身数据库/密钥配置或创建凭证配置。触发词：妙搭凭证, 三方集成凭证, Connection 凭证, 凭证 ID, connectionName, ConnectionsService, MiaodaConnectionsModule, @lark-apaas/miaoda-connections-sdk"
steering: true
steering-topic: connections_sdk
match-template-name: nestjs-react-fullstack
---

# Miaoda Connections SDK

在 NestJS 服务端代码中使用 `@lark-apaas/miaoda-connections-sdk` 读取妙搭凭证。

## 妙搭凭证是什么

妙搭凭证是用户在妙搭开发态为三方系统配置的授权或认证资源。产品概念里也会叫三方集成凭证、凭证 ID 或 SDK 消费 key；代码里对应 `Miaoda Connection` / `Connection`，业务代码通过 `connectionName` 读取运行态凭证值。

概念和代码标识对照：

| 中文概念 | 英文/代码标识 | 说明 |
|----------|---------------|------|
| 妙搭凭证、三方集成凭证 | `Miaoda Connection` / `Connection` | 用户在妙搭开发态配置并托管的三方系统凭证资源 |
| 凭证 ID、凭证名、SDK 消费 key | `connectionName` | 业务代码读取凭证时传入的名称 |
| 运行态凭证值 | `connection.value` / `ConnectionValue` | SDK 返回的类型化凭证数据 |
| 原始认证输入 | `authInput` | 创建凭证时的认证输入配置；可能包含敏感字段 |
| 自定义凭证数据 | `authData` | `custom` 或未知类型里的运行态字段 |

SDK 支持读取这些三方认证类型：

| 三方认证类型 | `connection.value.type` | 说明 |
|--------------|-------------------------|------|
| OAuth2 三方授权 | `oauth2` | 三方系统的 OAuth token，例如 OAuth Code 或 Client Credentials 建立后的访问凭证 |
| 三方接口密钥 | `api_key` | 三方 API 的 API Key 值；请求头名或 query 参数名来自三方 API 文档或 `authInput` 配置 |
| HTTP Bearer Token | `bearer_token` | 三方 HTTP API 的 Bearer token |
| Basic Auth | `basic` | 三方系统的用户名和密码 |
| 外部关系型数据库凭证 | `rdb` | 外部数据库的连接凭证，不是妙搭应用自身默认数据库 |
| 自定义或未知类型 | `custom` | SDK 未内置识别的类型会归到 `custom`，业务按实际字段读取 `authData` |

妙搭凭证不是：

- 妙搭应用自身的数据表或默认数据库连接。
- 需要写入 `.env` 的环境变量配置。
- 业务代码里临时声明的 token、api key、password。
- Authentication、ConnectionPolicy 或授权流程本身。

## 使用边界

| 场景 | 做法 |
|------|------|
| 服务端调用三方 API 或外部数据库，凭证来自用户已配置的妙搭凭证 | 使用本 SDK |
| 前端页面需要调用三方 API | 通过后端接口转发，前端不得读取妙搭凭证 |
| 用户还没创建妙搭凭证 | 提醒用户先在妙搭开发态配置凭证 |
| 需要创建 Authentication 或授权流程 | 不在业务代码里实现，交给妙搭开发态配置能力 |
| 只是配置妙搭应用自己的数据库、环境变量或专家模式密钥 | 不使用本 SDK |

禁止把 access token、bearer token、api key、password 写入 `.env`、源码、日志或聊天回复。

## 服务端接入

在应用模块中注册 `MiaodaConnectionsModule`，然后在业务 Service 中注入 `ConnectionsService` 使用。

```typescript
import { Injectable, Module } from '@nestjs/common';
import {
  ConnectionsService,
  MiaodaConnectionsModule,
} from '@lark-apaas/miaoda-connections-sdk';

@Module({
  imports: [MiaodaConnectionsModule.forRoot()],
})
export class AppModule {}

@Injectable()
export class GithubService {
  constructor(private readonly connections: ConnectionsService) {}
}
```

## 获取妙搭凭证

使用用户在妙搭开发态配置好的凭证 ID / 凭证名作为 `connectionName`。不要在代码中创建或修改凭证配置。

```typescript
const connection = await this.connections.getConnection({
  connectionName: 'github-main',
});

if (connection.state !== 'connected') {
  throw new Error(`Connection github-main requires ${connection.recoveryHint}`);
}
```

必须先判断 `connection.state === 'connected'`，再读取 `connection.value`。

## 按凭证类型处理

不要假设所有妙搭凭证都是 OAuth2。必须按 `connection.value.type` 分支处理。SDK 内置识别 `oauth2`、`api_key`、`bearer_token`、`basic`、`rdb`、`custom`；服务端新增但 SDK 尚未内置的类型会归一化为 `custom`。所有类型都有 `authInput`，表示原始认证输入；只能按业务需要读取，不要写入日志或错误信息。

### OAuth2 三方授权

```typescript
if (connection.value.type !== 'oauth2') {
  throw new Error('github-main must use oauth2 connection');
}

const response = await fetch('https://api.github.com/user/repos', {
  headers: {
    Authorization: `Bearer ${connection.value.accessToken}`,
  },
});
```

### 三方接口密钥

```typescript
if (connection.value.type !== 'api_key') {
  throw new Error('service-main must use api_key connection');
}

const response = await fetch('https://api.example.com/resources', {
  headers: {
    'x-api-key': connection.value.apiKey,
  },
});
```

`api_key` 只保证返回三方接口密钥值 `apiKey`。header 名、query 参数名等组装方式来自三方 API 文档或业务约定；如后端在 `authInput` 中透传了相关配置，也要先按具体字段断言后再使用。这里的三方接口密钥不是妙搭应用自身的环境变量、专家模式密钥或平台访问密钥。

### HTTP Bearer Token

```typescript
if (connection.value.type !== 'bearer_token') {
  throw new Error('partner-main must use bearer_token connection');
}

const response = await fetch('https://partner.example.com/resources', {
  headers: {
    Authorization: `Bearer ${connection.value.token}`,
  },
});
```

### Basic Auth

```typescript
if (connection.value.type !== 'basic') {
  throw new Error('erp-basic must use basic connection');
}

const authorization = Buffer.from(
  `${connection.value.userID}:${connection.value.password}`
).toString('base64');

const response = await fetch('https://erp.example.com/orders', {
  headers: {
    Authorization: `Basic ${authorization}`,
  },
});
```

### 外部关系型数据库凭证

```typescript
if (connection.value.type !== 'rdb') {
  throw new Error('sales-db must use rdb connection');
}

const config = {
  host: connection.value.host,
  port: connection.value.port,
  database: connection.value.database,
  user: connection.value.username,
  password: connection.value.password,
};
```

RDB 表示外部关系型数据库的连接凭证，不是妙搭应用自身默认数据库连接。RDB 的 `advanced` 用于特殊数据库类型的额外连接参数，例如 Oracle 的 `serviceName` 和驱动侧识别用的 `driverType`。Oracle SID 复用已有 `database` 字段，不要额外读取或生成 `advanced.sid`。

### Custom / 未知类型

```typescript
if (connection.value.type === 'custom') {
  const authData = connection.value.authData as {
    server: string;
    username: string;
    password: string;
  };

  return createMailClient(authData);
}
```

当服务端返回 SDK 尚不认识的 `ConnectionValue.type` 时，SDK 会把它归类为 `custom`：`authData` 保留原始 value 中除 `type` 和 `authInput` 外的运行态字段，`authInput` 保留在顶层。生成代码时可以基于 `authData` 的实际字段分支，但不要在日志或错误里输出 `authData` 或 `authInput` 明文。

## 不要做的事

- 不要在前端代码里调用 Connections SDK。
- 不要让用户把 token、api key、password 填到 `.env`。
- 不要在日志或错误里输出明文凭证值、authInput 或 authData。
- 不要手写平台内部 API 的鉴权 header。
- 不要在业务代码里直接请求平台内部接口或手写 SDK transport。
- 首版不要传 `user` 参数；等 end user policy 支持后再扩展用户态 Connection 示例。
