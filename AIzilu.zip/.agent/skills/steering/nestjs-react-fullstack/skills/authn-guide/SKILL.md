---
name: authn-guide
description: "Use when implementing authentication features: @NeedLogin decorator (AuthN is opt-in, public interfaces need no decorator), AuthNPaasGuard flow, or handling 401 errors. 触发词：认证, authn, 身份验证, 登录检查, NeedLogin, Public, 公开接口, AuthNPaasGuard, x-login-url, 401, 未授权"
steering: true
steering-topic: authn_guide
match-template-name: nestjs-react-fullstack
---

# 身份认证（AuthN）编码指南

本 skill 专注于**接口认证**：装饰器、守卫流程、401 处理。

**用户身份**（`req.userContext` 字段定义、`useCurrentUserProfile`、`AuthNPaasService`、`lark_user_id`、妙搭 ↔ 飞书 ID 转换）请使用 [`user-identity`](../user-identity/SKILL.md) skill。本文也会在认证流程里出现 `req.userContext`，那是守卫语义，**字段含义**仍以 user-identity 为准。

## 一、功能决策树

```text
用户需求
    │
    ├─ 需要标记某些接口必须登录才能访问？
    │   └─ 是 ──→ 使用 @NeedLogin() 装饰器（第二节）
    │
    ├─ 需要让某些接口公开访问？
    │   └─ 不需要任何装饰器 ──→ AuthNPaasGuard 默认放行未标 @NeedLogin() 的接口
    │       （`@Public()` 是历史遗留 no-op，不要使用，详见第二节）
    │
    ├─ 公开接口会写入应用数据库吗？
    │   ├─ 是，且允许未登录提交 ──→ 接口保持公开；目标 RLS 表补 `FOR INSERT TO anon WITH CHECK (true)`，未登录 POST 验证
    │   │   （anon SELECT / authenticated INSERT 都不能替代 anon INSERT WITH CHECK）
    │   └─ 否，需要当前用户或管理员身份 ──→ 使用 @NeedLogin()，不要开放匿名插入
    │
    ├─ 接口返回 401 / 登录跳转不对？
    │   └─ 是 ──→ 第四节 · 401 未授权
    │
    └─ 想读取当前用户 ID / 角色 / 飞书 ID？
        └─ 这属于"用户身份"范畴 ──→ 跳到 `user-identity` skill
```

> **相关技能**：用户身份/ID 转换/userContext 字段参见 `user-identity`；登录/登出/获取用户信息的 Dataloom SDK 操作参见 `client-builtins-user-service`；权限点位鉴权参见 `authz-guide`。

---

## 二、认证装饰器

### 模块注册

`AuthNPaasModule` 已通过 `PlatformModule.forRoot()` 自动注册，**无需手动导入**。模块全局生效，自动注册 `AuthNPaasGuard` 守卫。

### @NeedLogin()

标记接口需要登录。未登录用户访问时，守卫设置 `x-login-url` 响应头并返回 401。

```typescript
import { Controller, Get } from '@nestjs/common';
import { NeedLogin } from '@lark-apaas/fullstack-nestjs-core';

// 控制器级别 — 所有路由都需要登录
@Controller('api/dashboard')
@NeedLogin()
export class DashboardController {
  @Get()
  getDashboard() { return '仪表板'; }
}

// 方法级别 — 仅特定路由需要登录
@Controller('api')
export class ApiController {
  @Get('public-data')
  getPublicData() { return '公开数据'; }

  @Get('private-data')
  @NeedLogin()
  getPrivateData() { return '私密数据'; }
}
```

### ⚠️ @Public() 是 no-op，不要使用

`@lark-apaas/fullstack-nestjs-core` 仍然 export 了 `@Public()`，但 `AuthNPaasGuard` / `AuthZPaasGuard` 都**不读** `IS_PUBLIC_KEY`，整段是历史遗留死代码。Guard 默认 opt-in：**没标 `@NeedLogin()` 的接口直接放行**——这意味着公开接口本身就不需要任何装饰器。如果项目里有现存的 `@Public()` 用法，可以删掉。

### 认证流程

`AuthNPaasGuard` 是 **opt-in 模式**：未标记 `@NeedLogin()` 的接口默认放行，**公开接口无需任何装饰器**。

```text
请求 → Gateway 注入 x-larkgw-suda-webuser 头
     → UserContextMiddleware 解析 → req.userContext { userId, tenantId, appId, loginUrl, ... }
     → AuthNPaasGuard 检查：
         有 @NeedLogin() 且无 userId → 设置 x-login-url + 401
         其他（含未标记的接口）→ 放行
```

> `req.userContext` 的完整字段表（`userId` / `tenantId` / `roles` / `userName` 等）见 `user-identity` skill 第二节。

---

## 三、禁止行为清单

| 禁止行为 | 正确做法 |
|---------|---------|
| 单独注册 `AuthNPaasModule.forRoot()` | 已通过 `PlatformModule.forRoot()` 自动注册，无需手动导入 |
| 手动实例化 `AuthNPaasGuard` | 模块自动注册为全局守卫，无需手动 `@UseGuards()` |
| 用 `@Public()` 标记公开接口 | `@Public()` 是 no-op；公开接口不需要任何装饰器（opt-in 模式默认放行未标 `@NeedLogin()` 的接口） |
| 在未标 `@NeedLogin()` 的接口里依赖 `req.userContext.userId` 做业务判断 | 该接口默认放行未登录请求，`userId` 可能为 `undefined`，必须先判空 |
| 公开接口写 RLS 表但只给 anon SELECT / authenticated INSERT | 允许未登录提交时补 `FOR INSERT TO anon WITH CHECK (true)` 或等价 Drizzle policy，并用未登录 POST 验证；否则加 `@NeedLogin()` |
| 业务层自行返回 401 实现"未登录跳转" | 用 `@NeedLogin()` 让守卫统一处理，确保 `x-login-url` 头被正确写入 |
| 自建认证传输：自签 JWT 走自定义 `Authorization` / `X-Auth-Token` 头、自定义 cookie、query token | 这些头在妙搭网关转发时**不透传**（白名单只放 `x-suda-csrf-token` / `x-larkgw-suda-webuser` + 标准头），后端必拿不到 → 401，且易被误诊为网关故障。任何自有账号体系/自分配账号需求，身份一律取 `req.userContext`（网关注入，解析自 `x-larkgw-suda-webuser`）、用 `@NeedLogin()` 认证 + 业务角色表授权，不要自签 JWT 走自定义传输 |

> ⚠️ **"去飞书化 / 自分配账号"需求专项**：哪怕用户要"完全自己的账号体系"，登录态仍走平台 `x-larkgw-suda-webuser` 身份，自建的只是"业务角色/资料表"。自签 token 走任何自定义传输通道都会被网关白名单拦掉（必踩 401）。

---

## 四、常见问题

### 401 未授权

1. 确认接口是否标记了 `@NeedLogin()`
2. 检查请求是否携带了正确的 Cookie（`credentials: 'include'`）
3. 确认 Gateway 是否正确注入了 `x-larkgw-suda-webuser` 头
4. 确认响应头是否包含 `x-login-url`，前端拦截器需读取此头执行跳转

### 登录跳转 URL 错误

1. 检查 `req.userContext.loginUrl` 是否被中间件正确解析
2. 确认应用部署环境（preview / online）对应的网关配置

### 公开接口被错误地要求登录

1. 检查 Controller 或父级是否打了 `@NeedLogin()`（继承到本方法）；按 opt-in 默认行为，**移除装饰器**接口就会公开
2. **不要**用 `@Public()` 试图取消登录要求——它是 no-op，对 guard 无影响
3. 检查是否有自定义 Guard 比 `AuthNPaasGuard` 更早执行并主动拦了未登录请求
