---
name: devops-guide
description: "Use when user needs build, deploy, run, troubleshoot, or operate a miaoda fullstack app. IMPORTANT: Only activate this skill when the user explicitly asks about deployment, build failures, or service operations. Do NOT proactively trigger this skill during normal code development — reading devops skills to troubleshoot preemptively disrupts the development workflow. Only use when: build fails, deploy fails, service crashes, or user explicitly asks about ops issues. 触发词：devops, 构建, 部署, 运维, 日志, 启动失败, 编译失败, 服务异常, read_logs, pkill, ps, pstree"
steering: true
steering-topic: devops
match-template-name: nestjs-react-fullstack
control-by-feature-ab: true
---

# DevOps Guide

用于处理妙搭全栈应用的构建、部署、运行排障。

核心原则：**先检查，再验证，再看日志，最后才下结论**。

## Quick Reference

| 场景 | 必做动作 | 结果标准 |
|------|----------|----------|
| 修改代码后自检 | 先跑代码检查工具 | 无语法错误、无类型错误、无明显构建错误 |
| 修改服务端代码 | 补跑接口测试 | 每个新增接口都能验证通过 |
| 准备交付前 | 读取最新日志 | 最新改动后无错误日志 |
| 用户反馈编译失败 | 查 lint/typecheck + devServer 日志 | 定位到具体文件、具体报错 |
| 用户反馈服务无响应 | 查日志 + 查进程状态 | 确认是代码报错还是 dev 进程卡死 |

## Step 1：先判断问题类型

### A. 代码改完后的质量保障

按固定顺序执行：

1. 运行代码检查工具，优先发现语法、类型、样式问题。
2. 若改了服务端代码，执行接口测试，覆盖新增接口。
3. 最后读取日志，确认最新改动没有引入错误日志。

### B. 编译失败 / 服务启动失败 / 页面异常

按定位顺序执行：

1. 先查代码检查结果。
2. 再查 devServer 日志。
3. 必要时检查进程状态，判断 dev 进程是否失活。

## Step 2：根据改动范围读取正确日志

| 改动范围 | 必读日志 |
|----------|----------|
| 服务端代码 | `server`、`server-devserver` |
| 客户端代码 | `client-devserver` |
| 编译失败但范围不清楚 | `server-devserver` + `client-devserver` |
| 请求报错 | `server`，必要时补 `trace` |

规则：

- **不要只看一个日志源**。
- **不要基于旧日志下结论**，要读取最新日志。
- 日志为空不代表没问题，先确认对应服务是否真的在运行。

## Step 3：devServer 无响应时的 SOP

若你发现代码已经修改，但 dev 日志长时间不更新，优先怀疑 dev 进程失活。

### 检查顺序

1. 用 `ps` / `pgrep` / `pstree` 确认 `dev:server`、`dev:client` 相关进程是否存在。
2. 若进程存在但日志不更新，先把现象记录为结论，不要直接重启环境。
3. 只有调用方明确要求时，才执行 `pkill -f "dev:server"` 或 `pkill -f "dev:client"`。

### 推荐命令

```bash
ps -ef | grep "dev:server"
ps -ef | grep "dev:client"
pgrep -af "dev:server"
pgrep -af "dev:client"
pstree -p <pid>
pkill -f "dev:server"
pkill -f "dev:client"
```

### 判断标准

- 有进程、日志持续刷新：devServer 正常，继续排查代码问题。
- 有进程、日志不刷新：高概率卡死，先报告现象和证据。
- 没进程：说明服务未拉起，先看最近一次 devServer 错误日志。

## Step 4：构建 / 部署 / 运维排查框架

按照 **现象 → 根因 → 方案** 输出。

### 常见现象映射

| 现象 | 高概率根因 | 优先方案 |
|------|------------|----------|
| 编译失败 | 语法错误、类型错误、依赖误用 | 先跑 lint / typecheck，再看 devServer 日志 |
| 后端启动失败 | Nest 模块注册错误、配置错误、运行时异常 | 查 `server-devserver` 和 `server` |
| 页面白屏 | 前端编译错误、运行时异常、接口异常 | 查 `client-devserver`，必要时补 `browser` |
| 接口 500 | 服务端业务异常 | 查 `server` / `trace`，补接口测试 |
| 热更新失效 | dev 进程卡死 | 查进程状态，不要默认重启 |

## 交付要求

输出排查结果时，必须包含：

1. **现象**：用户看到什么错误。
2. **根因**：定位到哪一层出问题。
3. **证据**：哪条日志、哪段报错、哪个检查结果支撑结论。
4. **方案**：下一步修复动作。

## Common Mistakes

| 错误 | 正确做法 |
|------|----------|
| 改完代码直接说“没问题” | 先跑代码检查，再读日志 |
| 服务端改动后不测接口 | 必须验证新增接口 |
| 只看 `server` 不看 `server-devserver` | 服务端至少看两个日志源 |
| 发现无响应就直接 `pkill` | 先用 `ps` / `pgrep` / `pstree` 定位，再报告结论 |
| `pkill` 后不复读日志 | 只有明确要求重启时才执行，并再次读日志确认 |
| 只给结论不给证据 | 必须给日志或检查结果作为依据 |
