---
name: client-builtins-file-storage-service
description: 前端文件存储服务指南，基于 dataloom.storage 上传、删除、列表查询和获取文件 URL，包含 uploadFile、remove、list、getDefaultBucketId、generateDownloadUrlFromFilePath。Use when 需要：(1) 上传文件/图片/附件到云存储，(2) 删除存储桶文件，(3) 获取文件列表或浏览目录，(4) 前端把文件信息存入数据库：普通 text/varchar/JSON 字段默认保存 download_url；仅明确使用 file_attachment 类型字段时保存 bucket_id + file_path，(5) file_attachment 字段需用 file_path 换展示 URL，或其他前端文件存储开发。
steering: true
steering-topic: client_builtins_file_storage_service
match-template-name: nestjs-react-fullstack
---

# 前端文件开发规范

> **术语**：下文的 `file_attachment`、`text`、`varchar`、`JSON` 指数据库字段的**类型**，不是字段名。

- **默认保存展示 URL**：上传后取 `data.download_url`，存到普通 `text` / `varchar` / `JSON` 业务字段；渲染 / 下载时直接作为 `src` / `href`。
- **后台留路径时仍返回 URL**：后端异步处理可保存 `file_path` 作内部定位；列表 / 详情接口仍必须另返 `download_url` / `downloadURL` 展示 URL，前端只消费该 URL。
- **仅 `file_attachment` 字段从 file_path 换 URL**：业务明确使用 `file_attachment` 类型字段时，该字段存 `bucket_id` + `file_path`（不能存 `download_url`）；前端才用 dataloom SDK 的 `generateDownloadUrlFromFilePath(file_path)`，且 `file_path` 必须来自该字段。
- **禁止手拼运行态前缀**：不要把 `/runtime/api/v1/storage/object`、`/app/{appId}/runtime`、`/spark/app/{appId}/runtime`、`__runtime__` 当作 URL 合同拼接；使用上传返回值、后端返回值或 SDK 方法原始结果。
- 上传后的文件还要给后端 AI capability 解析/理解时，前端展示仍用 `download_url`；提交给后端时优先保留 `file_path`（以及可用的 `bucket_id`）。旧记录只有标准 storage `download_url` 时，后端必须先从中解析 `bucket_id + file_path`，再用 `fileService.from(bucketId).createSignedUrl(filePath, 3600)` 生成临时 http(s) URL；不得把 `download_url` 直接交给默认 bucket 的 `FileService.createSignedUrl()`。前端不要构造 signed URL；普通展示/下载仍默认用 `download_url`。

# dataloom SDK 文件服务

## 概述
项目提供了dataloom SDK的文件服务，用于文件的上传，下载，删除，列出bucket中文件，创建临时签名url等能力。

## 使用注意
- **入口边界**：本 SDK 是**应用前端代码**读写应用存储的唯一入口。Agent 自己在对话 / 开发中上传、灌数据或调试文件，先加载应用文件存储操作 skill（按「应用文件存储 / 文件上传 / 文件下载」召回），用其 CLI 命令操作，具体命令一律以该 skill 为准——二者操作同一个应用存储桶，但**该 CLI 命令只供 Agent 在沙箱终端使用，禁止写进页面代码**，页面里一律用本 SDK。
- @lark-apaas/client-toolkit/dataloom 这个SDK只适用于前端调用，禁止在服务端调用
- **沙箱 dev 限制**：`uploadFile` 打的 `/app/<appId>/__runtime__/api/v1/storage/object/<bucket>/pre_upload` **在沙箱 dev 下恒 404**，只有发布态可用。这是环境限制不是代码缺陷，按本 skill 写法即为正确，不要为它改代码；开发期要验证上传链路改走接口测试直接打后端接口，或复用库里已有的文件 URL。详见 coding-guide「沙箱 dev 不提供平台 runtime 接口」。
- 上传成功后，普通 `text` / `varchar` / `JSON` 业务字段默认保存 `data.download_url`，并把它作为页面展示 / 下载 URL
- **⚠️ 场景区分（重要）**：`dataloom.storage` 仅适用于需要持久化存储文件或获取 `download_url` 保存到数据库的场景。如果文件仅作为插件输入（传给 `capabilityClient`），**必须直接传 File/Blob 对象，禁止先走 dataloom 上传再传 URL**；插件调用（capability）不属于 dataloom，详见 plugin-guide
- **Server 侧 AI capability 边界**：文件已上传并持久化后，若由后端调用 `CapabilityService` 做文档解析/图片理解，不要把前端展示用 `download_url` 当插件入参；把 `file_path` 和 `bucket_id` 传给后端，由后端 `FileService` 签成临时 http(s) URL。
- **download_url 格式说明**：`download_url` 可能是相对路径。**禁止**拼接 `window.location.origin` 或任何运行态前缀；平台会自动解析相对路径，直接使用原始值。
- **文件URL**：调用 `generateDownloadUrlFromFilePath` 时，`file_path` 必须来自数据库 `file_attachment` 类型字段，禁止拼接；普通业务字段已有 `download_url` 时不要调用本方法。

## bucketId
关于bucketId的获取，在代码工程中已经预置了一个获取bucketid的方法，路径为`@lark-apaas/client-toolkit/tools/storage`中，直接具名导入即可使用。
import { getDefaultBucketId } from "@lark-apaas/client-toolkit/tools/storage";
getDefaultBucketId: () => string;

## 统一错误类型
```typescript
// dataloom 服务端报错
interface DataLoomError {
    error_msg: string;
    lang_id: number;
    status_code: string;
};

// sdk 内部校验报错
interface StorageError {
    name: 'StorageError';
    message: string;
};

// 其他未被识别报错, 继承 StorageError
interface StorageUnknownError {
    name: 'StorageUnknownError';
    message: string;
    // 兜底catch到的error
    originalError: unknown;
};

type StorageError = DataLoomError | StorageError ｜ StorageUnknownError;
```

#### 1. 文件上传接口 (uploadFile)

上传文件到指定的存储桶（本地文件或二进制数据），适用于：文档管理、图片上传、附件存储。

##### 文件名处理禁止事项

| 禁止行为 | 正确做法 |
|---------|---------|
| **禁止**在调用 `uploadFile` 前对文件名（`file.name`）做任何字符串替换、净化或重新生成 | 将从文件输入框（`<input type="file">`）或拖拽事件获取的原始 `File` 对象直接传给 `uploadFile` |
| **禁止**创建新的 `File` 对象（如 `new File(...)`）来包裹原始文件 | 同上 |

> 原因：SDK 内部已包含完整、健壮的文件名处理机制（特殊字符、冲突、安全），任何额外处理都是多余的，并且会干扰 SDK 正常工作。

##### 入参说明
| 属性名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|---------|
| `bucketId` | `string` | ✅ | - | 文件上传到tos的bucket id |
| `fileBody` | `FileBody` | ✅ | - | 文件内容，支持多种格式 |

##### 出参说明
| 字段名 | 类型 | 说明 |
|--------|------|---------|
| `data.bucket_id` | `string` | 所属bucket ID |
| `data.file_path` | `string` | 文件路径，不是文件 URL；只写入 `file_attachment` 类型字段，或作为后端内部处理定位字段 |
| `data.download_url` | `string` | 文件 URL（可能是相对路径），普通字段默认保存它，可直接用于下载文件或渲染图片；**禁止**拼接域名前缀，见「使用注意」 |
| `error` | `StorageError \| null` | 错误信息，成功时为null |

##### 使用示例
```typescript
import { getDataloom } from "@lark-apaas/client-toolkit/dataloom";
import { getDefaultBucketId } from "@lark-apaas/client-toolkit/tools/storage";
import { logger } from "@lark-apaas/client-toolkit/logger";
// 1. 获取文件与 dataloom 实例
const file = fileInput.files[0];
const dataloom = await getDataloom();
// 2. 调用上传接口
const { data, error } = await dataloom
  .storage
  .from(getDefaultBucketId())
  .uploadFile(file); // 直接传递原始 file 对象
if (error || !data) {
  throw new Error("文件上传失败: " + (error?.message || "未知错误"));
}
// 3. 提取并使用 `download_url`
logger.info("上传成功，文件下载链接为:", data.download_url);
// 4. 将 `download_url` 保存到数据库
const httpResponse = await imageControllerCreate({
  body: { url: data.download_url } // <-- 关键点：使用 data.download_url
});
if (!httpResponse.data?.success) {
  throw new Error(httpResponse.data?.message || "保存图片信息失败");
}
```

#### 2. 文件删除接口 (remove)

从云存储中永久删除一个或多个文件，适用于：清理过期文件、删除用户数据、批量清理。

##### 入参说明
| 属性名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|---------|
| `bucketId` | `string` | ✅ | - | 要删除文件所在的bucket id |
| `filePaths` | `string[]` | ✅ | - | 要删除的文件路径数组，可以是file_path也可以是download_url |

##### 出参说明
返回 `{ data: FileObject[] | null, error: StorageError | null }`：`data` 为被删除的文件对象数组（字段同 list 出参说明），删除不存在的 filePaths 会返回空数组；`error` 成功时为 null。

##### 使用示例
```typescript
import { getDataloom } from "@lark-apaas/client-toolkit/dataloom";
import { getDefaultBucketId } from "@lark-apaas/client-toolkit/tools/storage";

// 异步获取dataloom实例
const dataloom = await getDataloom();

// 批量删除文件（删除单个文件传长度为 1 的数组即可）
const { data, error } = await dataloom
  .storage
  .from(getDefaultBucketId())
  .remove(['/documents/file1.pdf', '/images/image1.jpg']);
```

#### 3. 文件列表接口 (list)

获取存储桶中的文件列表，适用于：文件管理、目录浏览、文件检索。

##### 入参说明
| 属性名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|---------|
| `bucketId` | `string` | ✅ | - | 文件所在的bucket id |
| `path` | `string` | ❌ | - | 文件夹路径，用于筛选特定目录 |
| `options.limit` | `number` | ❌ | `100` | 返回的文件数量限制 |
| `options.offset` | `number` | ❌ | `0` | 分页起始位置 |
| `options.sortBy.column` | `'name' \| 'created_at' \| 'updated_at'` | ❌ | `'name'` | 排序字段 |
| `options.sortBy.order` | `'asc' \| 'desc'` | ❌ | `'asc'` | 排序方向 |

##### 出参说明
| 字段名 | 类型 | 说明 |
|--------|------|---------|
| `data` | `FileObject[]` | 文件对象数组 |
| `data[].name` | `string` | 文件名称 |
| `data[].bucket_id` | `string` | 所属bucket ID |
| `data[].id` | `string` | 文件唯一标识符，如果id不存在则说明当前为文件夹，需要通过list接口继续获取文件夹下的文件，直到遍历完成才能拿到所有文件 |
| `data[].created_at` | `string` | 文件创建时间 |
| `data[].updated_at` | `string` | 文件更新时间 |
| `data[].created_by` | `string` | 文件创建者 |
| `data[].updated_by` | `string` | 文件更新者 |
| `data[].buckets` | `Bucket` | bucket详细信息 |
| `data[].metadata` | `TosMetaData` | 文件元数据（包含文件大小、类型等） |
| `error` | `StorageError \| null` | 错误信息，成功时为null |

##### 使用示例
```typescript
import { getDataloom } from "@lark-apaas/client-toolkit/dataloom";
import { getDefaultBucketId } from "@lark-apaas/client-toolkit/tools/storage";

// 异步获取dataloom实例
const dataloom = await getDataloom();

// 带分页和排序的查询（path 和 options 均可省略）
const { data, error } = await dataloom
  .storage
  .from(getDefaultBucketId())
  .list('/images', {
    limit: 20,
    offset: 0,
    sortBy: { column: 'created_at', order: 'desc' }
  });
```

#### 4. 根据filePath生成downloadUrl接口 (generateDownloadUrlFromFilePath)

**仅用于 `file_attachment` 类型字段场景**：只有手头是从该字段读出的 `file_path` 时，才用它换可渲染 / 下载 URL。普通 `text` / `varchar` / `JSON` 字段上传文件回显，默认直接用已保存或后端返回的 `download_url` / `downloadURL`，禁止调用本接口。

##### 入参说明

| 属性名 | 类型 | 必填 | 默认值 | 说明 |
|--------|--------|---------|--------|---------|
| `filePath` | `string` | ✅ | - | 文件的 filePath。**只能从数据库 `file_attachment` 类型字段读取，不得从普通业务字段取值或拼接路径** |

##### 出参说明
| 类型 | 说明 |
|------|---------|
| `string` | 文件的url，直接在页面上展示即可 |

##### 使用示例

```typescript
const dataloom = await getDataloom();
const imageUrl = dataloom
  .storage
  .from(getDefaultBucketId())
  .generateDownloadUrlFromFilePath(file.file_path); // file_path 取自数据库 file_attachment 类型字段
// 同步返回 string，直接用于 <img src={imageUrl} /> 渲染或作为下载链接
```

#### 5. 最小化文件上传与展示示例

##### 后端接口假设（`shared/api.interface.ts`）

```typescript
export interface FileRecord { id: string; fileName: string; downloadUrl: string; createdAt: string; }
// POST /api/files  → { success: true, data: FileRecord, message: "ok" }
// GET  /api/files  → { success: true, data: FileRecord[], message: "ok" }
export interface FileApiResp<T = FileRecord> { success: boolean; data: T; message: string; }
```

##### 示例代码

```tsx
import React, { useEffect, useRef, useState } from "react";
import { getDataloom } from "@lark-apaas/client-toolkit/dataloom";
import { getDefaultBucketId } from "@lark-apaas/client-toolkit/tools/storage";
import { axiosForBackend } from "@lark-apaas/client-toolkit/utils/getAxiosForBackend";
import { logger } from "@lark-apaas/client-toolkit/logger";
import { Button } from "@client/src/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@client/src/components/ui/card";
import { toast } from "sonner";
import { Upload, FileIcon, Loader2 } from "lucide-react";
import type { FileRecord, FileApiResp } from "@shared/api.interface";

const FileUploadDemo: React.FC = () => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<FileRecord[]>([]);
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading] = useState(false);

  const fetchFiles = async () => {
    setLoading(true);
    try {
      const res = await axiosForBackend.get<FileApiResp<FileRecord[]>>("/api/files");
      if (res.data?.success) setFiles(res.data.data);
    } catch (err) {
      logger.error(`获取文件列表失败: ${String(err)}`);
      toast.error("获取文件列表失败");
    } finally { setLoading(false); }
  };

  useEffect(() => { fetchFiles(); }, []);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      // 1. dataloom SDK 上传（直接传原始 file，禁止包装或修改文件名）
      const dataloom = await getDataloom();
      const { data, error } = await dataloom.storage.from(getDefaultBucketId()).uploadFile(file);
      if (error || !data) throw new Error("上传失败: " + (error?.message ?? error?.error_msg ?? "未知错误"));

      // 2. 保存 download_url 到后端
      const res = await axiosForBackend.post<FileApiResp>("/api/files", {
        fileName: file.name, downloadUrl: data.download_url,
      });
      if (!res.data?.success) throw new Error(res.data?.message || "保存失败");

      toast.success(`${file.name} 上传成功`);
      fetchFiles();
    } catch (err) {
      logger.error(`上传失败: ${String(err)}`);
      toast.error(String(err));
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><FileIcon className="h-5 w-5" />文件管理</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <input ref={inputRef} type="file" onChange={handleUpload} className="hidden" />
        <Button onClick={() => inputRef.current?.click()} disabled={uploading}>
          {uploading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
          {uploading ? "上传中..." : "选择文件上传"}
        </Button>
        {loading ? (
          <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
        ) : files.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">暂无文件</p>
        ) : (
          <ul className="space-y-2">
            {files.map((f) => (
              <li key={f.id} className="flex items-center justify-between gap-2 rounded-md border p-3">
                <a href={f.downloadUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 min-w-0 truncate text-sm hover:underline">
                  <FileIcon className="h-4 w-4 shrink-0 text-muted-foreground" />{f.fileName}
                </a>
                <span className="text-xs text-muted-foreground shrink-0">{new Date(f.createdAt).toLocaleDateString()}</span>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
};
export default FileUploadDemo;
```

##### 关键点

| 要点 | 说明 |
|------|------|
| 上传流程 | 展示/下载：`uploadFile(file)` → 取 `data.download_url` → POST 后端保存为展示 URL；后端 AI 解析：同时保存/提交 `data.file_path` 与 `data.bucket_id` 供后端签名 |
| 文件对象 | 直接传原始 `File`，**禁止**包装或修改文件名 |
| 组件依赖 | shadcn/ui `Button`/`Card` + `lucide-react` + `sonner` |
| 请求实例 | 必须用 `axiosForBackend`，禁止 `fetch` |
