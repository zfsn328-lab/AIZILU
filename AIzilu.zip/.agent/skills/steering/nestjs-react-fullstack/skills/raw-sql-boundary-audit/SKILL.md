---
name: raw-sql-boundary-audit
description: >-
  Use when editing or reviewing NestJS backend database code that contains Drizzle raw `sql` tagged templates,
  db.execute(sql`...`), report/statistics/aggregation endpoints, filter (...), CASE WHEN, window functions,
  or custom type / Date range parameters.
steering: true
steering-inclusion: always
steering-topic: raw_sql_boundary_audit
match-template-name: nestjs-react-fullstack
unavailable-agents:
  - AppInit
  - SpecDoc
---

# Drizzle raw SQL 参数边界审计

本 skill 只管一件事：改 NestJS 后端数据库代码时，raw `sql` 模板里的 `${...}` 参数必须是数据库 driver 可直接接收的标量。Drizzle helper 绑定 schema 列会按列 encoder 处理；raw `sql` 模板参数不会自动调用列的 `toDriver`。

## 何时必须执行审计

满足任一条件就执行：

- 正在修改 `server/**/*.service.ts` 或 repository 中的数据库查询；
- 文件里有 `sql\``、`db.execute(sql`、`filter (...)`、`CASE WHEN`、窗口函数或复杂 where；
- 需求涉及统计、报表、趋势、排行、周期范围、截止时间、创建/完成时间等后端汇总接口。

## 审计步骤（写代码前和提交前各做一次）

1. 先读 `server/database/schema.ts`，确认相关列类型和 custom type。
2. 枚举当前 service/repository 里的 raw SQL 模板；不要只看刚新增的查询。可用搜索辅助，但结论以读代码为准：

   ```bash
   rg -n 'sql`|db\.execute\(sql|filter \(|CASE WHEN|OVER \(' server
   ```

3. 对每个 raw SQL 模板逐个检查 `${...}` 参数：
   - 已是 string/number/boolean、ISO string、普通 ID、`sql.join(...)` 中逐个参数化的标量：可以保留；
   - `user_profile` 是特殊 custom type，不适用“普通 ID 标量即可”的泛化判断；raw SQL 遇到 `user_profile` 列必须按 coding-guide 的三侧写法处理：读 `(col).user_id`，写 `ROW(${userId})::user_profile`，过滤 `(col).user_id = ${userId}`；禁止裸列 SELECT、`col = ${userId}`、`col::text = ${userId}` 或 `col = ROW(...)::user_profile` 比较；
   - 是 `Date`、date/timestamptz/custom type 的运行时对象，或变量来源不明但表示时间/自定义结构：先转 driver-safe 标量再传入 raw SQL；日期时间用 `.toISOString()`；
   - 如果能用 `gte(col, Date)` / `lt(col, Date)` / `eq(col, value)` / `insert().values()` / `update().set()` 等绑定 schema 列的 helper 表达，就优先改回 helper。
4. 保留 helper 安全路径：不要把 `gte(col, Date)`、`lt(col, Date)` 这类绑定列的 Drizzle helper 当成坏边界。
5. 改完后调用受影响的真实 API，至少覆盖一个会触发该 raw SQL 的范围/筛选参数；HTTP 200 且后端无参数序列化错误才算完成。

## 写法示例

```typescript
const rangeStart: Date = getRangeStart(range);
const rangeStartIso: string = rangeStart.toISOString();

// helper 绑定 schema 列，可以直接传 Date
where: gte(tasks.createdAt, rangeStart)

// raw SQL 参数先转 driver-safe 标量
total: sql<number>`
  count(*) filter (where ${tasks.createdAt} >= ${rangeStartIso})
`

// 不要把 Date/custom type 运行时对象直接放进 raw SQL 模板参数
total: sql<number>`
  count(*) filter (where ${tasks.createdAt} >= ${rangeStart})
`
```
