---
name: miaoda-file
description: "Use when Agent 需要在对话 / 开发中对应用存储里的文件做一次性操作：上传、下载、列出、删除、清理、查看元数据，或获取下载 / 临时分享链接（如分析数据后上传产物、传素材、灌测试数据、验证上传、清理）。NOT for 应用运行时代码里的文件能力——前端用 client-builtins-file-storage-service、后端用 server-builtins-file-storage-service。触发词：文件上传, 文件下载, 文件列表, 文件删除, 文件清理, 文件查看, 文件元数据, 下载链接, 临时分享链接, miaoda file, 应用存储"
control-by-feature-ab: true
---

# miaoda-file

使用 `miaoda file` 处理应用存储里的文件型一次性操作，如上传、下载、查看元数据或生成临时分享链接。

## 角色边界：同一存储，两套入口

`miaoda file` CLI 和应用运行时的文件 SDK（前端 `dataloom` / 后端 `FileService`）**读写的是同一个应用存储桶**——正因为是同一个桶，最容易误用。区别只在"谁在调用、在哪调用"：

| 谁 / 何时 | 用什么 | 典型场景 |
|---|---|---|
| **Agent 在对话 / 开发中自己处理文件** | `miaoda file` CLI（本 skill） | 分析数据后上传产物、上传图片 / 素材、灌测试数据、验证上传、清理文件 |
| **应用运行时代码（前端 / 后端）** | SDK：`client-builtins-file-storage-service`（前端）、`server-builtins-file-storage-service`（后端） | 页面里的上传 / 下载 / 取链接、controller / service 里的文件处理 |

> **禁止在应用代码（前端 / 后端）里调用 `miaoda file` CLI。** CLI 只在 Agent 对话终端里执行；应用代码一律走 SDK。因为二者是同一个桶，Agent 用 CLI 上传的文件、app 代码用 SDK 就能读到，反之亦然——不要为了"让 app 拿到文件"而把 CLI 写进代码。

## 何时使用

### 匹配场景

- 用户要对应用存储里的文件做一次性操作：列出、查找、上传、下载、删除、查看元数据
- 用户要拿文件链接：应用内可用的下载地址，或对外分享、可过期的临时下载链接
- 用户要在 CI、脚本、一次性运维里处理测试文件、初始化测试数据或清理文件

### 不匹配场景

- 目标是实现应用代码（前端 / 后端）里的文件能力：见上文「角色边界」，一律用 SDK，不用本 CLI
- 输入来自当前会话附件，且还没确认真实本地路径：先用 `attachment`
- 目标是浏览器里的在线预览体验：用 `file-preview`
- 用户要操作工作区或代码仓库里的本地文件（如源代码、构建产物、`.env`），不是应用存储里的文件

## 按目标选择工具

| 目标 | 用什么 | 原因 |
|---|---|---|
| 当前会话附件继续上传到应用存储 | 先用 `attachment` 找真实本地路径，再 `miaoda file cp` | `miaoda file` 处理的是本地路径或应用存储路径，不直接处理附件引用 |
| 做 PDF / Word / Excel / PPT 在线预览 | `file-preview` | 目标是预览体验，不是文件运维 |

> 应用代码里的文件上传 / 下载 / 取链接不在此表——见上文「角色边界」，一律走 SDK。

## 关键概念

### 文档中的路径写法

- 本文把应用存储里的对象统一写成以 `/` 开头的存储路径，例如 `/images/brand/1858537546760216.png`
- 本地文件统一写成 `./logo.png`、`~/Desktop/` 这类宿主机路径
- 如果命令行为与本文示例不一致，以 `miaoda file --help` 或 `miaoda file <subcommand> --help` 为准

### 应用存储路径 `path` vs 文件名 `file_name`

`stat`、`sign`、`rm` 的 `<file>` 支持两种标识：

| 标识 | 格式 | 唯一性 | 适用 |
|---|---|---|---|
| `path` | `/images/brand/1858537546760216.png` | 全局唯一 | 推荐，最稳 |
| `file_name` | `logo.png` | 同应用下可重复 | 仅在确定不重名时使用 |

规则：

- 优先用 `path`
- `file_name` 重名时会报 `AMBIGUOUS_FILE_NAME`
- 下载场景 `miaoda file cp <src> <dst>` 的 `<src>` 只能是远程 `path`；裸文件名会被识别成本地路径
- `ls --path` 是精确匹配，不是目录前缀匹配

### 应用内下载地址 `download_url` vs 临时分享链接 `signed_url`

| 类型 | 公网可直接访问 | 有效期 | 适用场景 | 推荐获取方式 |
|---|---|---|---|---|
| `download_url` | 否 | 不过期 | 应用内使用文件、写入业务字段、前端或后端后续消费 | 刚上传完就读 `cp --json`；文件已在应用存储里就用 `stat --json` |
| `signed_url` | 是 | 会过期，默认 `1d`，最长 `30d` | 对外分享、浏览器直接打开、需要过期时间 | `miaoda file sign <file> --json` |

规则：

- 不要依赖 `ls` 的输出获取 `download_url`
- 只是应用内使用文件时，不要无故生成 `signed_url`
- 后续要稳定引用具体文件时，优先保留 `path`

## 命令速查

这里只列高频、默认安全路径；完整参数以 `--help` 为准。

| 场景 | 命令 |
|---|---|
| 先看总帮助 | `miaoda file --help` |
| 某个子命令用法不确定 | `miaoda file <subcommand> --help` |
| 列出全部文件 | `miaoda file ls --all --json` |
| 按文件名精确查找 | `miaoda file ls --name logo.png --json` |
| 按 path / 文件名 / MIME / 大小 / 上传时间过滤 | `miaoda file ls --path/--name/--type/--size-gt/--uploaded-since ... --json` |
| 查看单文件元数据 | `miaoda file stat <file> --json` |
| 上传本地文件到应用存储 | `miaoda file cp ./local.png /remote/dir/ --json` |
| 下载远程文件到本地 | `miaoda file cp /remote/path.png ./` |
| 删除前确认单文件范围 | `miaoda file stat <file> --json` |
| 删除前确认批量范围 | `miaoda file ls ... --all --json` |
| 执行删除（已确认影响范围后） | `miaoda file rm <file1> <file2> --yes --json` |
| 生成临时分享链接 | `miaoda file sign <file> --expires 7d --json` |

## 多步工作流

### 1. 当前会话附件上传到应用存储

- 先用 `attachment` 确认当前会话附件的真实本地路径
- 再把该本地路径作为 `cp` 的源路径上传到应用存储根目录

```bash
miaoda file cp /path/to/logo.png / --json
```

### 2. 上传后立即拿 `download_url`

```bash
miaoda file cp ./logo.png / --json
```

- 典型返回：

```json
{"data":{"path":"/logo.png","download_url":"/spark/app/.../logo.png"}}
```

- 从返回结果里的 `.data.download_url` 读取应用内下载地址
- 需要把文件链接写入业务字段、后续代码或测试数据时，优先直接用这次上传响应，不要再额外跑一次 `ls`

### 3. 已知 `file_name`，先查 `path` 再下载

```bash
# 先查 path
miaoda file ls --name logo.png --json
# 再下载
miaoda file cp /images/brand/1858537546760216.png ./
```

### 4. 批量清理文件

```bash
# 先报数
miaoda file ls --uploaded-until 2026-03-01 --all --json | jq '.data | length'

# 再看样本
miaoda file ls --uploaded-until 2026-03-01 --all --json \
  | jq '.data[] | {path, size_bytes, uploaded_at}'

```

可替换的范围过滤器：

- `--type image/png`
- `--size-gt 50MB`
- `--uploaded-since 2026-04-01`
- `--uploaded-until 2026-03-01`

- 先把命中总数、样本文件、过滤条件展示给用户，并明确说明这是不可逆删除
- 在拿到明确授权前，不要继续执行 `rm`

获得明确授权后，再拆批删除：

```bash
miaoda file ls --uploaded-until 2026-03-01 --all --json \
  | jq -r '.data[].path' \
  | xargs -n 100 miaoda file rm --yes
```

用法不确定或命令报错时，先看 `miaoda file --help` 或对应子命令的 `--help`。

## 安全规则

### 删除前必须确认影响范围

`rm` 是不可逆操作。对来源不明或可能是生产数据的文件，先展示影响范围，再删除。

建议流程：

1. 先用 `ls` 或 `stat` 拿到待删清单、总数、总大小
2. 向用户展示影响范围，并暂停等待明确授权；没有授权前不要继续执行 `rm`
3. 如果当前 agent 提供 `ask_user_question` 一类确认工具，优先用工具；没有时直接在对话中确认
4. 授权后再带 `--yes` 执行删除

### 批量删除要先报数

`--type`、`--size-gt`、`--uploaded-since` 一类范围过滤器容易扩大命中范围。删除前至少先跑一次：

```bash
miaoda file ls ... --json | jq '.data | length'
```

报数为 `0` 时不要继续跑 `xargs`。

### `rm` 是 best-effort

- 每项独立处理，部分失败不影响其他项
- 所有项成功退出码为 `0`
- 任一项失败退出码为 `1`
- `--json` 返回数组时，每项会带 `status: "ok" | "error"`

最小 JSON 参考：

```json
{
  "data": [
    {
      "status": "ok",
      "path": "/images/brand/1858537546760216.png"
    },
    {
      "status": "error",
      "error": {
        "code": "FILE_NOT_FOUND",
        "message": "..."
      }
    }
  ]
}
```

## 关键限制

- 单文件上传上限：`100 MB`
- 单次 `rm` 批量上限：`100` 个文件
- `file sign --expires` 上限：`30d`
- `rm` 在 non-TTY 场景必须显式带 `--yes`

## 典型错误码

| 错误码 | 含义 |
|---|---|
| `FILE_NOT_FOUND` | `path` 或 `file_name` 不存在 |
| `AMBIGUOUS_FILE_NAME` | `file_name` 匹配到多个文件，改用 `path` |
| `FILE_SIZE_EXCEEDED` | 上传超过 100 MB |
| `FILE_SRC_NOT_FOUND` | 上传源本地文件不存在 |
| `FILE_SIGN_DURATION_EXCEEDED` | `sign --expires` 超过 30d |
| `FILE_BATCH_TOO_MANY` | 单次 `rm` 超过 100 个文件 |
| `FILE_UPLOAD_FAILED` / `FILE_DOWNLOAD_FAILED` | 网络或服务端故障，可重试 |
| `FILE_UPLOAD_CALLBACK_INCOMPLETE` | PUT 成功但 callback 未回传 path，按 hint 用 `file ls --name` 回查 |
