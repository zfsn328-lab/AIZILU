# Security Review Examples

> Extracted from stability-check-examples.md. Covers S4 and A2 rules.

---

## S4 · Input Validation & Injection

**BAD — req.body passthrough**:
```typescript
// User can pass isAdmin: true
app.post('/register', async (req, res) => {
  const user = await User.create(req.body);
  res.json(user);
});
```

**GOOD — Schema validation**:
```typescript
import { z } from 'zod';
const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  name: z.string().max(100),
});
app.post('/register', async (req, res) => {
  const data = registerSchema.parse(req.body);
  const user = await User.create(data);
  res.json(user);
});
```

---

## A2 · Security Architecture

**BAD — Hardcoded key + CORS wide open + MD5**:
```typescript
const stripe = new Stripe('sk_live_abc123xyz789');
app.use(cors({ origin: '*' }));
function hashPassword(p: string) { return crypto.createHash('md5').update(p).digest('hex'); }
```

**GOOD — Env vars + CORS whitelist + bcrypt**:
```typescript
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);
app.use(cors({ origin: ['https://myapp.com'], credentials: true }));
import bcrypt from 'bcrypt';
async function hashPassword(p: string) { return bcrypt.hash(p, 12); }
```
