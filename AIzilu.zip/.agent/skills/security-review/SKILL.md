---
name: security-review
description: "Security audit checklist for the Reviewer agent. Covers input validation, injection, secrets, auth/authz, CSRF, security architecture. 触发词：安全审查, security review, 安全漏洞"
hook: SessionStart
available-agents:
  - Reviewer
---

# Security Review Checklist

## S4 · Input Validation & Injection

**Core issue**: SQL concatenation injection, unvalidated req.body passthrough, path traversal, missing pagination.

```typescript
// BAD: SQL injection
db.query(`SELECT * FROM users WHERE name = '${req.query.name}'`);
// GOOD: parameterized query
db.query('SELECT * FROM users WHERE name = $1', [req.query.name]);
```

**Checklist**:
- No SQL string concatenation — must use parameterized queries
- req.body / req.query / req.params must be schema-validated before use
- File path operations must prevent path traversal
- **List queries must have pagination params that are enforced** (no pagination = CRITICAL)
- File uploads must validate size
- User input must not be embedded directly in HTML (XSS)
- **LIKE/ILIKE queries: user input must escape `%`, `_`, `\` wildcards before use in LIKE patterns** — e.g. `%${keyword}%` allows user to input `%` to match all rows

| Scenario | Severity |
|----------|----------|
| SQL injection / path traversal | CRITICAL |
| No pagination / file upload size unchecked | CRITICAL |
| XSS | HIGH |
| req.body unvalidated | MEDIUM |

## A2 · Security Architecture

**Checklist**:
- Keys/passwords/tokens must not be hardcoded in source
- CORS must not be set to `*`
- Password hashing must not use MD5/SHA1
- Authenticated routes must also have authorization checks
- Error responses must not expose stack traces, internal paths, or implementation details in production
- **RLS/pgPolicy: check for empty array conditions (e.g. `ANY(ARRAY[]::text[])` is always false — policy is dead code)**
- **Test/debug endpoints (e.g. `/test/`, `/debug/`) must not be exposed without authentication in production**
- **URL path parameters (`:id`) must be validated for expected format (UUID, numeric) — not just body params**
- **Hardcoded employee names, user IDs, or other PII must not appear in source code**
- **RLS/pgPolicy permissive-all (`USING(true)` or no row-level filter) → app layer becomes the only authorization point**: decidable as CRITICAL from the server scope alone (no client-fallback join needed; severity aligned with correctness-review). Check every pgPolicy's `USING`/`WITH CHECK` for degeneration to always-true — including a policy that omits `USING` entirely (defaults to allowing all rows).
- **ProtectedRoute's "no permission" branch only does `<Navigate to={fallback} replace />` with no permission-denied fallback component → empty permission set silently redirects / blanks**: decidable as CRITICAL from `client/app.tsx` scope alone (severity aligned with correctness-review); criterion = guard contains `hasPermission ? children : <Navigate/>` and the app has no 403 / no-permission UI, **independent of service-layer empty-set behavior**.

| Scenario | Severity |
|----------|----------|
| Hardcoded secrets / MD5 passwords | CRITICAL |
| RLS policy with dead conditions (always-false) | CRITICAL |
| RLS/pgPolicy permissive-all (`USING(true)`/no row-level filter), app layer is the only authorization point | CRITICAL |
| CORS wide open / auth without authz | HIGH |
| ProtectedRoute no-permission branch only silently redirects, no 403 / no-permission page | CRITICAL |
| Stack traces / internal paths leaked in error responses | HIGH |
| Test/debug endpoints exposed without auth | HIGH |
| URL path params unvalidated | HIGH |
| Hardcoded PII in source code | HIGH |
