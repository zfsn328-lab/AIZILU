---
name: lark-apps
description: "在妙搭沙箱里用 lark-cli 操作【当前这个已存在的】妙搭应用：开放 API Key。当用户要在沙箱里对当前应用做这些操作时使用（可用能力以本次打包的模块为准）。"
metadata:
  requires:
    bins: ["lark-cli"]
  cliHelp: "lark-cli apps --help; lark-cli apps +<cmd> --help"
control-by-feature-ab: true
---

# 妙搭应用 (apps) · 沙箱版

在妙搭沙箱里通过 `lark-cli` 操作**当前这个已存在的**妙搭应用。

## 沙箱约定（先读）

- **命令名**：一律 `lark-cli apps +<cmd>`；命令/flag 细节以 `--help` 为准。
- **应用已存在、app_id 走环境变量**：应用 id 在环境变量 `app_id` 里，命令需要 `--app-id` 时用 `--app-id "$app_id"`。
- **鉴权自动**：apps 域请求由运行环境自动打到 innerAPI 并注入鉴权头。**不要** `auth login` / `config init` / `--as`。

## 意图路由

| 用户意图 | 命令 | 详情 |
|---|---|---|
| 管理开放 API Key（列/查/建/改/启停/删/轮换） | `+openapi-key-list` / `+openapi-key-get` / `+openapi-key-create` / `+openapi-key-update` / `+openapi-key-enable` / `+openapi-key-disable` / `+openapi-key-delete` / `+openapi-key-reset` | [openapi-key](references/openapi-key.md) ⚠️ create/reset 密钥一次性可见；delete/reset 高风险 |


## 失败处理
命令失败时把 `error.hint` 转述给用户，别原样甩 envelope JSON。

## 高风险写操作审批（exit 10）
`risk: high-risk-write` 的命令不带 `--yes` 会 **exit 10** 并返回 `confirmation_required`。处理：
1. 识别 exit code=10 且 `error.type=="confirmation_required"`；
2. 把 `error.risk.action` + 关键参数给用户，明确"高风险"，等显式同意；
3. 同意 → 原始 argv 末尾加 `--yes` 重试；拒绝 → 终止；
4. 想先看请求 → `--dry-run`（不触发门禁、不需 `--yes`）。
**绝不**看到 exit 10 就默认补 `--yes` 静默重试。
