# Business Analyzer — 业务特性分析参考

> 本文件由主 Skill Stage 1 引用。定义了业务类型识别规则和业务特性检查点映射。

---

## 业务类型识别规则

### 1. 依赖特征映射

通过 package.json 中的依赖组合来推断业务类型。不要只看单个依赖，要看组合：

| 依赖组合 | 推断业务类型 | 置信度 |
|----------|-------------|--------|
| stripe/paypal + cart/order 路由 | 电商系统 | 高 |
| stripe/paypal（无 cart 路由） | 支付/订阅系统 | 中 |
| socket.io/ws + message/chat 路由 | 即时通讯 | 高 |
| next + prisma + 大量 CRUD 路由 | CMS / 内容管理 | 中 |
| bull/bullmq + 任务相关模型 | 任务队列系统 | 中 |
| multer/sharp + upload 路由 | 文件/媒体管理 | 中 |
| cron/node-cron + 无前端路由 | 后台定时任务 | 中 |

如果依赖组合无法明确判定，结合路由端点和数据模型综合判断。

### 2. 路由模式识别

```bash
# 执行这些命令来识别路由模式
grep -rn "\.get\|\.post\|\.put\|\.delete\|router\." --include="*.ts" --include="*.js" <repoPath>/src/ | head -150
```

关键路由关键词与业务类型映射：

| 路由关键词 | 业务类型 |
|-----------|---------|
| `/product` `/cart` `/order` `/inventory` `/catalog` | 电商 |
| `/lottery` `/draw` `/prize` `/raffle` `/spin` | 抽奖/活动 |
| `/pay` `/checkout` `/subscription` `/invoice` `/billing` | 支付 |
| `/chat` `/message` `/conversation` `/room` `/channel` | 即时通讯 |
| `/post` `/article` `/page` `/content` `/blog` | CMS/内容管理 |
| `/task` `/job` `/queue` `/worker` | 任务系统 |
| `/upload` `/media` `/file` `/image` `/asset` | 文件管理 |
| `/admin` `/dashboard` `/analytics` `/report` | 后台管理 |
| `/auth` `/login` `/register` `/user` `/profile` | 用户系统（通常是子模块） |

### 3. 数据模型辅助判定

模型名称是强信号：

| 模型名称 | 指向 |
|---------|------|
| Product, Category, Cart, CartItem, Order, OrderItem | 电商 |
| Prize, LotteryRecord, DrawResult, Winner | 抽奖 |
| Payment, Transaction, Subscription, Invoice | 支付 |
| Message, Conversation, ChatRoom, Participant | 即时通讯 |
| Post, Article, Page, Comment, Tag | CMS |

---

## 业务特性检查点清单

识别出业务类型后，根据以下映射生成检查点。每个检查点有唯一 ID、名称、描述、严重等级和具体检查方法。

### 电商系统检查点

| ID | 检查点 | 严重等级 | 检查方法 |
|----|--------|---------|---------|
| BIZ-EC-001 | 超卖防护 | CRITICAL | 查找库存扣减逻辑，确认是否使用原子操作（如 `UPDATE ... SET stock = stock - 1 WHERE stock > 0`）或 ORM 的 `increment/decrement`。如果是先 `findOne` 再 `save`，且无 `version` 字段或 `FOR UPDATE` 锁，则判定为风险 |
| BIZ-EC-002 | 订单状态机完整性 | HIGH | 检查订单是否有明确的状态流转（pending→paid→shipped→completed），是否有非法状态跳转的防护 |
| BIZ-EC-003 | 价格篡改防护 | CRITICAL | 检查下单时价格是否从服务端重新查询，而非信任前端传入的价格 |
| BIZ-EC-004 | 库存回滚 | HIGH | 支付失败或订单取消时，库存是否有回滚机制 |

### 支付系统检查点

| ID | 检查点 | 严重等级 | 检查方法 |
|----|--------|---------|---------|
| BIZ-PAY-001 | 支付幂等性 | CRITICAL | 在支付创建的 handler 中查找 idempotencyKey / requestId / 幂等标识。Stripe 调用检查是否传了 `idempotencyKey` 参数 |
| BIZ-PAY-002 | 金额精度 | HIGH | 检查金额计算是否使用整数（分为单位）或 Decimal 库，而非浮点数运算 |
| BIZ-PAY-003 | Webhook 签名验证 | CRITICAL | 支付回调（如 Stripe webhook）是否验证签名（`stripe.webhooks.constructEvent`），防止伪造回调 |
| BIZ-PAY-004 | 敏感信息脱敏 | HIGH | 支付相关日志中是否泄露完整卡号、CVV 等信息 |

### 抽奖/活动系统检查点

| ID | 检查点 | 严重等级 | 检查方法 |
|----|--------|---------|---------|
| BIZ-LT-001 | 随机算法安全性 | CRITICAL | 查找抽奖核心逻辑中的随机函数。如果使用 `Math.random()`，判定为 CRITICAL（应使用 `crypto.randomInt()` 或 `crypto.randomBytes()`） |
| BIZ-LT-002 | 抽奖频率限制 | HIGH | 检查抽奖接口是否有频率限制（rate limiter），防止脚本刷奖 |
| BIZ-LT-003 | 概率配置可审计 | HIGH | 奖品概率是否有配置化管理和修改日志，而非硬编码 |
| BIZ-LT-004 | 奖品库存原子扣减 | CRITICAL | 奖品发放是否有库存扣减的原子保障（与超卖防护同理） |
| BIZ-LT-005 | 抽奖审计日志 | HIGH | 每次抽奖结果是否记录包含 userId、timestamp、奖品、随机种子的审计日志 |

### 即时通讯系统检查点

| ID | 检查点 | 严重等级 | 检查方法 |
|----|--------|---------|---------|
| BIZ-IM-001 | WebSocket 连接数限制 | HIGH | 检查是否限制单用户最大连接数，防止资源耗尽 |
| BIZ-IM-002 | 心跳与死连接清理 | HIGH | 是否有 ping/pong 心跳机制，是否定时清理未响应连接 |
| BIZ-IM-003 | 消息大小限制 | MEDIUM | 是否限制单条消息体积（`maxPayload`），防止大消息攻击 |
| BIZ-IM-004 | 消息持久化 | MEDIUM | 离线消息是否有持久化和补推机制 |

### 高流量场景检查点（适用于所有高并发业务）

| ID | 检查点 | 严重等级 | 检查方法 |
|----|--------|---------|---------|
| BIZ-HT-001 | 连接池配置 | CRITICAL | 数据库连接池是否有显式配置（非默认值）。对于 Prisma 检查 `connection_limit`，对于原生驱动检查 `max` 参数 |
| BIZ-HT-002 | API 限流 | HIGH | 是否有全局或关键路由级别的 rate limiter（express-rate-limit / 自定义中间件） |
| BIZ-HT-003 | 缓存 TTL | HIGH | Redis/缓存的 SET 操作是否都设置了过期时间，避免缓存永不失效 |
| BIZ-HT-004 | 缓存穿透防护 | MEDIUM | 不存在的 key 是否有空值缓存或布隆过滤器防护 |

### 高并发读写检查点

| ID | 检查点 | 严重等级 | 检查方法 |
|----|--------|---------|---------|
| BIZ-CR-001 | 乐观锁/悲观锁 | CRITICAL | 涉及读-修改-写模式的操作（如余额变更、库存扣减）是否有版本号或行锁保护。查找 `findOne` 后紧跟 `save/update` 且无 `version`/`@Version`/`FOR UPDATE` 的模式 |
| BIZ-CR-002 | 原子操作 | CRITICAL | 数值增减（如 `count += 1` 后 `save()`）是否使用 DB 原子操作（`increment`/`decrement`/`UPDATE SET x = x + 1`） |
| BIZ-CR-003 | 分布式锁 | HIGH | 跨进程的关键操作是否有分布式锁（如 Redis `SETNX`） |

---

## 扩展口设计

业务检查点是可扩展的。将来新增业务类型时，按以下格式追加到上面的清单中：

```markdown
### [新业务类型] 检查点

| ID | 检查点 | 严重等级 | 检查方法 |
|----|--------|---------|---------|
| BIZ-XX-001 | [检查点名称] | [CRITICAL/HIGH/MEDIUM/LOW] | [具体检查方法描述] |
```

ID 命名规则：`BIZ-{业务缩写}-{三位序号}`

预留的业务类型（暂未定义检查点，待后续补充）：
- 金融合规（BIZ-FIN-*）
- GDPR 数据合规（BIZ-GDPR-*）
- 多租户隔离（BIZ-MT-*）
- 搜索引擎（BIZ-SE-*）
- IoT 数据采集（BIZ-IOT-*）
